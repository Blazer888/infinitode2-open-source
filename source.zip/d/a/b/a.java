package d.a.b;

public interface a {
}
