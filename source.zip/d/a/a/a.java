package d.a.a;

public interface a {
   Object a();
}
