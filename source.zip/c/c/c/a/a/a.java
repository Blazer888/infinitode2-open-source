package c.c.c.a.a;

import java.util.concurrent.Future;

public interface a extends Future {
}
