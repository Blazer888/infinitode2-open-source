package c.c.a;

public enum a {
   b("Invalid Ad request."),
   c("Ad request successful, but no ad returned due to lack of ad inventory."),
   d("A network error occurred."),
   e("There was an internal error.");

   public final String a;

   public a(String var3) {
      this.a = var3;
   }

   public final String toString() {
      return this.a;
   }
}
