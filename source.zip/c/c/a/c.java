package c.c.a;

import c.c.b.a.a.e;

@Deprecated
public final class c {
   public static final c b = new c(-1, -2);
   public static final c c = new c(320, 50);
   public static final c d = new c(300, 250);
   public static final c e = new c(468, 60);
   public static final c f = new c(728, 90);
   public static final c g = new c(160, 600);
   public final e a;

   public c(int var1, int var2) {
      e var3 = new e(var1, var2);
      super();
      this.a = var3;
   }

   public c(e var1) {
      this.a = var1;
   }

   public final boolean equals(Object var1) {
      if (!(var1 instanceof c)) {
         return false;
      } else {
         c var2 = (c)var1;
         return this.a.equals(var2.a);
      }
   }

   public final int hashCode() {
      return this.a.hashCode();
   }

   public final String toString() {
      return this.a.c;
   }
}
