package c.c.a;

public enum b {
   a,
   b,
   c;
}
