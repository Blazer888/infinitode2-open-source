package c.c.a.d.g;

@Deprecated
public interface b extends d {
}
