package c.c.a.d.g;

public final class e extends c.c.a.d.e {
   @c.c.a.d.e.b(
      name = "label",
      required = true
   )
   public String a;
   @c.c.a.d.e.b(
      name = "class_name",
      required = true
   )
   public String b;
   @c.c.a.d.e.b(
      name = "parameter",
      required = false
   )
   public String c = null;
}
