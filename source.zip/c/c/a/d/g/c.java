package c.c.a.d.g;

@Deprecated
public interface c extends d {
}
