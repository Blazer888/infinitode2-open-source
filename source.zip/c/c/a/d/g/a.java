package c.c.a.d.g;

@Deprecated
public interface a {
   void destroy();
}
