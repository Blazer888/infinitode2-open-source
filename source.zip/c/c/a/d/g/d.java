package c.c.a.d.g;

@Deprecated
public interface d {
}
