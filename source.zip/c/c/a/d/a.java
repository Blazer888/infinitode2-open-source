package c.c.a.d;

import android.location.Location;
import java.util.Date;
import java.util.Set;

@Deprecated
public class a {
   public a(Date var1, c.c.a.b var2, Set var3, boolean var4, Location var5) {
   }
}
