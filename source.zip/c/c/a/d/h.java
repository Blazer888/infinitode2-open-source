package c.c.a.d;

import c.c.b.a.i.a.m5;
import com.google.ads.mediation.AbstractAdViewAdapter;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdAdapter;

public final class h implements c.c.b.a.a.q.c {
   // $FF: synthetic field
   public final AbstractAdViewAdapter a;

   public h(AbstractAdViewAdapter var1) {
      this.a = var1;
   }

   public final void onRewarded(c.c.b.a.a.q.a var1) {
      c.c.b.a.a.q.d.a var2 = AbstractAdViewAdapter.zza(this.a);
      AbstractAdViewAdapter var3 = this.a;
      ((m5)var2).a(var3, var1);
   }

   public final void onRewardedVideoAdClosed() {
      c.c.b.a.a.q.d.a var1 = AbstractAdViewAdapter.zza(this.a);
      AbstractAdViewAdapter var2 = this.a;
      ((m5)var1).a((MediationRewardedVideoAdAdapter)var2);
      AbstractAdViewAdapter.zza((AbstractAdViewAdapter)this.a, (c.c.b.a.a.i)null);
   }

   public final void onRewardedVideoAdFailedToLoad(int var1) {
      c.c.b.a.a.q.d.a var2 = AbstractAdViewAdapter.zza(this.a);
      AbstractAdViewAdapter var3 = this.a;
      ((m5)var2).a(var3, var1);
   }

   public final void onRewardedVideoAdLeftApplication() {
      c.c.b.a.a.q.d.a var1 = AbstractAdViewAdapter.zza(this.a);
      AbstractAdViewAdapter var2 = this.a;
      ((m5)var1).b(var2);
   }

   public final void onRewardedVideoAdLoaded() {
      c.c.b.a.a.q.d.a var1 = AbstractAdViewAdapter.zza(this.a);
      AbstractAdViewAdapter var2 = this.a;
      ((m5)var1).c(var2);
   }

   public final void onRewardedVideoAdOpened() {
      c.c.b.a.a.q.d.a var1 = AbstractAdViewAdapter.zza(this.a);
      AbstractAdViewAdapter var2 = this.a;
      ((m5)var1).d(var2);
   }

   public final void onRewardedVideoCompleted() {
      c.c.b.a.a.q.d.a var1 = AbstractAdViewAdapter.zza(this.a);
      AbstractAdViewAdapter var2 = this.a;
      ((m5)var1).f(var2);
   }

   public final void onRewardedVideoStarted() {
      c.c.b.a.a.q.d.a var1 = AbstractAdViewAdapter.zza(this.a);
      AbstractAdViewAdapter var2 = this.a;
      ((m5)var1).g(var2);
   }
}
