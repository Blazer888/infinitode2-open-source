package c.c.a.d;

@Deprecated
public interface d {
}
