package c.c.a.d;

import com.google.ads.mediation.AbstractAdViewAdapter;

public final class i {
   // $FF: synthetic field
   public final AbstractAdViewAdapter a;

   public i(AbstractAdViewAdapter var1) {
      this.a = var1;
   }
}
