package c.c.a.d;

@Deprecated
public interface b {
   void destroy();

   Class getAdditionalParametersType();

   Class getServerParametersType();
}
