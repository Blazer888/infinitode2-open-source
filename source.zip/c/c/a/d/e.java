package c.c.a.d;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

@Deprecated
public class e {
   public void a(Map var1) {
      HashMap var2 = new HashMap();
      Field[] var3 = this.getClass().getFields();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         Field var6 = var3[var5];
         e.b var7 = (e.b)var6.getAnnotation(e.b.class);
         if (var7 != null) {
            var2.put(var7.name(), var6);
         }
      }

      if (var2.isEmpty()) {
         b.c.b.b.g("No server options fields detected. To suppress this message either add a field with the @Parameter annotation, or override the load() method.");
      }

      Iterator var10 = var1.entrySet().iterator();

      Field var13;
      StringBuilder var19;
      while(var10.hasNext()) {
         Entry var16 = (Entry)var10.next();
         var13 = (Field)var2.remove(var16.getKey());
         if (var13 != null) {
            StringBuilder var14;
            String var17;
            try {
               var13.set(this, var16.getValue());
            } catch (IllegalAccessException var8) {
               var17 = (String)var16.getKey();
               var14 = new StringBuilder(c.a.b.a.a.b(var17, 49));
               var14.append("Server option \"");
               var14.append(var17);
               var14.append("\" could not be set: Illegal Access");
               b.c.b.b.g(var14.toString());
            } catch (IllegalArgumentException var9) {
               var17 = (String)var16.getKey();
               var14 = new StringBuilder(c.a.b.a.a.b(var17, 43));
               var14.append("Server option \"");
               var14.append(var17);
               var14.append("\" could not be set: Bad Type");
               b.c.b.b.g(var14.toString());
            }
         } else {
            String var15 = (String)var16.getKey();
            String var18 = (String)var16.getValue();
            var19 = new StringBuilder(c.a.b.a.a.b(var18, c.a.b.a.a.b(var15, 31)));
            var19.append("Unexpected server option: ");
            var19.append(var15);
            var19.append(" = \"");
            var19.append(var18);
            var19.append("\"");
            b.c.b.b.e(var19.toString());
         }
      }

      var19 = new StringBuilder();
      Iterator var12 = var2.values().iterator();

      String var11;
      while(var12.hasNext()) {
         var13 = (Field)var12.next();
         if (((e.b)var13.getAnnotation(e.b.class)).required()) {
            var11 = String.valueOf(((e.b)var13.getAnnotation(e.b.class)).name());
            if (var11.length() != 0) {
               var11 = "Required server option missing: ".concat(var11);
            } else {
               var11 = new String("Required server option missing: ");
            }

            b.c.b.b.g(var11);
            if (var19.length() > 0) {
               var19.append(", ");
            }

            var19.append(((e.b)var13.getAnnotation(e.b.class)).name());
         }
      }

      if (var19.length() > 0) {
         var11 = String.valueOf(var19.toString());
         if (var11.length() != 0) {
            var11 = "Required server option(s) missing: ".concat(var11);
         } else {
            var11 = new String("Required server option(s) missing: ");
         }

         throw new e.a(var11);
      }
   }

   public static final class a extends Exception {
      public a(String var1) {
         super(var1);
      }
   }

   @Retention(RetentionPolicy.RUNTIME)
   @Target({ElementType.FIELD})
   public @interface b {
      String name();

      boolean required() default true;
   }
}
