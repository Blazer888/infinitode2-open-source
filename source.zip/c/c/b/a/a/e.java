package c.c.b.a.a;

import android.content.Context;
import android.util.DisplayMetrics;
import c.c.b.a.i.a.b7;
import c.c.b.a.i.a.p7;
import c.c.b.a.i.a.u5;

public final class e {
   public static final e g = new e(320, 50, "320x50_mb");
   public static final e h = new e(468, 60, "468x60_as");
   public static final e i = new e(320, 100, "320x100_as");
   public static final e j = new e(728, 90, "728x90_as");
   public static final e k = new e(300, 250, "300x250_as");
   public static final e l = new e(160, 600, "160x600_as");
   public static final e m = new e(-1, -2, "smart_banner");
   public static final e n = new e(-3, -4, "fluid");
   public static final e o = new e(0, 0, "invalid");
   public static final e p = new e(50, 50, "50x50_mb");
   public final int a;
   public final int b;
   public final String c;
   public boolean d;
   public boolean e;
   public int f;

   static {
      new e(-3, 0, "search_v2");
   }

   public e(int var1, int var2) {
      String var3;
      if (var1 == -1) {
         var3 = "FULL";
      } else {
         var3 = String.valueOf(var1);
      }

      String var4;
      if (var2 == -2) {
         var4 = "AUTO";
      } else {
         var4 = String.valueOf(var2);
      }

      StringBuilder var5 = new StringBuilder(c.a.b.a.a.b(var4, c.a.b.a.a.b(var3, 4)));
      var5.append(var3);
      var5.append("x");
      var5.append(var4);
      var5.append("_as");
      this(var1, var2, var5.toString());
   }

   public e(int var1, int var2, String var3) {
      StringBuilder var4;
      if (var1 < 0 && var1 != -1 && var1 != -3) {
         var4 = new StringBuilder(37);
         var4.append("Invalid width for AdSize: ");
         var4.append(var1);
         throw new IllegalArgumentException(var4.toString());
      } else if (var2 < 0 && var2 != -2 && var2 != -4) {
         var4 = new StringBuilder(38);
         var4.append("Invalid height for AdSize: ");
         var4.append(var2);
         throw new IllegalArgumentException(var4.toString());
      } else {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }
   }

   public final int a(Context var1) {
      int var2 = this.b;
      if (var2 != -4 && var2 != -3) {
         if (var2 != -2) {
            u5 var3 = p7.i.a;
            return u5.a(var1.getResources().getDisplayMetrics(), var2);
         } else {
            DisplayMetrics var4 = var1.getResources().getDisplayMetrics();
            return (int)((float)b7.b(var4) * var4.density);
         }
      } else {
         return -1;
      }
   }

   public final int b(Context var1) {
      int var2 = this.a;
      if (var2 != -4 && var2 != -3) {
         if (var2 != -1) {
            u5 var3 = p7.i.a;
            return u5.a(var1.getResources().getDisplayMetrics(), var2);
         } else {
            return b7.a(var1.getResources().getDisplayMetrics());
         }
      } else {
         return -1;
      }
   }

   public final boolean equals(Object var1) {
      if (var1 == this) {
         return true;
      } else if (!(var1 instanceof e)) {
         return false;
      } else {
         e var2 = (e)var1;
         return this.a == var2.a && this.b == var2.b && this.c.equals(var2.c);
      }
   }

   public final int hashCode() {
      return this.c.hashCode();
   }

   public final String toString() {
      return this.c;
   }
}
