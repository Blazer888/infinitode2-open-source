package c.c.b.a.a.q.d;

public interface a {
}
