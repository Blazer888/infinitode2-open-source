package c.c.b.a.a.q;

public interface c {
   void onRewarded(a var1);

   void onRewardedVideoAdClosed();

   void onRewardedVideoAdFailedToLoad(int var1);

   void onRewardedVideoAdLeftApplication();

   void onRewardedVideoAdLoaded();

   void onRewardedVideoAdOpened();

   void onRewardedVideoCompleted();

   void onRewardedVideoStarted();
}
