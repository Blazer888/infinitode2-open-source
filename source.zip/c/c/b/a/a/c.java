package c.c.b.a.a;

import android.content.Context;
import android.os.RemoteException;
import c.c.b.a.i.a.a9;
import c.c.b.a.i.a.v7;
import c.c.b.a.i.a.z6;

public class c {
   public final Context a;
   public final v7 b;

   public c(Context var1, v7 var2) {
      this.a = var1;
      this.b = var2;
   }

   public void a(d var1) {
      a9 var3 = var1.a;

      try {
         this.b.a(z6.a(this.a, var3));
      } catch (RemoteException var2) {
         b.c.b.b.a((String)"Failed to load ad.", (Throwable)var2);
      }

   }
}
