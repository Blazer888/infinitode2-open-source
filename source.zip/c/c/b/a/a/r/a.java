package c.c.b.a.a.r;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import c.c.b.a.a.b;
import c.c.b.a.a.e;
import c.c.b.a.i.a.c9;

public final class a extends ViewGroup {
   public final c9 a;

   public final b getAdListener() {
      return this.a.e;
   }

   public final e getAdSize() {
      return this.a.b();
   }

   public final String getAdUnitId() {
      return this.a.c();
   }

   public final void onLayout(boolean var1, int var2, int var3, int var4, int var5) {
      View var6 = this.getChildAt(0);
      if (var6 != null && var6.getVisibility() != 8) {
         int var7 = var6.getMeasuredWidth();
         int var8 = var6.getMeasuredHeight();
         var2 = (var4 - var2 - var7) / 2;
         var3 = (var5 - var3 - var8) / 2;
         var6.layout(var2, var3, var7 + var2, var8 + var3);
      }

   }

   public final void onMeasure(int var1, int var2) {
      int var3 = 0;
      View var4 = this.getChildAt(0);
      int var5;
      if (var4 != null && var4.getVisibility() != 8) {
         this.measureChild(var4, var1, var2);
         var3 = var4.getMeasuredWidth();
         var5 = var4.getMeasuredHeight();
      } else {
         e var8 = null;

         label20: {
            e var6;
            try {
               var6 = this.getAdSize();
            } catch (NullPointerException var7) {
               b.c.b.b.a((String)"Unable to retrieve ad size.", (Throwable)var7);
               break label20;
            }

            var8 = var6;
         }

         if (var8 != null) {
            Context var9 = this.getContext();
            var3 = var8.b(var9);
            var5 = var8.a(var9);
         } else {
            var5 = 0;
         }
      }

      var3 = Math.max(var3, this.getSuggestedMinimumWidth());
      var5 = Math.max(var5, this.getSuggestedMinimumHeight());
      this.setMeasuredDimension(View.resolveSize(var3, var1), View.resolveSize(var5, var2));
   }

   public final void setAdListener(b var1) {
      c9 var2 = this.a;
      var2.e = var1;
      var2.c.a(var1);
   }

   public final void setAdSize(e var1) {
      c9 var2 = this.a;
      if (var2.f == null) {
         var2.a(var1);
      } else {
         throw new IllegalStateException("The ad size can only be set once on AdView.");
      }
   }

   public final void setAdUnitId(String var1) {
      this.a.a(var1);
   }
}
