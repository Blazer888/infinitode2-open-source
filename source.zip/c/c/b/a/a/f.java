package c.c.b.a.a;

import android.content.Context;
import c.c.b.a.i.a.c9;

public final class f extends g {
   public f(Context var1) {
      super(var1, 0);
      b.c.b.b.b((Object)var1, (Object)"Context cannot be null");
   }

   public final k getVideoController() {
      c9 var1 = super.a;
      return var1 != null ? var1.b : null;
   }
}
