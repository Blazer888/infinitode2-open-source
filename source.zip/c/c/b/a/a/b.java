package c.c.b.a.a;

public class b {
   public void a() {
      throw null;
   }

   public void a(int var1) {
      throw null;
   }

   public void b() {
   }

   public void c() {
      throw null;
   }

   public void d() {
   }

   public void e() {
      throw null;
   }

   public void f() {
      throw null;
   }
}
