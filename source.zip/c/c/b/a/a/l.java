package c.c.b.a.a;

import c.c.b.a.i.a.u9;

public final class l {
   public final boolean a;
   public final boolean b;
   public final boolean c;

   public l(u9 var1) {
      this.a = var1.a;
      this.b = var1.b;
      this.c = var1.c;
   }
}
