package c.c.b.a.a;

import java.util.Arrays;
import java.util.List;

public class j {
   public static final List d = Arrays.asList("MA", "T", "PG", "G");
   public final int a;
   public final int b;
   public final String c;

   // $FF: synthetic method
   public j(int var1, int var2, String var3, List var4, t var5) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }
}
