package c.c.b.a.a;

import android.content.Context;
import c.c.b.a.i.a.e9;

public final class i {
   public final e9 a;

   public i(Context var1) {
      this.a = new e9(var1);
      b.c.b.b.b((Object)var1, (Object)"Context cannot be null");
   }
}
