package c.c.b.a.a.p;

import java.util.List;

@Deprecated
public class q extends p {
   public String h;
   public List i;
   public String j;
   public c.c.b.a.a.n.c.b k;
   public String l;
   public double m;
   public String n;
   public String o;
}
