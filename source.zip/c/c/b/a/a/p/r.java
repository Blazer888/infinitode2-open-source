package c.c.b.a.a.p;

import java.util.List;

@Deprecated
public class r extends p {
   public String h;
   public List i;
   public String j;
   public c.c.b.a.a.n.c.b k;
   public String l;
   public String m;
}
