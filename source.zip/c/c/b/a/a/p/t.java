package c.c.b.a.a.p;

import android.content.Context;

public interface t {
   void a(Context var1);
}
