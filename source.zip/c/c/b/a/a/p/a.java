package c.c.b.a.a.p;

import android.content.Context;
import java.util.List;

public abstract class a implements j {
   public abstract w getSDKVersionInfo();

   public abstract w getVersionInfo();

   public abstract void initialize(Context var1, b var2, List var3);

   public void loadBannerAd(g var1, d var2) {
      var2.a(this.getClass().getSimpleName().concat(" does not support banner ads."));
   }

   public void loadInterstitialAd(k var1, d var2) {
      var2.a(this.getClass().getSimpleName().concat(" does not support interstitial ads."));
   }

   public void loadNativeAd(m var1, d var2) {
      var2.a(this.getClass().getSimpleName().concat(" does not support native ads."));
   }

   public void loadRewardedAd(o var1, d var2) {
      var2.a(this.getClass().getSimpleName().concat(" does not support rewarded ads."));
   }
}
