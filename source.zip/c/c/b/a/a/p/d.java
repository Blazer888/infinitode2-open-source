package c.c.b.a.a.p;

public interface d {
   void a(String var1);
}
