package c.c.b.a.a.p;

import android.os.Bundle;

public class i {
   public i(c.c.b.a.a.a var1, Bundle var2) {
   }
}
