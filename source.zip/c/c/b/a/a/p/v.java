package c.c.b.a.a.p;

import android.os.Bundle;
import android.view.View;
import java.util.List;
import java.util.Map;

public class v {
   public String a;
   public List b;
   public String c;
   public c.c.b.a.a.n.c.b d;
   public String e;
   public String f;
   public Double g;
   public String h;
   public String i;
   public c.c.b.a.a.k j;
   public boolean k;
   public View l;
   public View m;
   public Object n;
   public Bundle o = new Bundle();
   public boolean p;
   public boolean q;
   public float r;

   public void a(View var1, Map var2, Map var3) {
      throw null;
   }

   public final boolean a() {
      return this.q;
   }

   public final boolean b() {
      return this.p;
   }

   public final Double c() {
      return this.g;
   }

   public final c.c.b.a.a.k d() {
      return this.j;
   }

   public void e() {
   }

   public void f() {
   }

   public void g() {
   }
}
