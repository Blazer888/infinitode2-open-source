package c.c.b.a.a.p.x;

public interface f extends e {
}
