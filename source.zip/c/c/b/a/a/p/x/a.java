package c.c.b.a.a.p.x;

public interface a {
   void onDestroy();

   void onPause();

   void onResume();
}
