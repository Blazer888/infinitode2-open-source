package c.c.b.a.a.p.x;

public interface b extends e {
}
