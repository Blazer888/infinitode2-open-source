package c.c.b.a.a.p.x;

import java.util.HashMap;

@Deprecated
public final class c implements c.c.a.d.f {
   public final HashMap a = new HashMap();
}
