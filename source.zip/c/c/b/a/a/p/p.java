package c.c.b.a.a.p;

import android.os.Bundle;
import android.view.View;

@Deprecated
public class p {
   public boolean a;
   public boolean b;
   public Bundle c = new Bundle();
   public View d;
   public View e;
   public c.c.b.a.a.k f;
   public boolean g;

   public View a() {
      return this.d;
   }

   @Deprecated
   public void a(View var1) {
   }

   public final Bundle b() {
      return this.c;
   }

   public void c() {
   }

   public void d() {
   }

   public void e() {
   }

   public void f() {
   }

   public final View g() {
      return this.e;
   }
}
