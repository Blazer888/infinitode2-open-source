package c.c.b.a.a.p;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;

public class m extends c {
   public m(Context var1, String var2, Bundle var3, Bundle var4, boolean var5, Location var6, int var7, int var8, String var9, String var10) {
      super(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10);
   }
}
