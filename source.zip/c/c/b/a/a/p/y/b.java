package c.c.b.a.a.p.y;

public interface b {
}
