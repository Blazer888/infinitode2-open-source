package c.c.b.a.a.p.y;

import android.content.Context;
import android.os.Bundle;
import c.c.b.a.a.e;
import java.util.List;

public class a {
   public a(Context var1, List var2, Bundle var3, e var4) {
   }
}
