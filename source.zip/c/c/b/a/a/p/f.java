package c.c.b.a.a.p;

public interface f extends j {
   void onDestroy();

   void onPause();

   void onResume();
}
