package c.c.b.a.a.p;

import android.location.Location;
import java.util.Date;
import java.util.Set;

public interface e {
   @Deprecated
   boolean a();

   @Deprecated
   Date b();

   boolean c();

   Set d();

   int e();

   Location f();

   @Deprecated
   int g();
}
