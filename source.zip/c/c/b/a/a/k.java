package c.c.b.a.a;

import c.c.b.a.i.a.v8;

public final class k {
   public final Object a = new Object();
   public v8 b;

   public final v8 a() {
      // $FF: Couldn't be decompiled
   }

   public final void a(v8 param1) {
      // $FF: Couldn't be decompiled
   }
}
