package c.c.b.a.a;

import c.c.b.a.i.a.a9;
import c.c.b.a.i.a.d9;

public final class d {
   public final a9 a;

   // $FF: synthetic method
   public d(d.a var1, s var2) {
      this.a = new a9(var1.a);
   }

   public static final class a {
      public final d9 a = new d9();

      public a() {
         this.a.d.add("B3EEABB8EE11C2BE770B684D95219ECB");
      }

      public final d.a a(String var1) {
         this.a.d.add(var1);
         return this;
      }
   }
}
