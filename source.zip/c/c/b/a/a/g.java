package c.c.b.a.a;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import c.c.b.a.i.a.c9;
import c.c.b.a.i.a.r6;

public class g extends ViewGroup {
   public final c9 a;

   public g(Context var1, int var2) {
      super(var1);
      this.a = new c9(this, var2);
   }

   public void a() {
      this.a.a();
   }

   public void a(d var1) {
      this.a.a(var1.a);
   }

   public void b() {
      this.a.f();
   }

   public void c() {
      this.a.g();
   }

   public b getAdListener() {
      return this.a.e;
   }

   public e getAdSize() {
      return this.a.b();
   }

   public String getAdUnitId() {
      return this.a.c();
   }

   public String getMediationAdapterClassName() {
      return this.a.d();
   }

   public void onLayout(boolean var1, int var2, int var3, int var4, int var5) {
      View var6 = this.getChildAt(0);
      if (var6 != null && var6.getVisibility() != 8) {
         int var7 = var6.getMeasuredWidth();
         int var8 = var6.getMeasuredHeight();
         var2 = (var4 - var2 - var7) / 2;
         var3 = (var5 - var3 - var8) / 2;
         var6.layout(var2, var3, var7 + var2, var8 + var3);
      }

   }

   public void onMeasure(int var1, int var2) {
      int var3 = 0;
      View var4 = this.getChildAt(0);
      int var5;
      if (var4 != null && var4.getVisibility() != 8) {
         this.measureChild(var4, var1, var2);
         var3 = var4.getMeasuredWidth();
         var5 = var4.getMeasuredHeight();
      } else {
         e var8 = null;

         label20: {
            e var6;
            try {
               var6 = this.getAdSize();
            } catch (NullPointerException var7) {
               b.c.b.b.a((String)"Unable to retrieve ad size.", (Throwable)var7);
               break label20;
            }

            var8 = var6;
         }

         if (var8 != null) {
            Context var9 = this.getContext();
            var3 = var8.b(var9);
            var5 = var8.a(var9);
         } else {
            var5 = 0;
         }
      }

      var3 = Math.max(var3, this.getSuggestedMinimumWidth());
      var5 = Math.max(var5, this.getSuggestedMinimumHeight());
      this.setMeasuredDimension(View.resolveSize(var3, var1), View.resolveSize(var5, var2));
   }

   public void setAdListener(b var1) {
      c9 var2 = this.a;
      var2.e = var1;
      var2.c.a(var1);
      if (var1 == null) {
         this.a.a((r6)null);
         this.a.a((c.c.b.a.a.m.a)null);
      } else {
         if (var1 instanceof r6) {
            this.a.a((r6)var1);
         }

         if (var1 instanceof c.c.b.a.a.m.a) {
            this.a.a((c.c.b.a.a.m.a)var1);
         }

      }
   }

   public void setAdSize(e var1) {
      c9 var2 = this.a;
      if (var2.f == null) {
         var2.a(var1);
      } else {
         throw new IllegalStateException("The ad size can only be set once on AdView.");
      }
   }

   public void setAdUnitId(String var1) {
      this.a.a(var1);
   }
}
