package c.c.b.a.a;

public enum a {
   a,
   b,
   c,
   d;
}
