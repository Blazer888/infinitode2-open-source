package c.c.b.a.a.n;

import android.view.View;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;

public final class f {
   public static WeakHashMap b = new WeakHashMap();
   public WeakReference a;

   public final void a(c.c.b.a.f.a var1) {
      WeakReference var2 = this.a;
      View var3;
      if (var2 != null) {
         var3 = (View)var2.get();
      } else {
         var3 = null;
      }

      if (var3 == null) {
         b.c.b.b.g("NativeAdViewHolder.setNativeAd containerView doesn't exist, returning");
      } else {
         if (!b.containsKey(var3)) {
            b.put(var3, this);
         }

      }
   }
}
