package c.c.b.a.a.n;

import android.os.RemoteException;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import c.c.b.a.i.a.fa;
import c.c.b.a.i.a.p7;
import c.c.b.a.i.a.w9;

@Deprecated
public class e extends FrameLayout {
   public final FrameLayout a;

   public final View a(String var1) {
      throw null;
   }

   public final void a(String var1, View var2) {
      try {
         new c.c.b.a.f.b(var2);
      } catch (RemoteException var3) {
         b.c.b.b.a((String)"Unable to call setAssetView on delegate", (Throwable)var3);
         return;
      }

      throw null;
   }

   public void addView(View var1, int var2, LayoutParams var3) {
      super.addView(var1, var2, var3);
      super.bringChildToFront(this.a);
   }

   public void bringChildToFront(View var1) {
      super.bringChildToFront(var1);
      FrameLayout var2 = this.a;
      if (var2 != var1) {
         super.bringChildToFront(var2);
      }

   }

   public boolean dispatchTouchEvent(MotionEvent var1) {
      w9 var2 = fa.d;
      (Boolean)p7.i.e.a(var2);
      return super.dispatchTouchEvent(var1);
   }

   public a getAdChoicesView() {
      View var1 = this.a("1098");
      return var1 instanceof a ? (a)var1 : null;
   }

   public void onVisibilityChanged(View var1, int var2) {
      super.onVisibilityChanged(var1, var2);
   }

   public void removeAllViews() {
      super.removeAllViews();
      super.addView(this.a);
   }

   public void removeView(View var1) {
      if (this.a != var1) {
         super.removeView(var1);
      }
   }

   public void setAdChoicesView(a var1) {
      this.a("1098", var1);
   }

   public void setNativeAd(c var1) {
      try {
         c.c.b.a.f.a var3 = (c.c.b.a.f.a)var1.a();
      } catch (RemoteException var2) {
         b.c.b.b.a((String)"Unable to call setNativeAd on delegate", (Throwable)var2);
         return;
      }

      throw null;
   }
}
