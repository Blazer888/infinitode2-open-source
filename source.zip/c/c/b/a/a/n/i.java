package c.c.b.a.a.n;

public interface i {
   public interface a {
   }

   public interface b {
   }
}
