package c.c.b.a.a.n;

// $FF: synthetic class
public final class m {
}
