package c.c.b.a.a.n;

public final class d {
   public final boolean a;
   public final int b;
   public final int c;
   public final boolean d;
   public final int e;
   public final c.c.b.a.a.l f;
   public final boolean g;

   // $FF: synthetic method
   public d(d.a var1, m var2) {
      this.a = var1.a;
      this.b = var1.b;
      this.c = var1.c;
      this.d = var1.d;
      this.e = var1.f;
      this.f = var1.e;
      this.g = var1.g;
   }

   public static final class a {
      public boolean a = false;
      public int b = -1;
      public int c = 0;
      public boolean d = false;
      public c.c.b.a.a.l e;
      public int f = 1;
      public boolean g = false;
   }
}
