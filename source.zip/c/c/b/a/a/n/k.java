package c.c.b.a.a.n;

public abstract class k {
   public abstract String a();

   public abstract Object b();

   public interface a {
   }

   public interface b {
   }
}
