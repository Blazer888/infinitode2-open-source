package c.c.b.a.a.n;

@Deprecated
public abstract class g extends c {
   public abstract CharSequence b();

   public abstract CharSequence c();

   public abstract Double d();

   public abstract CharSequence e();

   public interface a {
   }
}
