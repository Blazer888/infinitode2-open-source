package c.c.b.a.a.n;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import c.c.b.a.i.a.d7;
import c.c.b.a.i.a.j8;

public final class j extends c.c.b.a.d.o.v.a {
   public static final Creator CREATOR = new n();
   public final boolean a;
   public final j8 b;
   public final IBinder c;

   public j(boolean var1, IBinder var2, IBinder var3) {
      this.a = var1;
      j8 var4;
      if (var2 != null) {
         var4 = d7.a(var2);
      } else {
         var4 = null;
      }

      this.b = var4;
      this.c = var3;
   }

   public final void writeToParcel(Parcel var1, int var2) {
      var2 = b.c.b.b.a(var1);
      b.c.b.b.a(var1, 1, this.a);
      j8 var3 = this.b;
      IBinder var4;
      if (var3 == null) {
         var4 = null;
      } else {
         var4 = var3.asBinder();
      }

      b.c.b.b.a(var1, 2, (IBinder)var4, false);
      b.c.b.b.a(var1, 3, (IBinder)this.c, false);
      b.c.b.b.m(var1, var2);
   }
}
