package c.c.b.a.a.n;

@Deprecated
public abstract class h extends c {
   public abstract CharSequence b();

   public interface a {
   }
}
