package c.c.b.a.a.n;

import android.content.Context;
import android.widget.FrameLayout;
import android.widget.ImageView.ScaleType;
import c.c.b.a.i.a.r;

public class b extends FrameLayout {
   public k.a a;
   public boolean b;
   public c.c.b.a.i.a.p c;
   public ScaleType d;
   public boolean e;
   public r f;

   public b(Context var1) {
      super(var1);
   }

   public final void a(c.c.b.a.i.a.p var1) {
      synchronized(this){}

      Throwable var10000;
      label81: {
         boolean var10001;
         k.a var2;
         try {
            this.c = var1;
            if (!this.b) {
               return;
            }

            var2 = this.a;
         } catch (Throwable var8) {
            var10000 = var8;
            var10001 = false;
            break label81;
         }

         p var9 = (p)var1;

         label72:
         try {
            var9.a.a(var2);
            return;
         } catch (Throwable var7) {
            var10000 = var7;
            var10001 = false;
            break label72;
         }
      }

      Throwable var10 = var10000;
      throw var10;
   }

   public final void a(r var1) {
      synchronized(this){}

      Throwable var10000;
      label81: {
         boolean var10001;
         ScaleType var2;
         try {
            this.f = var1;
            if (!this.e) {
               return;
            }

            var2 = this.d;
         } catch (Throwable var8) {
            var10000 = var8;
            var10001 = false;
            break label81;
         }

         o var9 = (o)var1;

         label72:
         try {
            var9.a.a(var2);
            return;
         } catch (Throwable var7) {
            var10000 = var7;
            var10001 = false;
            break label72;
         }
      }

      Throwable var10 = var10000;
      throw var10;
   }

   public void setImageScaleType(ScaleType var1) {
      this.e = true;
      this.d = var1;
      r var3 = this.f;
      if (var3 != null) {
         ScaleType var2 = this.d;
         ((o)var3).a.a(var2);
      }

   }

   public void setMediaContent(k.a var1) {
      this.b = true;
      this.a = var1;
      c.c.b.a.i.a.p var2 = this.c;
      if (var2 != null) {
         ((p)var2).a.a(var1);
      }

   }
}
