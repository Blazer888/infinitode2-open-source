package c.c.b.a.a.n;

import c.c.b.a.i.a.r;

// $FF: synthetic class
public final class o implements r {
   public final l a;

   public o(l var1) {
      this.a = var1;
   }
}
