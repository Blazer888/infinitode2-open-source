package c.c.b.a.a.n;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;

public final class n implements Creator {
   // $FF: synthetic method
   public final Object createFromParcel(Parcel var1) {
      int var2 = b.c.b.b.b(var1);
      IBinder var3 = null;
      boolean var4 = false;
      IBinder var5 = null;

      while(var1.dataPosition() < var2) {
         int var6 = var1.readInt();
         int var7 = '\uffff' & var6;
         if (var7 != 1) {
            if (var7 != 2) {
               if (var7 != 3) {
                  b.c.b.b.k(var1, var6);
               } else {
                  var5 = b.c.b.b.g(var1, var6);
               }
            } else {
               var3 = b.c.b.b.g(var1, var6);
            }
         } else {
            var4 = b.c.b.b.f(var1, var6);
         }
      }

      b.c.b.b.e(var1, var2);
      return new j(var4, var3, var5);
   }

   // $FF: synthetic method
   public final Object[] newArray(int var1) {
      return new j[var1];
   }
}
