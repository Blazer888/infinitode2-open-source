package c.c.b.a.a.n;

import android.os.RemoteException;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView.ScaleType;
import c.c.b.a.i.a.fa;
import c.c.b.a.i.a.p7;
import c.c.b.a.i.a.r;
import c.c.b.a.i.a.w9;

public final class l extends FrameLayout {
   public final FrameLayout a;

   // $FF: synthetic method
   public final void a(ScaleType var1) {
      try {
         if (!(var1 instanceof ScaleType)) {
            return;
         }

         new c.c.b.a.f.b(var1);
      } catch (RemoteException var2) {
         b.c.b.b.a((String)"Unable to call setMediaViewImageScaleType on delegate", (Throwable)var2);
         return;
      }

      throw null;
   }

   // $FF: synthetic method
   public final void a(k.a param1) {
      // $FF: Couldn't be decompiled
   }

   public final void a(String var1, View var2) {
      try {
         new c.c.b.a.f.b(var2);
      } catch (RemoteException var3) {
         b.c.b.b.a((String)"Unable to call setAssetView on delegate", (Throwable)var3);
         return;
      }

      throw null;
   }

   public final void addView(View var1, int var2, LayoutParams var3) {
      super.addView(var1, var2, var3);
      super.bringChildToFront(this.a);
   }

   public final void bringChildToFront(View var1) {
      super.bringChildToFront(var1);
      FrameLayout var2 = this.a;
      if (var2 != var1) {
         super.bringChildToFront(var2);
      }

   }

   public final boolean dispatchTouchEvent(MotionEvent var1) {
      w9 var2 = fa.d;
      (Boolean)p7.i.e.a(var2);
      return super.dispatchTouchEvent(var1);
   }

   public final a getAdChoicesView() {
      throw null;
   }

   public final View getAdvertiserView() {
      throw null;
   }

   public final View getBodyView() {
      throw null;
   }

   public final View getCallToActionView() {
      throw null;
   }

   public final View getHeadlineView() {
      throw null;
   }

   public final View getIconView() {
      throw null;
   }

   public final View getImageView() {
      throw null;
   }

   public final b getMediaView() {
      throw null;
   }

   public final View getPriceView() {
      throw null;
   }

   public final View getStarRatingView() {
      throw null;
   }

   public final View getStoreView() {
      throw null;
   }

   public final void onVisibilityChanged(View var1, int var2) {
      super.onVisibilityChanged(var1, var2);
   }

   public final void removeAllViews() {
      super.removeAllViews();
      super.addView(this.a);
   }

   public final void removeView(View var1) {
      if (this.a != var1) {
         super.removeView(var1);
      }
   }

   public final void setAdChoicesView(a var1) {
      this.a("3011", var1);
   }

   public final void setAdvertiserView(View var1) {
      this.a("3005", var1);
   }

   public final void setBodyView(View var1) {
      this.a("3004", var1);
   }

   public final void setCallToActionView(View var1) {
      this.a("3002", var1);
   }

   public final void setClickConfirmingView(View var1) {
      try {
         new c.c.b.a.f.b(var1);
      } catch (RemoteException var2) {
         b.c.b.b.a((String)"Unable to call setClickConfirmingView on delegate", (Throwable)var2);
         return;
      }

      throw null;
   }

   public final void setHeadlineView(View var1) {
      this.a("3001", var1);
   }

   public final void setIconView(View var1) {
      this.a("3003", var1);
   }

   public final void setImageView(View var1) {
      this.a("3008", var1);
   }

   public final void setMediaView(b var1) {
      this.a("3010", var1);
      if (var1 != null) {
         var1.a((c.c.b.a.i.a.p)(new p(this)));
         var1.a((r)(new o(this)));
      }

   }

   public final void setNativeAd(k var1) {
      try {
         c.c.b.a.f.a var3 = (c.c.b.a.f.a)var1.b();
      } catch (RemoteException var2) {
         b.c.b.b.a((String)"Unable to call setNativeAd on delegate", (Throwable)var2);
         return;
      }

      throw null;
   }

   public final void setPriceView(View var1) {
      this.a("3007", var1);
   }

   public final void setStarRatingView(View var1) {
      this.a("3009", var1);
   }

   public final void setStoreView(View var1) {
      this.a("3006", var1);
   }
}
