package c.c.b.a.a.n;

public abstract class c {
   public abstract Object a();

   public abstract static class a {
   }

   public abstract static class b {
   }
}
