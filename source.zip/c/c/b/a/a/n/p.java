package c.c.b.a.a.n;

// $FF: synthetic class
public final class p implements c.c.b.a.i.a.p {
   public final l a;

   public p(l var1) {
      this.a = var1;
   }
}
