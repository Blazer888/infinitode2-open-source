package c.c.b.a.a;

// $FF: synthetic class
public final class s {
}
