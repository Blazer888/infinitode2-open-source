package c.c.b.a.a.o;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.SystemClock;
import android.util.Log;
import c.c.b.a.d.f;
import c.c.b.a.d.g;
import c.c.b.a.d.i;
import c.c.b.a.i.b.d;
import c.c.b.a.i.b.e;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class a {
   public c.c.b.a.d.a a;
   public d b;
   public boolean c;
   public final Object d = new Object();
   public c.c.b.a.a.o.a.b e;
   public final Context f;
   public final boolean g;
   public final long h;

   public a(Context var1, long var2, boolean var4, boolean var5) {
      b.c.b.b.a((Object)var1);
      Context var6 = var1;
      if (var4) {
         var6 = var1.getApplicationContext();
         if (var6 == null) {
            var6 = var1;
         }
      }

      this.f = var6;
      this.c = false;
      this.h = var2;
      this.g = var5;
   }

   public static c.c.b.a.a.o.a.a a(Context var0) {
      SharedPreferences var1 = null;

      label707: {
         SharedPreferences var84;
         label706: {
            Throwable var10000;
            label711: {
               Context var2;
               boolean var10001;
               try {
                  var2 = i.b(var0);
               } catch (Throwable var79) {
                  var10000 = var79;
                  var10001 = false;
                  break label711;
               }

               if (var2 == null) {
                  break label707;
               }

               label701:
               try {
                  var84 = var2.getSharedPreferences("google_ads_flags", 0);
                  break label706;
               } catch (Throwable var78) {
                  var10000 = var78;
                  var10001 = false;
                  break label701;
               }
            }

            Throwable var82 = var10000;
            Log.w("GmscoreFlag", "Error while getting SharedPreferences ", var82);
            break label707;
         }

         var1 = var84;
      }

      boolean var3;
      label695: {
         if (var1 != null) {
            label693:
            try {
               var3 = var1.getBoolean("gads:ad_id_app_context:enabled", false);
               break label695;
            } catch (Throwable var77) {
               Log.w("GmscoreFlag", "Error while reading from SharedPreferences ", var77);
               break label693;
            }
         }

         var3 = false;
      }

      float var4;
      label689: {
         if (var1 != null) {
            label687:
            try {
               var4 = var1.getFloat("gads:ad_id_app_context:ping_ratio", 0.0F);
               break label689;
            } catch (Throwable var76) {
               Log.w("GmscoreFlag", "Error while reading from SharedPreferences ", var76);
               break label687;
            }
         }

         var4 = 0.0F;
      }

      String var85;
      label683: {
         if (var1 != null) {
            label681:
            try {
               var85 = var1.getString("gads:ad_id_use_shared_preference:experiment_id", "");
               break label683;
            } catch (Throwable var75) {
               Log.w("GmscoreFlag", "Error while reading from SharedPreferences ", var75);
               break label681;
            }
         }

         var85 = "";
      }

      boolean var5;
      label677: {
         if (var1 != null) {
            label675:
            try {
               var5 = var1.getBoolean("gads:ad_id_use_persistent_service:enabled", false);
               break label677;
            } catch (Throwable var74) {
               Log.w("GmscoreFlag", "Error while reading from SharedPreferences ", var74);
               break label675;
            }
         }

         var5 = false;
      }

      c.c.b.a.a.o.a var80 = new c.c.b.a.a.o.a(var0, -1L, var3, var5);

      c.c.b.a.a.o.a.a var83;
      try {
         long var6 = SystemClock.elapsedRealtime();
         var80.a(false);
         var83 = var80.b();
         var80.a(var83, var3, var4, SystemClock.elapsedRealtime() - var6, var85, (Throwable)null);
      } catch (Throwable var73) {
         Throwable var81 = var73;

         try {
            var80.a((c.c.b.a.a.o.a.a)null, var3, var4, -1L, var85, var81);
            throw var81;
         } finally {
            var80.a();
         }
      }

      var80.a();
      return var83;
   }

   public static c.c.b.a.d.a a(Context var0, boolean var1) {
      try {
         var0.getPackageManager().getPackageInfo("com.android.vending", 0);
      } catch (NameNotFoundException var8) {
         throw new g(9);
      }

      int var2 = c.c.b.a.d.f.a.a(var0, 12451000);
      if (var2 != 0 && var2 != 2) {
         throw new IOException("Google Play services not available");
      } else {
         String var3;
         if (var1) {
            var3 = "com.google.android.gms.ads.identifier.service.PERSISTENT_START";
         } else {
            var3 = "com.google.android.gms.ads.identifier.service.START";
         }

         c.c.b.a.d.a var4 = new c.c.b.a.d.a();
         Intent var9 = new Intent(var3);
         var9.setPackage("com.google.android.gms");

         try {
            var1 = c.c.b.a.d.q.a.a().a(var0, var9, var4, 1);
         } catch (Throwable var7) {
            throw new IOException(var7);
         }

         if (var1) {
            return var4;
         } else {
            throw new IOException("Connection failure");
         }
      }
   }

   public final void a() {
      b.c.b.b.c("Calling this from your main thread can lead to deadlock");
      synchronized(this){}

      Throwable var10000;
      boolean var10001;
      Throwable var44;
      label351: {
         label350: {
            c.c.b.a.d.a var1;
            try {
               if (this.f == null) {
                  break label350;
               }

               var1 = this.a;
            } catch (Throwable var43) {
               var10000 = var43;
               var10001 = false;
               break label351;
            }

            if (var1 != null) {
               try {
                  if (this.c) {
                     c.c.b.a.d.q.a.a().a(this.f, this.a);
                  }
               } catch (Throwable var41) {
                  var44 = var41;

                  label337:
                  try {
                     Log.i("AdvertisingIdClient", "AdvertisingIdClient unbindService failed.", var44);
                     break label337;
                  } catch (Throwable var40) {
                     var10000 = var40;
                     var10001 = false;
                     break label351;
                  }
               }

               try {
                  this.c = false;
                  this.b = null;
                  this.a = null;
                  return;
               } catch (Throwable var39) {
                  var10000 = var39;
                  var10001 = false;
                  break label351;
               }
            }
         }

         label343:
         try {
            return;
         } catch (Throwable var42) {
            var10000 = var42;
            var10001 = false;
            break label343;
         }
      }

      while(true) {
         var44 = var10000;

         try {
            throw var44;
         } catch (Throwable var38) {
            var10000 = var38;
            var10001 = false;
            continue;
         }
      }
   }

   public final void a(boolean var1) {
      b.c.b.b.c("Calling this from your main thread can lead to deadlock");
      synchronized(this){}

      Throwable var104;
      Throwable var10000;
      boolean var10001;
      label682: {
         try {
            if (this.c) {
               this.a();
            }
         } catch (Throwable var103) {
            var10000 = var103;
            var10001 = false;
            break label682;
         }

         c.c.b.a.d.a var2;
         try {
            this.a = a(this.f, this.g);
            var2 = this.a;
         } catch (Throwable var102) {
            var10000 = var102;
            var10001 = false;
            break label682;
         }

         d var106;
         label671: {
            try {
               try {
                  var106 = c.c.b.a.i.b.e.a(var2.a(10000L, TimeUnit.MILLISECONDS));
                  break label671;
               } catch (InterruptedException var100) {
               }
            } catch (Throwable var101) {
               var104 = var101;

               try {
                  IOException var3 = new IOException(var104);
                  throw var3;
               } catch (Throwable var96) {
                  var10000 = var96;
                  var10001 = false;
                  break label682;
               }
            }

            try {
               IOException var105 = new IOException("Interrupted exception");
               throw var105;
            } catch (Throwable var95) {
               var10000 = var95;
               var10001 = false;
               break label682;
            }
         }

         try {
            this.b = var106;
            this.c = true;
         } catch (Throwable var99) {
            var10000 = var99;
            var10001 = false;
            break label682;
         }

         if (var1) {
            try {
               this.c();
            } catch (Throwable var98) {
               var10000 = var98;
               var10001 = false;
               break label682;
            }
         }

         label658:
         try {
            return;
         } catch (Throwable var97) {
            var10000 = var97;
            var10001 = false;
            break label658;
         }
      }

      while(true) {
         var104 = var10000;

         try {
            throw var104;
         } catch (Throwable var94) {
            var10000 = var94;
            var10001 = false;
            continue;
         }
      }
   }

   public final boolean a(c.c.b.a.a.o.a.a var1, boolean var2, float var3, long var4, String var6, Throwable var7) {
      if (Math.random() > (double)var3) {
         return false;
      } else {
         HashMap var8 = new HashMap();
         String var9 = "1";
         String var10;
         if (var2) {
            var10 = "1";
         } else {
            var10 = "0";
         }

         var8.put("app_context", var10);
         if (var1 != null) {
            if (var1.b) {
               var10 = var9;
            } else {
               var10 = "0";
            }

            var8.put("limit_ad_tracking", var10);
         }

         if (var1 != null) {
            String var11 = var1.a;
            if (var11 != null) {
               var8.put("ad_id_size", Integer.toString(var11.length()));
            }
         }

         if (var7 != null) {
            var8.put("error", var7.getClass().getName());
         }

         if (var6 != null && !var6.isEmpty()) {
            var8.put("experiment_id", var6);
         }

         var8.put("tag", "AdvertisingIdClient");
         var8.put("time_spent", Long.toString(var4));
         (new c.c.b.a.a.o.b(var8)).start();
         return true;
      }
   }

   public c.c.b.a.a.o.a.a b() {
      // $FF: Couldn't be decompiled
   }

   public final void c() {
      // $FF: Couldn't be decompiled
   }

   public void finalize() {
      this.a();
      super.finalize();
   }

   public static final class a {
      public final String a;
      public final boolean b;

      public a(String var1, boolean var2) {
         this.a = var1;
         this.b = var2;
      }

      public final String toString() {
         String var1 = this.a;
         boolean var2 = this.b;
         StringBuilder var3 = new StringBuilder(c.a.b.a.a.b(var1, 7));
         var3.append("{");
         var3.append(var1);
         var3.append("}");
         var3.append(var2);
         return var3.toString();
      }
   }

   public static final class b extends Thread {
      public WeakReference a;
      public long b;
      public CountDownLatch c;
      public boolean d;

      public b(c.c.b.a.a.o.a var1, long var2) {
         this.a = new WeakReference(var1);
         this.b = var2;
         this.c = new CountDownLatch(1);
         this.d = false;
         this.start();
      }

      public final void run() {
         // $FF: Couldn't be decompiled
      }
   }
}
