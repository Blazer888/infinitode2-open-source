package c.c.b.a.a.o;

import android.net.Uri;
import android.net.Uri.Builder;
import android.util.Log;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;

public final class b extends Thread {
   // $FF: synthetic field
   public final Map a;

   public b(Map var1) {
      this.a = var1;
   }

   public final void run() {
      Map var1 = this.a;
      Builder var2 = Uri.parse("https://pagead2.googlesyndication.com/pagead/gen_204?id=gmob-apps").buildUpon();
      Iterator var3 = var1.keySet().iterator();

      String var4;
      while(var3.hasNext()) {
         var4 = (String)var3.next();
         var2.appendQueryParameter(var4, (String)var1.get(var4));
      }

      String var5 = var2.build().toString();

      StringBuilder var43;
      Object var44;
      String var45;
      label217: {
         Object var48;
         label216: {
            IndexOutOfBoundsException var50;
            label215: {
               IOException var49;
               label214: {
                  RuntimeException var10000;
                  label227: {
                     boolean var10001;
                     HttpURLConnection var47;
                     try {
                        URL var46 = new URL(var5);
                        var47 = (HttpURLConnection)var46.openConnection();
                     } catch (IndexOutOfBoundsException var39) {
                        var50 = var39;
                        var10001 = false;
                        break label215;
                     } catch (IOException var40) {
                        var49 = var40;
                        var10001 = false;
                        break label214;
                     } catch (RuntimeException var41) {
                        var10000 = var41;
                        var10001 = false;
                        break label227;
                     }

                     label228: {
                        Throwable var51;
                        label229: {
                           int var6;
                           try {
                              var6 = var47.getResponseCode();
                           } catch (Throwable var38) {
                              var51 = var38;
                              var10001 = false;
                              break label229;
                           }

                           if (var6 >= 200 && var6 < 300) {
                              break label228;
                           }

                           label203:
                           try {
                              int var7 = String.valueOf(var5).length();
                              var43 = new StringBuilder(var7 + 65);
                              var43.append("Received non-success response code ");
                              var43.append(var6);
                              var43.append(" from pinging URL: ");
                              var43.append(var5);
                              Log.w("HttpUrlPinger", var43.toString());
                              break label228;
                           } catch (Throwable var37) {
                              var51 = var37;
                              var10001 = false;
                              break label203;
                           }
                        }

                        Throwable var42 = var51;

                        try {
                           var47.disconnect();
                           throw var42;
                        } catch (IndexOutOfBoundsException var31) {
                           var50 = var31;
                           var10001 = false;
                           break label215;
                        } catch (IOException var32) {
                           var49 = var32;
                           var10001 = false;
                           break label214;
                        } catch (RuntimeException var33) {
                           var10000 = var33;
                           var10001 = false;
                           break label227;
                        }
                     }

                     try {
                        var47.disconnect();
                        return;
                     } catch (IndexOutOfBoundsException var34) {
                        var50 = var34;
                        var10001 = false;
                        break label215;
                     } catch (IOException var35) {
                        var49 = var35;
                        var10001 = false;
                        break label214;
                     } catch (RuntimeException var36) {
                        var10000 = var36;
                        var10001 = false;
                     }
                  }

                  var48 = var10000;
                  break label216;
               }

               var48 = var49;
               break label216;
            }

            var44 = var50;
            var4 = ((IndexOutOfBoundsException)var44).getMessage();
            var43 = new StringBuilder(c.a.b.a.a.b(var4, c.a.b.a.a.b(var5, 32)));
            var45 = "Error while parsing ping URL: ";
            break label217;
         }

         String var8 = ((Exception)var48).getMessage();
         var43 = new StringBuilder(c.a.b.a.a.b(var8, c.a.b.a.a.b(var5, 27)));
         var45 = "Error while pinging URL: ";
         var44 = var48;
         var4 = var8;
      }

      var43.append(var45);
      var43.append(var5);
      var43.append(". ");
      var43.append(var4);
      Log.w("HttpUrlPinger", var43.toString(), (Throwable)var44);
   }
}
