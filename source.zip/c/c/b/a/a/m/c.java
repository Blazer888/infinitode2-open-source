package c.c.b.a.a.m;

import android.content.Context;
import android.os.RemoteException;
import android.view.View;
import android.view.ViewGroup;
import c.c.b.a.a.e;
import c.c.b.a.a.h;
import c.c.b.a.a.k;
import c.c.b.a.a.l;
import c.c.b.a.i.a.c9;
import c.c.b.a.i.a.d8;
import c.c.b.a.i.a.u9;

public final class c extends ViewGroup {
   public final c9 a;

   public final c.c.b.a.a.b getAdListener() {
      return this.a.e;
   }

   public final e getAdSize() {
      return this.a.b();
   }

   public final e[] getAdSizes() {
      return this.a.f;
   }

   public final String getAdUnitId() {
      return this.a.c();
   }

   public final a getAppEventListener() {
      return this.a.g;
   }

   public final String getMediationAdapterClassName() {
      return this.a.d();
   }

   public final b getOnCustomRenderedAdLoadedListener() {
      this.a.e();
      return null;
   }

   public final k getVideoController() {
      return this.a.b;
   }

   public final l getVideoOptions() {
      return this.a.i;
   }

   public final void onLayout(boolean var1, int var2, int var3, int var4, int var5) {
      View var6 = this.getChildAt(0);
      if (var6 != null && var6.getVisibility() != 8) {
         int var7 = var6.getMeasuredWidth();
         int var8 = var6.getMeasuredHeight();
         var2 = (var4 - var2 - var7) / 2;
         var3 = (var5 - var3 - var8) / 2;
         var6.layout(var2, var3, var7 + var2, var8 + var3);
      }

   }

   public final void onMeasure(int var1, int var2) {
      int var3 = 0;
      View var4 = this.getChildAt(0);
      int var5;
      if (var4 != null && var4.getVisibility() != 8) {
         this.measureChild(var4, var1, var2);
         var3 = var4.getMeasuredWidth();
         var5 = var4.getMeasuredHeight();
      } else {
         e var8 = null;

         label20: {
            e var6;
            try {
               var6 = this.getAdSize();
            } catch (NullPointerException var7) {
               b.c.b.b.a((String)"Unable to retrieve ad size.", (Throwable)var7);
               break label20;
            }

            var8 = var6;
         }

         if (var8 != null) {
            Context var9 = this.getContext();
            var3 = var8.b(var9);
            var5 = var8.a(var9);
         } else {
            var5 = 0;
         }
      }

      var3 = Math.max(var3, this.getSuggestedMinimumWidth());
      var5 = Math.max(var5, this.getSuggestedMinimumHeight());
      this.setMeasuredDimension(View.resolveSize(var3, var1), View.resolveSize(var5, var2));
   }

   public final void setAdListener(c.c.b.a.a.b var1) {
      c9 var2 = this.a;
      var2.e = var1;
      var2.c.a(var1);
   }

   public final void setAdSizes(e... var1) {
      if (var1 != null && var1.length > 0) {
         this.a.a(var1);
      } else {
         throw new IllegalArgumentException("The supported ad sizes must contain at least one valid ad size.");
      }
   }

   public final void setAdUnitId(String var1) {
      this.a.a(var1);
   }

   public final void setAppEventListener(a var1) {
      this.a.a(var1);
   }

   @Deprecated
   public final void setCorrelator(h var1) {
   }

   public final void setManualImpressionsEnabled(boolean var1) {
      c9 var2 = this.a;
      var2.m = var1;

      RemoteException var10000;
      label28: {
         boolean var10001;
         d8 var3;
         try {
            var3 = var2.h;
         } catch (RemoteException var5) {
            var10000 = var5;
            var10001 = false;
            break label28;
         }

         if (var3 == null) {
            return;
         }

         try {
            var3.b(var2.m);
            return;
         } catch (RemoteException var4) {
            var10000 = var4;
            var10001 = false;
         }
      }

      RemoteException var6 = var10000;
      b.c.b.b.c((String)"#007 Could not call remote method.", (Throwable)var6);
   }

   public final void setOnCustomRenderedAdLoadedListener(b var1) {
      this.a.a(var1);
   }

   public final void setVideoOptions(l var1) {
      c9 var2 = this.a;
      var2.i = var1;

      RemoteException var10000;
      label37: {
         boolean var10001;
         d8 var8;
         try {
            var8 = var2.h;
         } catch (RemoteException var5) {
            var10000 = var5;
            var10001 = false;
            break label37;
         }

         if (var8 == null) {
            return;
         }

         u9 var6;
         if (var1 == null) {
            var6 = null;
         } else {
            try {
               var6 = new u9(var1);
            } catch (RemoteException var4) {
               var10000 = var4;
               var10001 = false;
               break label37;
            }
         }

         try {
            var8.a(var6);
            return;
         } catch (RemoteException var3) {
            var10000 = var3;
            var10001 = false;
         }
      }

      RemoteException var7 = var10000;
      b.c.b.b.c((String)"#007 Could not call remote method.", (Throwable)var7);
   }
}
