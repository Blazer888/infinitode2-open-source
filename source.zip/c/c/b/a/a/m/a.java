package c.c.b.a.a.m;

public interface a {
}
