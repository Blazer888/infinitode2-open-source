package c.c.b.a.b.a;

public final class b {
   public static final c.c.b.a.d.m.a.g a = new c.c.b.a.d.m.a.g();
   public static final c.c.b.a.d.m.a.a b = new e();
   public static final c.c.b.a.d.m.a c;
   public static final c.c.b.a.i.d.e d;

   static {
      c = new c.c.b.a.d.m.a("Auth.PROXY_API", b, a);
      d = new c.c.b.a.i.d.e();
   }
}
