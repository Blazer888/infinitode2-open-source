package c.c.b.a.b.a.d.e;

import android.os.IInterface;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.Status;

public interface t extends IInterface {
   void a(GoogleSignInAccount var1, Status var2);

   void a(Status var1);

   void b(Status var1);
}
