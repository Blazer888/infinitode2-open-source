package c.c.b.a.b.a.d.e;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;

public final class d implements Creator {
   // $FF: synthetic method
   public final Object createFromParcel(Parcel var1) {
      int var2 = b.c.b.b.b(var1);
      int var3 = 0;
      Bundle var4 = null;
      int var5 = 0;

      while(var1.dataPosition() < var2) {
         int var6 = var1.readInt();
         int var7 = '\uffff' & var6;
         if (var7 != 1) {
            if (var7 != 2) {
               if (var7 != 3) {
                  b.c.b.b.k(var1, var6);
               } else {
                  var4 = b.c.b.b.b(var1, var6);
               }
            } else {
               var5 = b.c.b.b.h(var1, var6);
            }
         } else {
            var3 = b.c.b.b.h(var1, var6);
         }
      }

      b.c.b.b.e(var1, var2);
      return new a(var3, var5, var4);
   }

   // $FF: synthetic method
   public final Object[] newArray(int var1) {
      return new a[var1];
   }
}
