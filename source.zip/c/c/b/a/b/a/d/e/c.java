package c.c.b.a.b.a.d.e;

import android.accounts.Account;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.text.TextUtils;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Scope;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class c {
   public static final Lock c = new ReentrantLock();
   public static c d;
   public final Lock a = new ReentrantLock();
   public final SharedPreferences b;

   public c(Context var1) {
      this.b = var1.getSharedPreferences("com.google.android.gms.signin", 0);
   }

   public static c a(Context var0) {
      b.c.b.b.a((Object)var0);
      c.lock();

      c var4;
      try {
         if (d == null) {
            c var1 = new c(var0.getApplicationContext());
            d = var1;
         }

         var4 = d;
      } finally {
         c.unlock();
      }

      return var4;
   }

   public static String b(String var0, String var1) {
      return c.a.b.a.a.a(c.a.b.a.a.b(var1, c.a.b.a.a.b(var0, 1)), var0, ":", var1);
   }

   public GoogleSignInAccount a() {
      String var1 = this.a("defaultGoogleSignInAccount");
      boolean var2 = TextUtils.isEmpty(var1);
      Object var3 = null;
      GoogleSignInAccount var6;
      if (var2) {
         var6 = (GoogleSignInAccount)var3;
      } else {
         String var4 = this.a(b("googleSignInAccount", var1));
         var6 = (GoogleSignInAccount)var3;
         if (var4 != null) {
            try {
               var6 = GoogleSignInAccount.a(var4);
            } catch (JSONException var5) {
               var6 = (GoogleSignInAccount)var3;
            }
         }
      }

      return var6;
   }

   public final String a(String var1) {
      this.a.lock();

      try {
         var1 = this.b.getString(var1, (String)null);
      } finally {
         this.a.unlock();
      }

      return var1;
   }

   public void a(GoogleSignInAccount var1, GoogleSignInOptions var2) {
      b.c.b.b.a((Object)var1);
      b.c.b.b.a((Object)var2);
      this.a("defaultGoogleSignInAccount", var1.i);
      b.c.b.b.a((Object)var1);
      b.c.b.b.a((Object)var2);
      String var3 = var1.i;
      String var4 = b("googleSignInAccount", var3);
      JSONObject var5 = new JSONObject();

      int var7;
      byte var8;
      int var9;
      JSONException var10000;
      boolean var10001;
      JSONException var38;
      JSONArray var46;
      label213: {
         label217: {
            String var6;
            try {
               var6 = var1.b;
            } catch (JSONException var35) {
               var10000 = var35;
               var10001 = false;
               break label217;
            }

            if (var6 != null) {
               try {
                  var5.put("id", var6);
               } catch (JSONException var34) {
                  var10000 = var34;
                  var10001 = false;
                  break label217;
               }
            }

            try {
               var6 = var1.c;
            } catch (JSONException var33) {
               var10000 = var33;
               var10001 = false;
               break label217;
            }

            if (var6 != null) {
               try {
                  var5.put("tokenId", var6);
               } catch (JSONException var32) {
                  var10000 = var32;
                  var10001 = false;
                  break label217;
               }
            }

            try {
               var6 = var1.d;
            } catch (JSONException var31) {
               var10000 = var31;
               var10001 = false;
               break label217;
            }

            if (var6 != null) {
               try {
                  var5.put("email", var6);
               } catch (JSONException var30) {
                  var10000 = var30;
                  var10001 = false;
                  break label217;
               }
            }

            try {
               var6 = var1.e;
            } catch (JSONException var29) {
               var10000 = var29;
               var10001 = false;
               break label217;
            }

            if (var6 != null) {
               try {
                  var5.put("displayName", var6);
               } catch (JSONException var28) {
                  var10000 = var28;
                  var10001 = false;
                  break label217;
               }
            }

            try {
               var6 = var1.k;
            } catch (JSONException var27) {
               var10000 = var27;
               var10001 = false;
               break label217;
            }

            if (var6 != null) {
               try {
                  var5.put("givenName", var6);
               } catch (JSONException var26) {
                  var10000 = var26;
                  var10001 = false;
                  break label217;
               }
            }

            try {
               var6 = var1.l;
            } catch (JSONException var25) {
               var10000 = var25;
               var10001 = false;
               break label217;
            }

            if (var6 != null) {
               try {
                  var5.put("familyName", var6);
               } catch (JSONException var24) {
                  var10000 = var24;
                  var10001 = false;
                  break label217;
               }
            }

            Uri var45;
            try {
               var45 = var1.f;
            } catch (JSONException var23) {
               var10000 = var23;
               var10001 = false;
               break label217;
            }

            if (var45 != null) {
               try {
                  var5.put("photoUrl", var45.toString());
               } catch (JSONException var22) {
                  var10000 = var22;
                  var10001 = false;
                  break label217;
               }
            }

            try {
               var6 = var1.g;
            } catch (JSONException var21) {
               var10000 = var21;
               var10001 = false;
               break label217;
            }

            if (var6 != null) {
               try {
                  var5.put("serverAuthCode", var6);
               } catch (JSONException var20) {
                  var10000 = var20;
                  var10001 = false;
                  break label217;
               }
            }

            Scope[] var37;
            try {
               var5.put("expirationTime", var1.h);
               var5.put("obfuscatedIdentifier", var1.i);
               var46 = new JSONArray();
               List var36 = var1.j;
               var37 = (Scope[])var36.toArray(new Scope[var36.size()]);
               Arrays.sort(var37, c.c.b.a.b.a.d.f.a);
               var7 = var37.length;
            } catch (JSONException var19) {
               var10000 = var19;
               var10001 = false;
               break label217;
            }

            var8 = 0;

            for(var9 = 0; var9 < var7; ++var9) {
               try {
                  var46.put(var37[var9].b);
               } catch (JSONException var18) {
                  var10000 = var18;
                  var10001 = false;
                  break label217;
               }
            }

            try {
               var5.put("grantedScopes", var46);
               break label213;
            } catch (JSONException var17) {
               var10000 = var17;
               var10001 = false;
            }
         }

         var38 = var10000;
         RuntimeException var39 = new RuntimeException(var38);
         throw var39;
      }

      var5.remove("serverAuthCode");
      this.a(var4, var5.toString());
      String var44 = b("googleSignInOptions", var3);
      JSONObject var40 = new JSONObject();

      label139: {
         label219: {
            ArrayList var41;
            try {
               var46 = new JSONArray();
               Collections.sort(var2.b, GoogleSignInOptions.q);
               var41 = var2.b;
               var7 = var41.size();
            } catch (JSONException var16) {
               var10000 = var16;
               var10001 = false;
               break label219;
            }

            var9 = var8;

            while(var9 < var7) {
               Object var43;
               try {
                  var43 = var41.get(var9);
               } catch (JSONException var15) {
                  var10000 = var15;
                  var10001 = false;
                  break label219;
               }

               ++var9;

               try {
                  var46.put(((Scope)var43).b);
               } catch (JSONException var14) {
                  var10000 = var14;
                  var10001 = false;
                  break label219;
               }
            }

            Account var42;
            try {
               var40.put("scopes", var46);
               var42 = var2.c;
            } catch (JSONException var13) {
               var10000 = var13;
               var10001 = false;
               break label219;
            }

            if (var42 != null) {
               try {
                  var40.put("accountName", var42.name);
               } catch (JSONException var12) {
                  var10000 = var12;
                  var10001 = false;
                  break label219;
               }
            }

            try {
               var40.put("idTokenRequested", var2.d);
               var40.put("forceCodeForRefreshToken", var2.f);
               var40.put("serverAuthRequested", var2.e);
               if (!TextUtils.isEmpty(var2.g)) {
                  var40.put("serverClientId", var2.g);
               }
            } catch (JSONException var11) {
               var10000 = var11;
               var10001 = false;
               break label219;
            }

            try {
               if (!TextUtils.isEmpty(var2.h)) {
                  var40.put("hostedDomain", var2.h);
               }
               break label139;
            } catch (JSONException var10) {
               var10000 = var10;
               var10001 = false;
            }
         }

         var38 = var10000;
         throw new RuntimeException(var38);
      }

      this.a(var44, var40.toString());
   }

   public final void a(String var1, String var2) {
      this.a.lock();

      try {
         this.b.edit().putString(var1, var2).apply();
      } finally {
         this.a.unlock();
      }

   }

   public GoogleSignInOptions b() {
      String var1 = this.a("defaultGoogleSignInAccount");
      boolean var2 = TextUtils.isEmpty(var1);
      Object var3 = null;
      GoogleSignInOptions var6;
      if (var2) {
         var6 = (GoogleSignInOptions)var3;
      } else {
         String var4 = this.a(b("googleSignInOptions", var1));
         var6 = (GoogleSignInOptions)var3;
         if (var4 != null) {
            try {
               var6 = GoogleSignInOptions.a(var4);
            } catch (JSONException var5) {
               var6 = (GoogleSignInOptions)var3;
            }
         }
      }

      return var6;
   }

   public final void b(String var1) {
      this.a.lock();

      try {
         this.b.edit().remove(var1).apply();
      } finally {
         this.a.unlock();
      }

   }
}
