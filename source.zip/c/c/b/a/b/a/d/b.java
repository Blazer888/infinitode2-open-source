package c.c.b.a.b.a.d;

import android.accounts.Account;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Looper;
import c.c.b.a.b.a.d.e.l;
import c.c.b.a.d.m.e;
import c.c.b.a.d.m.n.n;
import c.c.b.a.d.o.c0;
import c.c.b.a.d.o.d0;
import c.c.b.a.d.o.q;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.BasePendingResult;
import com.google.android.gms.dynamite.DynamiteModule;
import java.util.HashSet;

public class b extends c.c.b.a.d.m.d {
   public static final c.c.b.a.b.a.d.b.a j = new c.c.b.a.b.a.d.b.a((j)null);
   public static int k;

   public b(Activity var1, GoogleSignInOptions var2) {
      c.c.b.a.d.m.a var3 = c.c.b.a.b.a.a.e;
      c.c.b.a.d.m.n.a var4 = new c.c.b.a.d.m.n.a();
      b.c.b.b.b((Object)var4, (Object)"StatusExceptionMapper must not be null.");
      Looper var5 = var1.getMainLooper();
      b.c.b.b.b((Object)var5, (Object)"Looper must not be null.");
      Looper var6 = var5;
      if (var5 == null) {
         var6 = Looper.getMainLooper();
      }

      super(var1, var3, var2, new c.c.b.a.d.m.d.a(var4, (Account)null, var6));
   }

   public Intent c() {
      Context var1 = super.a;
      int var2 = c.c.b.a.b.a.d.j.a[this.f() - 1];
      GoogleSignInOptions var3;
      Intent var4;
      if (var2 != 1) {
         if (var2 != 2) {
            var3 = (GoogleSignInOptions)super.c;
            c.c.b.a.b.a.d.e.i.a.a("getNoImplementationSignInIntent()");
            var4 = c.c.b.a.b.a.d.e.i.a(var1, var3);
            var4.setAction("com.google.android.gms.auth.NO_IMPL");
            return var4;
         } else {
            return c.c.b.a.b.a.d.e.i.a(var1, (GoogleSignInOptions)super.c);
         }
      } else {
         var3 = (GoogleSignInOptions)super.c;
         c.c.b.a.b.a.d.e.i.a.a("getFallbackSignInIntent()");
         var4 = c.c.b.a.b.a.d.e.i.a(var1, var3);
         var4.setAction("com.google.android.gms.auth.APPAUTH_SIGN_IN");
         return var4;
      }
   }

   public c.c.b.a.l.g d() {
      e var1 = super.g;
      Context var2 = super.a;
      boolean var3;
      if (this.f() == 3) {
         var3 = true;
      } else {
         var3 = false;
      }

      c.c.b.a.b.a.d.e.i.a.a("Signing out");
      c.c.b.a.b.a.d.e.i.a(var2);
      Object var6;
      if (var3) {
         Status var7 = Status.e;
         b.c.b.b.b((Object)var7, (Object)"Result must not be null");
         var6 = new n(var1);
         ((BasePendingResult)var6).a((c.c.b.a.d.m.k)var7);
      } else {
         var6 = var1.b((c.c.b.a.d.m.n.c)(new l(var1)));
      }

      d0 var4 = new d0();
      q.b var8 = q.a;
      c.c.b.a.l.h var5 = new c.c.b.a.l.h();
      ((c.c.b.a.d.m.g)var6).a((c.c.b.a.d.m.g.a)(new c0((c.c.b.a.d.m.g)var6, var5, var4, var8)));
      return var5.a;
   }

   public c.c.b.a.l.g e() {
      e var1 = super.g;
      Context var2 = super.a;
      GoogleSignInOptions var3 = (GoogleSignInOptions)super.c;
      int var4 = this.f();
      boolean var5 = true;
      boolean var13;
      if (var4 == 3) {
         var13 = true;
      } else {
         var13 = false;
      }

      d var15;
      label54: {
         c.c.b.a.b.a.d.e.i.a.a("silentSignIn()");
         c.c.b.a.b.a.d.e.i.a.a("getEligibleSavedSignInResult()");
         b.c.b.b.a((Object)var3);
         GoogleSignInOptions var6 = c.c.b.a.b.a.d.e.q.a(var2).c();
         if (var6 != null) {
            Account var7 = var6.c;
            Account var8 = var3.c;
            boolean var9;
            if (var7 == null) {
               if (var8 == null) {
                  var9 = true;
               } else {
                  var9 = false;
               }
            } else {
               var9 = var7.equals(var8);
            }

            if (var9 && !var3.e && (!var3.d || var6.d && var3.g.equals(var6.g)) && (new HashSet(var6.a())).containsAll(new HashSet(var3.a()))) {
               GoogleSignInAccount var14 = c.c.b.a.b.a.d.e.q.a(var2).b();
               if (var14 != null) {
                  if (((c.c.b.a.d.r.c)GoogleSignInAccount.n).a() / 1000L < var14.h - 300L) {
                     var5 = false;
                  }

                  if (!var5) {
                     var15 = new d(var14, Status.e);
                     break label54;
                  }
               }
            }
         }

         var15 = null;
      }

      Object var16;
      if (var15 != null) {
         c.c.b.a.b.a.d.e.i.a.a("Eligible saved sign in result found");
         var16 = b.c.b.b.a((c.c.b.a.d.m.k)var15, (e)var1);
      } else if (var13) {
         var16 = b.c.b.b.a((c.c.b.a.d.m.k)(new d((GoogleSignInAccount)null, new Status(4))), (e)var1);
      } else {
         c.c.b.a.b.a.d.e.i.a.a("trySilentSignIn()");
         var16 = new c.c.b.a.d.m.n.k(var1.a((c.c.b.a.d.m.n.c)(new c.c.b.a.b.a.d.e.j(var1, var2, var3))));
      }

      c.c.b.a.b.a.d.b.a var12 = j;
      q.b var11 = q.a;
      c.c.b.a.l.h var10 = new c.c.b.a.l.h();
      ((c.c.b.a.d.m.g)var16).a((c.c.b.a.d.m.g.a)(new c0((c.c.b.a.d.m.g)var16, var10, var12, var11)));
      return var10.a;
   }

   public final int f() {
      synchronized(this){}

      Throwable var10000;
      label311: {
         boolean var10001;
         int var3;
         label316: {
            Context var1;
            c.c.b.a.d.e var2;
            try {
               if (k != 1) {
                  break label316;
               }

               var1 = super.a;
               var2 = c.c.b.a.d.e.d;
               var3 = var2.a(var1, 12451000);
            } catch (Throwable var32) {
               var10000 = var32;
               var10001 = false;
               break label311;
            }

            if (var3 == 0) {
               try {
                  k = 4;
               } catch (Throwable var31) {
                  var10000 = var31;
                  var10001 = false;
                  break label311;
               }
            } else {
               label319: {
                  try {
                     if (var2.a(var1, var3, (String)null) == null && DynamiteModule.a(var1, "com.google.android.gms.auth.api.fallback") != 0) {
                        k = 3;
                        break label319;
                     }
                  } catch (Throwable var33) {
                     var10000 = var33;
                     var10001 = false;
                     break label311;
                  }

                  try {
                     k = 2;
                  } catch (Throwable var30) {
                     var10000 = var30;
                     var10001 = false;
                     break label311;
                  }
               }
            }
         }

         label290:
         try {
            var3 = k;
            return var3;
         } catch (Throwable var29) {
            var10000 = var29;
            var10001 = false;
            break label290;
         }
      }

      Throwable var34 = var10000;
      throw var34;
   }

   public static final class a implements q.a {
      // $FF: synthetic method
      public a(j var1) {
      }

      // $FF: synthetic method
      public final Object a(c.c.b.a.d.m.k var1) {
         return ((d)var1).b;
      }
   }

   public static enum b {
      a = 1,
      b = 2,
      c = 3,
      d = 4;

      // $FF: synthetic field
      public static final int[] e;

      static {
         e = new int[]{a, b, c, d};
      }
   }
}
