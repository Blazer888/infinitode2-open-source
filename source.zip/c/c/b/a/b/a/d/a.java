package c.c.b.a.b.a.d;

public interface a {
}
