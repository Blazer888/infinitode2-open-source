package c.c.b.a.b.a.d.e;

public class b {
   public int a = 1;

   public b a(Object var1) {
      int var2 = this.a;
      int var3;
      if (var1 == null) {
         var3 = 0;
      } else {
         var3 = var1.hashCode();
      }

      this.a = 31 * var2 + var3;
      return this;
   }

   public final b a(boolean var1) {
      this.a = 31 * this.a + var1;
      return this;
   }
}
