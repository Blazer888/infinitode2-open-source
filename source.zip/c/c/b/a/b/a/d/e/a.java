package c.c.b.a.b.a.d.e;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;

public class a extends c.c.b.a.d.o.v.a {
   public static final Creator CREATOR = new d();
   public final int a;
   public int b;
   public Bundle c;

   public a(int var1, int var2, Bundle var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var2 = b.c.b.b.a(var1);
      b.c.b.b.a(var1, 1, this.a);
      b.c.b.b.a(var1, 2, this.b);
      b.c.b.b.a(var1, 3, (Bundle)this.c, false);
      b.c.b.b.m(var1, var2);
   }
}
