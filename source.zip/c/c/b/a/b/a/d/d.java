package c.c.b.a.b.a.d;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.Status;

public class d implements c.c.b.a.d.m.k {
   public Status a;
   public GoogleSignInAccount b;

   public d(GoogleSignInAccount var1, Status var2) {
      this.b = var1;
      this.a = var2;
   }

   public Status getStatus() {
      return this.a;
   }
}
