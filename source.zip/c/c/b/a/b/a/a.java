package c.c.b.a.b.a;

import android.os.Bundle;

public final class a {
   public static final c.c.b.a.d.m.a.g a = new c.c.b.a.d.m.a.g();
   public static final c.c.b.a.d.m.a.g b = new c.c.b.a.d.m.a.g();
   public static final c.c.b.a.d.m.a.a c = new f();
   public static final c.c.b.a.d.m.a.a d = new g();
   public static final c.c.b.a.d.m.a e;
   public static final c.c.b.a.b.a.d.a f;

   static {
      c.c.b.a.d.m.a var0 = c.c.b.a.b.a.b.c;
      c.c.b.a.d.m.a.a var2 = c;
      c.c.b.a.d.m.a.g var1 = a;
      b.c.b.b.b((Object)var2, (Object)"Cannot construct an Api with a null ClientBuilder");
      b.c.b.b.b((Object)var1, (Object)"Cannot construct an Api with a null ClientKey");
      e = new c.c.b.a.d.m.a("Auth.GOOGLE_SIGN_IN_API", d, b);
      c.c.b.a.i.d.e var3 = c.c.b.a.b.a.b.d;
      f = new c.c.b.a.b.a.d.e.g();
   }

   @Deprecated
   public static class a implements c.c.b.a.d.m.a.d.e {
      public final boolean a;

      static {
         (new c.c.b.a.b.a.a.a.a()).a();
      }

      public a(c.c.b.a.b.a.a.a.a var1) {
         this.a = var1.a;
      }

      public final Bundle a() {
         Bundle var1 = new Bundle();
         var1.putString("consumer_package", (String)null);
         var1.putBoolean("force_save_dialog", this.a);
         return var1;
      }

      @Deprecated
      public static class a {
         public Boolean a = false;

         public c.c.b.a.b.a.a.a a() {
            return new c.c.b.a.b.a.a.a(this);
         }
      }
   }
}
