package c.c.b.a.d.o.v;

public abstract class a implements c {
   public final int describeContents() {
      return 0;
   }
}
