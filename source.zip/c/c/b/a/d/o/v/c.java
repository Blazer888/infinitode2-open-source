package c.c.b.a.d.o.v;

import android.os.Parcelable;

public interface c extends Parcelable {
   String NULL = "SAFE_PARCELABLE_NULL_STRING";
}
