package c.c.b.a.d.m;

import com.google.android.gms.common.api.Status;

public interface k {
   Status getStatus();
}
