package c.c.b.a.d.m;

import android.accounts.Account;
import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import c.c.b.a.d.m.n.f1;
import c.c.b.a.d.m.n.n1;
import c.c.b.a.d.m.n.t;
import c.c.b.a.d.m.n.z1;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.GoogleApiActivity;
import java.util.Collections;
import java.util.Set;

public class d {
   public final Context a;
   public final c.c.b.a.d.m.a b;
   public final c.c.b.a.d.m.a.d c;
   public final z1 d;
   public final Looper e;
   public final int f;
   public final e g;
   public final c.c.b.a.d.m.n.a h;
   public final c.c.b.a.d.m.n.e i;

   public d(Activity var1, c.c.b.a.d.m.a var2, c.c.b.a.d.m.a.d var3, d.a var4) {
      b.c.b.b.b((Object)var1, (Object)"Null activity is not permitted.");
      b.c.b.b.b((Object)var2, (Object)"Api must not be null.");
      b.c.b.b.b((Object)var4, (Object)"Settings must not be null; use Settings.DEFAULT_SETTINGS instead.");
      this.a = var1.getApplicationContext();
      this.b = var2;
      this.c = var3;
      this.e = var4.b;
      this.d = new z1(this.b, this.c);
      this.g = new f1(this);
      this.i = c.c.b.a.d.m.n.e.a(this.a);
      this.f = this.i.g.getAndIncrement();
      this.h = var4.a;
      if (!(var1 instanceof GoogleApiActivity)) {
         t.a(var1, this.i, this.d);
      }

      Handler var5 = this.i.m;
      var5.sendMessage(var5.obtainMessage(7, this));
   }

   public d(Context var1, c.c.b.a.d.m.a var2, Looper var3) {
      b.c.b.b.b((Object)var1, (Object)"Null context is not permitted.");
      b.c.b.b.b((Object)var2, (Object)"Api must not be null.");
      b.c.b.b.b((Object)var3, (Object)"Looper must not be null.");
      this.a = var1.getApplicationContext();
      this.b = var2;
      this.c = null;
      this.e = var3;
      this.d = new z1(var2);
      this.g = new f1(this);
      this.i = c.c.b.a.d.m.n.e.a(this.a);
      this.f = this.i.g.getAndIncrement();
      this.h = new c.c.b.a.d.m.n.a();
   }

   public c.c.b.a.d.m.a.f a(Looper var1, c.c.b.a.d.m.n.e.a var2) {
      c.c.b.a.d.o.c var3 = this.a().a();
      c.c.b.a.d.m.a var4 = this.b;
      boolean var5;
      if (var4.a != null) {
         var5 = true;
      } else {
         var5 = false;
      }

      b.c.b.b.b(var5, "This API was constructed with a SimpleClientBuilder. Use getSimpleClientBuilder");
      return var4.a.a(this.a, var1, var3, this.c, var2, var2);
   }

   public c.c.b.a.d.m.n.c a(c.c.b.a.d.m.n.c var1) {
      var1.f();
      this.i.a(this, 0, var1);
      return var1;
   }

   public n1 a(Context var1, Handler var2) {
      return new n1(var1, var2, this.a().a(), n1.h);
   }

   public c.c.b.a.d.o.c.a a() {
      c.c.b.a.d.o.c.a var1;
      c.c.b.a.d.m.a.d var2;
      GoogleSignInAccount var3;
      Account var4;
      label33: {
         label32: {
            var1 = new c.c.b.a.d.o.c.a();
            var2 = this.c;
            if (var2 instanceof c.c.b.a.d.m.a.d.b) {
               var3 = ((c.c.b.a.h.b.a)var2).k;
               if (var3 != null) {
                  String var5 = var3.d;
                  if (var5 != null) {
                     var4 = new Account(var5, "com.google");
                     break label33;
                  }
                  break label32;
               }
            }

            var2 = this.c;
            if (var2 instanceof c.c.b.a.d.m.a.d.a) {
               var4 = ((c.c.b.a.d.m.a.d.a)var2).a();
               break label33;
            }
         }

         var4 = null;
      }

      Set var6;
      label24: {
         var1.a = var4;
         var2 = this.c;
         if (var2 instanceof c.c.b.a.d.m.a.d.b) {
            var3 = ((c.c.b.a.h.b.a)var2).k;
            if (var3 != null) {
               var6 = var3.a();
               break label24;
            }
         }

         var6 = Collections.emptySet();
      }

      if (var1.b == null) {
         var1.b = new b.b.c();
      }

      var1.b.addAll(var6);
      var1.g = this.a.getClass().getName();
      var1.f = this.a.getPackageName();
      return var1;
   }

   public c.c.b.a.l.g a(c.c.b.a.d.m.n.o var1) {
      c.c.b.a.l.h var2 = new c.c.b.a.l.h();
      this.i.a(this, 1, var1, var2, this.h);
      return var2.a;
   }

   public final c.c.b.a.d.m.a b() {
      return this.b;
   }

   public c.c.b.a.d.m.n.c b(c.c.b.a.d.m.n.c var1) {
      var1.f();
      this.i.a(this, 1, var1);
      return var1;
   }

   public static class a {
      public static final d.a c = new d.a(new c.c.b.a.d.m.n.a(), (Account)null, Looper.getMainLooper());
      public final c.c.b.a.d.m.n.a a;
      public final Looper b;

      // $FF: synthetic method
      public a(c.c.b.a.d.m.n.a var1, Account var2, Looper var3) {
         this.a = var1;
         this.b = var3;
      }
   }
}
