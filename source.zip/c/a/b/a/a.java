package c.a.b.a;

import android.os.RemoteException;
import b.c.b.b;
import b.d.a.d;
import c.b.a.f;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g3d.particles.values.ScaledNumericValue;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.scenes.scene2d.Group;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Json;
import com.badlogic.gdx.utils.StringBuilder;
import com.prineside.tdi2.Logger;
import com.prineside.tdi2.managers.LocaleManager;
import java.io.StringWriter;

public class a {
   public static float a(float var0, float var1, float var2, float var3) {
      return (var0 - var1) * var2 + var3;
   }

   public static float a(float var0, float var1, float var2, float var3, float var4, float var5) {
      return MathUtils.clamp(var0 / var1 * var2 + var3, var4, var5);
   }

   public static float a(ScaledNumericValue var0, float var1, float var2, float var3) {
      return var0.getScale(var1) * var2 + var3;
   }

   public static RemoteException a(String var0, Throwable var1) {
      b.a(var0, var1);
      return new RemoteException();
   }

   public static Group a(boolean var0) {
      Group var1 = new Group();
      var1.setTransform(var0);
      return var1;
   }

   public static Group a(boolean var0, float var1, float var2) {
      Group var3 = new Group();
      var3.setTransform(var0);
      var3.setSize(var1, var2);
      return var3;
   }

   public static Drawable a(float var0, float var1, float var2, float var3, TextureRegionDrawable var4) {
      return var4.tint(new Color(var0, var1, var2, var3));
   }

   public static StringBuilder a(int var0, char var1) {
      StringBuilder var2 = new StringBuilder(var0);
      var2.append(var1);
      return var2;
   }

   public static StringWriter a(Json var0) {
      StringWriter var1 = new StringWriter();
      var0.setWriter(var1);
      var0.writeArrayStart();
      return var1;
   }

   public static String a(int var0, String var1, int var2, String var3, int var4) {
      java.lang.StringBuilder var5 = new java.lang.StringBuilder(var0);
      var5.append(var1);
      var5.append(var2);
      var5.append(var3);
      var5.append(var4);
      return var5.toString();
   }

   public static String a(int var0, String var1, String var2, String var3) {
      java.lang.StringBuilder var4 = new java.lang.StringBuilder(var0);
      var4.append(var1);
      var4.append(var2);
      var4.append(var3);
      return var4.toString();
   }

   public static String a(Class var0, java.lang.StringBuilder var1) {
      var1.append(var0.getName());
      return var1.toString();
   }

   public static String a(String var0, float var1) {
      java.lang.StringBuilder var2 = new java.lang.StringBuilder();
      var2.append(var0);
      var2.append(var1);
      return var2.toString();
   }

   public static String a(String var0, int var1) {
      java.lang.StringBuilder var2 = new java.lang.StringBuilder();
      var2.append(var0);
      var2.append(var1);
      return var2.toString();
   }

   public static String a(String var0, int var1, String var2) {
      java.lang.StringBuilder var3 = new java.lang.StringBuilder();
      var3.append(var0);
      var3.append(var1);
      var3.append(var2);
      return var3.toString();
   }

   public static String a(String var0, d var1, String var2) {
      java.lang.StringBuilder var3 = new java.lang.StringBuilder();
      var3.append(var0);
      var3.append(var1);
      var3.append(var2);
      return var3.toString();
   }

   public static String a(String var0, String var1) {
      java.lang.StringBuilder var2 = new java.lang.StringBuilder();
      var2.append(var0);
      var2.append(var1);
      return var2.toString();
   }

   public static String a(String var0, String var1, String var2) {
      java.lang.StringBuilder var3 = new java.lang.StringBuilder();
      var3.append(var0);
      var3.append(var1);
      var3.append(var2);
      return var3.toString();
   }

   public static String a(java.lang.StringBuilder var0, int var1, String var2) {
      var0.append(var1);
      var0.append(var2);
      return var0.toString();
   }

   public static String a(java.lang.StringBuilder var0, String var1, String var2) {
      var0.append(var1);
      var0.append(var2);
      return var0.toString();
   }

   public static String a(java.lang.StringBuilder var0, String var1, String var2, String var3) {
      var0.append(var1);
      var0.append(var2);
      var0.append(var3);
      return var0.toString();
   }

   public static StringBuffer a(String var0) {
      StringBuffer var1 = new StringBuffer();
      var1.append(var0);
      return var1;
   }

   public static java.lang.StringBuilder a(String var0, int var1, String var2, int var3, String var4) {
      java.lang.StringBuilder var5 = new java.lang.StringBuilder();
      var5.append(var0);
      var5.append(var1);
      var5.append(var2);
      var5.append(var3);
      var5.append(var4);
      return var5;
   }

   public static void a(int var0, Image var1, float var2, float var3) {
      var1.setColor(new Color(var0));
      var1.setSize(var2, var3);
   }

   public static void a(LocaleManager.I18NBundleWithLinks var0, String var1, java.lang.StringBuilder var2, String var3) {
      var2.append(var0.get(var1));
      var2.append(var3);
   }

   public static void a(Class var0, java.lang.StringBuilder var1, String var2, f var3) {
      var1.append(var0.getName());
      var1.append(var2);
      var3.a(var1.toString());
   }

   public static void a(java.lang.StringBuilder var0, String var1, char var2, String var3) {
      var0.append(var1);
      var0.append(var2);
      var0.append(var3);
   }

   public static float b(float var0, float var1, float var2, float var3) {
      return var0 * var1 + var2 + var3;
   }

   public static int b(String var0, int var1) {
      return String.valueOf(var0).length() + var1;
   }

   public static java.lang.StringBuilder b(String var0) {
      java.lang.StringBuilder var1 = new java.lang.StringBuilder();
      var1.append(var0);
      return var1;
   }

   public static java.lang.StringBuilder b(String var0, int var1, String var2) {
      java.lang.StringBuilder var3 = new java.lang.StringBuilder();
      var3.append(var0);
      var3.append(var1);
      var3.append(var2);
      return var3;
   }

   public static java.lang.StringBuilder b(String var0, String var1) {
      java.lang.StringBuilder var2 = new java.lang.StringBuilder();
      var2.append(var0);
      var2.append(var1);
      return var2;
   }

   public static java.lang.StringBuilder b(String var0, String var1, String var2) {
      java.lang.StringBuilder var3 = new java.lang.StringBuilder();
      var3.append(var0);
      var3.append(var1);
      var3.append(var2);
      return var3;
   }

   public static void c(String var0, String var1, String var2) {
      java.lang.StringBuilder var3 = new java.lang.StringBuilder();
      var3.append(var0);
      var3.append(var1);
      Logger.error(var2, var3.toString());
   }
}
