package c.a.a.b;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import c.a.a.a.j;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;

public final class a {
   public static int a = Runtime.getRuntime().availableProcessors();

   public static int a(Intent var0, String var1) {
      if (var0 == null) {
         c("BillingHelper", "Got null intent!");
         return 6;
      } else {
         return a(var0.getExtras(), var1);
      }
   }

   public static int a(Bundle var0, String var1) {
      if (var0 == null) {
         c(var1, "Unexpected null bundle received!");
         return 6;
      } else {
         Object var3 = var0.get("RESPONSE_CODE");
         if (var3 == null) {
            b(var1, "getResponseCodeFromBundle() got null response code, assuming OK");
            return 0;
         } else if (var3 instanceof Integer) {
            return (Integer)var3;
         } else {
            StringBuilder var2 = c.a.b.a.a.b("Unexpected type for bundle response code: ");
            var2.append(var3.getClass().getName());
            c(var1, var2.toString());
            return 6;
         }
      }
   }

   public static j a(String var0, String var1) {
      Object var2 = null;
      if (var0 != null && var1 != null) {
         j var3;
         j var5;
         try {
            var3 = new j(var0, var1);
         } catch (JSONException var4) {
            StringBuilder var6 = new StringBuilder();
            var6.append("Got JSONException while parsing purchase data: ");
            var6.append(var4);
            c("BillingHelper", var6.toString());
            var5 = (j)var2;
            return var5;
         }

         var5 = var3;
         return var5;
      } else {
         c("BillingHelper", "Received a bad purchase data.");
         return null;
      }
   }

   public static List a(Bundle var0) {
      if (var0 == null) {
         return null;
      } else {
         ArrayList var1 = var0.getStringArrayList("INAPP_PURCHASE_DATA_LIST");
         ArrayList var2 = var0.getStringArrayList("INAPP_DATA_SIGNATURE_LIST");
         ArrayList var3 = new ArrayList();
         j var5;
         if (var1 != null && var2 != null) {
            for(int var4 = 0; var4 < var1.size() && var4 < var2.size(); ++var4) {
               var5 = a((String)var1.get(var4), (String)var2.get(var4));
               if (var5 != null) {
                  var3.add(var5);
               }
            }
         } else {
            c("BillingHelper", "Couldn't find purchase lists, trying to find single data.");
            var5 = a(var0.getString("INAPP_PURCHASE_DATA"), var0.getString("INAPP_DATA_SIGNATURE"));
            if (var5 == null) {
               c("BillingHelper", "Couldn't find single purchase data as well.");
               return null;
            }

            var3.add(var5);
         }

         return var3;
      }
   }

   public static void b(String var0, String var1) {
      if (Log.isLoggable(var0, 2)) {
         Log.v(var0, var1);
      }

   }

   public static void c(String var0, String var1) {
      if (Log.isLoggable(var0, 5)) {
         Log.w(var0, var1);
      }

   }
}
