package c.a.a.a;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import com.android.vending.billing.IInAppBillingService;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import org.json.JSONException;

public class c extends b {
   public int a = 0;
   public final Handler b = new Handler();
   public final a c;
   public final Context d;
   public IInAppBillingService e;
   public ServiceConnection f;
   public boolean g;
   public boolean h;
   public boolean i;
   public ExecutorService j;
   public final BroadcastReceiver k = new BroadcastReceiver() {
      public void onReceive(Context var1, Intent var2) {
         k var3 = c.this.c.b.a;
         if (var3 == null) {
            c.a.a.b.a.c("BillingClient", "PurchasesUpdatedListener is null - no way to return the response.");
         } else {
            var3.onPurchasesUpdated(var2.getIntExtra("response_code_key", 6), c.a.a.b.a.a(var2.getBundleExtra("response_bundle_key")));
         }
      }
   };

   public c(Context var1, k var2) {
      this.d = var1.getApplicationContext();
      this.c = new a(this.d, var2);
   }

   public final int a(int var1) {
      this.c.b.a.onPurchasesUpdated(var1, (List)null);
      return var1;
   }

   public final Bundle a(g var1) {
      Bundle var2 = new Bundle();
      int var3 = var1.f;
      if (var3 != 0) {
         var2.putInt("prorationMode", var3);
      }

      String var4 = var1.d;
      if (var4 != null) {
         var2.putString("accountId", var4);
      }

      if (var1.e) {
         var2.putBoolean("vr", true);
      }

      String var5 = var1.c;
      if (var5 != null) {
         var2.putStringArrayList("skusToReplace", new ArrayList(Arrays.asList(var5)));
      }

      return var2;
   }

   public l.a a(String var1, List var2) {
      ArrayList var3 = new ArrayList();
      int var4 = var2.size();

      int var6;
      for(int var5 = 0; var5 < var4; var5 = var6) {
         var6 = var5 + 20;
         int var7;
         if (var6 > var4) {
            var7 = var4;
         } else {
            var7 = var6;
         }

         ArrayList var8 = new ArrayList(var2.subList(var5, var7));
         Bundle var9 = new Bundle();
         var9.putStringArrayList("ITEM_ID_LIST", var8);
         var9.putString("libraryVersion", "1.1");

         StringBuilder var13;
         Bundle var14;
         try {
            var14 = this.e.b(3, this.d.getPackageName(), var1, var9);
         } catch (RemoteException var11) {
            var13 = new StringBuilder();
            var13.append("querySkuDetailsAsync got a remote exception (try to reconnect): ");
            var13.append(var11);
            c.a.a.b.a.c("BillingClient", var13.toString());
            return new l.a(-1, (List)null);
         }

         if (var14 == null) {
            c.a.a.b.a.c("BillingClient", "querySkuDetailsAsync got null sku details list");
            return new l.a(4, (List)null);
         }

         if (!var14.containsKey("DETAILS_LIST")) {
            var6 = c.a.a.b.a.a(var14, "BillingClient");
            if (var6 != 0) {
               var13 = new StringBuilder();
               var13.append("getSkuDetails() failed. Response code: ");
               var13.append(var6);
               c.a.a.b.a.c("BillingClient", var13.toString());
               return new l.a(var6, var3);
            }

            c.a.a.b.a.c("BillingClient", "getSkuDetails() returned a bundle with neither an error nor a detail list.");
            return new l.a(6, var3);
         }

         var8 = var14.getStringArrayList("DETAILS_LIST");
         if (var8 == null) {
            c.a.a.b.a.c("BillingClient", "querySkuDetailsAsync got null response list");
            return new l.a(4, (List)null);
         }

         for(var5 = 0; var5 < var8.size(); ++var5) {
            String var15 = (String)var8.get(var5);

            l var10;
            try {
               var10 = new l(var15);
            } catch (JSONException var12) {
               c.a.a.b.a.c("BillingClient", "Got a JSON exception trying to decode SkuDetails");
               return new l.a(6, (List)null);
            }

            StringBuilder var16 = new StringBuilder();
            var16.append("Got sku details: ");
            var16.append(var10);
            c.a.a.b.a.b("BillingClient", var16.toString());
            var3.add(var10);
         }
      }

      return new l.a(0, var3);
   }

   public void a() {
      try {
         c.a.a.a.i.a(this.d).a(this.k);
         this.c.a();
         if (this.f != null && this.e != null) {
            c.a.a.b.a.b("BillingClient", "Unbinding from service.");
            this.d.unbindService(this.f);
            this.f = null;
         }

         this.e = null;
         if (this.j != null) {
            this.j.shutdownNow();
            this.j = null;
         }
      } catch (Exception var5) {
         StringBuilder var2 = new StringBuilder();
         var2.append("There was an exception while ending connection: ");
         var2.append(var5);
         c.a.a.b.a.c("BillingClient", var2.toString());
      } finally {
         this.a = 3;
      }

   }

   public final void a(final String var1, final h var2) {
      RemoteException var10000;
      label36: {
         StringBuilder var3;
         final int var4;
         boolean var10001;
         try {
            var3 = new StringBuilder();
            var3.append("Consuming purchase with token: ");
            var3.append(var1);
            c.a.a.b.a.b("BillingClient", var3.toString());
            var4 = this.e.c(3, this.d.getPackageName(), var1);
         } catch (RemoteException var8) {
            var10000 = var8;
            var10001 = false;
            break label36;
         }

         Runnable var10;
         if (var4 == 0) {
            label39: {
               try {
                  c.a.a.b.a.b("BillingClient", "Successfully consumed purchase.");
               } catch (RemoteException var6) {
                  var10000 = var6;
                  var10001 = false;
                  break label39;
               }

               if (var2 == null) {
                  return;
               }

               try {
                  var10 = new Runnable(this) {
                     public void run() {
                        var2.onConsumeResponse(var4, var1);
                     }
                  };
                  this.b.post(var10);
                  return;
               } catch (RemoteException var5) {
                  var10000 = var5;
                  var10001 = false;
               }
            }
         } else {
            try {
               var3 = new StringBuilder();
               var3.append("Error consuming purchase with token. Response code: ");
               var3.append(var4);
               c.a.a.b.a.c("BillingClient", var3.toString());
               var10 = new Runnable(this) {
                  public void run() {
                     c.a.a.b.a.c("BillingClient", "Error consuming purchase.");
                     var2.onConsumeResponse(var4, var1);
                  }
               };
               this.b.post(var10);
               return;
            } catch (RemoteException var7) {
               var10000 = var7;
               var10001 = false;
            }
         }
      }

      final RemoteException var11 = var10000;
      Runnable var9 = new Runnable(this) {
         public void run() {
            StringBuilder var1x = c.a.b.a.a.b("Error consuming purchase; ex: ");
            var1x.append(var11);
            c.a.a.b.a.c("BillingClient", var1x.toString());
            var2.onConsumeResponse(-1, var1);
         }
      };
      this.b.post(var9);
   }

   public boolean b() {
      boolean var1;
      if (this.a == 2 && this.e != null && this.f != null) {
         var1 = true;
      } else {
         var1 = false;
      }

      return var1;
   }

   public final class e implements ServiceConnection {
      public final f a;

      // $FF: synthetic method
      public e(f var2, Object var3) {
         if (var2 != null) {
            this.a = var2;
         } else {
            throw new RuntimeException("Please specify a listener to know when init is done.");
         }
      }

      public void onServiceConnected(ComponentName var1, IBinder var2) {
         c.a.a.b.a.b("BillingClient", "Billing service connected.");
         c.this.e = IInAppBillingService.Stub.a(var2);
         String var20 = c.this.d.getPackageName();
         c var18 = c.this;
         var18.g = false;
         var18.h = false;
         var18.i = false;

         RemoteException var10000;
         label107: {
            int var3;
            boolean var10001;
            try {
               var3 = var18.e.b(6, var20, "subs");
            } catch (RemoteException var17) {
               var10000 = var17;
               var10001 = false;
               break label107;
            }

            if (var3 == 0) {
               try {
                  c.a.a.b.a.b("BillingClient", "In-app billing API version 6 with subs is supported.");
                  c.this.i = true;
                  c.this.g = true;
                  c.this.h = true;
               } catch (RemoteException var14) {
                  var10000 = var14;
                  var10001 = false;
                  break label107;
               }
            } else {
               try {
                  if (c.this.e.b(6, var20, "inapp") == 0) {
                     c.a.a.b.a.b("BillingClient", "In-app billing API without subs version 6 supported.");
                     c.this.i = true;
                  }
               } catch (RemoteException var16) {
                  var10000 = var16;
                  var10001 = false;
                  break label107;
               }

               try {
                  var3 = c.this.e.b(5, var20, "subs");
               } catch (RemoteException var13) {
                  var10000 = var13;
                  var10001 = false;
                  break label107;
               }

               if (var3 == 0) {
                  try {
                     c.a.a.b.a.b("BillingClient", "In-app billing API version 5 supported.");
                     c.this.h = true;
                     c.this.g = true;
                  } catch (RemoteException var12) {
                     var10000 = var12;
                     var10001 = false;
                     break label107;
                  }
               } else {
                  try {
                     var3 = c.this.e.b(3, var20, "subs");
                  } catch (RemoteException var11) {
                     var10000 = var11;
                     var10001 = false;
                     break label107;
                  }

                  if (var3 == 0) {
                     try {
                        c.a.a.b.a.b("BillingClient", "In-app billing API version 3 with subscriptions is supported.");
                        c.this.g = true;
                     } catch (RemoteException var10) {
                        var10000 = var10;
                        var10001 = false;
                        break label107;
                     }
                  } else {
                     label88: {
                        label109: {
                           try {
                              if (c.this.i) {
                                 break label109;
                              }
                           } catch (RemoteException var15) {
                              var10000 = var15;
                              var10001 = false;
                              break label107;
                           }

                           try {
                              var3 = c.this.e.b(3, var20, "inapp");
                           } catch (RemoteException var9) {
                              var10000 = var9;
                              var10001 = false;
                              break label107;
                           }

                           if (var3 == 0) {
                              try {
                                 c.a.a.b.a.b("BillingClient", "In-app billing API version 3 with in-app items is supported.");
                                 break label88;
                              } catch (RemoteException var8) {
                                 var10000 = var8;
                                 var10001 = false;
                                 break label107;
                              }
                           } else {
                              try {
                                 c.a.a.b.a.c("BillingClient", "Even billing API version 3 is not supported on this device.");
                                 break label88;
                              } catch (RemoteException var7) {
                                 var10000 = var7;
                                 var10001 = false;
                                 break label107;
                              }
                           }
                        }

                        var3 = 0;
                     }
                  }
               }
            }

            if (var3 == 0) {
               try {
                  c.this.a = 2;
               } catch (RemoteException var6) {
                  var10000 = var6;
                  var10001 = false;
                  break label107;
               }
            } else {
               try {
                  c.this.a = 0;
                  c.this.e = null;
               } catch (RemoteException var5) {
                  var10000 = var5;
                  var10001 = false;
                  break label107;
               }
            }

            try {
               this.a.onBillingSetupFinished(var3);
               return;
            } catch (RemoteException var4) {
               var10000 = var4;
               var10001 = false;
            }
         }

         RemoteException var21 = var10000;
         StringBuilder var19 = new StringBuilder();
         var19.append("RemoteException while setting up in-app billing");
         var19.append(var21);
         c.a.a.b.a.c("BillingClient", var19.toString());
         var18 = c.this;
         var18.a = 0;
         var18.e = null;
         this.a.onBillingSetupFinished(-1);
      }

      public void onServiceDisconnected(ComponentName var1) {
         c.a.a.b.a.c("BillingClient", "Billing service disconnected.");
         c var2 = c.this;
         var2.e = null;
         var2.a = 0;
         this.a.onBillingServiceDisconnected();
      }
   }
}
