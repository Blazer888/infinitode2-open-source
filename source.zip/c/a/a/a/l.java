package c.a.a.a;

import android.text.TextUtils;
import java.util.List;
import org.json.JSONObject;

public class l {
   public final String a;
   public final JSONObject b;

   public l(String var1) {
      this.a = var1;
      this.b = new JSONObject(this.a);
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && l.class == var1.getClass()) {
         l var2 = (l)var1;
         return TextUtils.equals(this.a, var2.a);
      } else {
         return false;
      }
   }

   public int hashCode() {
      return this.a.hashCode();
   }

   public String toString() {
      StringBuilder var1 = c.a.b.a.a.b("SkuDetails: ");
      var1.append(this.a);
      return var1.toString();
   }

   public static class a {
      public List a;
      public int b;

      public a(int var1, List var2) {
         this.a = var2;
         this.b = var1;
      }
   }
}
