package c.a.a.a;

public abstract class b {
   public abstract void a();

   public abstract boolean b();
}
