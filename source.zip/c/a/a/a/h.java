package c.a.a.a;

public interface h {
   void onConsumeResponse(int var1, String var2);
}
