package c.a.a.a;

public class g {
   public String a;
   public String b;
   public String c;
   public String d;
   public boolean e;
   public int f = 0;

   public boolean a() {
      return this.e;
   }
}
