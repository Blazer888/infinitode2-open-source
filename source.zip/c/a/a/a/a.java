package c.a.a.a;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.List;

public class a {
   public final Context a;
   public final a.b b;

   public a(Context var1, k var2) {
      this.a = var1;
      this.b = new a.b(var2);
   }

   // $FF: synthetic method
   public static a.b a(a var0) {
      return var0.b;
   }

   public void a() {
      a.b var1 = this.b;
      Context var2 = this.a;
      if (var1.b) {
         var2.unregisterReceiver(a(var1.c));
         var1.b = false;
      } else {
         c.a.a.b.a.c("BillingBroadcastManager", "Receiver is not registered.");
      }

   }

   public class b extends BroadcastReceiver {
      public final k a;
      public boolean b;

      // $FF: synthetic method
      public b(k var2, Object var3) {
         this.a = var2;
      }

      public void onReceive(Context var1, Intent var2) {
         int var3 = c.a.a.b.a.a(var2, "BillingBroadcastManager");
         List var4 = c.a.a.b.a.a(var2.getExtras());
         this.a.onPurchasesUpdated(var3, var4);
      }
   }
}
