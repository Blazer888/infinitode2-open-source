package c.a.a.a;

public interface f {
   void onBillingServiceDisconnected();

   void onBillingSetupFinished(int var1);
}
