package c.a.a.a;

import java.util.List;

public interface k {
   void onPurchasesUpdated(int var1, List var2);
}
