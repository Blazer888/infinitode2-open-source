package c.a.a.a;

import java.util.List;

public interface m {
   void onSkuDetailsResponse(int var1, List var2);
}
