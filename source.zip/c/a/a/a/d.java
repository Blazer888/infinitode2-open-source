package c.a.a.a;

import java.util.List;

public class d implements Runnable {
   // $FF: synthetic field
   public final String a;
   // $FF: synthetic field
   public final List b;
   // $FF: synthetic field
   public final m c;
   // $FF: synthetic field
   public final c d;

   public d(c var1, String var2, List var3, m var4) {
      this.d = var1;
      this.a = var2;
      this.b = var3;
      this.c = var4;
   }

   public void run() {
      final l.a var1 = this.d.a(this.a, this.b);
      c var2 = this.d;
      Runnable var3 = new Runnable() {
         public void run() {
            m var1x = d.this.c;
            l.a var2 = var1;
            var1x.onSkuDetailsResponse(var2.b, var2.a);
         }
      };
      var2.b.post(var3);
   }
}
