package c.a.a.a;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class i {
   public static final Object f = new Object();
   public static i g;
   public final Context a;
   public final HashMap b = new HashMap();
   public final HashMap c = new HashMap();
   public final ArrayList d = new ArrayList();
   public final Handler e;

   public i(Context var1) {
      this.a = var1;
      this.e = new Handler(var1.getMainLooper()) {
         public void handleMessage(Message var1) {
            if (var1.what != 1) {
               super.handleMessage(var1);
            } else {
               i.this.a();
            }

         }
      };
   }

   public static i a(Context var0) {
      Object var1 = f;
      synchronized(var1){}

      Throwable var10000;
      boolean var10001;
      label122: {
         try {
            if (g == null) {
               i var2 = new i(var0.getApplicationContext());
               g = var2;
            }
         } catch (Throwable var14) {
            var10000 = var14;
            var10001 = false;
            break label122;
         }

         label119:
         try {
            i var16 = g;
            return var16;
         } catch (Throwable var13) {
            var10000 = var13;
            var10001 = false;
            break label119;
         }
      }

      while(true) {
         Throwable var15 = var10000;

         try {
            throw var15;
         } catch (Throwable var12) {
            var10000 = var12;
            var10001 = false;
            continue;
         }
      }
   }

   public final void a() {
      label265:
      while(true) {
         HashMap var1 = this.b;
         synchronized(var1){}

         Throwable var10000;
         boolean var10001;
         label262: {
            int var2;
            try {
               var2 = this.d.size();
            } catch (Throwable var24) {
               var10000 = var24;
               var10001 = false;
               break label262;
            }

            if (var2 <= 0) {
               label255:
               try {
                  return;
               } catch (Throwable var22) {
                  var10000 = var22;
                  var10001 = false;
                  break label255;
               }
            } else {
               label267: {
                  i.b[] var26;
                  try {
                     var26 = new i.b[var2];
                     this.d.toArray(var26);
                     this.d.clear();
                  } catch (Throwable var23) {
                     var10000 = var23;
                     var10001 = false;
                     break label267;
                  }

                  var2 = 0;

                  while(true) {
                     if (var2 >= var26.length) {
                        continue label265;
                     }

                     i.b var25 = var26[var2];

                     for(int var4 = 0; var4 < var25.b.size(); ++var4) {
                        ((i.c)var25.b.get(var4)).b.onReceive(this.a, var25.a);
                     }

                     ++var2;
                  }
               }
            }
         }

         while(true) {
            Throwable var3 = var10000;

            try {
               throw var3;
            } catch (Throwable var21) {
               var10000 = var21;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public void a(BroadcastReceiver var1) {
      HashMap var2 = this.b;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label956: {
         ArrayList var3;
         try {
            var3 = (ArrayList)this.b.remove(var1);
         } catch (Throwable var100) {
            var10000 = var100;
            var10001 = false;
            break label956;
         }

         if (var3 == null) {
            label916:
            try {
               return;
            } catch (Throwable var93) {
               var10000 = var93;
               var10001 = false;
               break label916;
            }
         } else {
            label960: {
               int var4 = 0;

               while(true) {
                  IntentFilter var5;
                  try {
                     if (var4 >= var3.size()) {
                        break;
                     }

                     var5 = (IntentFilter)var3.get(var4);
                  } catch (Throwable var96) {
                     var10000 = var96;
                     var10001 = false;
                     break label960;
                  }

                  int var6 = 0;

                  while(true) {
                     String var7;
                     ArrayList var8;
                     try {
                        if (var6 >= var5.countActions()) {
                           break;
                        }

                        var7 = var5.getAction(var6);
                        var8 = (ArrayList)this.c.get(var7);
                     } catch (Throwable var97) {
                        var10000 = var97;
                        var10001 = false;
                        break label960;
                     }

                     if (var8 != null) {
                        int var9 = 0;

                        while(true) {
                           try {
                              if (var9 >= var8.size()) {
                                 break;
                              }
                           } catch (Throwable var98) {
                              var10000 = var98;
                              var10001 = false;
                              break label960;
                           }

                           int var10 = var9;

                           label938: {
                              try {
                                 if (((i.c)var8.get(var9)).b != var1) {
                                    break label938;
                                 }

                                 var8.remove(var9);
                              } catch (Throwable var99) {
                                 var10000 = var99;
                                 var10001 = false;
                                 break label960;
                              }

                              var10 = var9 - 1;
                           }

                           var9 = var10 + 1;
                        }

                        try {
                           if (var8.size() <= 0) {
                              this.c.remove(var7);
                           }
                        } catch (Throwable var95) {
                           var10000 = var95;
                           var10001 = false;
                           break label960;
                        }
                     }

                     ++var6;
                  }

                  ++var4;
               }

               label918:
               try {
                  return;
               } catch (Throwable var94) {
                  var10000 = var94;
                  var10001 = false;
                  break label918;
               }
            }
         }
      }

      while(true) {
         Throwable var101 = var10000;

         try {
            throw var101;
         } catch (Throwable var92) {
            var10000 = var92;
            var10001 = false;
            continue;
         }
      }
   }

   public void a(BroadcastReceiver var1, IntentFilter var2) {
      HashMap var3 = this.b;
      synchronized(var3){}

      Throwable var10000;
      boolean var10001;
      label587: {
         i.c var4;
         ArrayList var5;
         try {
            var4 = new i.c(var2, var1);
            var5 = (ArrayList)this.b.get(var1);
         } catch (Throwable var79) {
            var10000 = var79;
            var10001 = false;
            break label587;
         }

         ArrayList var6 = var5;
         if (var5 == null) {
            try {
               var6 = new ArrayList(1);
               this.b.put(var1, var6);
            } catch (Throwable var78) {
               var10000 = var78;
               var10001 = false;
               break label587;
            }
         }

         try {
            var6.add(var2);
         } catch (Throwable var77) {
            var10000 = var77;
            var10001 = false;
            break label587;
         }

         int var7 = 0;

         while(true) {
            String var82;
            try {
               if (var7 >= var2.countActions()) {
                  break;
               }

               var82 = var2.getAction(var7);
               var6 = (ArrayList)this.c.get(var82);
            } catch (Throwable var76) {
               var10000 = var76;
               var10001 = false;
               break label587;
            }

            ArrayList var80 = var6;
            if (var6 == null) {
               try {
                  var80 = new ArrayList(1);
                  this.c.put(var82, var80);
               } catch (Throwable var75) {
                  var10000 = var75;
                  var10001 = false;
                  break label587;
               }
            }

            try {
               var80.add(var4);
            } catch (Throwable var74) {
               var10000 = var74;
               var10001 = false;
               break label587;
            }

            ++var7;
         }

         label559:
         try {
            return;
         } catch (Throwable var73) {
            var10000 = var73;
            var10001 = false;
            break label559;
         }
      }

      while(true) {
         Throwable var81 = var10000;

         try {
            throw var81;
         } catch (Throwable var72) {
            var10000 = var72;
            var10001 = false;
            continue;
         }
      }
   }

   public boolean a(Intent var1) {
      HashMap var2 = this.b;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label3481: {
         String var3;
         String var4;
         Uri var5;
         String var6;
         Set var7;
         boolean var8;
         label3476: {
            label3475: {
               try {
                  var3 = var1.getAction();
                  var4 = var1.resolveTypeIfNeeded(this.a.getContentResolver());
                  var5 = var1.getData();
                  var6 = var1.getScheme();
                  var7 = var1.getCategories();
                  if ((var1.getFlags() & 8) != 0) {
                     break label3475;
                  }
               } catch (Throwable var395) {
                  var10000 = var395;
                  var10001 = false;
                  break label3481;
               }

               var8 = false;
               break label3476;
            }

            var8 = true;
         }

         StringBuilder var9;
         if (var8) {
            try {
               var9 = new StringBuilder();
               var9.append("Resolving type ");
               var9.append(var4);
               var9.append(" scheme ");
               var9.append(var6);
               var9.append(" of intent ");
               var9.append(var1);
               Log.v("LocalBroadcastManager", var9.toString());
            } catch (Throwable var394) {
               var10000 = var394;
               var10001 = false;
               break label3481;
            }
         }

         ArrayList var10;
         try {
            var10 = (ArrayList)this.c.get(var1.getAction());
         } catch (Throwable var393) {
            var10000 = var393;
            var10001 = false;
            break label3481;
         }

         if (var10 != null) {
            if (var8) {
               try {
                  var9 = new StringBuilder();
                  var9.append("Action list: ");
                  var9.append(var10);
                  Log.v("LocalBroadcastManager", var9.toString());
               } catch (Throwable var390) {
                  var10000 = var390;
                  var10001 = false;
                  break label3481;
               }
            }

            Object var11 = null;
            int var12 = 0;

            while(true) {
               i.c var13;
               try {
                  if (var12 >= var10.size()) {
                     break;
                  }

                  var13 = (i.c)var10.get(var12);
               } catch (Throwable var391) {
                  var10000 = var391;
                  var10001 = false;
                  break label3481;
               }

               if (var8) {
                  try {
                     var9 = new StringBuilder();
                     var9.append("Matching against filter ");
                     var9.append(var13.a);
                     Log.v("LocalBroadcastManager", var9.toString());
                  } catch (Throwable var389) {
                     var10000 = var389;
                     var10001 = false;
                     break label3481;
                  }
               }

               label3484: {
                  label3454: {
                     try {
                        if (!var13.c) {
                           break label3454;
                        }
                     } catch (Throwable var392) {
                        var10000 = var392;
                        var10001 = false;
                        break label3481;
                     }

                     if (var8) {
                        try {
                           Log.v("LocalBroadcastManager", "  Filter's target already added");
                        } catch (Throwable var388) {
                           var10000 = var388;
                           var10001 = false;
                           break label3481;
                        }
                     }
                     break label3484;
                  }

                  IntentFilter var14;
                  try {
                     var14 = var13.a;
                  } catch (Throwable var387) {
                     var10000 = var387;
                     var10001 = false;
                     break label3481;
                  }

                  int var15;
                  try {
                     var15 = var14.match(var3, var4, var6, var5, var7, "LocalBroadcastManager");
                  } catch (Throwable var386) {
                     var10000 = var386;
                     var10001 = false;
                     break label3481;
                  }

                  if (var15 >= 0) {
                     if (var8) {
                        try {
                           var11 = new StringBuilder();
                           ((StringBuilder)var11).append("  Filter matched!  match=0x");
                           ((StringBuilder)var11).append(Integer.toHexString(var15));
                           Log.v("LocalBroadcastManager", ((StringBuilder)var11).toString());
                        } catch (Throwable var385) {
                           var10000 = var385;
                           var10001 = false;
                           break label3481;
                        }
                     }

                     if (var11 == null) {
                        try {
                           var11 = new ArrayList();
                        } catch (Throwable var384) {
                           var10000 = var384;
                           var10001 = false;
                           break label3481;
                        }
                     } else {
                        var11 = var11;
                     }

                     try {
                        ((ArrayList)var11).add(var13);
                        var13.c = true;
                     } catch (Throwable var383) {
                        var10000 = var383;
                        var10001 = false;
                        break label3481;
                     }
                  } else if (var8) {
                     String var399;
                     if (var15 != -4) {
                        if (var15 != -3) {
                           if (var15 != -2) {
                              if (var15 != -1) {
                                 var399 = "unknown reason";
                              } else {
                                 var399 = "type";
                              }
                           } else {
                              var399 = "data";
                           }
                        } else {
                           var399 = "action";
                        }
                     } else {
                        var399 = "category";
                     }

                     try {
                        StringBuilder var401 = new StringBuilder();
                        var401.append("  Filter did not match: ");
                        var401.append(var399);
                        Log.v("LocalBroadcastManager", var401.toString());
                     } catch (Throwable var382) {
                        var10000 = var382;
                        var10001 = false;
                        break label3481;
                     }
                  }
               }

               ++var12;
            }

            if (var11 != null) {
               int var398 = 0;

               while(true) {
                  try {
                     if (var398 >= ((ArrayList)var11).size()) {
                        break;
                     }

                     ((i.c)((ArrayList)var11).get(var398)).c = false;
                  } catch (Throwable var380) {
                     var10000 = var380;
                     var10001 = false;
                     break label3481;
                  }

                  ++var398;
               }

               try {
                  ArrayList var400 = this.d;
                  i.b var397 = new i.b(var1, (ArrayList)var11);
                  var400.add(var397);
                  if (!this.e.hasMessages(1)) {
                     this.e.sendEmptyMessage(1);
                  }
               } catch (Throwable var379) {
                  var10000 = var379;
                  var10001 = false;
                  break label3481;
               }

               try {
                  return true;
               } catch (Throwable var378) {
                  var10000 = var378;
                  var10001 = false;
                  break label3481;
               }
            }
         }

         label3417:
         try {
            return false;
         } catch (Throwable var381) {
            var10000 = var381;
            var10001 = false;
            break label3417;
         }
      }

      while(true) {
         Throwable var396 = var10000;

         try {
            throw var396;
         } catch (Throwable var377) {
            var10000 = var377;
            var10001 = false;
            continue;
         }
      }
   }

   public static class b {
      public final Intent a;
      public final ArrayList b;

      public b(Intent var1, ArrayList var2) {
         this.a = var1;
         this.b = var2;
      }
   }

   public static class c {
      public final IntentFilter a;
      public final BroadcastReceiver b;
      public boolean c;

      public c(IntentFilter var1, BroadcastReceiver var2) {
         this.a = var1;
         this.b = var2;
      }

      public String toString() {
         StringBuilder var1 = new StringBuilder(128);
         var1.append("Receiver{");
         var1.append(this.b);
         var1.append(" filter=");
         var1.append(this.a);
         var1.append("}");
         return var1.toString();
      }
   }
}
