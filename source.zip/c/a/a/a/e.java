package c.a.a.a;

public class e implements Runnable {
   // $FF: synthetic field
   public final String a;
   // $FF: synthetic field
   public final h b;
   // $FF: synthetic field
   public final c c;

   public e(c var1, String var2, h var3) {
      this.c = var1;
      this.a = var2;
      this.b = var3;
   }

   public void run() {
      this.c.a(this.a, this.b);
   }
}
