package c.a.a.a;

import android.text.TextUtils;
import java.util.List;
import org.json.JSONObject;

public class j {
   public final String a;
   public final String b;
   public final JSONObject c;

   public j(String var1, String var2) {
      this.a = var1;
      this.b = var2;
      this.c = new JSONObject(this.a);
   }

   public String a() {
      JSONObject var1 = this.c;
      return var1.optString("token", var1.optString("purchaseToken"));
   }

   public String b() {
      return this.c.optString("productId");
   }

   public boolean equals(Object var1) {
      boolean var2 = true;
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof j)) {
         return false;
      } else {
         j var3 = (j)var1;
         if (!TextUtils.equals(this.a, var3.a) || !TextUtils.equals(this.b, var3.b)) {
            var2 = false;
         }

         return var2;
      }
   }

   public int hashCode() {
      return this.a.hashCode();
   }

   public String toString() {
      StringBuilder var1 = c.a.b.a.a.b("Purchase. Json: ");
      var1.append(this.a);
      return var1.toString();
   }

   public static class a {
      public List a;
      public int b;

      public a(int var1, List var2) {
         this.a = var2;
         this.b = var1;
      }
   }
}
