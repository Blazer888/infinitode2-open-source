package c.b.a;

public class f extends RuntimeException {
   public StringBuffer a;

   public f(String var1) {
      super(var1);
   }

   public f(String var1, Throwable var2) {
      super(var1, var2);
   }

   public f(Throwable var1) {
      super(var1);
   }

   public void a(String var1) {
      if (var1 != null) {
         if (this.a == null) {
            this.a = new StringBuffer(512);
         }

         this.a.append('\n');
         this.a.append(var1);
      } else {
         throw new IllegalArgumentException("info cannot be null.");
      }
   }

   public String getMessage() {
      if (this.a == null) {
         return super.getMessage();
      } else {
         StringBuffer var1 = new StringBuffer(512);
         var1.append(super.getMessage());
         if (var1.length() > 0) {
            var1.append('\n');
         }

         var1.append("Serialization trace:");
         var1.append(this.a);
         return var1.toString();
      }
   }
}
