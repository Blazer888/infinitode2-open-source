package c.b.a.p;

import java.util.ArrayList;

public class g implements c.b.a.i {
   public final d a = new d();
   public final ArrayList b = new ArrayList();

   public boolean a(Class var1) {
      return i.d(var1) ^ true;
   }
}
