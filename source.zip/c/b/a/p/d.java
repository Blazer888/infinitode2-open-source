package c.b.a.p;

public class d {
   public int a;
   public Object[] b;
   public int[] c;
   public int d;
   public int e;
   public float f;
   public int g;
   public int h;
   public int i;
   public int j;
   public int k;

   public d() {
      if (this.d <= 1073741824) {
         this.d = c.b.a.p.h.d(32);
         this.f = 0.8F;
         int var1 = this.d;
         this.i = (int)((float)var1 * 0.8F);
         this.h = var1 - 1;
         this.g = 31 - Integer.numberOfTrailingZeros(var1);
         this.j = Math.max(3, (int)Math.ceil(Math.log((double)this.d)) * 2);
         this.k = Math.max(Math.min(this.d, 8), (int)Math.sqrt((double)this.d) / 8);
         this.b = new Object[this.d + this.j];
         this.c = new int[this.b.length];
      } else {
         throw new IllegalArgumentException(c.a.b.a.a.a("initialCapacity is too large: ", 32));
      }
   }

   public final int a(int var1) {
      var1 *= -1262997959;
      return (var1 ^ var1 >>> this.g) & this.h;
   }

   public int a(Object var1, int var2) {
      int var3 = System.identityHashCode(var1);
      int var4 = this.h & var3;
      int var5 = var4;
      if (var1 != this.b[var4]) {
         var4 = this.a(var3);
         var5 = var4;
         if (var1 != this.b[var4]) {
            var4 = this.b(var3);
            Object[] var6 = this.b;
            var5 = var4;
            if (var1 != var6[var4]) {
               var4 = this.d;
               int var7 = this.e;
               var5 = var4;

               while(true) {
                  var3 = var5;
                  var5 = var2;
                  if (var3 >= var7 + var4) {
                     break;
                  }

                  if (var1 == var6[var3]) {
                     var5 = this.c[var3];
                     break;
                  }

                  var5 = var3 + 1;
               }

               return var5;
            }
         }
      }

      return this.c[var5];
   }

   public void a() {
      Object[] var1 = this.b;
      int var2 = this.d + this.e;

      while(true) {
         int var3 = var2 - 1;
         if (var2 <= 0) {
            this.a = 0;
            this.e = 0;
            return;
         }

         var1[var3] = null;
         var2 = var3;
      }
   }

   public final void a(Object var1, int var2, int var3, Object var4, int var5, Object var6, int var7, Object var8) {
      Object[] var9 = this.b;
      int[] var10 = this.c;
      int var11 = this.h;
      int var12 = this.k;
      int var13 = var3;
      Object var14 = var4;
      var4 = var6;
      int var15 = var7;
      var3 = 0;
      var7 = var5;
      var6 = var14;
      var5 = var2;
      var14 = var1;

      int var16;
      do {
         var2 = c.b.a.p.h.l.nextInt(3);
         if (var2 != 0) {
            if (var2 != 1) {
               var2 = var10[var15];
               var9[var15] = var14;
               var10[var15] = var5;
               var1 = var8;
            } else {
               var2 = var10[var7];
               var9[var7] = var14;
               var10[var7] = var5;
               var1 = var4;
            }
         } else {
            var2 = var10[var13];
            var9[var13] = var14;
            var10[var13] = var5;
            var1 = var6;
         }

         var5 = System.identityHashCode(var1);
         var13 = var5 & var11;
         var6 = var9[var13];
         if (var6 == null) {
            var9[var13] = var1;
            var10[var13] = var2;
            var2 = this.a++;
            if (var2 >= this.i) {
               this.c(this.d << 1);
            }

            return;
         }

         var7 = this.a(var5);
         var4 = var9[var7];
         if (var4 == null) {
            var9[var7] = var1;
            var10[var7] = var2;
            var2 = this.a++;
            if (var2 >= this.i) {
               this.c(this.d << 1);
            }

            return;
         }

         var15 = this.b(var5);
         var8 = var9[var15];
         if (var8 == null) {
            var9[var15] = var1;
            var10[var15] = var2;
            var2 = this.a++;
            if (var2 >= this.i) {
               this.c(this.d << 1);
            }

            return;
         }

         var16 = var3 + 1;
         var14 = var1;
         var5 = var2;
         var3 = var16;
      } while(var16 != var12);

      var5 = this.e;
      if (var5 == this.j) {
         this.c(this.d << 1);
         this.b(var1, var2);
      } else {
         var3 = this.d + var5;
         this.b[var3] = var1;
         this.c[var3] = var2;
         this.e = var5 + 1;
         ++this.a;
      }

   }

   public final int b(int var1) {
      var1 *= -825114047;
      return (var1 ^ var1 >>> this.g) & this.h;
   }

   public void b(Object var1, int var2) {
      if (var1 != null) {
         Object[] var3 = this.b;
         int var4 = System.identityHashCode(var1);
         int var5 = var4 & this.h;
         Object var6 = var3[var5];
         if (var1 == var6) {
            this.c[var5] = var2;
         } else {
            int var7 = this.a(var4);
            Object var8 = var3[var7];
            if (var1 == var8) {
               this.c[var7] = var2;
            } else {
               int var9 = this.b(var4);
               Object var10 = var3[var9];
               if (var1 == var10) {
                  this.c[var9] = var2;
               } else {
                  int var11 = this.d;
                  int var12 = this.e;

                  for(var4 = var11; var4 < var12 + var11; ++var4) {
                     if (var3[var4] == var1) {
                        this.c[var4] = var2;
                        return;
                     }
                  }

                  if (var6 == null) {
                     var3[var5] = var1;
                     this.c[var5] = var2;
                     var2 = this.a++;
                     if (var2 >= this.i) {
                        this.c(this.d << 1);
                     }

                  } else if (var8 == null) {
                     var3[var7] = var1;
                     this.c[var7] = var2;
                     var2 = this.a++;
                     if (var2 >= this.i) {
                        this.c(this.d << 1);
                     }

                  } else if (var10 == null) {
                     var3[var9] = var1;
                     this.c[var9] = var2;
                     var2 = this.a++;
                     if (var2 >= this.i) {
                        this.c(this.d << 1);
                     }

                  } else {
                     this.a(var1, var2, var5, var6, var7, var8, var9, var10);
                  }
               }
            }
         }
      } else {
         IllegalArgumentException var13 = new IllegalArgumentException("key cannot be null.");
         throw var13;
      }
   }

   public final void c(int var1) {
      int var2 = this.d;
      int var3 = this.e;
      this.d = var1;
      this.i = (int)((float)var1 * this.f);
      this.h = var1 - 1;
      this.g = 31 - Integer.numberOfTrailingZeros(var1);
      double var4 = (double)var1;
      this.j = Math.max(3, (int)Math.ceil(Math.log(var4)) * 2);
      this.k = Math.max(Math.min(var1, 8), (int)Math.sqrt(var4) / 8);
      Object[] var6 = this.b;
      int[] var7 = this.c;
      int var8 = this.j;
      this.b = new Object[var1 + var8];
      this.c = new int[var1 + var8];
      var8 = this.a;
      var1 = 0;
      this.a = 0;
      this.e = 0;
      if (var8 > 0) {
         for(; var1 < var2 + var3; ++var1) {
            Object var9 = var6[var1];
            if (var9 != null) {
               int var10 = var7[var1];
               int var11 = System.identityHashCode(var9);
               int var12 = var11 & this.h;
               Object[] var13 = this.b;
               Object var14 = var13[var12];
               if (var14 == null) {
                  var13[var12] = var9;
                  this.c[var12] = var10;
                  var8 = this.a++;
                  if (var8 >= this.i) {
                     this.c(this.d << 1);
                  }
               } else {
                  var8 = this.a(var11);
                  Object[] var15 = this.b;
                  Object var17 = var15[var8];
                  if (var17 == null) {
                     var15[var8] = var9;
                     this.c[var8] = var10;
                     var8 = this.a++;
                     if (var8 >= this.i) {
                        this.c(this.d << 1);
                     }
                  } else {
                     var11 = this.b(var11);
                     var15 = this.b;
                     Object var16 = var15[var11];
                     if (var16 == null) {
                        var15[var11] = var9;
                        this.c[var11] = var10;
                        var8 = this.a++;
                        if (var8 >= this.i) {
                           this.c(this.d << 1);
                        }
                     } else {
                        this.a(var9, var10, var12, var14, var8, var17, var11, var16);
                     }
                  }
               }
            }
         }
      }

   }

   public String toString() {
      if (this.a == 0) {
         return "{}";
      } else {
         StringBuilder var1 = new StringBuilder(32);
         var1.append('{');
         Object[] var2 = this.b;
         int[] var3 = this.c;
         int var4 = var2.length;

         int var6;
         Object var7;
         while(true) {
            int var5 = var4 - 1;
            var6 = var5;
            if (var4 <= 0) {
               break;
            }

            var7 = var2[var5];
            if (var7 != null) {
               var1.append(var7);
               var1.append('=');
               var1.append(var3[var5]);
               var6 = var5;
               break;
            }

            var4 = var5;
         }

         while(true) {
            var4 = var6 - 1;
            if (var6 <= 0) {
               var1.append('}');
               return var1.toString();
            }

            var7 = var2[var4];
            if (var7 != null) {
               var1.append(", ");
               var1.append(var7);
               var1.append('=');
               var1.append(var3[var4]);
            }

            var6 = var4;
         }
      }
   }
}
