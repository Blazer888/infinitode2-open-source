package c.b.a.p;

import c.b.a.j;

public class a implements c.b.a.a {
   public c.b.a.d a;
   public final f b = new f();
   public final h c = new h();
   public d d;
   public f e;
   public h f;
   public int g;
   public int h = -1;
   public j i;
   public Class j;
   public j k;

   public j a(j var1) {
      if (var1 != null) {
         StringBuilder var2;
         if (var1.b != -1) {
            if (c.b.c.a.c) {
               var2 = c.a.b.a.a.b("Register class ID ");
               var2.append(var1.b);
               var2.append(": ");
               var2.append(c.b.a.p.i.a(var1.a));
               var2.append(" (");
               var2.append(var1.c.getClass().getName());
               var2.append(")");
               c.b.c.a.b("kryo", var2.toString());
            }

            this.b.a(var1.b, var1);
         } else if (c.b.c.a.c) {
            var2 = c.a.b.a.a.b("Register class name: ");
            var2.append(c.b.a.p.i.a(var1.a));
            var2.append(" (");
            var2.append(var1.c.getClass().getName());
            var2.append(")");
            c.b.c.a.b("kryo", var2.toString());
         }

         this.c.a(var1.a, var1);
         if (var1.a.isPrimitive()) {
            this.c.a(c.b.a.p.i.c(var1.a), var1);
         }

         return var1;
      } else {
         throw new IllegalArgumentException("registration cannot be null.");
      }
   }

   public j a(c.b.a.n.a var1) {
      int var2 = var1.a(true);
      Class var3 = null;
      if (var2 != 0) {
         StringBuilder var9;
         if (var2 != 1) {
            if (var2 == this.h) {
               return this.i;
            } else {
               f var10 = this.b;
               int var4 = var2 - 2;
               j var12 = (j)var10.a(var4);
               if (var12 != null) {
                  if (c.b.c.a.c) {
                     var9 = c.a.b.a.a.b("Read class ", var4, ": ");
                     var9.append(c.b.a.p.i.a(var12.a));
                     c.b.c.a.b("kryo", var9.toString());
                  }

                  this.h = var2;
                  this.i = var12;
                  return var12;
               } else {
                  throw new c.b.a.f(c.a.b.a.a.a("Encountered unregistered class ID: ", var4));
               }
            }
         } else {
            var2 = var1.a(true);
            if (this.e == null) {
               this.e = new f();
            }

            Class var5 = (Class)this.e.a(var2);
            if (var5 == null) {
               String var13 = var1.j();
               h var6 = this.f;
               Class var8 = var3;
               if (var6 != null) {
                  var8 = (Class)var6.b(var13);
               }

               if (var8 == null) {
                  try {
                     var8 = Class.forName(var13, false, this.a.getClassLoader());
                  } catch (ClassNotFoundException var7) {
                     throw new c.b.a.f(c.a.b.a.a.a("Unable to find class: ", var13), var7);
                  }

                  if (this.f == null) {
                     this.f = new h();
                  }

                  this.f.a(var13, var8);
               }

               this.e.a(var2, var8);
               var3 = var8;
               if (c.b.c.a.c) {
                  StringBuilder var11 = new StringBuilder();
                  var11.append("Read class name: ");
                  var11.append(var13);
                  c.b.c.a.b("kryo", var11.toString());
                  var3 = var8;
               }
            } else {
               var3 = var5;
               if (c.b.c.a.c) {
                  var9 = c.a.b.a.a.b("Read class name reference ", var2, ": ");
                  var9.append(c.b.a.p.i.a(var5));
                  c.b.c.a.b("kryo", var9.toString());
                  var3 = var5;
               }
            }

            return this.a.getRegistration(var3);
         }
      } else {
         if (c.b.c.a.c || c.b.c.a.b && this.a.getDepth() == 1) {
            c.b.a.p.i.a("Read", (Object)null);
         }

         return null;
      }
   }

   public j a(c.b.a.n.b var1, Class var2) {
      if (var2 == null) {
         if (c.b.c.a.c || c.b.c.a.b && this.a.getDepth() == 1) {
            c.b.a.p.i.a("Write", (Object)null);
         }

         var1.a(0, true);
         return null;
      } else {
         j var3 = this.a.getRegistration(var2);
         StringBuilder var6;
         if (var3.b == -1) {
            var1.a(1, true);
            d var4 = this.d;
            int var5;
            if (var4 != null) {
               var5 = var4.a(var2, -1);
               if (var5 != -1) {
                  if (c.b.c.a.c) {
                     var6 = c.a.b.a.a.b("Write class name reference ", var5, ": ");
                     var6.append(c.b.a.p.i.a(var2));
                     c.b.c.a.b("kryo", var6.toString());
                  }

                  var1.a(var5, true);
                  return var3;
               }
            }

            if (c.b.c.a.c) {
               var6 = c.a.b.a.a.b("Write class name: ");
               var6.append(c.b.a.p.i.a(var2));
               c.b.c.a.b("kryo", var6.toString());
            }

            var5 = this.g++;
            if (this.d == null) {
               this.d = new d();
            }

            this.d.b(var2, var5);
            var1.a(var5, true);
            var1.a(var2.getName());
         } else {
            if (c.b.c.a.c) {
               var6 = c.a.b.a.a.b("Write class ");
               var6.append(var3.b);
               var6.append(": ");
               var6.append(c.b.a.p.i.a(var2));
               c.b.c.a.b("kryo", var6.toString());
            }

            var1.a(var3.b + 2, true);
         }

         return var3;
      }
   }

   public j a(Class var1) {
      if (var1 == this.j) {
         return this.k;
      } else {
         j var2 = (j)this.c.b(var1);
         if (var2 != null) {
            this.j = var1;
            this.k = var2;
         }

         return var2;
      }
   }
}
