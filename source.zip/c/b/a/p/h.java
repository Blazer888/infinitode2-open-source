package c.b.a.p;

import java.util.Random;

public class h {
   public static Random l = new Random();
   public int a;
   public Object[] b;
   public Object[] c;
   public int d = d(32);
   public int e;
   public float f = 0.8F;
   public int g;
   public int h;
   public int i;
   public int j;
   public int k;

   public h() {
      int var1 = this.d;
      this.i = (int)((float)var1 * 0.8F);
      this.h = var1 - 1;
      this.g = 31 - Integer.numberOfTrailingZeros(var1);
      this.j = Math.max(3, (int)Math.ceil(Math.log((double)this.d)) * 2);
      this.k = Math.max(Math.min(this.d, 8), (int)Math.sqrt((double)this.d) / 8);
      this.b = new Object[this.d + this.j];
      this.c = new Object[this.b.length];
   }

   public static int d(int var0) {
      if (var0 == 0) {
         return 1;
      } else {
         --var0;
         var0 |= var0 >> 1;
         var0 |= var0 >> 2;
         var0 |= var0 >> 4;
         var0 |= var0 >> 8;
         return (var0 | var0 >> 16) + 1;
      }
   }

   public final int a(int var1) {
      var1 *= -1262997959;
      return (var1 ^ var1 >>> this.g) & this.h;
   }

   public Object a(Object var1, Object var2) {
      if (var1 != null) {
         return this.b(var1, var2);
      } else {
         throw new IllegalArgumentException("key cannot be null.");
      }
   }

   public final void a(Object var1, Object var2, int var3, Object var4, int var5, Object var6, int var7, Object var8) {
      Object[] var9 = this.b;
      Object[] var10 = this.c;
      int var11 = this.h;
      int var12 = this.k;
      int var13 = var3;
      Object var14 = var4;
      var4 = var6;
      int var15 = var7;
      var3 = 0;
      var7 = var13;
      var6 = var14;
      var14 = var2;
      Object var16 = var1;
      var13 = var15;

      do {
         var15 = l.nextInt(3);
         if (var15 != 0) {
            if (var15 != 1) {
               var2 = var10[var13];
               var9[var13] = var16;
               var10[var13] = var14;
               var1 = var8;
            } else {
               var2 = var10[var5];
               var9[var5] = var16;
               var10[var5] = var14;
               var1 = var4;
            }
         } else {
            var2 = var10[var7];
            var9[var7] = var16;
            var10[var7] = var14;
            var1 = var6;
         }

         var13 = var1.hashCode();
         var7 = var13 & var11;
         var6 = var9[var7];
         if (var6 == null) {
            var9[var7] = var1;
            var10[var7] = var2;
            var3 = this.a++;
            if (var3 >= this.i) {
               this.c(this.d << 1);
            }

            return;
         }

         var5 = this.a(var13);
         var4 = var9[var5];
         if (var4 == null) {
            var9[var5] = var1;
            var10[var5] = var2;
            var3 = this.a++;
            if (var3 >= this.i) {
               this.c(this.d << 1);
            }

            return;
         }

         var13 = this.b(var13);
         var8 = var9[var13];
         if (var8 == null) {
            var9[var13] = var1;
            var10[var13] = var2;
            var3 = this.a++;
            if (var3 >= this.i) {
               this.c(this.d << 1);
            }

            return;
         }

         var15 = var3 + 1;
         var16 = var1;
         var14 = var2;
         var3 = var15;
      } while(var15 != var12);

      var3 = this.e;
      if (var3 == this.j) {
         this.c(this.d << 1);
         this.b(var1, var2);
      } else {
         var5 = this.d + var3;
         this.b[var5] = var1;
         this.c[var5] = var2;
         this.e = var3 + 1;
         ++this.a;
      }

   }

   public boolean a(Object var1) {
      int var2 = var1.hashCode();
      int var3 = this.h;
      boolean var4 = var1.equals(this.b[var3 & var2]);
      boolean var5 = true;
      boolean var6 = var5;
      if (!var4) {
         var3 = this.a(var2);
         var6 = var5;
         if (!var1.equals(this.b[var3])) {
            var2 = this.b(var2);
            var6 = var5;
            if (!var1.equals(this.b[var2])) {
               Object[] var7 = this.b;
               var3 = this.d;
               int var8 = this.e;
               var2 = var3;

               while(true) {
                  if (var2 >= var8 + var3) {
                     var6 = false;
                     break;
                  }

                  if (var1.equals(var7[var2])) {
                     var6 = var5;
                     break;
                  }

                  ++var2;
               }
            }
         }
      }

      return var6;
   }

   public final int b(int var1) {
      var1 *= -825114047;
      return (var1 ^ var1 >>> this.g) & this.h;
   }

   public Object b(Object var1) {
      int var2 = var1.hashCode();
      int var3 = this.h & var2;
      int var4 = var3;
      if (!var1.equals(this.b[var3])) {
         var3 = this.a(var2);
         var4 = var3;
         if (!var1.equals(this.b[var3])) {
            var3 = this.b(var2);
            var4 = var3;
            if (!var1.equals(this.b[var3])) {
               Object[] var5 = this.b;
               var3 = this.d;
               var2 = this.e;
               var4 = var3;

               while(true) {
                  if (var4 >= var2 + var3) {
                     var1 = null;
                     break;
                  }

                  if (var1.equals(var5[var4])) {
                     var1 = this.c[var4];
                     break;
                  }

                  ++var4;
               }

               return var1;
            }
         }
      }

      return this.c[var4];
   }

   public final Object b(Object var1, Object var2) {
      Object[] var3 = this.b;
      int var4 = var1.hashCode();
      int var5 = var4 & this.h;
      Object var6 = var3[var5];
      if (var1.equals(var6)) {
         Object[] var13 = this.c;
         var6 = var13[var5];
         var13[var5] = var2;
         return var6;
      } else {
         int var7 = this.a(var4);
         Object var8 = var3[var7];
         Object[] var14;
         if (var1.equals(var8)) {
            var14 = this.c;
            var1 = var14[var7];
            var14[var7] = var2;
            return var1;
         } else {
            int var9 = this.b(var4);
            Object var10 = var3[var9];
            if (var1.equals(var10)) {
               var14 = this.c;
               var1 = var14[var9];
               var14[var9] = var2;
               return var1;
            } else {
               int var11 = this.d;
               int var12 = this.e;

               for(var4 = var11; var4 < var12 + var11; ++var4) {
                  if (var1.equals(var3[var4])) {
                     var14 = this.c;
                     var1 = var14[var4];
                     var14[var4] = var2;
                     return var1;
                  }
               }

               if (var6 == null) {
                  var3[var5] = var1;
                  this.c[var5] = var2;
                  var4 = this.a++;
                  if (var4 >= this.i) {
                     this.c(this.d << 1);
                  }

                  return null;
               } else if (var8 == null) {
                  var3[var7] = var1;
                  this.c[var7] = var2;
                  var4 = this.a++;
                  if (var4 >= this.i) {
                     this.c(this.d << 1);
                  }

                  return null;
               } else if (var10 == null) {
                  var3[var9] = var1;
                  this.c[var9] = var2;
                  var4 = this.a++;
                  if (var4 >= this.i) {
                     this.c(this.d << 1);
                  }

                  return null;
               } else {
                  this.a(var1, var2, var5, var6, var7, var8, var9, var10);
                  return null;
               }
            }
         }
      }
   }

   public final void c(int var1) {
      int var2 = this.d;
      int var3 = this.e;
      this.d = var1;
      this.i = (int)((float)var1 * this.f);
      this.h = var1 - 1;
      this.g = 31 - Integer.numberOfTrailingZeros(var1);
      double var4 = (double)var1;
      this.j = Math.max(3, (int)Math.ceil(Math.log(var4)) * 2);
      this.k = Math.max(Math.min(var1, 8), (int)Math.sqrt(var4) / 8);
      Object[] var6 = this.b;
      Object[] var7 = this.c;
      int var8 = this.j;
      this.b = new Object[var1 + var8];
      this.c = new Object[var1 + var8];
      var8 = this.a;
      var1 = 0;
      this.a = 0;
      this.e = 0;
      if (var8 > 0) {
         for(; var1 < var2 + var3; ++var1) {
            Object var9 = var6[var1];
            if (var9 != null) {
               Object var10 = var7[var1];
               int var11 = var9.hashCode();
               var8 = var11 & this.h;
               Object[] var12 = this.b;
               Object var13 = var12[var8];
               if (var13 == null) {
                  var12[var8] = var9;
                  this.c[var8] = var10;
                  var8 = this.a++;
                  if (var8 >= this.i) {
                     this.c(this.d << 1);
                  }
               } else {
                  int var14 = this.a(var11);
                  Object[] var15 = this.b;
                  Object var17 = var15[var14];
                  if (var17 == null) {
                     var15[var14] = var9;
                     this.c[var14] = var10;
                     var8 = this.a++;
                     if (var8 >= this.i) {
                        this.c(this.d << 1);
                     }
                  } else {
                     var11 = this.b(var11);
                     Object[] var16 = this.b;
                     Object var18 = var16[var11];
                     if (var18 == null) {
                        var16[var11] = var9;
                        this.c[var11] = var10;
                        var8 = this.a++;
                        if (var8 >= this.i) {
                           this.c(this.d << 1);
                        }
                     } else {
                        this.a(var9, var10, var8, var13, var14, var17, var11, var18);
                     }
                  }
               }
            }
         }
      }

   }

   public String toString() {
      if (this.a == 0) {
         return "{}";
      } else {
         StringBuilder var1 = new StringBuilder(32);
         var1.append('{');
         Object[] var2 = this.b;
         Object[] var3 = this.c;
         int var4 = var2.length;

         int var5;
         int var6;
         Object var7;
         while(true) {
            var5 = var4 - 1;
            var6 = var5;
            if (var4 <= 0) {
               break;
            }

            var7 = var2[var5];
            if (var7 != null) {
               var1.append(var7);
               var1.append('=');
               var1.append(var3[var5]);
               var6 = var5;
               break;
            }

            var4 = var5;
         }

         while(true) {
            var5 = var6 - 1;
            if (var6 <= 0) {
               var1.append('}');
               return var1.toString();
            }

            var7 = var2[var5];
            if (var7 != null) {
               var1.append(", ");
               var1.append(var7);
               var1.append('=');
               var1.append(var3[var5]);
            }

            var6 = var5;
         }
      }
   }
}
