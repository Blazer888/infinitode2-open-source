package c.b.a.p;

import c.b.a.l;

public class b implements l {
   public void a(c.b.a.d var1) {
   }
}
