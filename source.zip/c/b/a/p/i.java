package c.b.a.p;

public class i {
   public static boolean a;

   static {
      try {
         Class.forName("android.os.Process");
         a = true;
      } catch (Exception var1) {
      }

   }

   public static String a(Class var0) {
      if (!var0.isArray()) {
         return !var0.isPrimitive() && var0 != Object.class && var0 != Boolean.class && var0 != Byte.class && var0 != Character.class && var0 != Short.class && var0 != Integer.class && var0 != Long.class && var0 != Float.class && var0 != Double.class && var0 != String.class ? var0.getName() : var0.getSimpleName();
      } else {
         Class var1 = b(var0);
         StringBuilder var2 = new StringBuilder(16);
         var0 = var0.getComponentType();
         byte var3 = 0;
         int var4 = 0;

         while(true) {
            int var5 = var3;
            if (var0 == null) {
               while(var5 < var4) {
                  var2.append("[]");
                  ++var5;
               }

               StringBuilder var6 = new StringBuilder();
               var6.append(a(var1));
               var6.append(var2);
               return var6.toString();
            }

            ++var4;
            var0 = var0.getComponentType();
         }
      }
   }

   public static String a(Object var0) {
      if (var0 == null) {
         return "null";
      } else {
         Class var1 = var0.getClass();
         if (var1.isArray()) {
            return a(var1);
         } else {
            String var3;
            String var4;
            label56: {
               try {
                  if (var1.getMethod("toString").getDeclaringClass() != Object.class) {
                     return String.valueOf(var0);
                  }

                  if (c.b.c.a.c) {
                     var4 = a(var1);
                     break label56;
                  }

                  var4 = var1.getSimpleName();
               } catch (Exception var2) {
                  return String.valueOf(var0);
               }

               var3 = var4;
               return var3;
            }

            var3 = var4;
            return var3;
         }
      }
   }

   public static void a(String var0, Object var1) {
      if (var1 == null) {
         if (c.b.c.a.c) {
            StringBuilder var4 = new StringBuilder();
            var4.append(var0);
            var4.append(": null");
            c.b.c.a.b("kryo", var4.toString());
         }

      } else {
         Class var2 = var1.getClass();
         StringBuilder var3;
         if (!var2.isPrimitive() && var2 != Boolean.class && var2 != Byte.class && var2 != Character.class && var2 != Short.class && var2 != Integer.class && var2 != Long.class && var2 != Float.class && var2 != Double.class && var2 != String.class) {
            var3 = c.a.b.a.a.b(var0, ": ");
            var3.append(a(var1));
            c.b.c.a.a("kryo", var3.toString());
         } else if (c.b.c.a.c) {
            var3 = c.a.b.a.a.b(var0, ": ");
            var3.append(a(var1));
            c.b.c.a.b("kryo", var3.toString());
         }

      }
   }

   public static Class b(Class var0) {
      while(var0.getComponentType() != null) {
         var0 = var0.getComponentType();
      }

      return var0;
   }

   public static Class c(Class var0) {
      if (var0 == Integer.TYPE) {
         return Integer.class;
      } else if (var0 == Float.TYPE) {
         return Float.class;
      } else if (var0 == Boolean.TYPE) {
         return Boolean.class;
      } else if (var0 == Long.TYPE) {
         return Long.class;
      } else if (var0 == Byte.TYPE) {
         return Byte.class;
      } else if (var0 == Character.TYPE) {
         return Character.class;
      } else if (var0 == Short.TYPE) {
         return Short.class;
      } else {
         return var0 == Double.TYPE ? Double.class : Void.class;
      }
   }

   public static boolean d(Class var0) {
      boolean var1;
      if (var0 != Integer.class && var0 != Float.class && var0 != Boolean.class && var0 != Long.class && var0 != Byte.class && var0 != Character.class && var0 != Short.class && var0 != Double.class) {
         var1 = false;
      } else {
         var1 = true;
      }

      return var1;
   }
}
