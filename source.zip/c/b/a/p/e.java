package c.b.a.p;

public class e {
   public int[] a;
   public int b;

   public e(boolean var1, int var2) {
      this.a = new int[var2];
   }

   public void a(int var1) {
      int[] var2 = this.a;
      int var3 = this.b;
      int[] var4 = var2;
      if (var3 == var2.length) {
         var4 = new int[Math.max(8, (int)((float)var3 * 1.75F))];
         var2 = this.a;
         System.arraycopy(var2, 0, var4, 0, Math.min(var2.length, var4.length));
         this.a = var4;
      }

      var3 = this.b++;
      var4[var3] = var1;
   }

   public String toString() {
      if (this.b == 0) {
         return "[]";
      } else {
         int[] var1 = this.a;
         StringBuilder var2 = new StringBuilder(32);
         var2.append('[');
         var2.append(var1[0]);

         for(int var3 = 1; var3 < this.b; ++var3) {
            var2.append(", ");
            var2.append(var1[var3]);
         }

         var2.append(']');
         return var2.toString();
      }
   }
}
