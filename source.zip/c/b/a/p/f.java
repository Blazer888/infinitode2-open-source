package c.b.a.p;

public class f {
   public int a;
   public int[] b;
   public Object[] c;
   public int d = c.b.a.p.h.d(32);
   public int e;
   public Object f;
   public boolean g;
   public float h = 0.8F;
   public int i;
   public int j;
   public int k;
   public int l;
   public int m;

   public f() {
      int var1 = this.d;
      this.k = (int)((float)var1 * 0.8F);
      this.j = var1 - 1;
      this.i = 31 - Integer.numberOfTrailingZeros(var1);
      this.l = Math.max(3, (int)Math.ceil(Math.log((double)this.d)) * 2);
      this.m = Math.max(Math.min(this.d, 8), (int)Math.sqrt((double)this.d) / 8);
      this.b = new int[this.d + this.l];
      this.c = new Object[this.b.length];
   }

   public Object a(int var1) {
      Object var2 = null;
      if (var1 == 0) {
         return !this.g ? null : this.f;
      } else {
         int var3 = this.j & var1;
         int var4 = var3;
         if (this.b[var3] != var1) {
            var3 = this.b(var1);
            var4 = var3;
            if (this.b[var3] != var1) {
               var3 = this.c(var1);
               int[] var5 = this.b;
               var4 = var3;
               if (var5[var3] != var1) {
                  var3 = this.d;
                  int var6 = this.e;
                  var4 = var3;

                  Object var7;
                  while(true) {
                     var7 = var2;
                     if (var4 >= var6 + var3) {
                        break;
                     }

                     if (var5[var4] == var1) {
                        var7 = this.c[var4];
                        break;
                     }

                     ++var4;
                  }

                  return var7;
               }
            }
         }

         return this.c[var4];
      }
   }

   public Object a(int var1, Object var2) {
      if (var1 == 0) {
         Object var15 = this.f;
         this.f = var2;
         if (!this.g) {
            this.g = true;
            ++this.a;
         }

         return var15;
      } else {
         int[] var3 = this.b;
         int var4 = var1 & this.j;
         int var5 = var3[var4];
         Object var6;
         Object[] var14;
         if (var5 == var1) {
            var14 = this.c;
            var6 = var14[var4];
            var14[var4] = var2;
            return var6;
         } else {
            int var7 = this.b(var1);
            int var8 = var3[var7];
            if (var8 == var1) {
               var14 = this.c;
               var6 = var14[var7];
               var14[var7] = var2;
               return var6;
            } else {
               int var9 = this.c(var1);
               int var10 = var3[var9];
               if (var10 == var1) {
                  var14 = this.c;
                  var6 = var14[var9];
                  var14[var9] = var2;
                  return var6;
               } else {
                  int var11 = this.d;
                  int var12 = this.e;

                  for(int var13 = var11; var13 < var12 + var11; ++var13) {
                     if (var3[var13] == var1) {
                        var14 = this.c;
                        var6 = var14[var13];
                        var14[var13] = var2;
                        return var6;
                     }
                  }

                  if (var5 == 0) {
                     var3[var4] = var1;
                     this.c[var4] = var2;
                     var1 = this.a++;
                     if (var1 >= this.k) {
                        this.d(this.d << 1);
                     }

                     return null;
                  } else if (var8 == 0) {
                     var3[var7] = var1;
                     this.c[var7] = var2;
                     var1 = this.a++;
                     if (var1 >= this.k) {
                        this.d(this.d << 1);
                     }

                     return null;
                  } else if (var10 == 0) {
                     var3[var9] = var1;
                     this.c[var9] = var2;
                     var1 = this.a++;
                     if (var1 >= this.k) {
                        this.d(this.d << 1);
                     }

                     return null;
                  } else {
                     this.a(var1, var2, var4, var5, var7, var8, var9, var10);
                     return null;
                  }
               }
            }
         }
      }
   }

   public final void a(int var1, Object var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      int[] var9 = this.b;
      Object[] var10 = this.c;
      int var11 = this.j;
      int var12 = this.m;
      byte var13 = 0;
      int var14 = var3;
      Object var15 = var2;
      int var16 = var1;
      var3 = var13;

      int var17;
      do {
         var1 = c.b.a.p.h.l.nextInt(3);
         if (var1 != 0) {
            if (var1 != 1) {
               var2 = var10[var7];
               var9[var7] = var16;
               var10[var7] = var15;
               var1 = var8;
            } else {
               var2 = var10[var5];
               var9[var5] = var16;
               var10[var5] = var15;
               var1 = var6;
            }
         } else {
            var2 = var10[var14];
            var9[var14] = var16;
            var10[var14] = var15;
            var1 = var4;
         }

         var14 = var1 & var11;
         var4 = var9[var14];
         if (var4 == 0) {
            var9[var14] = var1;
            var10[var14] = var2;
            var1 = this.a++;
            if (var1 >= this.k) {
               this.d(this.d << 1);
            }

            return;
         }

         var5 = this.b(var1);
         var6 = var9[var5];
         if (var6 == 0) {
            var9[var5] = var1;
            var10[var5] = var2;
            var1 = this.a++;
            if (var1 >= this.k) {
               this.d(this.d << 1);
            }

            return;
         }

         var7 = this.c(var1);
         var8 = var9[var7];
         if (var8 == 0) {
            var9[var7] = var1;
            var10[var7] = var2;
            var1 = this.a++;
            if (var1 >= this.k) {
               this.d(this.d << 1);
            }

            return;
         }

         var17 = var3 + 1;
         var3 = var17;
         var16 = var1;
         var15 = var2;
      } while(var17 != var12);

      var4 = this.e;
      if (var4 == this.l) {
         this.d(this.d << 1);
         this.a(var1, var2);
      } else {
         var3 = this.d + var4;
         this.b[var3] = var1;
         this.c[var3] = var2;
         this.e = var4 + 1;
         ++this.a;
      }

   }

   public final int b(int var1) {
      var1 *= -1262997959;
      return (var1 ^ var1 >>> this.i) & this.j;
   }

   public final int c(int var1) {
      var1 *= -825114047;
      return (var1 ^ var1 >>> this.i) & this.j;
   }

   public final void d(int var1) {
      int var2 = this.d;
      int var3 = this.e;
      this.d = var1;
      this.k = (int)((float)var1 * this.h);
      this.j = var1 - 1;
      this.i = 31 - Integer.numberOfTrailingZeros(var1);
      double var4 = (double)var1;
      this.l = Math.max(3, (int)Math.ceil(Math.log(var4)) * 2);
      this.m = Math.max(Math.min(var1, 8), (int)Math.sqrt(var4) / 8);
      int[] var6 = this.b;
      Object[] var7 = this.c;
      int var8 = this.l;
      this.b = new int[var1 + var8];
      this.c = new Object[var1 + var8];
      var8 = this.a;
      this.a = this.g;
      var1 = 0;
      this.e = 0;
      if (var8 > 0) {
         for(; var1 < var2 + var3; ++var1) {
            int var9 = var6[var1];
            if (var9 != 0) {
               Object var10 = var7[var1];
               if (var9 == 0) {
                  this.f = var10;
                  this.g = true;
               } else {
                  int var11 = var9 & this.j;
                  int[] var12 = this.b;
                  int var13 = var12[var11];
                  if (var13 == 0) {
                     var12[var11] = var9;
                     this.c[var11] = var10;
                     var8 = this.a++;
                     if (var8 >= this.k) {
                        this.d(this.d << 1);
                     }
                  } else {
                     int var14 = this.b(var9);
                     var12 = this.b;
                     int var15 = var12[var14];
                     if (var15 == 0) {
                        var12[var14] = var9;
                        this.c[var14] = var10;
                        var8 = this.a++;
                        if (var8 >= this.k) {
                           this.d(this.d << 1);
                        }
                     } else {
                        int var16 = this.c(var9);
                        var12 = this.b;
                        var8 = var12[var16];
                        if (var8 == 0) {
                           var12[var16] = var9;
                           this.c[var16] = var10;
                           var8 = this.a++;
                           if (var8 >= this.k) {
                              this.d(this.d << 1);
                           }
                        } else {
                           this.a(var9, var10, var11, var13, var14, var15, var16, var8);
                        }
                     }
                  }
               }
            }
         }
      }

   }

   public String toString() {
      if (this.a == 0) {
         return "[]";
      } else {
         StringBuilder var1 = new StringBuilder(32);
         var1.append('[');
         int[] var2 = this.b;
         Object[] var3 = this.c;
         int var4 = var2.length;
         int var5 = var4;
         int var6;
         if (this.g) {
            var1.append("0=");
            var1.append(this.f);
         } else {
            while(true) {
               var6 = var5 - 1;
               var4 = var6;
               if (var5 <= 0) {
                  break;
               }

               var4 = var2[var6];
               if (var4 != 0) {
                  var1.append(var4);
                  var1.append('=');
                  var1.append(var3[var6]);
                  var4 = var6;
                  break;
               }

               var5 = var6;
            }
         }

         while(true) {
            var6 = var4 - 1;
            if (var4 <= 0) {
               var1.append(']');
               return var1.toString();
            }

            var4 = var2[var6];
            if (var4 == 0) {
               var4 = var6;
            } else {
               var1.append(", ");
               var1.append(var4);
               var1.append('=');
               var1.append(var3[var6]);
               var4 = var6;
            }
         }
      }
   }
}
