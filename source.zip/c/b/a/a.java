package c.b.a;

public interface a {
}
