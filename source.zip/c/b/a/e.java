package c.b.a;

public interface e {
   Object a(d var1);
}
