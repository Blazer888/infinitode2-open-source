package c.b.a;

import java.util.HashMap;
import java.util.Map;

public class c {
   public Map a;
   public c b;

   public c() {
      this.a = new HashMap();
      this.b = null;
   }

   public c(Map var1) {
      this.a = new HashMap(var1);
      this.b = null;
   }

   public Class a(String var1) {
      Class var2 = (Class)this.a.get(var1);
      if (var2 == null) {
         c var3 = this.b;
         if (var3 != null) {
            return var3.a(var1);
         }
      }

      return var2;
   }

   public String toString() {
      return this.a.toString();
   }
}
