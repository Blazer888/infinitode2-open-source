package c.b.a;

public class j {
   public final Class a;
   public final int b;
   public k c;
   public d.a.a.a d;

   public j(Class var1, k var2, int var3) {
      if (var1 != null) {
         if (var2 != null) {
            this.a = var1;
            this.c = var2;
            this.b = var3;
         } else {
            throw new IllegalArgumentException("serializer cannot be null.");
         }
      } else {
         throw new IllegalArgumentException("type cannot be null.");
      }
   }

   public String toString() {
      StringBuilder var1 = c.a.b.a.a.b("[");
      var1.append(this.b);
      var1.append(", ");
      var1.append(c.b.a.p.i.a(this.a));
      var1.append("]");
      return var1.toString();
   }
}
