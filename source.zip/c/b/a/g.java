package c.b.a;

public interface g {
   void read(d var1, c.b.a.n.a var2);

   void write(d var1, c.b.a.n.b var2);
}
