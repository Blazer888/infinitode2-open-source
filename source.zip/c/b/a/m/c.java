package c.b.a.m;

import c.b.a.d;
import c.b.a.k;

public interface c {
   k a(d var1, Class var2);
}
