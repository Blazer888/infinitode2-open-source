package c.b.a.m;

import c.b.a.d;
import c.b.a.k;

public class a implements c {
   public final k a;

   public a(k var1) {
      this.a = var1;
   }

   public k a(d var1, Class var2) {
      return this.a;
   }
}
