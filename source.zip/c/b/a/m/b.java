package c.b.a.m;

import c.b.a.d;
import c.b.a.k;
import c.b.a.p.i;

public class b implements c {
   public final Class a;

   public b(Class var1) {
      this.a = var1;
   }

   public static k a(d var0, Class var1, Class var2) {
      try {
         try {
            k var9 = (k)var1.getConstructor(d.class, Class.class).newInstance(var0, var2);
            return var9;
         } catch (NoSuchMethodException var6) {
            k var8;
            try {
               var8 = (k)var1.getConstructor(d.class).newInstance(var0);
               return var8;
            } catch (NoSuchMethodException var5) {
               try {
                  var8 = (k)var1.getConstructor(Class.class).newInstance(var2);
                  return var8;
               } catch (NoSuchMethodException var4) {
                  var8 = (k)var1.newInstance();
                  return var8;
               }
            }
         }
      } catch (Exception var7) {
         StringBuilder var3 = c.a.b.a.a.b("Unable to create serializer \"");
         var3.append(var1.getName());
         var3.append("\" for class: ");
         var3.append(i.a(var2));
         throw new IllegalArgumentException(var3.toString(), var7);
      }
   }

   public k a(d var1, Class var2) {
      return a(var1, this.a, var2);
   }
}
