package c.b.a;

public abstract class k {
   public boolean a;
   public boolean b;

   public k() {
   }

   public k(boolean var1) {
      this.a = var1;
   }

   public k(boolean var1, boolean var2) {
      this.a = var1;
      this.b = var2;
   }

   public Object copy(d var1, Object var2) {
      if (this.b) {
         return var2;
      } else {
         StringBuilder var3 = c.a.b.a.a.b("Serializer does not support copy: ");
         var3.append(this.getClass().getName());
         throw new f(var3.toString());
      }
   }

   public boolean getAcceptsNull() {
      return this.a;
   }

   public boolean isImmutable() {
      return this.b;
   }

   public abstract Object read(d var1, c.b.a.n.a var2, Class var3);

   public void setAcceptsNull(boolean var1) {
      this.a = var1;
   }

   public void setGenerics(d var1, Class[] var2) {
   }

   public void setImmutable(boolean var1) {
      this.b = var1;
   }

   public abstract void write(d var1, c.b.a.n.b var2, Object var3);
}
