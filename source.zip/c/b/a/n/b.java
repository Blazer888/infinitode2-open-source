package c.b.a.n;

import c.b.a.f;
import java.io.IOException;
import java.io.OutputStream;

public class b extends OutputStream {
   public int a;
   public long b;
   public int c;
   public int d;
   public byte[] e;
   public OutputStream f;

   public b(int var1, int var2) {
      if (var2 >= -1) {
         this.d = var1;
         int var3 = var2;
         if (var2 == -1) {
            var3 = Integer.MAX_VALUE;
         }

         this.a = var3;
         this.e = new byte[var1];
      } else {
         throw new IllegalArgumentException(c.a.b.a.a.a("maxBufferSize cannot be < -1: ", var2));
      }
   }

   public int a(int var1, boolean var2) {
      int var3 = var1;
      if (!var2) {
         var3 = var1 >> 31 ^ var1 << 1;
      }

      int var4 = var3 >>> 7;
      byte[] var5;
      if (var4 == 0) {
         this.a((int)1);
         var5 = this.e;
         var1 = this.c++;
         var5[var1] = (byte)((byte)var3);
         return 1;
      } else {
         var1 = var3 >>> 14;
         if (var1 == 0) {
            this.a((int)2);
            var5 = this.e;
            var1 = this.c++;
            var5[var1] = (byte)((byte)(var3 & 127 | 128));
            var1 = this.c++;
            var5[var1] = (byte)((byte)var4);
            return 2;
         } else {
            int var6 = var3 >>> 21;
            if (var6 == 0) {
               this.a((int)3);
               var5 = this.e;
               var6 = this.c++;
               var5[var6] = (byte)((byte)(var3 & 127 | 128));
               var3 = this.c++;
               var5[var3] = (byte)((byte)(var4 | 128));
               var3 = this.c++;
               var5[var3] = (byte)((byte)var1);
               return 3;
            } else {
               int var7 = var3 >>> 28;
               if (var7 == 0) {
                  this.a((int)4);
                  var5 = this.e;
                  var7 = this.c++;
                  var5[var7] = (byte)((byte)(var3 & 127 | 128));
                  var3 = this.c++;
                  var5[var3] = (byte)((byte)(var4 | 128));
                  var3 = this.c++;
                  var5[var3] = (byte)((byte)(var1 | 128));
                  var1 = this.c++;
                  var5[var1] = (byte)((byte)var6);
                  return 4;
               } else {
                  this.a((int)5);
                  var5 = this.e;
                  int var8 = this.c++;
                  var5[var8] = (byte)((byte)(var3 & 127 | 128));
                  var3 = this.c++;
                  var5[var3] = (byte)((byte)(var4 | 128));
                  var3 = this.c++;
                  var5[var3] = (byte)((byte)(var1 | 128));
                  var1 = this.c++;
                  var5[var1] = (byte)((byte)(var6 | 128));
                  var1 = this.c++;
                  var5[var1] = (byte)((byte)var7);
                  return 5;
               }
            }
         }
      }
   }

   public int a(long var1, boolean var3) {
      if (!var3) {
         var1 = var1 << 1 ^ var1 >> 63;
      }

      long var4 = var1 >>> 7;
      byte[] var6;
      int var7;
      if (var4 == 0L) {
         this.a((int)1);
         var6 = this.e;
         var7 = this.c++;
         var6[var7] = (byte)((byte)((int)var1));
         return 1;
      } else {
         long var8 = var1 >>> 14;
         if (var8 == 0L) {
            this.a((int)2);
            var6 = this.e;
            var7 = this.c++;
            var6[var7] = (byte)((byte)((int)(var1 & 127L | 128L)));
            var7 = this.c++;
            var6[var7] = (byte)((byte)((int)var4));
            return 2;
         } else {
            long var10 = var1 >>> 21;
            if (var10 == 0L) {
               this.a((int)3);
               var6 = this.e;
               var7 = this.c++;
               var6[var7] = (byte)((byte)((int)(var1 & 127L | 128L)));
               var7 = this.c++;
               var6[var7] = (byte)((byte)((int)(var4 | 128L)));
               var7 = this.c++;
               var6[var7] = (byte)((byte)((int)var8));
               return 3;
            } else {
               long var12 = var1 >>> 28;
               if (var12 == 0L) {
                  this.a((int)4);
                  var6 = this.e;
                  var7 = this.c++;
                  var6[var7] = (byte)((byte)((int)(var1 & 127L | 128L)));
                  var7 = this.c++;
                  var6[var7] = (byte)((byte)((int)(var4 | 128L)));
                  var7 = this.c++;
                  var6[var7] = (byte)((byte)((int)(var8 | 128L)));
                  var7 = this.c++;
                  var6[var7] = (byte)((byte)((int)var10));
                  return 4;
               } else {
                  long var14 = var1 >>> 35;
                  if (var14 == 0L) {
                     this.a((int)5);
                     var6 = this.e;
                     var7 = this.c++;
                     var6[var7] = (byte)((byte)((int)(var1 & 127L | 128L)));
                     var7 = this.c++;
                     var6[var7] = (byte)((byte)((int)(var4 | 128L)));
                     var7 = this.c++;
                     var6[var7] = (byte)((byte)((int)(var8 | 128L)));
                     var7 = this.c++;
                     var6[var7] = (byte)((byte)((int)(var10 | 128L)));
                     var7 = this.c++;
                     var6[var7] = (byte)((byte)((int)var12));
                     return 5;
                  } else {
                     long var16 = var1 >>> 42;
                     if (var16 == 0L) {
                        this.a((int)6);
                        var6 = this.e;
                        var7 = this.c++;
                        var6[var7] = (byte)((byte)((int)(var1 & 127L | 128L)));
                        var7 = this.c++;
                        var6[var7] = (byte)((byte)((int)(var4 | 128L)));
                        var7 = this.c++;
                        var6[var7] = (byte)((byte)((int)(var8 | 128L)));
                        var7 = this.c++;
                        var6[var7] = (byte)((byte)((int)(var10 | 128L)));
                        var7 = this.c++;
                        var6[var7] = (byte)((byte)((int)(var12 | 128L)));
                        var7 = this.c++;
                        var6[var7] = (byte)((byte)((int)var14));
                        return 6;
                     } else {
                        long var18 = var1 >>> 49;
                        if (var18 == 0L) {
                           this.a((int)7);
                           var6 = this.e;
                           var7 = this.c++;
                           var6[var7] = (byte)((byte)((int)(var1 & 127L | 128L)));
                           var7 = this.c++;
                           var6[var7] = (byte)((byte)((int)(var4 | 128L)));
                           var7 = this.c++;
                           var6[var7] = (byte)((byte)((int)(var8 | 128L)));
                           var7 = this.c++;
                           var6[var7] = (byte)((byte)((int)(var10 | 128L)));
                           var7 = this.c++;
                           var6[var7] = (byte)((byte)((int)(var12 | 128L)));
                           var7 = this.c++;
                           var6[var7] = (byte)((byte)((int)(var14 | 128L)));
                           var7 = this.c++;
                           var6[var7] = (byte)((byte)((int)var16));
                           return 7;
                        } else {
                           long var20 = var1 >>> 56;
                           if (var20 == 0L) {
                              this.a((int)8);
                              var6 = this.e;
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)(var1 & 127L | 128L)));
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)(var4 | 128L)));
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)(var8 | 128L)));
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)(var10 | 128L)));
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)(var12 | 128L)));
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)(var14 | 128L)));
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)(var16 | 128L)));
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)var18));
                              return 8;
                           } else {
                              this.a((int)9);
                              var6 = this.e;
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)(var1 & 127L | 128L)));
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)(var4 | 128L)));
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)(var8 | 128L)));
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)(var10 | 128L)));
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)(var12 | 128L)));
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)(var14 | 128L)));
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)(var16 | 128L)));
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)(var18 | 128L)));
                              var7 = this.c++;
                              var6[var7] = (byte)((byte)((int)var20));
                              return 9;
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public void a() {
      this.c = 0;
      this.b = 0L;
   }

   public void a(byte var1) {
      if (this.c == this.d) {
         this.a((int)1);
      }

      byte[] var2 = this.e;
      int var3 = this.c++;
      var2[var3] = (byte)var1;
   }

   public void a(char var1) {
      this.a((int)2);
      byte[] var2 = this.e;
      int var3 = this.c++;
      var2[var3] = (byte)((byte)(var1 >>> 8));
      var3 = this.c++;
      var2[var3] = (byte)((byte)var1);
   }

   public void a(double var1) {
      this.a(Double.doubleToLongBits(var1));
   }

   public void a(float var1) {
      this.d(Float.floatToIntBits(var1));
   }

   public void a(long var1) {
      this.a((int)8);
      byte[] var3 = this.e;
      int var4 = this.c++;
      var3[var4] = (byte)((byte)((int)(var1 >>> 56)));
      var4 = this.c++;
      var3[var4] = (byte)((byte)((int)(var1 >>> 48)));
      var4 = this.c++;
      var3[var4] = (byte)((byte)((int)(var1 >>> 40)));
      var4 = this.c++;
      var3[var4] = (byte)((byte)((int)(var1 >>> 32)));
      var4 = this.c++;
      var3[var4] = (byte)((byte)((int)(var1 >>> 24)));
      var4 = this.c++;
      var3[var4] = (byte)((byte)((int)(var1 >>> 16)));
      var4 = this.c++;
      var3[var4] = (byte)((byte)((int)(var1 >>> 8)));
      var4 = this.c++;
      var3[var4] = (byte)((byte)((int)var1));
   }

   public void a(CharSequence var1) {
      if (var1 == null) {
         this.c(128);
      } else {
         int var2 = var1.length();
         if (var2 == 0) {
            this.c(129);
         } else {
            this.f(var2 + 1);
            int var3 = 0;
            byte var4 = 0;
            int var5 = this.d;
            int var6 = this.c;
            if (var5 - var6 >= var2) {
               byte[] var7 = this.e;

               for(var3 = var4; var3 < var2; ++var6) {
                  char var8 = var1.charAt(var3);
                  if (var8 > 127) {
                     break;
                  }

                  var7[var6] = (byte)((byte)var8);
                  ++var3;
               }

               this.c = var6;
            }

            if (var3 < var2) {
               this.a(var1, var2, var3);
            }

         }
      }
   }

   public final void a(CharSequence var1, int var2, int var3) {
      for(; var3 < var2; ++var3) {
         int var4 = this.c;
         int var5 = this.d;
         if (var4 == var5) {
            this.a(Math.min(var5, var2 - var3));
         }

         char var7 = var1.charAt(var3);
         byte[] var6;
         if (var7 <= 127) {
            var6 = this.e;
            var5 = this.c++;
            var6[var5] = (byte)((byte)var7);
         } else if (var7 > 2047) {
            var6 = this.e;
            var5 = this.c++;
            var6[var5] = (byte)((byte)(var7 >> 12 & 15 | 224));
            this.a((int)2);
            var6 = this.e;
            var5 = this.c++;
            var6[var5] = (byte)((byte)(var7 >> 6 & 63 | 128));
            var5 = this.c++;
            var6[var5] = (byte)((byte)(var7 & 63 | 128));
         } else {
            var6 = this.e;
            var5 = this.c++;
            var6[var5] = (byte)((byte)(var7 >> 6 & 31 | 192));
            this.a((int)1);
            var6 = this.e;
            var5 = this.c++;
            var6[var5] = (byte)((byte)(var7 & 63 | 128));
         }
      }

   }

   public void a(String var1) {
      if (var1 == null) {
         this.c(128);
      } else {
         int var2 = var1.length();
         if (var2 == 0) {
            this.c(129);
         } else {
            byte var3;
            byte var4;
            byte var5;
            int var6;
            boolean var13;
            label72: {
               var3 = 0;
               var4 = 0;
               var5 = 0;
               if (var2 > 1 && var2 < 64) {
                  var6 = 0;

                  while(true) {
                     if (var6 >= var2) {
                        var13 = true;
                        break label72;
                     }

                     if (var1.charAt(var6) > 127) {
                        break;
                     }

                     ++var6;
                  }
               }

               var13 = false;
            }

            byte[] var7;
            int var12;
            if (var13) {
               int var10 = this.d;
               var6 = this.c;
               if (var10 - var6 < var2) {
                  var7 = this.e;
                  var10 = Math.min(var2, var10 - var6);
                  var6 = var5;

                  for(var12 = var10; var6 < var2; var6 = var10) {
                     var10 = var6 + var12;
                     var1.getBytes(var6, var10, var7, this.c);
                     this.c += var12;
                     var12 = Math.min(var2 - var10, this.d);
                     if (this.a(var12)) {
                        var7 = this.e;
                     }
                  }
               } else {
                  var1.getBytes(0, var2, this.e, var6);
                  this.c += var2;
               }

               byte[] var9 = this.e;
               var6 = this.c - 1;
               var9[var6] = (byte)((byte)(128 | var9[var6]));
            } else {
               this.f(var2 + 1);
               int var8 = this.d;
               var12 = this.c;
               var6 = var4;
               if (var8 - var12 >= var2) {
                  var7 = this.e;

                  for(var6 = var3; var6 < var2; ++var12) {
                     char var11 = var1.charAt(var6);
                     if (var11 > 127) {
                        break;
                     }

                     var7[var12] = (byte)((byte)var11);
                     ++var6;
                  }

                  this.c = var12;
               }

               if (var6 < var2) {
                  this.a((CharSequence)var1, var2, var6);
               }
            }

         }
      }
   }

   public void a(boolean var1) {
      if (this.c == this.d) {
         this.a((int)1);
      }

      byte[] var2 = this.e;
      int var3 = this.c++;
      var2[var3] = (byte)((byte)var1);
   }

   public void a(byte[] var1) {
      if (var1 != null) {
         this.a((byte[])var1, 0, var1.length);
      } else {
         throw new IllegalArgumentException("bytes cannot be null.");
      }
   }

   public void a(byte[] var1, int var2, int var3) {
      if (var1 == null) {
         IllegalArgumentException var5 = new IllegalArgumentException("bytes cannot be null.");
         throw var5;
      } else {
         int var4 = Math.min(this.d - this.c, var3);

         while(true) {
            System.arraycopy(var1, var2, this.e, this.c, var4);
            this.c += var4;
            var3 -= var4;
            if (var3 == 0) {
               return;
            }

            var2 += var4;
            var4 = Math.min(this.d, var3);
            this.a(var4);
         }
      }
   }

   public boolean a(int var1) {
      if (this.d - this.c >= var1) {
         return false;
      } else {
         StringBuilder var3;
         if (var1 <= this.a) {
            this.flush();

            while(true) {
               int var2 = this.d;
               if (var2 - this.c >= var1) {
                  return true;
               }

               if (var2 == this.a) {
                  var3 = c.a.b.a.a.b("Buffer overflow. Available: ");
                  var3.append(this.d - this.c);
                  var3.append(", required: ");
                  var3.append(var1);
                  throw new f(var3.toString());
               }

               if (var2 == 0) {
                  this.d = 1;
               }

               this.d = Math.min(this.d * 2, this.a);
               if (this.d < 0) {
                  this.d = this.a;
               }

               byte[] var5 = new byte[this.d];
               System.arraycopy(this.e, 0, var5, 0, this.c);
               this.e = var5;
            }
         } else {
            var3 = c.a.b.a.a.b("Buffer overflow. Max capacity: ");
            var3.append(this.a);
            var3.append(", required: ");
            var3.append(var1);
            f var4 = new f(var3.toString());
            throw var4;
         }
      }
   }

   public void c(int var1) {
      if (this.c == this.d) {
         this.a((int)1);
      }

      byte[] var2 = this.e;
      int var3 = this.c++;
      var2[var3] = (byte)((byte)var1);
   }

   public void close() {
      this.flush();
      OutputStream var1 = this.f;
      if (var1 != null) {
         try {
            var1.close();
         } catch (IOException var2) {
         }
      }

   }

   public void d(int var1) {
      this.a((int)4);
      byte[] var2 = this.e;
      int var3 = this.c++;
      var2[var3] = (byte)((byte)(var1 >> 24));
      var3 = this.c++;
      var2[var3] = (byte)((byte)(var1 >> 16));
      var3 = this.c++;
      var2[var3] = (byte)((byte)(var1 >> 8));
      var3 = this.c++;
      var2[var3] = (byte)((byte)var1);
   }

   public void e(int var1) {
      this.a((int)2);
      byte[] var2 = this.e;
      int var3 = this.c++;
      var2[var3] = (byte)((byte)(var1 >>> 8));
      var3 = this.c++;
      var2[var3] = (byte)((byte)var1);
   }

   public final void f(int var1) {
      int var2 = var1 >>> 6;
      byte[] var3;
      int var4;
      if (var2 == 0) {
         this.a((int)1);
         var3 = this.e;
         var4 = this.c++;
         var3[var4] = (byte)((byte)(var1 | 128));
      } else {
         var4 = var1 >>> 13;
         if (var4 == 0) {
            this.a((int)2);
            var3 = this.e;
            var4 = this.c++;
            var3[var4] = (byte)((byte)(var1 | 64 | 128));
            var1 = this.c++;
            var3[var1] = (byte)((byte)var2);
         } else {
            int var5 = var1 >>> 20;
            if (var5 == 0) {
               this.a((int)3);
               var3 = this.e;
               var5 = this.c++;
               var3[var5] = (byte)((byte)(var1 | 64 | 128));
               var1 = this.c++;
               var3[var1] = (byte)((byte)(var2 | 128));
               var1 = this.c++;
               var3[var1] = (byte)((byte)var4);
            } else {
               int var6 = var1 >>> 27;
               if (var6 == 0) {
                  this.a((int)4);
                  var3 = this.e;
                  var6 = this.c++;
                  var3[var6] = (byte)((byte)(var1 | 64 | 128));
                  var1 = this.c++;
                  var3[var1] = (byte)((byte)(var2 | 128));
                  var1 = this.c++;
                  var3[var1] = (byte)((byte)(var4 | 128));
                  var1 = this.c++;
                  var3[var1] = (byte)((byte)var5);
               } else {
                  this.a((int)5);
                  var3 = this.e;
                  int var7 = this.c++;
                  var3[var7] = (byte)((byte)(var1 | 64 | 128));
                  var1 = this.c++;
                  var3[var1] = (byte)((byte)(var2 | 128));
                  var1 = this.c++;
                  var3[var1] = (byte)((byte)(var4 | 128));
                  var1 = this.c++;
                  var3[var1] = (byte)((byte)(var5 | 128));
                  var1 = this.c++;
                  var3[var1] = (byte)((byte)var6);
               }
            }
         }
      }

   }

   public void flush() {
      OutputStream var1 = this.f;
      if (var1 != null) {
         try {
            var1.write(this.e, 0, this.c);
         } catch (IOException var2) {
            throw new f(var2);
         }

         this.b += (long)this.c;
         this.c = 0;
      }
   }

   public void write(int var1) {
      if (this.c == this.d) {
         this.a((int)1);
      }

      byte[] var2 = this.e;
      int var3 = this.c++;
      var2[var3] = (byte)((byte)var1);
   }

   public void write(byte[] var1) {
      if (var1 != null) {
         this.a((byte[])var1, 0, var1.length);
      } else {
         throw new IllegalArgumentException("bytes cannot be null.");
      }
   }

   public void write(byte[] var1, int var2, int var3) {
      this.a(var1, var2, var3);
   }
}
