package c.b.a.n;

import c.b.a.f;
import java.io.IOException;
import java.io.InputStream;

public class a extends InputStream {
   public byte[] a;
   public int b;
   public int c;
   public int d;
   public long e;
   public char[] f = new char[32];
   public InputStream g;

   public final int a(int var1) {
      int var2 = this.d - this.b;
      if (var2 >= var1) {
         return var1;
      } else {
         int var3 = Math.min(var1, this.c);
         byte[] var4 = this.a;
         var1 = this.d;
         int var5 = this.a(var4, var1, this.c - var1);
         int var6 = -1;
         if (var5 == -1) {
            if (var2 != 0) {
               var6 = Math.min(var2, var3);
            }

            return var6;
         } else {
            var1 = var2 + var5;
            if (var1 >= var3) {
               this.d += var5;
               return var3;
            } else {
               var4 = this.a;
               System.arraycopy(var4, this.b, var4, 0, var1);
               this.e += (long)this.b;
               this.b = 0;

               while(true) {
                  var2 = this.a(this.a, var1, this.c - var1);
                  if (var2 == -1) {
                     break;
                  }

                  var2 += var1;
                  var1 = var2;
                  if (var2 >= var3) {
                     var1 = var2;
                     break;
                  }
               }

               this.d = var1;
               if (var1 != 0) {
                  var6 = Math.min(var1, var3);
               }

               return var6;
            }
         }
      }
   }

   public int a(boolean var1) {
      byte[] var2;
      int var3;
      byte var4;
      int var5;
      if (this.g(1) < 5) {
         var2 = this.a;
         var3 = this.b++;
         var4 = var2[var3];
         var5 = var4 & 127;
         var3 = var5;
         if ((var4 & 128) != 0) {
            this.g(1);
            var2 = this.a;
            var3 = this.b++;
            var4 = var2[var3];
            var5 |= (var4 & 127) << 7;
            var3 = var5;
            if ((var4 & 128) != 0) {
               this.g(1);
               var3 = this.b++;
               var4 = var2[var3];
               var5 |= (var4 & 127) << 14;
               var3 = var5;
               if ((var4 & 128) != 0) {
                  this.g(1);
                  var3 = this.b++;
                  var4 = var2[var3];
                  var5 |= (var4 & 127) << 21;
                  var3 = var5;
                  if ((var4 & 128) != 0) {
                     this.g(1);
                     var3 = this.b++;
                     var3 = var5 | (var2[var3] & 127) << 28;
                  }
               }
            }
         }

         if (!var1) {
            var3 = var3 >>> 1 ^ -(var3 & 1);
         }

         return var3;
      } else {
         var2 = this.a;
         var3 = this.b++;
         var4 = var2[var3];
         var5 = var4 & 127;
         var3 = var5;
         if ((var4 & 128) != 0) {
            var3 = this.b++;
            var4 = var2[var3];
            var5 |= (var4 & 127) << 7;
            var3 = var5;
            if ((var4 & 128) != 0) {
               var3 = this.b++;
               var4 = var2[var3];
               var5 |= (var4 & 127) << 14;
               var3 = var5;
               if ((var4 & 128) != 0) {
                  var3 = this.b++;
                  var4 = var2[var3];
                  var5 |= (var4 & 127) << 21;
                  var3 = var5;
                  if ((var4 & 128) != 0) {
                     var3 = this.b++;
                     var3 = var5 | (var2[var3] & 127) << 28;
                  }
               }
            }
         }

         if (!var1) {
            var3 = var3 >>> 1 ^ -(var3 & 1);
         }

         return var3;
      }
   }

   public int a(byte[] var1, int var2, int var3) {
      InputStream var4 = this.g;
      if (var4 == null) {
         return -1;
      } else {
         try {
            var2 = var4.read(var1, var2, var3);
            return var2;
         } catch (IOException var5) {
            throw new f(var5);
         }
      }
   }

   public final String a() {
      byte[] var1 = this.a;
      int var2 = this.b;
      int var3 = var2 - 1;

      int var4;
      int var7;
      for(var4 = this.d; var2 != var4; var2 = var7) {
         var7 = var2 + 1;
         if ((var1[var2] & 128) != 0) {
            var2 = var7 - 1;
            var1[var2] = (byte)((byte)(var1[var2] & 127));
            String var5 = new String(var1, 0, var3, var7 - var3);
            var1[var2] = (byte)((byte)(var1[var2] | 128));
            this.b = var7;
            return var5;
         }
      }

      --this.b;
      var3 = this.d - this.b;
      if (var3 > this.f.length) {
         this.f = new char[var3 * 2];
      }

      char[] var9 = this.f;
      byte[] var6 = this.a;
      var7 = this.b;
      var4 = this.d;

      for(var2 = 0; var7 < var4; ++var2) {
         var9[var2] = (char)((char)var6[var7]);
         ++var7;
      }

      this.b = this.d;
      var2 = var3;

      while(true) {
         this.g(1);
         var7 = this.b++;
         byte var10 = var6[var7];
         char[] var8 = var9;
         if (var2 == var9.length) {
            var8 = new char[var2 * 2];
            System.arraycopy(var9, 0, var8, 0, var2);
            this.f = var8;
         }

         if ((var10 & 128) == 128) {
            var8[var2] = (char)((char)(var10 & 127));
            return new String(var8, 0, var2 + 1);
         }

         var8[var2] = (char)((char)var10);
         ++var2;
         var9 = var8;
      }
   }

   public void a(byte[] var1) {
      int var2 = var1.length;
      this.a = var1;
      this.b = 0;
      this.d = 0 + var2;
      this.c = var1.length;
      this.e = 0L;
      this.g = null;
   }

   public int available() {
      int var1 = this.d;
      int var2 = this.b;
      InputStream var3 = this.g;
      int var4;
      if (var3 != null) {
         var4 = var3.available();
      } else {
         var4 = 0;
      }

      return var1 - var2 + var4;
   }

   public long b(boolean var1) {
      byte[] var2;
      int var3;
      long var4;
      long var6;
      byte var8;
      if (this.g(1) < 9) {
         var2 = this.a;
         var3 = this.b++;
         var8 = var2[var3];
         var4 = (long)(var8 & 127);
         var6 = var4;
         if ((var8 & 128) != 0) {
            this.g(1);
            var2 = this.a;
            var3 = this.b++;
            var8 = var2[var3];
            var4 |= (long)((var8 & 127) << 7);
            var6 = var4;
            if ((var8 & 128) != 0) {
               this.g(1);
               var3 = this.b++;
               var8 = var2[var3];
               var4 |= (long)((var8 & 127) << 14);
               var6 = var4;
               if ((var8 & 128) != 0) {
                  this.g(1);
                  var3 = this.b++;
                  var8 = var2[var3];
                  var4 |= (long)((var8 & 127) << 21);
                  var6 = var4;
                  if ((var8 & 128) != 0) {
                     this.g(1);
                     var3 = this.b++;
                     var8 = var2[var3];
                     var4 |= (long)(var8 & 127) << 28;
                     var6 = var4;
                     if ((var8 & 128) != 0) {
                        this.g(1);
                        var3 = this.b++;
                        var8 = var2[var3];
                        var4 |= (long)(var8 & 127) << 35;
                        var6 = var4;
                        if ((var8 & 128) != 0) {
                           this.g(1);
                           var3 = this.b++;
                           var8 = var2[var3];
                           var4 |= (long)(var8 & 127) << 42;
                           var6 = var4;
                           if ((var8 & 128) != 0) {
                              this.g(1);
                              var3 = this.b++;
                              var8 = var2[var3];
                              var4 |= (long)(var8 & 127) << 49;
                              var6 = var4;
                              if ((var8 & 128) != 0) {
                                 this.g(1);
                                 var3 = this.b++;
                                 var6 = var4 | (long)var2[var3] << 56;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         var4 = var6;
         if (!var1) {
            var4 = -(var6 & 1L) ^ var6 >>> 1;
         }

         return var4;
      } else {
         var2 = this.a;
         var3 = this.b++;
         var8 = var2[var3];
         var4 = (long)(var8 & 127);
         var6 = var4;
         if ((var8 & 128) != 0) {
            var3 = this.b++;
            var8 = var2[var3];
            var4 |= (long)((var8 & 127) << 7);
            var6 = var4;
            if ((var8 & 128) != 0) {
               var3 = this.b++;
               var8 = var2[var3];
               var4 |= (long)((var8 & 127) << 14);
               var6 = var4;
               if ((var8 & 128) != 0) {
                  var3 = this.b++;
                  var8 = var2[var3];
                  var4 |= (long)((var8 & 127) << 21);
                  var6 = var4;
                  if ((var8 & 128) != 0) {
                     var3 = this.b++;
                     var8 = var2[var3];
                     var4 |= (long)(var8 & 127) << 28;
                     var6 = var4;
                     if ((var8 & 128) != 0) {
                        var3 = this.b++;
                        var8 = var2[var3];
                        var4 |= (long)(var8 & 127) << 35;
                        var6 = var4;
                        if ((var8 & 128) != 0) {
                           var3 = this.b++;
                           var8 = var2[var3];
                           var4 |= (long)(var8 & 127) << 42;
                           var6 = var4;
                           if ((var8 & 128) != 0) {
                              var3 = this.b++;
                              var8 = var2[var3];
                              var4 |= (long)(var8 & 127) << 49;
                              var6 = var4;
                              if ((var8 & 128) != 0) {
                                 var3 = this.b++;
                                 var6 = var4 | (long)var2[var3] << 56;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         var4 = var6;
         if (!var1) {
            var4 = var6 >>> 1 ^ -(var6 & 1L);
         }

         return var4;
      }
   }

   public boolean b() {
      boolean var1 = true;
      this.g(1);
      byte[] var2 = this.a;
      int var3 = this.b++;
      if (var2[var3] != 1) {
         var1 = false;
      }

      return var1;
   }

   public byte c() {
      this.g(1);
      byte[] var1 = this.a;
      int var2 = this.b++;
      return var1[var2];
   }

   public byte[] c(int var1) {
      byte[] var2 = new byte[var1];
      int var3 = Math.min(this.d - this.b, var1);
      byte var4 = 0;
      int var5 = var1;
      var1 = var4;

      while(true) {
         System.arraycopy(this.a, this.b, var2, var1, var3);
         this.b += var3;
         var5 -= var3;
         if (var5 == 0) {
            return var2;
         }

         var1 += var3;
         var3 = Math.min(var5, this.c);
         this.g(var3);
      }
   }

   public void close() {
      InputStream var1 = this.g;
      if (var1 != null) {
         try {
            var1.close();
         } catch (IOException var2) {
         }
      }

   }

   public char d() {
      this.g(2);
      byte[] var1 = this.a;
      int var2 = this.b++;
      byte var3 = var1[var2];
      var2 = this.b++;
      return (char)(var1[var2] & 255 | (var3 & 255) << 8);
   }

   public final void d(int var1) {
      byte[] var2 = this.a;
      char[] var3 = this.f;
      int var4 = Math.min(this.g(1), var1);
      int var5 = this.b;
      int var6 = 0;

      int var7;
      while(true) {
         var7 = var5;
         if (var6 >= var4) {
            break;
         }

         var7 = var5 + 1;
         byte var10 = var2[var5];
         if (var10 < 0) {
            --var7;
            break;
         }

         var3[var6] = (char)((char)var10);
         var5 = var7;
         ++var6;
      }

      this.b = var7;
      if (var6 < var1) {
         char[] var8 = this.f;

         for(byte[] var9 = this.a; var6 < var1; ++var6) {
            if (this.b == this.d) {
               this.g(1);
            }

            var5 = this.b++;
            var5 = var9[var5] & 255;
            switch(var5 >> 4) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
               var8[var6] = (char)((char)var5);
            case 8:
            case 9:
            case 10:
            case 11:
            default:
               break;
            case 12:
            case 13:
               if (this.b == this.d) {
                  this.g(1);
               }

               var7 = this.b++;
               var8[var6] = (char)((char)((var5 & 31) << 6 | var9[var7] & 63));
               break;
            case 14:
               this.g(2);
               var7 = this.b++;
               byte var11 = var9[var7];
               var4 = this.b++;
               var8[var6] = (char)((char)((var5 & 15) << 12 | (var11 & 63) << 6 | var9[var4] & 63));
            }
         }
      }

   }

   public double e() {
      return Double.longBitsToDouble(this.h());
   }

   public final int e(int var1) {
      int var2 = var1 & 63;
      int var3 = var2;
      if ((var1 & 64) != 0) {
         byte[] var4 = this.a;
         var1 = this.b++;
         byte var5 = var4[var1];
         var1 = var2 | (var5 & 127) << 6;
         var3 = var1;
         if ((var5 & 128) != 0) {
            var3 = this.b++;
            byte var6 = var4[var3];
            var1 |= (var6 & 127) << 13;
            var3 = var1;
            if ((var6 & 128) != 0) {
               var3 = this.b++;
               var6 = var4[var3];
               var1 |= (var6 & 127) << 20;
               var3 = var1;
               if ((var6 & 128) != 0) {
                  var3 = this.b++;
                  var3 = var1 | (var4[var3] & 127) << 27;
               }
            }
         }
      }

      return var3;
   }

   public float f() {
      return Float.intBitsToFloat(this.g());
   }

   public final int f(int var1) {
      int var2 = var1 & 63;
      int var3 = var2;
      if ((var1 & 64) != 0) {
         this.g(1);
         byte[] var4 = this.a;
         var1 = this.b++;
         byte var5 = var4[var1];
         var1 = var2 | (var5 & 127) << 6;
         var3 = var1;
         if ((var5 & 128) != 0) {
            this.g(1);
            var3 = this.b++;
            byte var6 = var4[var3];
            var1 |= (var6 & 127) << 13;
            var3 = var1;
            if ((var6 & 128) != 0) {
               this.g(1);
               var3 = this.b++;
               var6 = var4[var3];
               var1 |= (var6 & 127) << 20;
               var3 = var1;
               if ((var6 & 128) != 0) {
                  this.g(1);
                  var3 = this.b++;
                  var3 = var1 | (var4[var3] & 127) << 27;
               }
            }
         }
      }

      return var3;
   }

   public int g() {
      this.g(4);
      byte[] var1 = this.a;
      int var2 = this.b;
      this.b = var2 + 4;
      byte var3 = var1[var2];
      byte var4 = var1[var2 + 1];
      byte var5 = var1[var2 + 2];
      return var1[var2 + 3] & 255 | (var3 & 255) << 24 | (var4 & 255) << 16 | (var5 & 255) << 8;
   }

   public int g(int var1) {
      int var2 = this.d;
      int var3 = var2 - this.b;
      if (var3 >= var1) {
         return var3;
      } else {
         int var4 = this.c;
         if (var1 > var4) {
            StringBuilder var7 = c.a.b.a.a.b("Buffer too small: capacity: ");
            var7.append(this.c);
            var7.append(", required: ");
            var7.append(var1);
            f var8 = new f(var7.toString());
            throw var8;
         } else {
            int var5 = var3;
            if (var3 > 0) {
               var2 = this.a(this.a, var2, var4 - var2);
               if (var2 == -1) {
                  throw new f("Buffer underflow.");
               }

               var3 += var2;
               var5 = var3;
               if (var3 >= var1) {
                  this.d += var2;
                  return var3;
               }
            }

            byte[] var6 = this.a;
            System.arraycopy(var6, this.b, var6, 0, var5);
            this.e += (long)this.b;
            this.b = 0;

            while(true) {
               var3 = this.a(this.a, var5, this.c - var5);
               if (var3 == -1) {
                  if (var5 < var1) {
                     throw new f("Buffer underflow.");
                  }
                  break;
               }

               var3 += var5;
               var5 = var3;
               if (var3 >= var1) {
                  var5 = var3;
                  break;
               }
            }

            this.d = var5;
            return var5;
         }
      }
   }

   public long h() {
      this.g(8);
      byte[] var1 = this.a;
      int var2 = this.b++;
      long var3 = (long)var1[var2];
      var2 = this.b++;
      long var5 = (long)(var1[var2] & 255);
      var2 = this.b++;
      long var7 = (long)(var1[var2] & 255);
      var2 = this.b++;
      long var9 = (long)(var1[var2] & 255);
      var2 = this.b++;
      long var11 = (long)(var1[var2] & 255);
      var2 = this.b++;
      long var13 = (long)((var1[var2] & 255) << 16);
      var2 = this.b++;
      long var15 = (long)((var1[var2] & 255) << 8);
      var2 = this.b++;
      return (long)(var1[var2] & 255) | var3 << 56 | var5 << 48 | var7 << 40 | var9 << 32 | var11 << 24 | var13 | var15;
   }

   public short i() {
      this.g(2);
      byte[] var1 = this.a;
      int var2 = this.b++;
      byte var3 = var1[var2];
      var2 = this.b++;
      return (short)(var1[var2] & 255 | (var3 & 255) << 8);
   }

   public String j() {
      int var1 = this.g(1);
      byte[] var2 = this.a;
      int var3 = this.b++;
      byte var4 = var2[var3];
      if ((var4 & 128) == 0) {
         return this.a();
      } else {
         if (var1 >= 5) {
            var1 = this.e(var4);
         } else {
            var1 = this.f(var4);
         }

         if (var1 != 0) {
            if (var1 != 1) {
               --var1;
               if (this.f.length < var1) {
                  this.f = new char[var1];
               }

               this.d(var1);
               return new String(this.f, 0, var1);
            } else {
               return "";
            }
         } else {
            return null;
         }
      }
   }

   public int read() {
      if (this.a(1) <= 0) {
         return -1;
      } else {
         byte[] var1 = this.a;
         int var2 = this.b++;
         return var1[var2] & 255;
      }
   }

   public int read(byte[] var1) {
      return this.read(var1, 0, var1.length);
   }

   public int read(byte[] var1, int var2, int var3) {
      if (var1 == null) {
         IllegalArgumentException var7 = new IllegalArgumentException("bytes cannot be null.");
         throw var7;
      } else {
         int var4 = Math.min(this.d - this.b, var3);
         int var5 = var3;

         int var6;
         do {
            System.arraycopy(this.a, this.b, var1, var2, var4);
            this.b += var4;
            var6 = var5 - var4;
            if (var6 == 0) {
               break;
            }

            var2 += var4;
            var4 = this.a(var6);
            if (var4 == -1) {
               if (var3 == var6) {
                  return -1;
               }
               break;
            }

            var5 = var6;
         } while(this.b != this.d);

         return var3 - var6;
      }
   }

   public long skip(long var1) {
      int var5;
      for(long var3 = var1; var3 > 0L; var3 -= (long)var5) {
         var5 = (int)Math.min(2147483647L, var3);
         int var6 = Math.min(this.d - this.b, var5);
         int var7 = var5;

         while(true) {
            this.b += var6;
            var7 -= var6;
            if (var7 == 0) {
               break;
            }

            var6 = Math.min(var7, this.c);
            this.g(var6);
         }
      }

      return var1;
   }
}
