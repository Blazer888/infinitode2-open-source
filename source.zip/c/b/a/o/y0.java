package c.b.a.o;

import java.util.TimeZone;

public class y0 extends c.b.a.k {
   public y0() {
      this.setImmutable(true);
   }

   public TimeZone a(c.b.a.n.a var1) {
      return TimeZone.getTimeZone(var1.j());
   }

   public void a(c.b.a.n.b var1, TimeZone var2) {
      var1.a(var2.getID());
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      return TimeZone.getTimeZone(var2.j());
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      var2.a(((TimeZone)var3).getID());
   }
}
