package c.b.a.o;

public class z extends c.b.a.k {
   public z() {
      this.setImmutable(true);
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      return var2.b();
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      var2.a((Boolean)var3);
   }
}
