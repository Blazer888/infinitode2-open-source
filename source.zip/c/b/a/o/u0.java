package c.b.a.o;

public class u0 extends c.b.a.k {
   public u0() {
      this.setImmutable(true);
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      return var2.i();
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      var2.e((Short)var3);
   }
}
