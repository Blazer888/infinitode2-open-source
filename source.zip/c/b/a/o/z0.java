package c.b.a.o;

import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;

public class z0 extends g1 {
   public Map a(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      return new TreeMap((Comparator)var1.readClassAndObject(var2));
   }

   public Map a(c.b.a.d var1, Map var2) {
      return new TreeMap(((TreeMap)var2).comparator());
   }

   public void a(c.b.a.d var1, c.b.a.n.b var2, Map var3) {
      var1.writeClassAndObject(var2, ((TreeMap)var3).comparator());
      super.a(var1, var2, var3);
   }
}
