package c.b.a.o;

public class o extends c.b.a.k {
   public o() {
      this.setAcceptsNull(true);
   }

   public Object copy(c.b.a.d var1, Object var2) {
      byte[] var3 = (byte[])var2;
      byte[] var4 = new byte[var3.length];
      System.arraycopy(var3, 0, var4, 0, var4.length);
      return var4;
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      int var4 = var2.a(true);
      byte[] var5;
      if (var4 == 0) {
         var5 = null;
      } else {
         var5 = var2.c(var4 - 1);
      }

      return var5;
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      byte[] var4 = (byte[])var3;
      if (var4 == null) {
         var2.a(0, true);
      } else {
         var2.a(var4.length + 1, true);
         var2.a(var4);
      }

   }
}
