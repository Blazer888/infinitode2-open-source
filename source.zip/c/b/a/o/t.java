package c.b.a.o;

public class t extends c.b.a.k {
   public t() {
      this.setAcceptsNull(true);
   }

   public Object copy(c.b.a.d var1, Object var2) {
      long[] var3 = (long[])var2;
      long[] var4 = new long[var3.length];
      System.arraycopy(var3, 0, var4, 0, var4.length);
      return var4;
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      int var4 = var2.a(true);
      long[] var6;
      if (var4 == 0) {
         var6 = null;
      } else {
         int var5 = var4 - 1;
         long[] var7 = new long[var5];
         var4 = 0;

         while(true) {
            var6 = var7;
            if (var4 >= var5) {
               break;
            }

            var7[var4] = var2.b(false);
            ++var4;
         }
      }

      return var6;
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      long[] var6 = (long[])var3;
      if (var6 == null) {
         var2.a(0, true);
      } else {
         var2.a(var6.length + 1, true);
         int var4 = var6.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            var2.a(var6[var5], false);
         }
      }

   }
}
