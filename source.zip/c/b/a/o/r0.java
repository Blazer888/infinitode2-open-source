package c.b.a.o;

public class r0 extends c.b.a.k {
   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      c.b.a.g var4 = (c.b.a.g)var1.newInstance(var3);
      var1.reference(var4);
      var4.read(var1, var2);
      return var4;
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      ((c.b.a.g)var3).write(var1, var2);
   }
}
