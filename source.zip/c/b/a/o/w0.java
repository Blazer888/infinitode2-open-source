package c.b.a.o;

public class w0 extends c.b.a.k {
   public w0() {
      this.setAcceptsNull(true);
   }

   public Object copy(c.b.a.d var1, Object var2) {
      return new StringBuilder((StringBuilder)var2);
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      int var4 = var2.g(1);
      byte[] var6 = var2.a;
      int var5 = var2.b++;
      byte var8 = var6[var5];
      StringBuilder var7;
      if ((var8 & 128) == 0) {
         var7 = new StringBuilder(var2.a());
      } else {
         if (var4 >= 5) {
            var4 = var2.e(var8);
         } else {
            var4 = var2.f(var8);
         }

         if (var4 != 0) {
            if (var4 != 1) {
               --var4;
               if (var2.f.length < var4) {
                  var2.f = new char[var4];
               }

               var2.d(var4);
               var7 = new StringBuilder(var4);
               var7.append(var2.f, 0, var4);
            } else {
               var7 = new StringBuilder("");
            }
         } else {
            var7 = null;
         }
      }

      return var7;
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      var2.a((CharSequence)((StringBuilder)var3));
   }
}
