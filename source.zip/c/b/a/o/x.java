package c.b.a.o;

import java.math.BigDecimal;
import java.math.BigInteger;

public class x extends c.b.a.k {
   public y c = new y();

   public x() {
      this.setAcceptsNull(true);
      this.setImmutable(true);
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      BigInteger var4 = this.c.a(var2);
      BigDecimal var5;
      if (var4 == null) {
         var5 = null;
      } else {
         var5 = new BigDecimal(var4, var2.a(false));
      }

      return var5;
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      BigDecimal var4 = (BigDecimal)var3;
      if (var4 == null) {
         var2.a(0, true);
      } else {
         this.c.a(var2, var4.unscaledValue());
         var2.a(var4.scale(), false);
      }

   }
}
