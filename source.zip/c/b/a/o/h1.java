package c.b.a.o;

import java.lang.reflect.Field;

public class h1 implements c1.c {
   public c1.b a(Class var1, Field var2, c1 var3) {
      Object var4;
      if (var1.isPrimitive()) {
         if (var1 == Boolean.TYPE) {
            var4 = new i1.a(var3);
         } else if (var1 == Byte.TYPE) {
            var4 = new i1.b(var3);
         } else if (var1 == Character.TYPE) {
            var4 = new i1.c(var3);
         } else if (var1 == Short.TYPE) {
            var4 = new i1.h(var3);
         } else if (var1 == Integer.TYPE) {
            var4 = new i1.f(var3);
         } else if (var1 == Long.TYPE) {
            var4 = new i1.g(var3);
         } else if (var1 == Float.TYPE) {
            var4 = new i1.e(var3);
         } else if (var1 == Double.TYPE) {
            var4 = new i1.d(var3);
         } else {
            var4 = new i1(var3);
         }
      } else {
         var4 = new i1(var3);
      }

      return (c1.b)var4;
   }
}
