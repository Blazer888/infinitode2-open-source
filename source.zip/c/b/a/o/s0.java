package c.b.a.o;

import java.util.Locale;

public class s0 extends c.b.a.k {
   public s0() {
      this.setImmutable(true);
   }

   public static boolean a(Locale var0, String var1, String var2, String var3) {
      boolean var4 = false;
      if (var0 == null) {
         return false;
      } else {
         boolean var5 = var4;
         if (var0.getLanguage().equals(var1)) {
            var5 = var4;
            if (var0.getCountry().equals(var2)) {
               var5 = var4;
               if (var0.getVariant().equals(var3)) {
                  var5 = true;
               }
            }
         }

         return var5;
      }
   }

   public Locale a(String var1, String var2, String var3) {
      if (a(Locale.US, var1, var2, var3)) {
         return Locale.US;
      } else if (a(Locale.UK, var1, var2, var3)) {
         return Locale.UK;
      } else if (a(Locale.ENGLISH, var1, var2, var3)) {
         return Locale.ENGLISH;
      } else if (a(Locale.FRENCH, var1, var2, var3)) {
         return Locale.FRENCH;
      } else if (a(Locale.GERMAN, var1, var2, var3)) {
         return Locale.GERMAN;
      } else if (a(Locale.ITALIAN, var1, var2, var3)) {
         return Locale.ITALIAN;
      } else if (a(Locale.FRANCE, var1, var2, var3)) {
         return Locale.FRANCE;
      } else if (a(Locale.GERMANY, var1, var2, var3)) {
         return Locale.GERMANY;
      } else if (a(Locale.ITALY, var1, var2, var3)) {
         return Locale.ITALY;
      } else if (a(Locale.JAPAN, var1, var2, var3)) {
         return Locale.JAPAN;
      } else if (a(Locale.KOREA, var1, var2, var3)) {
         return Locale.KOREA;
      } else if (a(Locale.CHINA, var1, var2, var3)) {
         return Locale.CHINA;
      } else if (a(Locale.PRC, var1, var2, var3)) {
         return Locale.PRC;
      } else if (a(Locale.TAIWAN, var1, var2, var3)) {
         return Locale.TAIWAN;
      } else if (a(Locale.CANADA, var1, var2, var3)) {
         return Locale.CANADA;
      } else if (a(Locale.CANADA_FRENCH, var1, var2, var3)) {
         return Locale.CANADA_FRENCH;
      } else if (a(Locale.JAPANESE, var1, var2, var3)) {
         return Locale.JAPANESE;
      } else if (a(Locale.KOREAN, var1, var2, var3)) {
         return Locale.KOREAN;
      } else if (a(Locale.CHINESE, var1, var2, var3)) {
         return Locale.CHINESE;
      } else if (a(Locale.SIMPLIFIED_CHINESE, var1, var2, var3)) {
         return Locale.SIMPLIFIED_CHINESE;
      } else {
         return a(Locale.TRADITIONAL_CHINESE, var1, var2, var3) ? Locale.TRADITIONAL_CHINESE : new Locale(var1, var2, var3);
      }
   }

   public Object copy(c.b.a.d var1, Object var2) {
      Locale var3 = (Locale)var2;
      return this.a(var3.getLanguage(), var3.getDisplayCountry(), var3.getVariant());
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      return this.a(var2.j(), var2.j(), var2.j());
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      Locale var4 = (Locale)var3;
      var2.a(var4.getLanguage());
      var2.a(var4.getCountry());
      var2.a(var4.getVariant());
   }
}
