package c.b.a.o;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.HashMap;

public final class e1 {
   public c.b.a.d a;
   public c1 b;

   public e1(c1 var1) {
      this.b = var1;
      this.a = var1.c;
   }

   public static Class[] a(Type var0, c.b.a.d var1) {
      if (var0 instanceof GenericArrayType) {
         var0 = ((GenericArrayType)var0).getGenericComponentType();
         return var0 instanceof Class ? new Class[]{(Class)var0} : a(var0, var1);
      } else if (!(var0 instanceof ParameterizedType)) {
         return null;
      } else {
         if (c.b.c.a.c) {
            StringBuilder var2 = new StringBuilder();
            var2.append("Processing generic type ");
            var2.append(var0);
            c.b.c.a.b("kryo", var2.toString());
         }

         Type[] var10 = ((ParameterizedType)var0).getActualTypeArguments();
         Class[] var9 = new Class[var10.length];
         int var3 = var10.length;
         int var4 = 0;

         int var5;
         int var8;
         for(var5 = 0; var4 < var3; var5 = var8) {
            Type var6 = var10[var4];
            if (c.b.c.a.c) {
               StringBuilder var7 = new StringBuilder();
               var7.append("Processing actual type ");
               var7.append(var6);
               var7.append(" (");
               var7.append(var6.getClass().getName());
               var7.append(")");
               c.b.c.a.b("kryo", var7.toString());
            }

            label66: {
               var9[var4] = Object.class;
               if (var6 instanceof Class) {
                  var9[var4] = (Class)var6;
               } else if (var6 instanceof ParameterizedType) {
                  var9[var4] = (Class)((ParameterizedType)var6).getRawType();
               } else {
                  Class var11;
                  c.b.a.c var12;
                  if (var6 instanceof TypeVariable) {
                     var12 = var1.getGenericsScope();
                     var8 = var5;
                     if (var12 == null) {
                        break label66;
                     }

                     var11 = var12.a(((TypeVariable)var6).getName());
                     var8 = var5;
                     if (var11 == null) {
                        break label66;
                     }

                     var9[var4] = var11;
                  } else {
                     var8 = var5;
                     if (!(var6 instanceof GenericArrayType)) {
                        break label66;
                     }

                     var6 = ((GenericArrayType)var6).getGenericComponentType();
                     if (var6 instanceof Class) {
                        var9[var4] = Array.newInstance((Class)var6, 0).getClass();
                     } else if (var6 instanceof TypeVariable) {
                        var12 = var1.getGenericsScope();
                        if (var12 != null) {
                           var11 = var12.a(((TypeVariable)var6).getName());
                           if (var11 != null) {
                              var9[var4] = Array.newInstance(var11, 0).getClass();
                           }
                        }
                     } else {
                        Class[] var13 = a(var6, var1);
                        if (var13 != null) {
                           var9[var4] = var13[0];
                        }
                     }
                  }
               }

               var8 = var5 + 1;
            }

            ++var4;
         }

         if (var5 == 0) {
            return null;
         } else {
            return var9;
         }
      }
   }

   public c.b.a.c a(Class var1, Class[] var2) {
      Class var3 = var1;

      TypeVariable[] var4;
      TypeVariable[] var5;
      for(var4 = null; var3 != null; var4 = var5) {
         var5 = var3.getTypeParameters();
         if (var5 != null) {
            var4 = var5;
            if (var5.length != 0) {
               break;
            }
         }

         var3 = var3.getComponentType();
      }

      if (var4 != null && var4.length > 0) {
         StringBuilder var14 = c.a.b.a.a.b("Class ");
         var14.append(var1.getName());
         var14.append(" has generic type parameters");
         c.b.c.a.b("kryo", var14.toString());
         HashMap var15 = new HashMap();
         int var6 = var4.length;
         int var7 = 0;

         for(int var8 = 0; var7 < var6; ++var7) {
            TypeVariable var9 = var4[var7];
            String var12 = var9.getName();
            if (c.b.c.a.c) {
               StringBuilder var10 = c.a.b.a.a.b("Type parameter variable: name=", var12, " type bounds=");
               var10.append(Arrays.toString(var9.getBounds()));
               c.b.c.a.b("kryo", var10.toString());
            }

            if (var2 != null && var2.length > var8) {
               var1 = var2[var8];
            } else {
               if (c.b.c.a.c) {
                  c.b.c.a.b("kryo", "Trying to use kryo.getGenericScope");
               }

               c.b.a.c var11 = this.a.getGenericsScope();
               if (var11 != null) {
                  var1 = var11.a(var12);
               } else {
                  var1 = null;
               }
            }

            if (var1 != null) {
               var15.put(var12, var1);
               if (c.b.c.a.c) {
                  StringBuilder var13 = c.a.b.a.a.b("Concrete type used for ", var12, " is: ");
                  var13.append(var1.getName());
                  c.b.c.a.b("kryo", var13.toString());
               }
            }

            ++var8;
         }

         return new c.b.a.c(var15);
      } else {
         return null;
      }
   }

   public c1.b a(Field var1, int var2, Class[] var3, Type var4) {
      StringBuilder var5;
      if (c.b.c.a.c) {
         var5 = c.a.b.a.a.b("Field '");
         var5.append(var1.getName());
         var5.append("' of type ");
         var5.append(var3[0]);
         var5.append(" of generic type ");
         var5.append(var4);
         c.b.c.a.b("kryo", var5.toString());
      }

      if (c.b.c.a.c && var4 != null) {
         var5 = c.a.b.a.a.b("Field generic type is of class ");
         var5.append(var4.getClass().getName());
         c.b.c.a.b("kryo", var5.toString());
      }

      Class[] var11 = a(var4, this.a);
      c.b.a.c var6 = this.a(var3[0], var11);
      c.b.a.c var12 = var6;
      if (var3[0] == Object.class) {
         var12 = var6;
         if (var4 instanceof TypeVariable) {
            c.b.a.c var7 = this.b.s;
            var12 = var6;
            if (var7 != null) {
               TypeVariable var8 = (TypeVariable)var4;
               Class var15 = var7.a(var8.getName());
               var12 = var6;
               if (var15 != null) {
                  var12 = new c.b.a.c();
                  String var13 = var8.getName();
                  var12.a.put(var13, var15);
               }
            }
         }
      }

      if (c.b.c.a.c) {
         StringBuilder var14 = c.a.b.a.a.b("Generics scope of field '");
         var14.append(var1.getName());
         var14.append("' of class ");
         var14.append(var4);
         var14.append(" is ");
         var14.append(var12);
         c.b.c.a.b("kryo", var14.toString());
      }

      var11 = this.a(var4, var1, var3);
      c1.b var9 = this.b.a(var1, var2, var3[0], var4, var11);
      if (var11 != null && var9 instanceof i1 && var11.length > 0 && var11[0] != null) {
         ((i1)var9).i = var11;
         if (c.b.c.a.c) {
            StringBuilder var10 = c.a.b.a.a.b("Field generics: ");
            var10.append(Arrays.toString(var11));
            c.b.c.a.b("kryo", var10.toString());
         }
      }

      return var9;
   }

   public Class[] a(Type var1, Field var2, Class[] var3) {
      c.b.a.c var4 = null;
      Class[] var5 = var4;
      if (var1 != null) {
         StringBuilder var15;
         if (var1 instanceof TypeVariable) {
            c.b.a.c var14 = this.b.s;
            if (var14 != null) {
               Class var8 = var14.a(((TypeVariable)var1).getName());
               var5 = var4;
               if (var8 != null) {
                  var3[0] = var8;
                  Class[] var9 = new Class[]{var3[0]};
                  var5 = var9;
                  if (c.b.c.a.c) {
                     var15 = c.a.b.a.a.b("Determined concrete class of '");
                     var15.append(var2.getName());
                     var15.append("' to be ");
                     var15.append(var3[0].getName());
                     c.b.c.a.b("kryo", var15.toString());
                     var5 = var9;
                     return var5;
                  }
               }

               return var5;
            }
         }

         if (var1 instanceof ParameterizedType) {
            Type[] var10 = ((ParameterizedType)var1).getActualTypeArguments();
            var5 = var4;
            if (var10 != null) {
               var5 = new Class[var10.length];

               for(int var6 = 0; var6 < var10.length; ++var6) {
                  Type var7 = var10[var6];
                  if (var7 instanceof Class) {
                     var5[var6] = (Class)var7;
                  } else if (var7 instanceof ParameterizedType) {
                     var5[var6] = (Class)((ParameterizedType)var7).getRawType();
                  } else {
                     if (var7 instanceof TypeVariable) {
                        var4 = this.b.s;
                        if (var4 != null) {
                           var5[var6] = var4.a(((TypeVariable)var7).getName());
                           continue;
                        }
                     }

                     if (var7 instanceof WildcardType) {
                        var5[var6] = Object.class;
                     } else if (var7 instanceof GenericArrayType) {
                        Type var12 = ((GenericArrayType)var7).getGenericComponentType();
                        if (var12 instanceof Class) {
                           var5[var6] = Array.newInstance((Class)var12, 0).getClass();
                        } else if (var12 instanceof TypeVariable) {
                           c.b.a.c var16 = this.b.s;
                           if (var16 != null) {
                              Class var13 = var16.a(((TypeVariable)var12).getName());
                              if (var13 != null) {
                                 var5[var6] = Array.newInstance(var13, 0).getClass();
                              }
                           }
                        }
                     } else {
                        var5[var6] = null;
                     }
                  }
               }

               if (c.b.c.a.c) {
                  StringBuilder var11 = c.a.b.a.a.b("Determined concrete class of parametrized '");
                  var11.append(var2.getName());
                  var11.append("' to be ");
                  var11.append(var1);
                  var11.append(" where type parameters are ");
                  var11.append(Arrays.toString(var5));
                  c.b.c.a.b("kryo", var11.toString());
               }
            }
         } else {
            var5 = var4;
            if (var1 instanceof GenericArrayType) {
               var3 = this.a(((GenericArrayType)var1).getGenericComponentType(), var2, new Class[]{var3[0]});
               if (c.b.c.a.c && var3 != null) {
                  var15 = c.a.b.a.a.b("Determined concrete class of a generic array '");
                  var15.append(var2.getName());
                  var15.append("' to be ");
                  var15.append(var1);
                  var15.append(" where type parameters are ");
                  var15.append(Arrays.toString(var3));
                  c.b.c.a.b("kryo", var15.toString());
                  var5 = var3;
               } else {
                  var5 = var3;
                  if (c.b.c.a.c) {
                     var15 = c.a.b.a.a.b("Determined concrete class of '");
                     var15.append(var2.getName());
                     var15.append("' to be ");
                     var15.append(var1);
                     c.b.c.a.b("kryo", var15.toString());
                     var5 = var3;
                  }
               }
            }
         }
      }

      return var5;
   }
}
