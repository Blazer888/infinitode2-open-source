package c.b.a.o;

import java.util.Collection;
import java.util.Comparator;
import java.util.TreeSet;

public class a1 extends m {
   public Collection a(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      return new TreeSet((Comparator)var1.readClassAndObject(var2));
   }

   public Collection a(c.b.a.d var1, Collection var2) {
      return new TreeSet(((TreeSet)var2).comparator());
   }

   public void a(c.b.a.d var1, c.b.a.n.b var2, Collection var3) {
      var1.writeClassAndObject(var2, ((TreeSet)var3).comparator());
      super.a(var1, var2, var3);
   }
}
