package c.b.a.o;

public class a0 extends c.b.a.k {
   public a0() {
      this.setImmutable(true);
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      return var2.c();
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      var2.a((Byte)var3);
   }
}
