package c.b.a.o;

import java.util.Currency;

public class k0 extends c.b.a.k {
   public k0() {
      this.setImmutable(true);
      this.setAcceptsNull(true);
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      String var4 = var2.j();
      Currency var5;
      if (var4 == null) {
         var5 = null;
      } else {
         var5 = Currency.getInstance(var4);
      }

      return var5;
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      Currency var4 = (Currency)var3;
      String var5;
      if (var4 == null) {
         var5 = null;
      } else {
         var5 = var4.getCurrencyCode();
      }

      var2.a(var5);
   }
}
