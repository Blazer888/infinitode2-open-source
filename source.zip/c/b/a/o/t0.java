package c.b.a.o;

public class t0 extends c.b.a.k {
   public t0() {
      this.setImmutable(true);
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      return var2.b(false);
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      var2.a((Long)var3, false);
   }
}
