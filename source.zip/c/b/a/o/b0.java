package c.b.a.o;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class b0 extends c.b.a.k {
   public y0 c = new y0();

   public Object copy(c.b.a.d var1, Object var2) {
      return (Calendar)((Calendar)var2).clone();
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      Calendar var6 = Calendar.getInstance(this.c.a(var2));
      var6.setTimeInMillis(var2.b(true));
      var6.setLenient(var2.b());
      var6.setFirstDayOfWeek(var2.a(true));
      var6.setMinimalDaysInFirstWeek(var2.a(true));
      long var4 = var2.b(false);
      if (var4 != -12219292800000L && var6 instanceof GregorianCalendar) {
         ((GregorianCalendar)var6).setGregorianChange(new Date(var4));
      }

      return var6;
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      Calendar var4 = (Calendar)var3;
      this.c.a(var2, var4.getTimeZone());
      var2.a(var4.getTimeInMillis(), true);
      var2.a(var4.isLenient());
      var2.a(var4.getFirstDayOfWeek(), true);
      var2.a(var4.getMinimalDaysInFirstWeek(), true);
      if (var4 instanceof GregorianCalendar) {
         var2.a(((GregorianCalendar)var4).getGregorianChange().getTime(), false);
      } else {
         var2.a(-12219292800000L, false);
      }

   }
}
