package c.b.a.o;

public abstract class c extends c1.b {
}
