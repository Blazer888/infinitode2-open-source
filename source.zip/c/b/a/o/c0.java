package c.b.a.o;

public class c0 extends c.b.a.k {
   public c0() {
      this.setImmutable(true);
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      return var2.d();
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      var2.a((Character)var3);
   }
}
