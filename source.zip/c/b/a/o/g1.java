package c.b.a.o;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class g1 extends c.b.a.k {
   public Class c;
   public Class d;
   public c.b.a.k e;
   public c.b.a.k f;
   public boolean g = true;
   public boolean h = true;
   public Class i;
   public Class j;

   public Map a(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      return (Map)var1.newInstance(var3);
   }

   public Map a(c.b.a.d var1, Map var2) {
      return (Map)var1.newInstance(var2.getClass());
   }

   public void a(c.b.a.d var1, c.b.a.n.b var2, Map var3) {
      var2.a(var3.size(), true);
      c.b.a.k var4 = this.e;
      Class var5 = this.i;
      c.b.a.k var6 = var4;
      c.b.a.k var7;
      if (var5 != null) {
         var7 = var4;
         if (var4 == null) {
            var7 = var1.getSerializer(var5);
         }

         this.i = null;
         var6 = var7;
      }

      var4 = this.f;
      var5 = this.j;
      var7 = var4;
      if (var5 != null) {
         var7 = var4;
         if (var4 == null) {
            var7 = var1.getSerializer(var5);
         }

         this.j = null;
      }

      Iterator var8 = var3.entrySet().iterator();

      while(var8.hasNext()) {
         Entry var9 = (Entry)var8.next();
         if (var6 != null) {
            if (this.g) {
               var1.writeObjectOrNull(var2, var9.getKey(), var6);
            } else {
               var1.writeObject(var2, var9.getKey(), var6);
            }
         } else {
            var1.writeClassAndObject(var2, var9.getKey());
         }

         if (var7 != null) {
            if (this.h) {
               var1.writeObjectOrNull(var2, var9.getValue(), var7);
            } else {
               var1.writeObject(var2, var9.getValue(), var7);
            }
         } else {
            var1.writeClassAndObject(var2, var9.getValue());
         }
      }

   }

   public Object copy(c.b.a.d var1, Object var2) {
      Map var3 = (Map)var2;
      Map var5 = this.a(var1, var3);
      Iterator var6 = var3.entrySet().iterator();

      while(var6.hasNext()) {
         Entry var4 = (Entry)var6.next();
         var5.put(var1.copy(var4.getKey()), var1.copy(var4.getValue()));
      }

      return var5;
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      Map var4 = this.a(var1, var2, var3);
      int var5 = var2.a(true);
      Class var6 = this.c;
      Class var7 = this.d;
      c.b.a.k var8 = this.e;
      Class var9 = this.i;
      c.b.a.k var10 = var8;
      c.b.a.k var13;
      if (var9 != null) {
         var13 = var8;
         if (var8 == null) {
            var13 = var1.getSerializer(var9);
         }

         this.i = null;
         var6 = var9;
         var10 = var13;
      }

      var8 = this.f;
      Class var11 = this.j;
      c.b.a.k var16 = var8;
      if (var11 != null) {
         var13 = var8;
         if (var8 == null) {
            var13 = var1.getSerializer(var11);
         }

         this.j = null;
         var7 = var11;
         var16 = var13;
      }

      var1.reference(var4);

      for(int var12 = 0; var12 < var5; ++var12) {
         Object var14;
         if (var10 != null) {
            if (this.g) {
               var14 = var1.readObjectOrNull(var2, var6, var10);
            } else {
               var14 = var1.readObject(var2, var6, var10);
            }
         } else {
            var14 = var1.readClassAndObject(var2);
         }

         Object var15;
         if (var16 != null) {
            if (this.h) {
               var15 = var1.readObjectOrNull(var2, var7, var16);
            } else {
               var15 = var1.readObject(var2, var7, var16);
            }
         } else {
            var15 = var1.readClassAndObject(var2);
         }

         var4.put(var14, var15);
      }

      return var4;
   }

   public void setGenerics(c.b.a.d var1, Class[] var2) {
      this.i = null;
      this.j = null;
      if (var2 != null && var2.length > 0) {
         if (var2[0] != null && var1.isFinal(var2[0])) {
            this.i = var2[0];
         }

         if (var2.length > 1 && var2[1] != null && var1.isFinal(var2[1])) {
            this.j = var2[1];
         }
      }

   }

   @Retention(RetentionPolicy.RUNTIME)
   @Target({ElementType.FIELD})
   public @interface a {
      Class keyClass() default Object.class;

      Class keySerializer() default c.b.a.k.class;

      boolean keysCanBeNull() default true;

      Class valueClass() default Object.class;

      Class valueSerializer() default c.b.a.k.class;

      boolean valuesCanBeNull() default true;
   }
}
