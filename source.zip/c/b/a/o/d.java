package c.b.a.o;

public final class d extends c {
   public void a(c.b.a.n.a var1, Object var2) {
      super.b.a(var2, super.f, var1.d());
   }

   public void a(c.b.a.n.b var1, Object var2) {
      var1.a(super.b.d(var2, super.f));
   }

   public void a(Object var1, Object var2) {
      c.b.d.c var3 = super.b;
      int var4 = super.f;
      var3.a(var2, var4, var3.d(var1, var4));
   }
}
