package c.b.a.o;

public class n extends c.b.a.k {
   public n() {
      this.setAcceptsNull(true);
   }

   public Object copy(c.b.a.d var1, Object var2) {
      boolean[] var3 = (boolean[])var2;
      boolean[] var4 = new boolean[var3.length];
      System.arraycopy(var3, 0, var4, 0, var4.length);
      return var4;
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      int var4 = var2.a(true);
      boolean[] var6;
      if (var4 == 0) {
         var6 = null;
      } else {
         int var5 = var4 - 1;
         var6 = new boolean[var5];

         for(var4 = 0; var4 < var5; ++var4) {
            var6[var4] = var2.b();
         }
      }

      return var6;
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      boolean[] var6 = (boolean[])var3;
      int var4 = 0;
      if (var6 == null) {
         var2.a(0, true);
      } else {
         var2.a(var6.length + 1, true);

         for(int var5 = var6.length; var4 < var5; ++var4) {
            var2.a(var6[var4]);
         }
      }

   }
}
