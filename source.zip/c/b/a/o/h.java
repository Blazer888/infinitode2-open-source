package c.b.a.o;

public final class h extends c {
   public void a(c.b.a.n.a var1, Object var2) {
      if (super.h) {
         super.b.a(var2, super.f, var1.b(false));
      } else {
         super.b.a(var2, super.f, var1.h());
      }

   }

   public void a(c.b.a.n.b var1, Object var2) {
      if (super.h) {
         var1.a(super.b.h(var2, super.f), false);
      } else {
         var1.a(super.b.h(var2, super.f));
      }

   }

   public void a(Object var1, Object var2) {
      c.b.d.c var3 = super.b;
      int var4 = super.f;
      var3.a(var2, var4, var3.h(var1, var4));
   }
}
