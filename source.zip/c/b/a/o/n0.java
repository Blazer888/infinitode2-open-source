package c.b.a.o;

public class n0 extends c.b.a.k {
   public Object[] c;

   public n0(Class var1) {
      this.setImmutable(true);
      this.setAcceptsNull(true);
      this.c = var1.getEnumConstants();
      if (this.c == null) {
         StringBuilder var2 = new StringBuilder();
         var2.append("The type must be an enum: ");
         var2.append(var1);
         throw new IllegalArgumentException(var2.toString());
      }
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      int var4 = var2.a(true);
      Enum var7;
      if (var4 == 0) {
         var7 = null;
         return var7;
      } else {
         --var4;
         if (var4 >= 0) {
            Object[] var5 = this.c;
            if (var4 <= var5.length - 1) {
               var7 = (Enum)var5[var4];
               return var7;
            }
         }

         StringBuilder var6 = c.a.b.a.a.b("Invalid ordinal for enum \"");
         var6.append(var3.getName());
         var6.append("\": ");
         var6.append(var4);
         throw new c.b.a.f(var6.toString());
      }
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      Enum var4 = (Enum)var3;
      if (var4 == null) {
         var2.a(0, true);
      } else {
         var2.a(var4.ordinal() + 1, true);
      }

   }
}
