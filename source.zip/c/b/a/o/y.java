package c.b.a.o;

import java.math.BigInteger;

public class y extends c.b.a.k {
   public y() {
      this.setImmutable(true);
      this.setAcceptsNull(true);
   }

   public BigInteger a(c.b.a.n.a var1) {
      int var2 = var1.a(true);
      return var2 == 0 ? null : new BigInteger(var1.c(var2 - 1));
   }

   public void a(c.b.a.n.b var1, BigInteger var2) {
      if (var2 == null) {
         var1.a(0, true);
      } else {
         byte[] var3 = var2.toByteArray();
         var1.a(var3.length + 1, true);
         var1.a(var3);
      }
   }
}
