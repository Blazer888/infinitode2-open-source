package c.b.a.o;

import java.lang.reflect.Field;

public class l implements c1.c {
   public c1.b a(Class var1, Field var2, c1 var3) {
      Object var4;
      if (var1.isPrimitive()) {
         if (var1 == Boolean.TYPE) {
            var4 = new a();
         } else if (var1 == Byte.TYPE) {
            var4 = new b();
         } else if (var1 == Character.TYPE) {
            var4 = new d();
         } else if (var1 == Short.TYPE) {
            var4 = new j();
         } else if (var1 == Integer.TYPE) {
            var4 = new g();
         } else if (var1 == Long.TYPE) {
            var4 = new h();
         } else if (var1 == Float.TYPE) {
            var4 = new f();
         } else if (var1 == Double.TYPE) {
            var4 = new e();
         } else {
            var4 = new i(var3);
         }
      } else if (var1 != String.class || var3.c.getReferences() && ((c.b.a.p.g)var3.c.getReferenceResolver()).a(String.class)) {
         var4 = new i(var3);
      } else {
         var4 = new k();
      }

      return (c1.b)var4;
   }
}
