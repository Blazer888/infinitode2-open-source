package c.b.a.o;

import java.util.EnumSet;
import java.util.Iterator;

public class o0 extends c.b.a.k {
   public Object copy(c.b.a.d var1, Object var2) {
      return EnumSet.copyOf((EnumSet)var2);
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      c.b.a.j var4 = var1.readClass(var2);
      EnumSet var7 = EnumSet.noneOf(var4.a);
      c.b.a.k var8 = var4.c;
      int var5 = var2.a(true);

      for(int var6 = 0; var6 < var5; ++var6) {
         var7.add(var8.read(var1, var2, (Class)null));
      }

      return var7;
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      EnumSet var4 = (EnumSet)var3;
      c.b.a.k var6;
      if (var4.isEmpty()) {
         EnumSet var5 = EnumSet.complementOf(var4);
         if (var5.isEmpty()) {
            throw new c.b.a.f("An EnumSet must have a defined Enum to be serialized.");
         }

         var6 = var1.writeClass(var2, var5.iterator().next().getClass()).c;
      } else {
         var6 = var1.writeClass(var2, var4.iterator().next().getClass()).c;
      }

      var2.a(var4.size(), true);
      Iterator var7 = var4.iterator();

      while(var7.hasNext()) {
         var6.write(var1, var2, var7.next());
      }

   }
}
