package c.b.a.o;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.security.AccessControlException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public class c1 extends c.b.a.k implements Comparator {
   public static Class A;
   public static Method B;
   public static c1.c w;
   public static c1.c x;
   public static c1.c y;
   public static boolean z;
   public final c.b.a.d c;
   public final Class d;
   public final TypeVariable[] e;
   public c1.b[] f = new c1.b[0];
   public c1.b[] g = new c1.b[0];
   public HashSet h = new HashSet();
   public Object i;
   public boolean j = true;
   public boolean k = true;
   public boolean l = true;
   public boolean m;
   public boolean n;
   public f1 o;
   public e1 p;
   public d1 q;
   public Class[] r;
   public c.b.a.c s;
   public boolean t;
   public boolean u = false;
   public boolean v = true;

   static {
      boolean var2 = false;

      label34:
      try {
         var2 = true;
         A = c1.class.getClassLoader().loadClass("com.esotericsoftware.kryo.util.UnsafeUtil");
         Method var0 = A.getMethod("unsafe");
         B = A.getMethod("sortFieldsByOffset", List.class);
         if (var0.invoke((Object)null) != null) {
            z = true;
            var2 = false;
         } else {
            var2 = false;
         }
      } finally {
         if (var2) {
            if (c.b.c.a.c) {
               c.b.c.a.b("kryo", "sun.misc.Unsafe is unavailable.");
            }
            break label34;
         }
      }

   }

   public c1(c.b.a.d var1, Class var2) {
      this.n = z ^ true;
      this.t = true;
      if (c.b.c.a.c) {
         StringBuilder var3 = c.a.b.a.a.b("Optimize ints: ");
         var3.append(this.t);
         c.b.c.a.b("kryo", var3.toString());
      }

      this.c = var1;
      this.d = var2;
      this.e = var2.getTypeParameters();
      this.n = var1.getAsmEnabled();
      if (!this.n && !z) {
         this.n = true;
         if (c.b.c.a.c) {
            c.b.c.a.b("kryo", "sun.misc.Unsafe is unavailable, using ASM.");
         }
      }

      f1 var6;
      label25: {
         this.p = new e1(this);
         Constructor var5 = f1.a.a;
         if (var5 != null) {
            try {
               var6 = (f1)var5.newInstance(this);
               break label25;
            } catch (Exception var4) {
            }
         }

         var6 = null;
      }

      this.o = var6;
      this.q = new d1();
      this.a(false);
   }

   public c1.b a(Field var1, int var2, Class var3, Type var4, Class[] var5) {
      c1.b var7;
      if (var2 != -1) {
         if (w == null) {
            w = new l();
         }

         var7 = w.a(var3, var1, this);
      } else if (!this.n) {
         if (y == null) {
            try {
               y = (c1.c)this.getClass().getClassLoader().loadClass("com.esotericsoftware.kryo.serializers.UnsafeCachedFieldFactory").newInstance();
            } catch (Exception var6) {
               throw new RuntimeException("Cannot create UnsafeFieldFactory", var6);
            }
         }

         var7 = y.a(var3, var1, this);
      } else {
         if (x == null) {
            x = new h1();
         }

         c1.b var9 = x.a(var3, var1, this);
         if (var5 != null) {
            ((i1)var9).i = var5;
            var7 = var9;
         } else {
            Class[] var10 = e1.a(var4, this.c);
            ((i1)var9).i = var10;
            var7 = var9;
            if (c.b.c.a.c) {
               StringBuilder var8 = c.a.b.a.a.b("Field generics: ");
               var8.append(Arrays.toString(var10));
               c.b.c.a.b("kryo", var8.toString());
               var7 = var9;
            }
         }
      }

      return var7;
   }

   public final List a(boolean var1, List var2, c.b.a.p.h var3, c.b.a.p.e var4) {
      ArrayList var5 = new ArrayList(var2.size());
      int var6 = var2.size();

      for(int var7 = 0; var7 < var6; ++var7) {
         Field var8 = (Field)var2.get(var7);
         int var9 = var8.getModifiers();
         if (Modifier.isTransient(var9) == var1 && !Modifier.isStatic(var9) && (!var8.isSynthetic() || !this.l)) {
            boolean var10 = var8.isAccessible();
            byte var11 = 1;
            if (!var10) {
               if (!this.k) {
                  continue;
               }

               try {
                  var8.setAccessible(true);
               } catch (AccessControlException var13) {
                  continue;
               }
            }

            c1.d var12 = (c1.d)var8.getAnnotation(c1.d.class);
            if (var12 == null || var3.a(var12.value())) {
               var5.add(var8);
               if (Modifier.isFinal(var9) || !Modifier.isPublic(var9) || !Modifier.isPublic(var8.getType().getModifiers())) {
                  var11 = 0;
               }

               var4.a(var11);
            }
         }
      }

      return var5;
   }

   public final List a(c1.b[] var1, c.b.a.p.e var2) {
      ArrayList var3 = new ArrayList(var1.length);
      int var4 = var1.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         c1.b var6 = var1[var5];
         var3.add(var6.a);
         byte var7;
         if (var6.f > -1) {
            var7 = 1;
         } else {
            var7 = 0;
         }

         var2.a(var7);
      }

      return var3;
   }

   public final void a(c.b.a.p.e var1, List var2, List var3, int var4) {
      if (!this.n && this.u) {
         this.o.a(var2, var3, var4, var1);
      } else {
         int var5 = var2.size();

         for(int var6 = 0; var6 < var5; ++var6) {
            Field var7;
            int var9;
            label45: {
               var7 = (Field)var2.get(var6);
               Object var8 = this.i;
               if (var8 != null) {
                  var9 = var4 + var6;
                  if (var9 >= var1.b) {
                     throw new IndexOutOfBoundsException(String.valueOf(var9));
                  }

                  if (var1.a[var9] == 1) {
                     var9 = ((c.b.d.c)var8).a(var7.getName());
                     break label45;
                  }
               }

               var9 = -1;
            }

            var3.size();
            Class[] var10 = new Class[]{var7.getType()};
            Type var11 = var7.getGenericType();
            c1.b var14;
            if (var11 == var10[0]) {
               if (c.b.c.a.c) {
                  StringBuilder var13 = c.a.b.a.a.b("Field ");
                  var13.append(var7.getName());
                  var13.append(": ");
                  var13.append(var10[0]);
                  c.b.c.a.b("kryo", var13.toString());
               }

               var14 = this.a(var7, var9, var10[0], var11, (Class[])null);
            } else {
               var14 = this.p.a(var7, var9, var10, var11);
            }

            boolean var12 = var14 instanceof i1;
            var14.a = var7;
            var14.h = this.t;
            if (!this.n) {
               var14.g = this.o.a(var7);
            }

            var14.b = (c.b.d.c)this.i;
            var14.f = var9;
            if (this.j && !var10[0].isPrimitive() && !var7.isAnnotationPresent(c.b.a.h.class)) {
               var12 = true;
            } else {
               var12 = false;
            }

            var14.e = var12;
            if (this.c.isFinal(var10[0]) || this.m) {
               var14.c = var10[0];
            }

            var3.add(var14);
         }
      }

   }

   public void a(boolean var1) {
      StringBuilder var2;
      if (c.b.c.a.c && this.r != null) {
         var2 = c.a.b.a.a.b("Generic type parameters: ");
         var2.append(Arrays.toString(this.r));
         c.b.c.a.b("kryo", var2.toString());
      }

      if (this.d.isInterface()) {
         this.f = new c1.b[0];
      } else {
         this.s = this.p.a(this.d, this.r);
         c.b.a.c var11 = this.s;
         if (var11 != null) {
            this.c.pushGenericsScope(this.d, var11);
         }

         c.b.a.p.e var3 = new c.b.a.p.e(true, 16);
         int var7;
         List var14;
         List var15;
         if (!var1) {
            ArrayList var4 = new ArrayList();

            int var6;
            for(Class var12 = this.d; var12 != Object.class; var12 = var12.getSuperclass()) {
               Field[] var5 = var12.getDeclaredFields();
               if (var5 != null) {
                  var6 = var5.length;

                  for(var7 = 0; var7 < var6; ++var7) {
                     Field var8 = var5[var7];
                     if (!Modifier.isStatic(var8.getModifiers())) {
                        var4.add(var8);
                     }
                  }
               }
            }

            c.b.a.p.h var16 = this.c.getContext();
            Object var13 = var4;
            if (this.u) {
               var13 = var4;
               if (!this.n) {
                  var13 = var4;
                  if (z) {
                     try {
                        var13 = Arrays.asList((Field[])B.invoke((Object)null, var4));
                     } catch (Exception var9) {
                        throw new RuntimeException("Cannot invoke UnsafeUtil.sortFieldsByOffset()", var9);
                     }
                  }
               }
            }

            List var24 = this.a(false, (List)var13, var16, var3);
            List var17 = this.a(true, (List)var13, var16, var3);
            var14 = var24;
            var15 = var17;
            if (this.n) {
               var14 = var24;
               var15 = var17;
               if (!c.b.a.p.i.a) {
                  var14 = var24;
                  var15 = var17;
                  if (Modifier.isPublic(this.d.getModifiers())) {
                     int[] var19 = var3.a;
                     var6 = var3.b;
                     var7 = 0;

                     while(true) {
                        if (var7 >= var6) {
                           var7 = -1;
                           break;
                        }

                        if (var19[var7] == 1) {
                           break;
                        }

                        ++var7;
                     }

                     var14 = var24;
                     var15 = var17;
                     if (var7 != -1) {
                        label81: {
                           try {
                              this.i = c.b.d.c.a(this.d);
                           } catch (RuntimeException var10) {
                              var14 = var24;
                              var15 = var17;
                              break label81;
                           }

                           var14 = var24;
                           var15 = var17;
                        }
                     }
                  }
               }
            }
         } else {
            var14 = this.a(this.f, var3);
            var15 = this.a(this.g, var3);
         }

         ArrayList var25 = new ArrayList(var14.size());
         ArrayList var18 = new ArrayList(var15.size());
         this.a(var3, var14, var25, 0);
         this.a(var3, var15, var18, var14.size());
         Collections.sort(var25, this);
         this.f = (c1.b[])var25.toArray(new c1.b[var25.size()]);
         Collections.sort(var18, this);
         this.g = (c1.b[])var18.toArray(new c1.b[var18.size()]);
         if (this.s != null) {
            this.c.popGenericsScope();
         }

         Iterator var26 = this.h.iterator();

         while(var26.hasNext()) {
            c1.b var20 = (c1.b)var26.next();
            var7 = 0;

            while(true) {
               c1.b[] var22 = this.f;
               if (var7 >= var22.length) {
                  var2 = new StringBuilder();
                  var2.append("Field \"");
                  var2.append(var20);
                  var2.append("\" not found on class: ");
                  throw new IllegalArgumentException(c.a.b.a.a.a(this.d, var2));
               }

               c1.b var23 = var22[var7];
               if (var23 == var20) {
                  c1.b[] var21 = new c1.b[var22.length - 1];
                  System.arraycopy(var22, 0, var21, 0, var7);
                  System.arraycopy(this.f, var7 + 1, var21, var7, var21.length - var7);
                  this.f = var21;
                  this.h.add(var23);
                  break;
               }

               ++var7;
            }
         }

         this.q.a(this);
      }
   }

   public int compare(Object var1, Object var2) {
      c1.b var3 = (c1.b)var1;
      c1.b var4 = (c1.b)var2;
      return var3.a.getName().compareTo(var4.a.getName());
   }

   public Object copy(c.b.a.d var1, Object var2) {
      Object var3 = var1.newInstance(var2.getClass());
      var1.reference(var3);
      boolean var4 = this.v;
      byte var5 = 0;
      int var6;
      int var7;
      if (var4) {
         var6 = this.g.length;

         for(var7 = 0; var7 < var6; ++var7) {
            this.g[var7].a(var2, var3);
         }
      }

      var6 = this.f.length;

      for(var7 = var5; var7 < var6; ++var7) {
         this.f[var7].a(var2, var3);
      }

      return var3;
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      Throwable var10000;
      label379: {
         TypeVariable[] var4;
         boolean var10001;
         try {
            var4 = this.e;
         } catch (Throwable var36) {
            var10000 = var36;
            var10001 = false;
            break label379;
         }

         int var5 = 0;
         if (var4 != null) {
            try {
               if (this.r != null) {
                  this.a(false);
               }
            } catch (Throwable var35) {
               var10000 = var35;
               var10001 = false;
               break label379;
            }
         }

         try {
            if (this.s != null) {
               var1.pushGenericsScope(var3, this.s);
            }
         } catch (Throwable var34) {
            var10000 = var34;
            var10001 = false;
            break label379;
         }

         c1.b[] var38;
         int var6;
         Object var39;
         try {
            var39 = var1.newInstance(var3);
            var1.reference(var39);
            var38 = this.f;
            var6 = var38.length;
         } catch (Throwable var33) {
            var10000 = var33;
            var10001 = false;
            break label379;
         }

         while(true) {
            if (var5 >= var6) {
               if (this.s != null && var1.getGenericsScope() != null) {
                  var1.popGenericsScope();
               }

               return var39;
            }

            try {
               var38[var5].a(var2, var39);
            } catch (Throwable var32) {
               var10000 = var32;
               var10001 = false;
               break;
            }

            ++var5;
         }
      }

      Throwable var37 = var10000;
      if (this.s != null && var1.getGenericsScope() != null) {
         var1.popGenericsScope();
      }

      throw var37;
   }

   public void setGenerics(c.b.a.d var1, Class[] var2) {
      this.r = var2;
      TypeVariable[] var3 = this.e;
      if (var3 != null && var3.length > 0) {
         this.a(true);
      }

   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      if (c.b.c.a.c) {
         StringBuilder var4 = c.a.b.a.a.b("FieldSerializer.write fields of class: ");
         var4.append(var3.getClass().getName());
         c.b.c.a.b("kryo", var4.toString());
      }

      TypeVariable[] var7 = this.e;
      int var5 = 0;
      if (var7 != null && this.r != null) {
         this.a(false);
      }

      c.b.a.c var8 = this.s;
      if (var8 != null) {
         var1.pushGenericsScope(this.d, var8);
      }

      c1.b[] var9 = this.f;

      for(int var6 = var9.length; var5 < var6; ++var5) {
         var9[var5].a(var2, var3);
      }

      if (this.s != null) {
         var1.popGenericsScope();
      }

   }

   @Retention(RetentionPolicy.RUNTIME)
   @Target({ElementType.FIELD})
   public @interface a {
      Class value();
   }

   public abstract static class b {
      public Field a;
      public c.b.d.c b;
      public Class c;
      public c.b.a.k d;
      public boolean e;
      public int f = -1;
      public long g;
      public boolean h = true;

      public abstract void a(c.b.a.n.a var1, Object var2);

      public abstract void a(c.b.a.n.b var1, Object var2);

      public abstract void a(Object var1, Object var2);

      public String toString() {
         return this.a.getName();
      }
   }

   public interface c {
      c1.b a(Class var1, Field var2, c1 var3);
   }

   @Retention(RetentionPolicy.RUNTIME)
   @Target({ElementType.FIELD})
   public @interface d {
      String value();
   }
}
