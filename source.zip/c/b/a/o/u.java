package c.b.a.o;

import java.lang.reflect.Array;
import java.lang.reflect.Modifier;

public class u extends c.b.a.k {
   public boolean c;
   public boolean d = true;
   public Class[] e;

   public u(Class var1) {
      this.setAcceptsNull(true);
      boolean var2;
      if ((var1.getComponentType().getModifiers() & 16) != 0) {
         var2 = true;
      } else {
         var2 = false;
      }

      if (var2) {
         this.c = true;
      }

   }

   public Object copy(c.b.a.d var1, Object var2) {
      Object[] var3 = (Object[])var2;
      Object[] var6 = (Object[])Array.newInstance(var3.getClass().getComponentType(), var3.length);
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         var6[var5] = var1.copy(var3[var5]);
      }

      return var6;
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      int var4 = var2.a(true);
      Object[] var11;
      if (var4 == 0) {
         var11 = null;
      } else {
         Object[] var5 = (Object[])Array.newInstance(var3.getComponentType(), var4 - 1);
         var1.reference(var5);
         Class var6 = var5.getClass().getComponentType();
         boolean var7 = this.c;
         byte var8 = 0;
         var4 = 0;
         if (!var7 && !Modifier.isFinal(var6.getModifiers())) {
            int var13 = var5.length;

            while(true) {
               var11 = var5;
               if (var4 >= var13) {
                  break;
               }

               c.b.a.j var12 = var1.readClass(var2);
               if (var12 != null) {
                  var12.c.setGenerics(var1, this.e);
                  var5[var4] = var1.readObject(var2, var12.a, var12.c);
               } else {
                  var5[var4] = null;
               }

               ++var4;
            }
         } else {
            c.b.a.k var9 = var1.getSerializer(var6);
            var9.setGenerics(var1, this.e);
            int var10 = var5.length;
            var4 = var8;

            while(true) {
               var11 = var5;
               if (var4 >= var10) {
                  break;
               }

               if (this.d) {
                  var5[var4] = var1.readObjectOrNull(var2, var6, var9);
               } else {
                  var5[var4] = var1.readObject(var2, var6, var9);
               }

               ++var4;
            }
         }
      }

      return var11;
   }

   public void setGenerics(c.b.a.d var1, Class[] var2) {
      if (c.b.c.a.c) {
         c.b.c.a.b("kryo", "setting generics for ObjectArraySerializer");
      }

      this.e = var2;
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      Object[] var8 = (Object[])var3;
      byte var4 = 0;
      int var5 = 0;
      if (var8 == null) {
         var2.a(0, true);
      } else {
         var2.a(var8.length + 1, true);
         Class var6 = var8.getClass().getComponentType();
         if (!this.c && !Modifier.isFinal(var6.getModifiers())) {
            for(int var9 = var8.length; var5 < var9; ++var5) {
               if (var8[var5] != null) {
                  var1.getSerializer(var8[var5].getClass()).setGenerics(var1, this.e);
               }

               var1.writeClassAndObject(var2, var8[var5]);
            }
         } else {
            c.b.a.k var10 = var1.getSerializer(var6);
            var10.setGenerics(var1, this.e);
            int var7 = var8.length;

            for(var5 = var4; var5 < var7; ++var5) {
               if (this.d) {
                  var1.writeObjectOrNull(var2, var8[var5], var10);
               } else {
                  var1.writeObject(var2, var8[var5], var10);
               }
            }
         }
      }

   }
}
