package c.b.a.o;

public final class e extends c {
   public void a(c.b.a.n.a var1, Object var2) {
      super.b.a(var2, super.f, var1.e());
   }

   public void a(c.b.a.n.b var1, Object var2) {
      var1.a(super.b.e(var2, super.f));
   }

   public void a(Object var1, Object var2) {
      c.b.d.c var3 = super.b;
      int var4 = super.f;
      var3.a(var2, var4, var3.e(var1, var4));
   }
}
