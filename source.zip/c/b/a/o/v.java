package c.b.a.o;

public class v extends c.b.a.k {
   public v() {
      this.setAcceptsNull(true);
   }

   public Object copy(c.b.a.d var1, Object var2) {
      short[] var4 = (short[])var2;
      short[] var3 = new short[var4.length];
      System.arraycopy(var4, 0, var3, 0, var3.length);
      return var3;
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      int var4 = var2.a(true);
      short[] var6;
      if (var4 == 0) {
         var6 = null;
      } else {
         int var5 = var4 - 1;
         short[] var7 = new short[var5];
         var4 = 0;

         while(true) {
            var6 = var7;
            if (var4 >= var5) {
               break;
            }

            var7[var4] = var2.i();
            ++var4;
         }
      }

      return var6;
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      short[] var6 = (short[])var3;
      int var4 = 0;
      if (var6 == null) {
         var2.a(0, true);
      } else {
         var2.a(var6.length + 1, true);

         for(int var5 = var6.length; var4 < var5; ++var4) {
            var2.e(var6[var4]);
         }
      }

   }
}
