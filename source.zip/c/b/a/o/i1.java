package c.b.a.o;

public class i1 extends c1.b {
   public Class[] i;
   public final c1 j;
   public final Class k;
   public final c.b.a.d l;

   public i1(c1 var1) {
      this.j = var1;
      this.l = var1.c;
      this.k = var1.d;
   }

   public Object a(Object var1) {
      return super.a.get(var1);
   }

   public void a(c.b.a.n.a param1, Object param2) {
      // $FF: Couldn't be decompiled
   }

   public void a(c.b.a.n.b param1, Object param2) {
      // $FF: Couldn't be decompiled
   }

   public void a(Object var1, Object var2) {
      StringBuilder var9;
      try {
         if (super.f != -1) {
            c.b.d.c var3 = (c.b.d.c)this.j.i;
            var3.a(var2, super.f, this.l.copy(var3.a(var1, super.f)));
         } else {
            this.b(var2, this.l.copy(this.a(var1)));
         }

      } catch (IllegalAccessException var4) {
         var9 = new StringBuilder();
         var9.append("Error accessing field: ");
         var9.append(this);
         var9.append(" (");
         var9.append(this.k.getName());
         var9.append(")");
         throw new c.b.a.f(var9.toString(), var4);
      } catch (c.b.a.f var5) {
         StringBuilder var8 = new StringBuilder();
         var8.append(this);
         var8.append(" (");
         c.a.b.a.a.a(this.k, var8, ")", var5);
         throw var5;
      } catch (RuntimeException var6) {
         c.b.a.f var7 = new c.b.a.f(var6);
         var9 = new StringBuilder();
         var9.append(this);
         var9.append(" (");
         c.a.b.a.a.a(this.k, var9, ")", var7);
         throw var7;
      }
   }

   public void b(Object var1, Object var2) {
      super.a.set(var1, var2);
   }

   public static final class a extends i1 {
      public a(c1 var1) {
         super(var1);
      }

      public Object a(Object var1) {
         return super.a.getBoolean(var1);
      }

      public void a(c.b.a.n.a var1, Object var2) {
         try {
            super.a.setBoolean(var2, var1.b());
         } catch (Exception var3) {
            c.b.a.f var5 = new c.b.a.f(var3);
            StringBuilder var4 = new StringBuilder();
            var4.append(this);
            var4.append(" (");
            c.a.b.a.a.a(super.k, var4, ")", var5);
            throw var5;
         }
      }

      public void a(c.b.a.n.b var1, Object var2) {
         try {
            var1.a(super.a.getBoolean(var2));
         } catch (Exception var3) {
            c.b.a.f var4 = new c.b.a.f(var3);
            StringBuilder var5 = new StringBuilder();
            var5.append(this);
            var5.append(" (");
            c.a.b.a.a.a(super.k, var5, ")", var4);
            throw var4;
         }
      }

      public void a(Object var1, Object var2) {
         try {
            super.a.setBoolean(var2, super.a.getBoolean(var1));
         } catch (Exception var3) {
            c.b.a.f var5 = new c.b.a.f(var3);
            StringBuilder var4 = new StringBuilder();
            var4.append(this);
            var4.append(" (");
            c.a.b.a.a.a(super.k, var4, ")", var5);
            throw var5;
         }
      }
   }

   public static final class b extends i1 {
      public b(c1 var1) {
         super(var1);
      }

      public Object a(Object var1) {
         return super.a.getByte(var1);
      }

      public void a(c.b.a.n.a var1, Object var2) {
         try {
            super.a.setByte(var2, var1.c());
         } catch (Exception var3) {
            c.b.a.f var5 = new c.b.a.f(var3);
            StringBuilder var4 = new StringBuilder();
            var4.append(this);
            var4.append(" (");
            c.a.b.a.a.a(super.k, var4, ")", var5);
            throw var5;
         }
      }

      public void a(c.b.a.n.b var1, Object var2) {
         try {
            var1.a(super.a.getByte(var2));
         } catch (Exception var3) {
            c.b.a.f var4 = new c.b.a.f(var3);
            StringBuilder var5 = new StringBuilder();
            var5.append(this);
            var5.append(" (");
            c.a.b.a.a.a(super.k, var5, ")", var4);
            throw var4;
         }
      }

      public void a(Object var1, Object var2) {
         try {
            super.a.setByte(var2, super.a.getByte(var1));
         } catch (Exception var3) {
            c.b.a.f var4 = new c.b.a.f(var3);
            StringBuilder var5 = new StringBuilder();
            var5.append(this);
            var5.append(" (");
            c.a.b.a.a.a(super.k, var5, ")", var4);
            throw var4;
         }
      }
   }

   public static final class c extends i1 {
      public c(c1 var1) {
         super(var1);
      }

      public Object a(Object var1) {
         return super.a.getChar(var1);
      }

      public void a(c.b.a.n.a var1, Object var2) {
         try {
            super.a.setChar(var2, var1.d());
         } catch (Exception var3) {
            c.b.a.f var4 = new c.b.a.f(var3);
            StringBuilder var5 = new StringBuilder();
            var5.append(this);
            var5.append(" (");
            c.a.b.a.a.a(super.k, var5, ")", var4);
            throw var4;
         }
      }

      public void a(c.b.a.n.b var1, Object var2) {
         try {
            var1.a(super.a.getChar(var2));
         } catch (Exception var3) {
            c.b.a.f var4 = new c.b.a.f(var3);
            StringBuilder var5 = new StringBuilder();
            var5.append(this);
            var5.append(" (");
            c.a.b.a.a.a(super.k, var5, ")", var4);
            throw var4;
         }
      }

      public void a(Object var1, Object var2) {
         try {
            super.a.setChar(var2, super.a.getChar(var1));
         } catch (Exception var3) {
            c.b.a.f var4 = new c.b.a.f(var3);
            StringBuilder var5 = new StringBuilder();
            var5.append(this);
            var5.append(" (");
            c.a.b.a.a.a(super.k, var5, ")", var4);
            throw var4;
         }
      }
   }

   public static final class d extends i1 {
      public d(c1 var1) {
         super(var1);
      }

      public Object a(Object var1) {
         return super.a.getDouble(var1);
      }

      public void a(c.b.a.n.a var1, Object var2) {
         try {
            super.a.setDouble(var2, var1.e());
         } catch (Exception var3) {
            c.b.a.f var4 = new c.b.a.f(var3);
            StringBuilder var5 = new StringBuilder();
            var5.append(this);
            var5.append(" (");
            c.a.b.a.a.a(super.k, var5, ")", var4);
            throw var4;
         }
      }

      public void a(c.b.a.n.b var1, Object var2) {
         try {
            var1.a(super.a.getDouble(var2));
         } catch (Exception var3) {
            c.b.a.f var4 = new c.b.a.f(var3);
            StringBuilder var5 = new StringBuilder();
            var5.append(this);
            var5.append(" (");
            c.a.b.a.a.a(super.k, var5, ")", var4);
            throw var4;
         }
      }

      public void a(Object var1, Object var2) {
         try {
            super.a.setDouble(var2, super.a.getDouble(var1));
         } catch (Exception var3) {
            c.b.a.f var4 = new c.b.a.f(var3);
            StringBuilder var5 = new StringBuilder();
            var5.append(this);
            var5.append(" (");
            c.a.b.a.a.a(super.k, var5, ")", var4);
            throw var4;
         }
      }
   }

   public static final class e extends i1 {
      public e(c1 var1) {
         super(var1);
      }

      public Object a(Object var1) {
         return super.a.getFloat(var1);
      }

      public void a(c.b.a.n.a var1, Object var2) {
         try {
            super.a.setFloat(var2, var1.f());
         } catch (Exception var3) {
            c.b.a.f var4 = new c.b.a.f(var3);
            StringBuilder var5 = new StringBuilder();
            var5.append(this);
            var5.append(" (");
            c.a.b.a.a.a(super.k, var5, ")", var4);
            throw var4;
         }
      }

      public void a(c.b.a.n.b var1, Object var2) {
         try {
            var1.a(super.a.getFloat(var2));
         } catch (Exception var3) {
            c.b.a.f var4 = new c.b.a.f(var3);
            StringBuilder var5 = new StringBuilder();
            var5.append(this);
            var5.append(" (");
            c.a.b.a.a.a(super.k, var5, ")", var4);
            throw var4;
         }
      }

      public void a(Object var1, Object var2) {
         try {
            super.a.setFloat(var2, super.a.getFloat(var1));
         } catch (Exception var3) {
            c.b.a.f var5 = new c.b.a.f(var3);
            StringBuilder var4 = new StringBuilder();
            var4.append(this);
            var4.append(" (");
            c.a.b.a.a.a(super.k, var4, ")", var5);
            throw var5;
         }
      }
   }

   public static final class f extends i1 {
      public f(c1 var1) {
         super(var1);
      }

      public Object a(Object var1) {
         return super.a.getInt(var1);
      }

      public void a(c.b.a.n.a var1, Object var2) {
         try {
            if (super.h) {
               super.a.setInt(var2, var1.a(false));
            } else {
               super.a.setInt(var2, var1.g());
            }

         } catch (Exception var3) {
            c.b.a.f var5 = new c.b.a.f(var3);
            StringBuilder var4 = new StringBuilder();
            var4.append(this);
            var4.append(" (");
            c.a.b.a.a.a(super.k, var4, ")", var5);
            throw var5;
         }
      }

      public void a(c.b.a.n.b var1, Object var2) {
         try {
            if (super.h) {
               var1.a(super.a.getInt(var2), false);
            } else {
               var1.d(super.a.getInt(var2));
            }

         } catch (Exception var3) {
            c.b.a.f var5 = new c.b.a.f(var3);
            StringBuilder var4 = new StringBuilder();
            var4.append(this);
            var4.append(" (");
            c.a.b.a.a.a(super.k, var4, ")", var5);
            throw var5;
         }
      }

      public void a(Object var1, Object var2) {
         try {
            super.a.setInt(var2, super.a.getInt(var1));
         } catch (Exception var3) {
            c.b.a.f var5 = new c.b.a.f(var3);
            StringBuilder var4 = new StringBuilder();
            var4.append(this);
            var4.append(" (");
            c.a.b.a.a.a(super.k, var4, ")", var5);
            throw var5;
         }
      }
   }

   public static final class g extends i1 {
      public g(c1 var1) {
         super(var1);
      }

      public Object a(Object var1) {
         return super.a.getLong(var1);
      }

      public void a(c.b.a.n.a var1, Object var2) {
         try {
            if (super.h) {
               super.a.setLong(var2, var1.b(false));
            } else {
               super.a.setLong(var2, var1.h());
            }

         } catch (Exception var3) {
            c.b.a.f var4 = new c.b.a.f(var3);
            StringBuilder var5 = new StringBuilder();
            var5.append(this);
            var5.append(" (");
            c.a.b.a.a.a(super.k, var5, ")", var4);
            throw var4;
         }
      }

      public void a(c.b.a.n.b var1, Object var2) {
         try {
            if (super.h) {
               var1.a(super.a.getLong(var2), false);
            } else {
               var1.a(super.a.getLong(var2));
            }

         } catch (Exception var3) {
            c.b.a.f var5 = new c.b.a.f(var3);
            StringBuilder var4 = new StringBuilder();
            var4.append(this);
            var4.append(" (");
            c.a.b.a.a.a(super.k, var4, ")", var5);
            throw var5;
         }
      }

      public void a(Object var1, Object var2) {
         try {
            super.a.setLong(var2, super.a.getLong(var1));
         } catch (Exception var3) {
            c.b.a.f var5 = new c.b.a.f(var3);
            StringBuilder var4 = new StringBuilder();
            var4.append(this);
            var4.append(" (");
            c.a.b.a.a.a(super.k, var4, ")", var5);
            throw var5;
         }
      }
   }

   public static final class h extends i1 {
      public h(c1 var1) {
         super(var1);
      }

      public Object a(Object var1) {
         return super.a.getShort(var1);
      }

      public void a(c.b.a.n.a var1, Object var2) {
         try {
            super.a.setShort(var2, var1.i());
         } catch (Exception var3) {
            c.b.a.f var5 = new c.b.a.f(var3);
            StringBuilder var4 = new StringBuilder();
            var4.append(this);
            var4.append(" (");
            c.a.b.a.a.a(super.k, var4, ")", var5);
            throw var5;
         }
      }

      public void a(c.b.a.n.b var1, Object var2) {
         try {
            var1.e(super.a.getShort(var2));
         } catch (Exception var3) {
            c.b.a.f var5 = new c.b.a.f(var3);
            StringBuilder var4 = new StringBuilder();
            var4.append(this);
            var4.append(" (");
            c.a.b.a.a.a(super.k, var4, ")", var5);
            throw var5;
         }
      }

      public void a(Object var1, Object var2) {
         try {
            super.a.setShort(var2, super.a.getShort(var1));
         } catch (Exception var3) {
            c.b.a.f var5 = new c.b.a.f(var3);
            StringBuilder var4 = new StringBuilder();
            var4.append(this);
            var4.append(" (");
            c.a.b.a.a.a(super.k, var4, ")", var5);
            throw var5;
         }
      }
   }
}
