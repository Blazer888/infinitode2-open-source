package c.b.a.o;

import java.lang.reflect.Constructor;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Date;

public class l0 extends c.b.a.k {
   public final Date a(c.b.a.d var1, Class var2, long var3) {
      if (var2.equals(Date.class)) {
         return new Date(var3);
      } else if (var2.equals(Timestamp.class)) {
         return new Timestamp(var3);
      } else if (var2.equals(java.sql.Date.class)) {
         return new java.sql.Date(var3);
      } else if (var2.equals(Time.class)) {
         return new Time(var3);
      } else {
         Exception var10000;
         label102: {
            Constructor var5;
            boolean var10001;
            try {
               var5 = var2.getDeclaredConstructor(Long.TYPE);
            } catch (Exception var16) {
               var10000 = var16;
               var10001 = false;
               break label102;
            }

            if (var5 != null) {
               label116: {
                  boolean var6;
                  try {
                     var6 = var5.isAccessible();
                  } catch (Exception var14) {
                     var10000 = var14;
                     var10001 = false;
                     break label116;
                  }

                  if (!var6) {
                     label87:
                     try {
                        var5.setAccessible(true);
                     } finally {
                        break label87;
                     }
                  }

                  try {
                     return (Date)var5.newInstance(var3);
                  } catch (Exception var13) {
                     var10000 = var13;
                     var10001 = false;
                  }
               }
            } else {
               try {
                  Date var18 = (Date)var1.newInstance(var2);
                  var18.setTime(var3);
                  return var18;
               } catch (Exception var15) {
                  var10000 = var15;
                  var10001 = false;
               }
            }
         }

         Exception var17 = var10000;
         throw new c.b.a.f(var17);
      }
   }

   public Object copy(c.b.a.d var1, Object var2) {
      Date var3 = (Date)var2;
      return this.a(var1, var3.getClass(), var3.getTime());
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      return this.a(var1, var3, var2.b(true));
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      var2.a(((Date)var3).getTime(), true);
   }
}
