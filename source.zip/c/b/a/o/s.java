package c.b.a.o;

public class s extends c.b.a.k {
   public s() {
      this.setAcceptsNull(true);
   }

   public Object copy(c.b.a.d var1, Object var2) {
      int[] var3 = (int[])var2;
      int[] var4 = new int[var3.length];
      System.arraycopy(var3, 0, var4, 0, var4.length);
      return var4;
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      int var4 = var2.a(true);
      int[] var6;
      if (var4 == 0) {
         var6 = null;
      } else {
         int var5 = var4 - 1;
         int[] var7 = new int[var5];
         var4 = 0;

         while(true) {
            var6 = var7;
            if (var4 >= var5) {
               break;
            }

            var7[var4] = var2.a(false);
            ++var4;
         }
      }

      return var6;
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      int[] var6 = (int[])var3;
      if (var6 == null) {
         var2.a(0, true);
      } else {
         var2.a(var6.length + 1, true);
         int var4 = var6.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            var2.a(var6[var5], false);
         }
      }

   }
}
