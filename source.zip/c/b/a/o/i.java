package c.b.a.o;

public final class i extends i1 {
   public i(c1 var1) {
      super(var1);
   }

   public Object a(Object var1) {
      int var2 = super.f;
      if (var2 != -1) {
         return super.b.a(var1, var2);
      } else {
         throw new c.b.a.f("Unknown acess index");
      }
   }

   public void a(Object var1, Object var2) {
      try {
         if (super.f != -1) {
            super.b.a(var2, super.f, super.l.copy(super.b.a(var1, super.f)));
         } else {
            c.b.a.f var6 = new c.b.a.f("Unknown acess index");
            throw var6;
         }
      } catch (c.b.a.f var3) {
         StringBuilder var8 = new StringBuilder();
         var8.append(this);
         var8.append(" (");
         c.a.b.a.a.a(super.k, var8, ")", var3);
         throw var3;
      } catch (RuntimeException var4) {
         c.b.a.f var7 = new c.b.a.f(var4);
         StringBuilder var5 = new StringBuilder();
         var5.append(this);
         var5.append(" (");
         c.a.b.a.a.a(super.k, var5, ")", var7);
         throw var7;
      }
   }

   public void b(Object var1, Object var2) {
      int var3 = super.f;
      if (var3 != -1) {
         super.b.a(var1, var3, var2);
      } else {
         throw new c.b.a.f("Unknown acess index");
      }
   }
}
