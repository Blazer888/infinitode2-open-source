package c.b.a.o;

import java.util.Collections;
import java.util.Map;
import java.util.Map.Entry;

public class i0 extends c.b.a.k {
   public i0() {
      this.setImmutable(true);
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      return Collections.singletonMap(var1.readClassAndObject(var2), var1.readClassAndObject(var2));
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      Entry var4 = (Entry)((Map)var3).entrySet().iterator().next();
      var1.writeClassAndObject(var2, var4.getKey());
      var1.writeClassAndObject(var2, var4.getValue());
   }
}
