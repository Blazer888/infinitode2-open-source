package c.b.a.o;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class m extends c.b.a.k {
   public boolean c = true;
   public c.b.a.k d;
   public Class e;
   public Class f;

   public Collection a(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      return (Collection)var1.newInstance(var3);
   }

   public Collection a(c.b.a.d var1, Collection var2) {
      return (Collection)var1.newInstance(var2.getClass());
   }

   public void a(c.b.a.d var1, c.b.a.n.b var2, Collection var3) {
      var2.a(var3.size(), true);
      c.b.a.k var4 = this.d;
      Class var5 = this.f;
      c.b.a.k var6 = var4;
      if (var5 != null) {
         var6 = var4;
         if (var4 == null) {
            var6 = var1.getSerializer(var5);
         }

         this.f = null;
      }

      Iterator var7;
      if (var6 != null) {
         if (this.c) {
            var7 = var3.iterator();

            while(var7.hasNext()) {
               var1.writeObjectOrNull(var2, var7.next(), var6);
            }
         } else {
            var7 = var3.iterator();

            while(var7.hasNext()) {
               var1.writeObject(var2, var7.next(), var6);
            }
         }
      } else {
         var7 = var3.iterator();

         while(var7.hasNext()) {
            var1.writeClassAndObject(var2, var7.next());
         }
      }

   }

   public Object copy(c.b.a.d var1, Object var2) {
      Collection var3 = (Collection)var2;
      Collection var4 = this.a(var1, var3);
      var1.reference(var4);
      Iterator var5 = var3.iterator();

      while(var5.hasNext()) {
         var4.add(var1.copy(var5.next()));
      }

      return var4;
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      Collection var4 = this.a(var1, var2, var3);
      var1.reference(var4);
      int var5 = var2.a(true);
      if (var4 instanceof ArrayList) {
         ((ArrayList)var4).ensureCapacity(var5);
      }

      var3 = this.e;
      c.b.a.k var6 = this.d;
      Class var7 = this.f;
      Class var8 = var3;
      c.b.a.k var9 = var6;
      if (var7 != null) {
         var9 = var6;
         if (var6 == null) {
            var9 = var1.getSerializer(var7);
            var3 = var7;
         }

         this.f = null;
         var8 = var3;
      }

      byte var10 = 0;
      int var11 = 0;
      byte var12 = 0;
      if (var9 != null) {
         var11 = var10;
         if (!this.c) {
            while(var11 < var5) {
               var4.add(var1.readObject(var2, var8, var9));
               ++var11;
            }
         } else {
            for(var11 = var12; var11 < var5; ++var11) {
               var4.add(var1.readObjectOrNull(var2, var8, var9));
            }
         }
      } else {
         while(var11 < var5) {
            var4.add(var1.readClassAndObject(var2));
            ++var11;
         }
      }

      return var4;
   }

   public void setGenerics(c.b.a.d var1, Class[] var2) {
      this.f = null;
      if (var2 != null && var2.length > 0 && var1.isFinal(var2[0])) {
         this.f = var2[0];
      }

   }

   @Retention(RetentionPolicy.RUNTIME)
   @Target({ElementType.FIELD})
   public @interface a {
      Class elementClass() default Object.class;

      Class elementSerializer() default c.b.a.k.class;

      boolean elementsCanBeNull() default true;
   }
}
