package c.b.a.o;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.List;

public interface f1 {
   long a(Field var1);

   void a(List var1, List var2, int var3, c.b.a.p.e var4);

   public static class a {
      public static Constructor a;

      static {
         label19:
         try {
            a = c1.class.getClassLoader().loadClass("com.esotericsoftware.kryo.serializers.FieldSerializerUnsafeUtilImpl").getConstructor(c1.class);
         } finally {
            break label19;
         }

      }
   }
}
