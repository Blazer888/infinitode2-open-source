package c.b.a.o;

public class w extends c.b.a.k {
   public w() {
      this.setAcceptsNull(true);
   }

   public Object copy(c.b.a.d var1, Object var2) {
      String[] var3 = (String[])var2;
      String[] var4 = new String[var3.length];
      System.arraycopy(var3, 0, var4, 0, var4.length);
      return var4;
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      int var4 = var2.a(true);
      String[] var10;
      if (var4 == 0) {
         var10 = null;
      } else {
         String[] var11;
         label25: {
            int var5 = var4 - 1;
            var11 = new String[var5];
            boolean var6 = var1.getReferences();
            byte var7 = 0;
            byte var8 = 0;
            var4 = var7;
            if (var6) {
               var4 = var7;
               if (((c.b.a.p.g)var1.getReferenceResolver()).a(String.class)) {
                  c.b.a.k var9 = var1.getSerializer(String.class);
                  var4 = var8;

                  while(true) {
                     if (var4 >= var5) {
                        break label25;
                     }

                     var11[var4] = (String)var1.readObjectOrNull(var2, String.class, var9);
                     ++var4;
                  }
               }
            }

            while(var4 < var5) {
               var11[var4] = var2.j();
               ++var4;
            }
         }

         var10 = var11;
      }

      return var10;
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      String[] var4 = (String[])var3;
      byte var5 = 0;
      int var6 = 0;
      if (var4 == null) {
         var2.a(0, true);
      } else {
         var2.a(var4.length + 1, true);
         if (var1.getReferences() && ((c.b.a.p.g)var1.getReferenceResolver()).a(String.class)) {
            c.b.a.k var8 = var1.getSerializer(String.class);

            for(int var9 = var4.length; var6 < var9; ++var6) {
               var1.writeObjectOrNull(var2, var4[var6], (c.b.a.k)var8);
            }
         } else {
            int var7 = var4.length;

            for(var6 = var5; var6 < var7; ++var6) {
               var2.a(var4[var6]);
            }
         }
      }

   }
}
