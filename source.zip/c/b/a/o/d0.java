package c.b.a.o;

public class d0 extends c.b.a.k {
   public d0() {
      this.setImmutable(true);
      this.setAcceptsNull(true);
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      c.b.a.j var5 = var1.readClass(var2);
      int var4 = var2.read();
      Class var6;
      if (var5 != null) {
         var6 = var5.a;
      } else {
         var6 = null;
      }

      Class var7 = var6;
      if (var6 != null) {
         if (!var6.isPrimitive()) {
            var7 = var6;
         } else if (var4 == 1) {
            var7 = var6;
         } else {
            var7 = c.b.a.p.i.c(var6);
         }
      }

      return var7;
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      Class var5 = (Class)var3;
      var1.writeClass(var2, var5);
      byte var4;
      if (var5 != null && var5.isPrimitive()) {
         var4 = 1;
      } else {
         var4 = 0;
      }

      var2.c(var4);
   }
}
