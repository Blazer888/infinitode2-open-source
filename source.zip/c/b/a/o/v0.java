package c.b.a.o;

public class v0 extends c.b.a.k {
   public v0() {
      this.setAcceptsNull(true);
   }

   public Object copy(c.b.a.d var1, Object var2) {
      return new StringBuffer((StringBuffer)var2);
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      String var4 = var2.j();
      StringBuffer var5;
      if (var4 == null) {
         var5 = null;
      } else {
         var5 = new StringBuffer(var4);
      }

      return var5;
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      var2.a((CharSequence)((StringBuffer)var3));
   }
}
