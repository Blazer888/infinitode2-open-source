package c.b.a.o;

import java.util.Collections;
import java.util.Set;

public class j0 extends c.b.a.k {
   public j0() {
      this.setImmutable(true);
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      return Collections.singleton(var1.readClassAndObject(var2));
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
      var1.writeClassAndObject(var2, ((Set)var3).iterator().next());
   }
}
