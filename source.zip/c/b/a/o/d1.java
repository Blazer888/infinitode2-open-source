package c.b.a.o;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.Map;

public final class d1 {
   public void a(c1 var1) {
      c1.b[] var2 = var1.f;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         Field var5 = var2[var4].a;
         Class var6;
         c.b.a.k var14;
         if (var5.isAnnotationPresent(c1.a.class)) {
            var6 = ((c1.a)var5.getAnnotation(c1.a.class)).value();
            var14 = c.b.a.m.b.a(var1.c, var6, var5.getClass());
            var2[var4].d = var14;
         }

         if (var5.isAnnotationPresent(m.a.class)) {
            var5.isAnnotationPresent(g1.a.class);
         }

         Class var8;
         boolean var9;
         StringBuilder var12;
         Class var15;
         if (var5.isAnnotationPresent(m.a.class)) {
            if (var2[var4].d != null) {
               var12 = c.a.b.a.a.b("CollectionSerialier.Bind cannot be used with field ");
               var12.append(var2[var4].a.getDeclaringClass().getName());
               var12.append(".");
               var12.append(var2[var4].a.getName());
               var12.append(", because it has a serializer already.");
               throw new RuntimeException(var12.toString());
            }

            m.a var7 = (m.a)var5.getAnnotation(m.a.class);
            if (!Collection.class.isAssignableFrom(var2[var4].a.getType())) {
               var12 = c.a.b.a.a.b("CollectionSerialier.Bind should be used only with fields implementing java.util.Collection, but field ");
               var12.append(var2[var4].a.getDeclaringClass().getName());
               var12.append(".");
               var12.append(var2[var4].a.getName());
               var12.append(" does not implement it.");
               throw new RuntimeException(var12.toString());
            }

            var8 = var7.elementSerializer();
            var6 = var8;
            if (var8 == c.b.a.k.class) {
               var6 = null;
            }

            if (var6 == null) {
               var14 = null;
            } else {
               var14 = c.b.a.m.b.a(var1.c, var6, var5.getClass());
            }

            var9 = var7.elementsCanBeNull();
            var15 = var7.elementClass();
            var8 = var15;
            if (var15 == Object.class) {
               var8 = null;
            }

            m var16 = new m();
            var16.c = var9;
            var16.e = var8;
            var16.d = var14;
            var2[var4].d = var16;
         }

         if (var5.isAnnotationPresent(g1.a.class)) {
            if (var2[var4].d != null) {
               var12 = c.a.b.a.a.b("MapSerialier.Bind cannot be used with field ");
               var12.append(var2[var4].a.getDeclaringClass().getName());
               var12.append(".");
               var12.append(var2[var4].a.getName());
               var12.append(", because it has a serializer already.");
               throw new RuntimeException(var12.toString());
            }

            g1.a var10 = (g1.a)var5.getAnnotation(g1.a.class);
            if (!Map.class.isAssignableFrom(var2[var4].a.getType())) {
               var12 = c.a.b.a.a.b("MapSerialier.Bind should be used only with fields implementing java.util.Map, but field ");
               var12.append(var2[var4].a.getDeclaringClass().getName());
               var12.append(".");
               var12.append(var2[var4].a.getName());
               var12.append(" does not implement it.");
               throw new RuntimeException(var12.toString());
            }

            var8 = var10.valueSerializer();
            var15 = var10.keySerializer();
            var6 = var8;
            if (var8 == c.b.a.k.class) {
               var6 = null;
            }

            var8 = var15;
            if (var15 == c.b.a.k.class) {
               var8 = null;
            }

            if (var6 == null) {
               var14 = null;
            } else {
               var14 = c.b.a.m.b.a(var1.c, var6, var5.getClass());
            }

            c.b.a.k var18;
            if (var8 == null) {
               var18 = null;
            } else {
               var18 = c.b.a.m.b.a(var1.c, var8, var5.getClass());
            }

            var9 = var10.valuesCanBeNull();
            boolean var11 = var10.keysCanBeNull();
            Class var13 = var10.keyClass();
            Class var17 = var10.valueClass();
            var15 = var13;
            if (var13 == Object.class) {
               var15 = null;
            }

            var13 = var17;
            if (var17 == Object.class) {
               var13 = null;
            }

            g1 var19 = new g1();
            var19.g = var11;
            var19.h = var9;
            var19.c = var15;
            var19.e = var18;
            var19.d = var13;
            var19.f = var14;
            var2[var4].d = var19;
         }
      }

   }
}
