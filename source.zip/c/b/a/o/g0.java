package c.b.a.o;

import java.util.Collections;

public class g0 extends c.b.a.k {
   public g0() {
      this.setImmutable(true);
   }

   public Object read(c.b.a.d var1, c.b.a.n.a var2, Class var3) {
      return Collections.EMPTY_SET;
   }

   public void write(c.b.a.d var1, c.b.a.n.b var2, Object var3) {
   }
}
