package c.b.a;

import c.b.a.o.a0;
import c.b.a.o.a1;
import c.b.a.o.b0;
import c.b.a.o.b1;
import c.b.a.o.c0;
import c.b.a.o.c1;
import c.b.a.o.d0;
import c.b.a.o.e0;
import c.b.a.o.f0;
import c.b.a.o.g0;
import c.b.a.o.g1;
import c.b.a.o.h0;
import c.b.a.o.i0;
import c.b.a.o.j0;
import c.b.a.o.k0;
import c.b.a.o.l0;
import c.b.a.o.m;
import c.b.a.o.m0;
import c.b.a.o.n;
import c.b.a.o.n0;
import c.b.a.o.o;
import c.b.a.o.o0;
import c.b.a.o.p;
import c.b.a.o.p0;
import c.b.a.o.q;
import c.b.a.o.q0;
import c.b.a.o.r;
import c.b.a.o.r0;
import c.b.a.o.s;
import c.b.a.o.s0;
import c.b.a.o.t;
import c.b.a.o.t0;
import c.b.a.o.u;
import c.b.a.o.u0;
import c.b.a.o.v;
import c.b.a.o.v0;
import c.b.a.o.w;
import c.b.a.o.w0;
import c.b.a.o.x;
import c.b.a.o.x0;
import c.b.a.o.y;
import c.b.a.o.y0;
import c.b.a.o.z;
import c.b.a.o.z0;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.ConcurrentModificationException;
import java.util.Currency;
import java.util.Date;
import java.util.EnumSet;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.TreeSet;

public class d {
   public static final byte NOT_NULL = 1;
   public static final byte NULL = 0;
   public c.b.a.m.c a;
   public final ArrayList b;
   public final int c;
   public final c.b.a.a d;
   public int e;
   public ClassLoader f;
   public d.a.b.a g;
   public boolean h;
   public int i;
   public int j;
   public boolean k;
   public volatile Thread l;
   public c.b.a.p.h m;
   public c.b.a.p.h n;
   public i o;
   public final c.b.a.p.e p;
   public boolean q;
   public boolean r;
   public Object s;
   public int t;
   public boolean u;
   public c.b.a.p.c v;
   public Object w;
   public c x;
   public boolean y;
   public l z;

   public d() {
      this(new c.b.a.p.a(), new c.b.a.p.g(), new c.b.a.p.b());
   }

   public d(c.b.a.a var1, i var2) {
      this(var1, var2, new c.b.a.p.b());
   }

   public d(c.b.a.a var1, i var2, l var3) {
      this.a = new c.b.a.m.b(c1.class);
      this.b = new ArrayList(32);
      this.f = this.getClass().getClassLoader();
      this.g = new d.a();
      this.j = Integer.MAX_VALUE;
      this.k = true;
      this.p = new c.b.a.p.e(true, 0);
      this.r = true;
      this.y = false;
      if (var1 != null) {
         this.d = var1;
         ((c.b.a.p.a)var1).a = this;
         this.z = var3;
         ((c.b.a.p.b)var3).a(this);
         this.o = var2;
         if (var2 != null) {
            c.b.a.p.g var4 = (c.b.a.p.g)var2;
            this.q = true;
         }

         this.addDefaultSerializer(byte[].class, o.class);
         this.addDefaultSerializer(char[].class, p.class);
         this.addDefaultSerializer(short[].class, v.class);
         this.addDefaultSerializer(int[].class, s.class);
         this.addDefaultSerializer(long[].class, t.class);
         this.addDefaultSerializer(float[].class, r.class);
         this.addDefaultSerializer(double[].class, q.class);
         this.addDefaultSerializer(boolean[].class, n.class);
         this.addDefaultSerializer(String[].class, w.class);
         this.addDefaultSerializer(Object[].class, u.class);
         this.addDefaultSerializer(g.class, r0.class);
         this.addDefaultSerializer(BigInteger.class, y.class);
         this.addDefaultSerializer(BigDecimal.class, x.class);
         this.addDefaultSerializer(Class.class, d0.class);
         this.addDefaultSerializer(Date.class, l0.class);
         this.addDefaultSerializer(Enum.class, n0.class);
         this.addDefaultSerializer(EnumSet.class, o0.class);
         this.addDefaultSerializer(Currency.class, k0.class);
         this.addDefaultSerializer(StringBuffer.class, v0.class);
         this.addDefaultSerializer(StringBuilder.class, w0.class);
         this.addDefaultSerializer(Collections.EMPTY_LIST.getClass(), e0.class);
         this.addDefaultSerializer(Collections.EMPTY_MAP.getClass(), f0.class);
         this.addDefaultSerializer(Collections.EMPTY_SET.getClass(), g0.class);
         this.addDefaultSerializer(Collections.singletonList((Object)null).getClass(), h0.class);
         this.addDefaultSerializer(Collections.singletonMap((Object)null, (Object)null).getClass(), i0.class);
         this.addDefaultSerializer(Collections.singleton((Object)null).getClass(), j0.class);
         this.addDefaultSerializer(TreeSet.class, a1.class);
         this.addDefaultSerializer(Collection.class, m.class);
         this.addDefaultSerializer(TreeMap.class, z0.class);
         this.addDefaultSerializer(Map.class, g1.class);
         this.addDefaultSerializer(TimeZone.class, y0.class);
         this.addDefaultSerializer(Calendar.class, b0.class);
         this.addDefaultSerializer(Locale.class, s0.class);
         this.c = this.b.size();
         this.register(Integer.TYPE, new q0());
         this.register(String.class, new x0());
         this.register(Float.TYPE, new p0());
         this.register(Boolean.TYPE, new z());
         this.register(Byte.TYPE, new a0());
         this.register(Character.TYPE, new c0());
         this.register(Short.TYPE, new u0());
         this.register(Long.TYPE, new t0());
         this.register(Double.TYPE, new m0());
         this.register(Void.TYPE, new b1());
      } else {
         throw new IllegalArgumentException("classResolver cannot be null.");
      }
   }

   public d(i var1) {
      this(new c.b.a.p.a(), var1, new c.b.a.p.b());
   }

   public int a(c.b.a.n.a var1, Class var2, boolean var3) {
      Class var4 = var2;
      if (var2.isPrimitive()) {
         var4 = c.b.a.p.i.c(var2);
      }

      boolean var5 = ((c.b.a.p.g)this.o).a(var4);
      int var6;
      if (var3) {
         var6 = var1.a(true);
         if (var6 == 0) {
            if (c.b.c.a.c || c.b.c.a.b && this.i == 1) {
               c.b.a.p.i.a("Read", (Object)null);
            }

            this.s = null;
            return -1;
         }

         if (!var5) {
            this.p.a(-2);
            return this.p.b;
         }
      } else {
         if (!var5) {
            this.p.a(-2);
            return this.p.b;
         }

         var6 = var1.a(true);
      }

      StringBuilder var7;
      if (var6 == 1) {
         c.b.a.p.g var8 = (c.b.a.p.g)this.o;
         var6 = var8.b.size();
         var8.b.add((Object)null);
         if (c.b.c.a.c) {
            var7 = c.a.b.a.a.b("Read initial object reference ", var6, ": ");
            var7.append(c.b.a.p.i.a(var4));
            c.b.c.a.b("kryo", var7.toString());
         }

         this.p.a(var6);
         return this.p.b;
      } else {
         var6 -= 2;
         this.s = ((c.b.a.p.g)this.o).b.get(var6);
         if (c.b.c.a.b) {
            var7 = c.a.b.a.a.b("Read object reference ", var6, ": ");
            var7.append(c.b.a.p.i.a(this.s));
            c.b.c.a.a("kryo", var7.toString());
         }

         return -1;
      }
   }

   public k a(Class var1) {
      return this.a.a(this, var1);
   }

   public final void a() {
      if (c.b.c.a.b) {
         if (this.i == 0) {
            this.l = Thread.currentThread();
         } else if (this.l != Thread.currentThread()) {
            throw new ConcurrentModificationException("Kryo must not be accessed concurrently by multiple threads.");
         }
      }

      int var1 = this.i;
      if (var1 != this.j) {
         this.i = var1 + 1;
      } else {
         StringBuilder var2 = c.a.b.a.a.b("Max depth exceeded: ");
         var2.append(this.i);
         throw new f(var2.toString());
      }
   }

   public boolean a(c.b.a.n.b var1, Object var2, boolean var3) {
      if (var2 != null) {
         i var4 = this.o;
         Class var5 = var2.getClass();
         if (!((c.b.a.p.g)var4).a(var5)) {
            if (var3) {
               var1.a(1, true);
            }

            return false;
         } else {
            int var6 = ((c.b.a.p.g)this.o).a.a(var2, -1);
            if (var6 != -1) {
               if (c.b.c.a.b) {
                  StringBuilder var9 = c.a.b.a.a.b("Write object reference ", var6, ": ");
                  var9.append(c.b.a.p.i.a(var2));
                  c.b.c.a.a("kryo", var9.toString());
               }

               var1.a(var6 + 2, true);
               return true;
            } else {
               c.b.a.p.d var8 = ((c.b.a.p.g)this.o).a;
               var6 = var8.a;
               var8.b(var2, var6);
               var1.a(1, true);
               if (c.b.c.a.c) {
                  StringBuilder var7 = c.a.b.a.a.b("Write initial object reference ", var6, ": ");
                  var7.append(c.b.a.p.i.a(var2));
                  c.b.c.a.b("kryo", var7.toString());
               }

               return false;
            }
         }
      } else {
         if (c.b.c.a.c || c.b.c.a.b && this.i == 1) {
            c.b.a.p.i.a("Write", (Object)null);
         }

         var1.a(0, true);
         return true;
      }
   }

   public void addDefaultSerializer(Class var1, k var2) {
      if (var1 != null) {
         if (var2 != null) {
            d.b var3 = new d.b(var1, new c.b.a.m.a(var2));
            ArrayList var4 = this.b;
            var4.add(var4.size() - this.c, var3);
         } else {
            throw new IllegalArgumentException("serializer cannot be null.");
         }
      } else {
         throw new IllegalArgumentException("type cannot be null.");
      }
   }

   public void addDefaultSerializer(Class var1, c.b.a.m.c var2) {
      if (var1 != null) {
         if (var2 != null) {
            d.b var4 = new d.b(var1, var2);
            ArrayList var3 = this.b;
            var3.add(var3.size() - this.c, var4);
         } else {
            throw new IllegalArgumentException("serializerFactory cannot be null.");
         }
      } else {
         throw new IllegalArgumentException("type cannot be null.");
      }
   }

   public void addDefaultSerializer(Class var1, Class var2) {
      if (var1 != null) {
         if (var2 != null) {
            d.b var4 = new d.b(var1, new c.b.a.m.b(var2));
            ArrayList var3 = this.b;
            var3.add(var3.size() - this.c, var4);
         } else {
            throw new IllegalArgumentException("serializerClass cannot be null.");
         }
      } else {
         throw new IllegalArgumentException("type cannot be null.");
      }
   }

   public d.a.a.a b(Class var1) {
      return ((d.a)this.g).a(var1);
   }

   public Object copy(Object var1) {
      if (var1 == null) {
         return null;
      } else if (this.u) {
         return var1;
      } else {
         ++this.t;

         int var3;
         Throwable var10000;
         label900: {
            boolean var10001;
            try {
               if (this.v == null) {
                  c.b.a.p.c var2 = new c.b.a.p.c();
                  this.v = var2;
               }
            } catch (Throwable var75) {
               var10000 = var75;
               var10001 = false;
               break label900;
            }

            Object var77;
            try {
               var77 = this.v.a(var1);
            } catch (Throwable var74) {
               var10000 = var74;
               var10001 = false;
               break label900;
            }

            if (var77 != null) {
               var3 = this.t - 1;
               this.t = var3;
               if (var3 == 0) {
                  this.reset();
               }

               return var77;
            }

            try {
               if (this.r) {
                  this.w = var1;
               }
            } catch (Throwable var73) {
               var10000 = var73;
               var10001 = false;
               break label900;
            }

            label878: {
               try {
                  if (var1 instanceof e) {
                     var1 = ((e)var1).a(this);
                     break label878;
                  }
               } catch (Throwable var72) {
                  var10000 = var72;
                  var10001 = false;
                  break label900;
               }

               try {
                  var1 = this.getSerializer(var1.getClass()).copy(this, var1);
               } catch (Throwable var71) {
                  var10000 = var71;
                  var10001 = false;
                  break label900;
               }
            }

            try {
               if (this.w != null) {
                  this.reference(var1);
               }
            } catch (Throwable var70) {
               var10000 = var70;
               var10001 = false;
               break label900;
            }

            label865: {
               try {
                  if (!c.b.c.a.c && (!c.b.c.a.b || this.t != 1)) {
                     break label865;
                  }
               } catch (Throwable var69) {
                  var10000 = var69;
                  var10001 = false;
                  break label900;
               }

               try {
                  c.b.a.p.i.a("Copy", var1);
               } catch (Throwable var68) {
                  var10000 = var68;
                  var10001 = false;
                  break label900;
               }
            }

            var3 = this.t - 1;
            this.t = var3;
            if (var3 == 0) {
               this.reset();
            }

            return var1;
         }

         Throwable var76 = var10000;
         var3 = this.t - 1;
         this.t = var3;
         if (var3 == 0) {
            this.reset();
         }

         throw var76;
      }
   }

   public Object copy(Object var1, k var2) {
      if (var1 == null) {
         return null;
      } else if (this.u) {
         return var1;
      } else {
         ++this.t;

         int var4;
         Throwable var10000;
         label900: {
            boolean var10001;
            try {
               if (this.v == null) {
                  c.b.a.p.c var3 = new c.b.a.p.c();
                  this.v = var3;
               }
            } catch (Throwable var76) {
               var10000 = var76;
               var10001 = false;
               break label900;
            }

            Object var78;
            try {
               var78 = this.v.a(var1);
            } catch (Throwable var75) {
               var10000 = var75;
               var10001 = false;
               break label900;
            }

            if (var78 != null) {
               var4 = this.t - 1;
               this.t = var4;
               if (var4 == 0) {
                  this.reset();
               }

               return var78;
            }

            try {
               if (this.r) {
                  this.w = var1;
               }
            } catch (Throwable var74) {
               var10000 = var74;
               var10001 = false;
               break label900;
            }

            label878: {
               try {
                  if (var1 instanceof e) {
                     var1 = ((e)var1).a(this);
                     break label878;
                  }
               } catch (Throwable var73) {
                  var10000 = var73;
                  var10001 = false;
                  break label900;
               }

               try {
                  var1 = var2.copy(this, var1);
               } catch (Throwable var72) {
                  var10000 = var72;
                  var10001 = false;
                  break label900;
               }
            }

            try {
               if (this.w != null) {
                  this.reference(var1);
               }
            } catch (Throwable var71) {
               var10000 = var71;
               var10001 = false;
               break label900;
            }

            label865: {
               try {
                  if (!c.b.c.a.c && (!c.b.c.a.b || this.t != 1)) {
                     break label865;
                  }
               } catch (Throwable var70) {
                  var10000 = var70;
                  var10001 = false;
                  break label900;
               }

               try {
                  c.b.a.p.i.a("Copy", var1);
               } catch (Throwable var69) {
                  var10000 = var69;
                  var10001 = false;
                  break label900;
               }
            }

            var4 = this.t - 1;
            this.t = var4;
            if (var4 == 0) {
               this.reset();
            }

            return var1;
         }

         Throwable var77 = var10000;
         var4 = this.t - 1;
         this.t = var4;
         if (var4 == 0) {
            this.reset();
         }

         throw var77;
      }
   }

   public Object copyShallow(Object var1) {
      if (var1 == null) {
         return null;
      } else {
         ++this.t;
         this.u = true;

         int var3;
         Throwable var10000;
         label854: {
            boolean var10001;
            try {
               if (this.v == null) {
                  c.b.a.p.c var2 = new c.b.a.p.c();
                  this.v = var2;
               }
            } catch (Throwable var75) {
               var10000 = var75;
               var10001 = false;
               break label854;
            }

            Object var77;
            try {
               var77 = this.v.a(var1);
            } catch (Throwable var74) {
               var10000 = var74;
               var10001 = false;
               break label854;
            }

            if (var77 != null) {
               this.u = false;
               var3 = this.t - 1;
               this.t = var3;
               if (var3 == 0) {
                  this.reset();
               }

               return var77;
            }

            try {
               if (this.r) {
                  this.w = var1;
               }
            } catch (Throwable var73) {
               var10000 = var73;
               var10001 = false;
               break label854;
            }

            label858: {
               try {
                  if (var1 instanceof e) {
                     var1 = ((e)var1).a(this);
                     break label858;
                  }
               } catch (Throwable var72) {
                  var10000 = var72;
                  var10001 = false;
                  break label854;
               }

               try {
                  var1 = this.getSerializer(var1.getClass()).copy(this, var1);
               } catch (Throwable var71) {
                  var10000 = var71;
                  var10001 = false;
                  break label854;
               }
            }

            try {
               if (this.w != null) {
                  this.reference(var1);
               }
            } catch (Throwable var70) {
               var10000 = var70;
               var10001 = false;
               break label854;
            }

            label823: {
               try {
                  if (!c.b.c.a.c && (!c.b.c.a.b || this.t != 1)) {
                     break label823;
                  }
               } catch (Throwable var69) {
                  var10000 = var69;
                  var10001 = false;
                  break label854;
               }

               try {
                  c.b.a.p.i.a("Shallow copy", var1);
               } catch (Throwable var68) {
                  var10000 = var68;
                  var10001 = false;
                  break label854;
               }
            }

            this.u = false;
            var3 = this.t - 1;
            this.t = var3;
            if (var3 == 0) {
               this.reset();
            }

            return var1;
         }

         Throwable var76 = var10000;
         this.u = false;
         var3 = this.t - 1;
         this.t = var3;
         if (var3 == 0) {
            this.reset();
         }

         throw var76;
      }
   }

   public Object copyShallow(Object var1, k var2) {
      if (var1 == null) {
         return null;
      } else {
         ++this.t;
         this.u = true;

         int var4;
         Throwable var10000;
         label855: {
            boolean var10001;
            try {
               if (this.v == null) {
                  c.b.a.p.c var3 = new c.b.a.p.c();
                  this.v = var3;
               }
            } catch (Throwable var76) {
               var10000 = var76;
               var10001 = false;
               break label855;
            }

            Object var78;
            try {
               var78 = this.v.a(var1);
            } catch (Throwable var75) {
               var10000 = var75;
               var10001 = false;
               break label855;
            }

            if (var78 != null) {
               this.u = false;
               var4 = this.t - 1;
               this.t = var4;
               if (var4 == 0) {
                  this.reset();
               }

               return var78;
            }

            try {
               if (this.r) {
                  this.w = var1;
               }
            } catch (Throwable var74) {
               var10000 = var74;
               var10001 = false;
               break label855;
            }

            label859: {
               try {
                  if (var1 instanceof e) {
                     var1 = ((e)var1).a(this);
                     break label859;
                  }
               } catch (Throwable var73) {
                  var10000 = var73;
                  var10001 = false;
                  break label855;
               }

               try {
                  var1 = var2.copy(this, var1);
               } catch (Throwable var72) {
                  var10000 = var72;
                  var10001 = false;
                  break label855;
               }
            }

            try {
               if (this.w != null) {
                  this.reference(var1);
               }
            } catch (Throwable var71) {
               var10000 = var71;
               var10001 = false;
               break label855;
            }

            label824: {
               try {
                  if (!c.b.c.a.c && (!c.b.c.a.b || this.t != 1)) {
                     break label824;
                  }
               } catch (Throwable var70) {
                  var10000 = var70;
                  var10001 = false;
                  break label855;
               }

               try {
                  c.b.a.p.i.a("Shallow copy", var1);
               } catch (Throwable var69) {
                  var10000 = var69;
                  var10001 = false;
                  break label855;
               }
            }

            this.u = false;
            var4 = this.t - 1;
            this.t = var4;
            if (var4 == 0) {
               this.reset();
            }

            return var1;
         }

         Throwable var77 = var10000;
         this.u = false;
         var4 = this.t - 1;
         this.t = var4;
         if (var4 == 0) {
            this.reset();
         }

         throw var77;
      }
   }

   public boolean getAsmEnabled() {
      return this.y;
   }

   public ClassLoader getClassLoader() {
      return this.f;
   }

   public c.b.a.a getClassResolver() {
      return this.d;
   }

   public c.b.a.p.h getContext() {
      if (this.m == null) {
         this.m = new c.b.a.p.h();
      }

      return this.m;
   }

   public k getDefaultSerializer(Class var1) {
      if (var1 != null) {
         if (var1.isAnnotationPresent(c.b.a.b.class)) {
            return c.b.a.m.b.a(this, ((c.b.a.b)var1.getAnnotation(c.b.a.b.class)).value(), var1);
         } else {
            int var2 = 0;

            for(int var3 = this.b.size(); var2 < var3; ++var2) {
               d.b var4 = (d.b)this.b.get(var2);
               if (var4.a.isAssignableFrom(var1)) {
                  return var4.b.a(this, var1);
               }
            }

            return this.a(var1);
         }
      } else {
         IllegalArgumentException var5 = new IllegalArgumentException("type cannot be null.");
         throw var5;
      }
   }

   public int getDepth() {
      return this.i;
   }

   public c getGenericsScope() {
      return this.x;
   }

   public c.b.a.p.h getGraphContext() {
      if (this.n == null) {
         this.n = new c.b.a.p.h();
      }

      return this.n;
   }

   public d.a.b.a getInstantiatorStrategy() {
      return this.g;
   }

   public int getNextRegistrationId() {
      while(true) {
         int var1 = this.e;
         if (var1 == -2) {
            f var2 = new f("No registration IDs are available.");
            throw var2;
         }

         if ((j)((c.b.a.p.a)this.d).b.a(var1) == null) {
            return this.e;
         }

         ++this.e;
      }
   }

   public c.b.a.p.c getOriginalToCopyMap() {
      return this.v;
   }

   public i getReferenceResolver() {
      return this.o;
   }

   public boolean getReferences() {
      return this.q;
   }

   public j getRegistration(int var1) {
      return (j)((c.b.a.p.a)this.d).b.a(var1);
   }

   public j getRegistration(Class var1) {
      if (var1 == null) {
         throw new IllegalArgumentException("type cannot be null.");
      } else {
         j var2 = ((c.b.a.p.a)this.d).a(var1);
         j var3 = var2;
         if (var2 == null) {
            if (Proxy.isProxyClass(var1)) {
               var2 = this.getRegistration(InvocationHandler.class);
            } else if (!var1.isEnum() && Enum.class.isAssignableFrom(var1)) {
               var2 = this.getRegistration(var1.getEnclosingClass());
            } else if (EnumSet.class.isAssignableFrom(var1)) {
               var2 = ((c.b.a.p.a)this.d).a(EnumSet.class);
            }

            var3 = var2;
            if (var2 == null) {
               if (this.h) {
                  StringBuilder var5 = c.a.b.a.a.b("Class is not registered: ");
                  var5.append(c.b.a.p.i.a(var1));
                  var5.append("\nNote: To register this class use: kryo.register(");
                  var5.append(c.b.a.p.i.a(var1));
                  var5.append(".class);");
                  throw new IllegalArgumentException(var5.toString());
               }

               c.b.a.p.a var4 = (c.b.a.p.a)this.d;
               var3 = new j(var1, var4.a.getDefaultSerializer(var1), -1);
               var4.a(var3);
            }
         }

         return var3;
      }
   }

   public k getSerializer(Class var1) {
      return this.getRegistration(var1).c;
   }

   public l getStreamFactory() {
      return this.z;
   }

   public boolean isFinal(Class var1) {
      if (var1 != null) {
         return var1.isArray() ? Modifier.isFinal(c.b.a.p.i.b(var1).getModifiers()) : Modifier.isFinal(var1.getModifiers());
      } else {
         throw new IllegalArgumentException("type cannot be null.");
      }
   }

   public boolean isRegistrationRequired() {
      return this.h;
   }

   public Object newInstance(Class var1) {
      j var2 = this.getRegistration(var1);
      d.a.a.a var3 = var2.d;
      d.a.a.a var4 = var3;
      if (var3 == null) {
         var4 = this.b(var1);
         if (var4 == null) {
            throw new IllegalArgumentException("instantiator cannot be null.");
         }

         var2.d = var4;
      }

      return var4.a();
   }

   public void popGenericsScope() {
      c var1 = this.x;
      if (var1 != null) {
         this.x = var1.b;
      }

      if (var1 != null) {
         var1.b = null;
      }

   }

   public void pushGenericsScope(Class var1, c var2) {
      if (c.b.c.a.c) {
         StringBuilder var3 = c.a.b.a.a.b("Settting a new generics scope for class ");
         var3.append(var1.getName());
         var3.append(": ");
         var3.append(var2);
         c.b.c.a.b("kryo", var3.toString());
      }

      c var5 = this.x;
      c var4 = var2;
      if (var2.b != null) {
         var4 = new c(var2.a);
      }

      this.x = var4;
      var4 = this.x;
      if (var4.b == null) {
         var4.b = var5;
      } else {
         throw new IllegalStateException("Parent scope can be set just once");
      }
   }

   public j readClass(c.b.a.n.a var1) {
      if (var1 != null) {
         j var10;
         label116: {
            Throwable var10000;
            label117: {
               boolean var10001;
               c.b.a.a var2;
               try {
                  var2 = this.d;
               } catch (Throwable var8) {
                  var10000 = var8;
                  var10001 = false;
                  break label117;
               }

               c.b.a.p.a var11 = (c.b.a.p.a)var2;

               label106:
               try {
                  var10 = var11.a(var1);
                  break label116;
               } catch (Throwable var7) {
                  var10000 = var7;
                  var10001 = false;
                  break label106;
               }
            }

            Throwable var9 = var10000;
            if (this.i == 0 && this.k) {
               this.reset();
            }

            throw var9;
         }

         if (this.i == 0 && this.k) {
            this.reset();
         }

         return var10;
      } else {
         throw new IllegalArgumentException("input cannot be null.");
      }
   }

   public Object readClassAndObject(c.b.a.n.a var1) {
      if (var1 != null) {
         this.a();

         int var3;
         Throwable var10000;
         label985: {
            j var2;
            boolean var10001;
            try {
               var2 = this.readClass(var1);
            } catch (Throwable var76) {
               var10000 = var76;
               var10001 = false;
               break label985;
            }

            if (var2 == null) {
               var3 = this.i - 1;
               this.i = var3;
               if (var3 == 0 && this.k) {
                  this.reset();
               }

               return null;
            }

            Object var77;
            label986: {
               Class var4;
               label973: {
                  try {
                     var4 = var2.a;
                     if (this.q) {
                        var2.c.setGenerics(this, (Class[])null);
                        var3 = this.a(var1, var4, false);
                        break label973;
                     }
                  } catch (Throwable var75) {
                     var10000 = var75;
                     var10001 = false;
                     break label985;
                  }

                  try {
                     var77 = var2.c.read(this, var1, var4);
                     break label986;
                  } catch (Throwable var72) {
                     var10000 = var72;
                     var10001 = false;
                     break label985;
                  }
               }

               if (var3 == -1) {
                  try {
                     var77 = this.s;
                  } catch (Throwable var69) {
                     var10000 = var69;
                     var10001 = false;
                     break label985;
                  }

                  var3 = this.i - 1;
                  this.i = var3;
                  if (var3 == 0 && this.k) {
                     this.reset();
                  }

                  return var77;
               }

               Object var78;
               try {
                  var78 = var2.c.read(this, var1, var4);
               } catch (Throwable var73) {
                  var10000 = var73;
                  var10001 = false;
                  break label985;
               }

               var77 = var78;

               try {
                  if (var3 != this.p.b) {
                     break label986;
                  }

                  this.reference(var78);
               } catch (Throwable var74) {
                  var10000 = var74;
                  var10001 = false;
                  break label985;
               }

               var77 = var78;
            }

            label953: {
               try {
                  if (!c.b.c.a.c && (!c.b.c.a.b || this.i != 1)) {
                     break label953;
                  }
               } catch (Throwable var71) {
                  var10000 = var71;
                  var10001 = false;
                  break label985;
               }

               try {
                  c.b.a.p.i.a("Read", var77);
               } catch (Throwable var70) {
                  var10000 = var70;
                  var10001 = false;
                  break label985;
               }
            }

            var3 = this.i - 1;
            this.i = var3;
            if (var3 == 0 && this.k) {
               this.reset();
            }

            return var77;
         }

         Throwable var79 = var10000;
         var3 = this.i - 1;
         this.i = var3;
         if (var3 == 0 && this.k) {
            this.reset();
         }

         throw var79;
      } else {
         throw new IllegalArgumentException("input cannot be null.");
      }
   }

   public Object readObject(c.b.a.n.a var1, Class var2) {
      if (var1 == null) {
         throw new IllegalArgumentException("input cannot be null.");
      } else if (var2 != null) {
         this.a();

         int var3;
         Throwable var10000;
         label794: {
            boolean var10001;
            Object var60;
            label795: {
               label784: {
                  try {
                     if (this.q) {
                        var3 = this.a(var1, var2, false);
                        break label784;
                     }
                  } catch (Throwable var59) {
                     var10000 = var59;
                     var10001 = false;
                     break label794;
                  }

                  try {
                     var60 = this.getRegistration(var2).c.read(this, var1, var2);
                     break label795;
                  } catch (Throwable var56) {
                     var10000 = var56;
                     var10001 = false;
                     break label794;
                  }
               }

               if (var3 == -1) {
                  try {
                     var60 = this.s;
                  } catch (Throwable var53) {
                     var10000 = var53;
                     var10001 = false;
                     break label794;
                  }

                  var3 = this.i - 1;
                  this.i = var3;
                  if (var3 == 0 && this.k) {
                     this.reset();
                  }

                  return var60;
               }

               Object var61;
               try {
                  var61 = this.getRegistration(var2).c.read(this, var1, var2);
               } catch (Throwable var57) {
                  var10000 = var57;
                  var10001 = false;
                  break label794;
               }

               var60 = var61;

               try {
                  if (var3 != this.p.b) {
                     break label795;
                  }

                  this.reference(var61);
               } catch (Throwable var58) {
                  var10000 = var58;
                  var10001 = false;
                  break label794;
               }

               var60 = var61;
            }

            label764: {
               try {
                  if (!c.b.c.a.c && (!c.b.c.a.b || this.i != 1)) {
                     break label764;
                  }
               } catch (Throwable var55) {
                  var10000 = var55;
                  var10001 = false;
                  break label794;
               }

               try {
                  c.b.a.p.i.a("Read", var60);
               } catch (Throwable var54) {
                  var10000 = var54;
                  var10001 = false;
                  break label794;
               }
            }

            var3 = this.i - 1;
            this.i = var3;
            if (var3 == 0 && this.k) {
               this.reset();
            }

            return var60;
         }

         Throwable var62 = var10000;
         var3 = this.i - 1;
         this.i = var3;
         if (var3 == 0 && this.k) {
            this.reset();
         }

         throw var62;
      } else {
         throw new IllegalArgumentException("type cannot be null.");
      }
   }

   public Object readObject(c.b.a.n.a var1, Class var2, k var3) {
      if (var1 != null) {
         if (var2 == null) {
            throw new IllegalArgumentException("type cannot be null.");
         } else if (var3 != null) {
            this.a();

            int var4;
            Throwable var10000;
            label827: {
               boolean var10001;
               Object var61;
               label828: {
                  label815: {
                     try {
                        if (this.q) {
                           var4 = this.a(var1, var2, false);
                           break label815;
                        }
                     } catch (Throwable var60) {
                        var10000 = var60;
                        var10001 = false;
                        break label827;
                     }

                     try {
                        var61 = var3.read(this, var1, var2);
                        break label828;
                     } catch (Throwable var57) {
                        var10000 = var57;
                        var10001 = false;
                        break label827;
                     }
                  }

                  if (var4 == -1) {
                     try {
                        var61 = this.s;
                     } catch (Throwable var54) {
                        var10000 = var54;
                        var10001 = false;
                        break label827;
                     }

                     var4 = this.i - 1;
                     this.i = var4;
                     if (var4 == 0 && this.k) {
                        this.reset();
                     }

                     return var61;
                  }

                  Object var62;
                  try {
                     var62 = var3.read(this, var1, var2);
                  } catch (Throwable var58) {
                     var10000 = var58;
                     var10001 = false;
                     break label827;
                  }

                  var61 = var62;

                  try {
                     if (var4 != this.p.b) {
                        break label828;
                     }

                     this.reference(var62);
                  } catch (Throwable var59) {
                     var10000 = var59;
                     var10001 = false;
                     break label827;
                  }

                  var61 = var62;
               }

               label795: {
                  try {
                     if (!c.b.c.a.c && (!c.b.c.a.b || this.i != 1)) {
                        break label795;
                     }
                  } catch (Throwable var56) {
                     var10000 = var56;
                     var10001 = false;
                     break label827;
                  }

                  try {
                     c.b.a.p.i.a("Read", var61);
                  } catch (Throwable var55) {
                     var10000 = var55;
                     var10001 = false;
                     break label827;
                  }
               }

               var4 = this.i - 1;
               this.i = var4;
               if (var4 == 0 && this.k) {
                  this.reset();
               }

               return var61;
            }

            Throwable var63 = var10000;
            var4 = this.i - 1;
            this.i = var4;
            if (var4 == 0 && this.k) {
               this.reset();
            }

            throw var63;
         } else {
            throw new IllegalArgumentException("serializer cannot be null.");
         }
      } else {
         throw new IllegalArgumentException("input cannot be null.");
      }
   }

   public Object readObjectOrNull(c.b.a.n.a var1, Class var2) {
      if (var1 == null) {
         throw new IllegalArgumentException("input cannot be null.");
      } else if (var2 != null) {
         this.a();

         int var4;
         label1513: {
            Throwable var10000;
            label1524: {
               boolean var3;
               boolean var10001;
               try {
                  var3 = this.q;
               } catch (Throwable var115) {
                  var10000 = var115;
                  var10001 = false;
                  break label1524;
               }

               Object var116;
               if (var3) {
                  label1516: {
                     try {
                        var4 = this.a(var1, var2, true);
                     } catch (Throwable var112) {
                        var10000 = var112;
                        var10001 = false;
                        break label1524;
                     }

                     if (var4 == -1) {
                        try {
                           var116 = this.s;
                        } catch (Throwable var106) {
                           var10000 = var106;
                           var10001 = false;
                           break label1524;
                        }

                        var4 = this.i - 1;
                        this.i = var4;
                        if (var4 == 0 && this.k) {
                           this.reset();
                        }

                        return var116;
                     }

                     Object var117;
                     try {
                        var117 = this.getRegistration(var2).c.read(this, var1, var2);
                     } catch (Throwable var111) {
                        var10000 = var111;
                        var10001 = false;
                        break label1524;
                     }

                     var116 = var117;

                     try {
                        if (var4 != this.p.b) {
                           break label1516;
                        }

                        this.reference(var117);
                     } catch (Throwable var113) {
                        var10000 = var113;
                        var10001 = false;
                        break label1524;
                     }

                     var116 = var117;
                  }
               } else {
                  k var5;
                  label1498: {
                     try {
                        var5 = this.getRegistration(var2).c;
                        if (var5.getAcceptsNull() || var1.c() != 0) {
                           break label1498;
                        }

                        if (!c.b.c.a.c && (!c.b.c.a.b || this.i != 1)) {
                           break label1513;
                        }
                     } catch (Throwable var114) {
                        var10000 = var114;
                        var10001 = false;
                        break label1524;
                     }

                     try {
                        c.b.a.p.i.a("Read", (Object)null);
                        break label1513;
                     } catch (Throwable var109) {
                        var10000 = var109;
                        var10001 = false;
                        break label1524;
                     }
                  }

                  try {
                     var116 = var5.read(this, var1, var2);
                  } catch (Throwable var110) {
                     var10000 = var110;
                     var10001 = false;
                     break label1524;
                  }
               }

               label1464: {
                  try {
                     if (!c.b.c.a.c && (!c.b.c.a.b || this.i != 1)) {
                        break label1464;
                     }
                  } catch (Throwable var108) {
                     var10000 = var108;
                     var10001 = false;
                     break label1524;
                  }

                  try {
                     c.b.a.p.i.a("Read", var116);
                  } catch (Throwable var107) {
                     var10000 = var107;
                     var10001 = false;
                     break label1524;
                  }
               }

               var4 = this.i - 1;
               this.i = var4;
               if (var4 == 0 && this.k) {
                  this.reset();
               }

               return var116;
            }

            Throwable var118 = var10000;
            var4 = this.i - 1;
            this.i = var4;
            if (var4 == 0 && this.k) {
               this.reset();
            }

            throw var118;
         }

         var4 = this.i - 1;
         this.i = var4;
         if (var4 == 0 && this.k) {
            this.reset();
         }

         return null;
      } else {
         throw new IllegalArgumentException("type cannot be null.");
      }
   }

   public Object readObjectOrNull(c.b.a.n.a var1, Class var2, k var3) {
      if (var1 != null) {
         if (var2 == null) {
            throw new IllegalArgumentException("type cannot be null.");
         } else if (var3 != null) {
            this.a();

            int var5;
            label1558: {
               Throwable var10000;
               label1569: {
                  boolean var4;
                  boolean var10001;
                  try {
                     var4 = this.q;
                  } catch (Throwable var115) {
                     var10000 = var115;
                     var10001 = false;
                     break label1569;
                  }

                  Object var116;
                  if (var4) {
                     label1561: {
                        try {
                           var5 = this.a(var1, var2, true);
                        } catch (Throwable var112) {
                           var10000 = var112;
                           var10001 = false;
                           break label1569;
                        }

                        if (var5 == -1) {
                           try {
                              var116 = this.s;
                           } catch (Throwable var106) {
                              var10000 = var106;
                              var10001 = false;
                              break label1569;
                           }

                           var5 = this.i - 1;
                           this.i = var5;
                           if (var5 == 0 && this.k) {
                              this.reset();
                           }

                           return var116;
                        }

                        Object var117;
                        try {
                           var117 = var3.read(this, var1, var2);
                        } catch (Throwable var111) {
                           var10000 = var111;
                           var10001 = false;
                           break label1569;
                        }

                        var116 = var117;

                        try {
                           if (var5 != this.p.b) {
                              break label1561;
                           }

                           this.reference(var117);
                        } catch (Throwable var113) {
                           var10000 = var113;
                           var10001 = false;
                           break label1569;
                        }

                        var116 = var117;
                     }
                  } else {
                     label1565: {
                        label1541: {
                           try {
                              if (!var3.getAcceptsNull() && var1.c() == 0) {
                                 if (!c.b.c.a.c && (!c.b.c.a.b || this.i != 1)) {
                                    break label1558;
                                 }
                                 break label1541;
                              }
                           } catch (Throwable var114) {
                              var10000 = var114;
                              var10001 = false;
                              break label1569;
                           }

                           try {
                              var116 = var3.read(this, var1, var2);
                              break label1565;
                           } catch (Throwable var110) {
                              var10000 = var110;
                              var10001 = false;
                              break label1569;
                           }
                        }

                        try {
                           c.b.a.p.i.a("Read", (Object)null);
                           break label1558;
                        } catch (Throwable var109) {
                           var10000 = var109;
                           var10001 = false;
                           break label1569;
                        }
                     }
                  }

                  label1507: {
                     try {
                        if (!c.b.c.a.c && (!c.b.c.a.b || this.i != 1)) {
                           break label1507;
                        }
                     } catch (Throwable var108) {
                        var10000 = var108;
                        var10001 = false;
                        break label1569;
                     }

                     try {
                        c.b.a.p.i.a("Read", var116);
                     } catch (Throwable var107) {
                        var10000 = var107;
                        var10001 = false;
                        break label1569;
                     }
                  }

                  var5 = this.i - 1;
                  this.i = var5;
                  if (var5 == 0 && this.k) {
                     this.reset();
                  }

                  return var116;
               }

               Throwable var118 = var10000;
               var5 = this.i - 1;
               this.i = var5;
               if (var5 == 0 && this.k) {
                  this.reset();
               }

               throw var118;
            }

            var5 = this.i - 1;
            this.i = var5;
            if (var5 == 0 && this.k) {
               this.reset();
            }

            return null;
         } else {
            throw new IllegalArgumentException("serializer cannot be null.");
         }
      } else {
         throw new IllegalArgumentException("input cannot be null.");
      }
   }

   public void reference(Object var1) {
      if (this.t > 0) {
         Object var2 = this.w;
         if (var2 != null) {
            if (var1 == null) {
               throw new IllegalArgumentException("object cannot be null.");
            }

            this.v.a(var2, var1);
            this.w = null;
         }
      } else if (this.q && var1 != null) {
         c.b.a.p.e var5 = this.p;
         int[] var3 = var5.a;
         int var4 = var5.b - 1;
         var5.b = var4;
         var4 = var3[var4];
         if (var4 != -2) {
            ((c.b.a.p.g)this.o).b.set(var4, var1);
         }
      }

   }

   public j register(j var1) {
      int var2 = var1.b;
      if (var2 >= 0) {
         j var3 = this.getRegistration(var2);
         if (c.b.c.a.b && var3 != null && var3.a != var1.a) {
            StringBuilder var4 = c.a.b.a.a.b("An existing registration with a different type already uses ID: ");
            var4.append(var1.b);
            var4.append("\nExisting registration: ");
            var4.append(var3);
            var4.append("\nUnable to set registration: ");
            var4.append(var1);
            String var5 = var4.toString();
            if (c.b.c.a.b) {
               c.b.c.a.d.a(2, (String)null, var5, (Throwable)null);
            }
         }

         ((c.b.a.p.a)this.d).a(var1);
         return var1;
      } else {
         throw new IllegalArgumentException(c.a.b.a.a.a("id must be > 0: ", var2));
      }
   }

   public j register(Class var1) {
      j var2 = ((c.b.a.p.a)this.d).a(var1);
      return var2 != null ? var2 : this.register(var1, this.getDefaultSerializer(var1));
   }

   public j register(Class var1, int var2) {
      j var3 = ((c.b.a.p.a)this.d).a(var1);
      return var3 != null ? var3 : this.register(var1, this.getDefaultSerializer(var1), var2);
   }

   public j register(Class var1, k var2) {
      j var3 = ((c.b.a.p.a)this.d).a(var1);
      if (var3 != null) {
         if (var2 != null) {
            var3.c = var2;
            if (c.b.c.a.c) {
               StringBuilder var5 = c.a.b.a.a.b("Update registered serializer: ");
               var5.append(var3.a.getName());
               var5.append(" (");
               var5.append(var2.getClass().getName());
               var5.append(")");
               c.b.c.a.b("kryo", var5.toString());
            }

            return var3;
         } else {
            throw new IllegalArgumentException("serializer cannot be null.");
         }
      } else {
         c.b.a.a var6 = this.d;
         j var4 = new j(var1, var2, this.getNextRegistrationId());
         ((c.b.a.p.a)var6).a(var4);
         return var4;
      }
   }

   public j register(Class var1, k var2, int var3) {
      if (var3 >= 0) {
         return this.register(new j(var1, var2, var3));
      } else {
         throw new IllegalArgumentException(c.a.b.a.a.a("id must be >= 0: ", var3));
      }
   }

   public void reset() {
      this.i = 0;
      c.b.a.p.h var1 = this.n;
      Object[] var2;
      Object[] var3;
      int var4;
      int var5;
      if (var1 != null) {
         var2 = var1.b;
         var3 = var1.c;
         var4 = var1.d + var1.e;

         while(true) {
            var5 = var4 - 1;
            if (var4 <= 0) {
               var1.a = 0;
               var1.e = 0;
               break;
            }

            var2[var5] = null;
            var3[var5] = null;
            var4 = var5;
         }
      }

      c.b.a.p.a var7 = (c.b.a.p.a)this.d;
      if (!var7.a.isRegistrationRequired()) {
         c.b.a.p.d var10 = var7.d;
         if (var10 != null) {
            var10.a();
         }

         c.b.a.p.f var12 = var7.e;
         if (var12 != null) {
            int[] var6 = var12.b;
            var2 = var12.c;
            var4 = var12.d + var12.e;

            while(true) {
               var5 = var4 - 1;
               if (var4 <= 0) {
                  var12.a = 0;
                  var12.e = 0;
                  var12.f = null;
                  var12.g = false;
                  break;
               }

               var6[var5] = 0;
               var2[var5] = null;
               var4 = var5;
            }
         }

         var7.g = 0;
      }

      if (this.q) {
         c.b.a.p.g var8 = (c.b.a.p.g)this.o;
         var8.b.clear();
         var8.a.a();
         this.s = null;
      }

      this.t = 0;
      c.b.a.p.c var11 = this.v;
      if (var11 != null) {
         var4 = var11.d;
         if (var4 <= 2048) {
            Object[] var9 = var11.b;
            var3 = var11.c;
            var4 += var11.e;

            while(true) {
               var5 = var4 - 1;
               if (var4 <= 0) {
                  var11.a = 0;
                  var11.e = 0;
                  break;
               }

               var9[var5] = null;
               var3[var5] = null;
               var4 = var5;
            }
         } else {
            var11.a = 0;
            var11.c(2048);
         }
      }

      if (c.b.c.a.c) {
         c.b.c.a.b("kryo", "Object graph complete.");
      }

   }

   public void setAsmEnabled(boolean var1) {
      this.y = var1;
   }

   public void setAutoReset(boolean var1) {
      this.k = var1;
   }

   public void setClassLoader(ClassLoader var1) {
      if (var1 != null) {
         this.f = var1;
      } else {
         throw new IllegalArgumentException("classLoader cannot be null.");
      }
   }

   public void setCopyReferences(boolean var1) {
      this.r = var1;
   }

   public void setDefaultSerializer(c.b.a.m.c var1) {
      if (var1 != null) {
         this.a = var1;
      } else {
         throw new IllegalArgumentException("serializer cannot be null.");
      }
   }

   public void setDefaultSerializer(Class var1) {
      if (var1 != null) {
         this.a = new c.b.a.m.b(var1);
      } else {
         throw new IllegalArgumentException("serializer cannot be null.");
      }
   }

   public void setInstantiatorStrategy(d.a.b.a var1) {
      this.g = var1;
   }

   public void setMaxDepth(int var1) {
      if (var1 > 0) {
         this.j = var1;
      } else {
         throw new IllegalArgumentException("maxDepth must be > 0.");
      }
   }

   public void setReferenceResolver(i var1) {
      if (var1 != null) {
         this.q = true;
         this.o = var1;
         if (c.b.c.a.c) {
            StringBuilder var2 = c.a.b.a.a.b("Reference resolver: ");
            var2.append(var1.getClass().getName());
            c.b.c.a.b("kryo", var2.toString());
         }

      } else {
         throw new IllegalArgumentException("referenceResolver cannot be null.");
      }
   }

   public boolean setReferences(boolean var1) {
      if (var1 == this.q) {
         return var1;
      } else {
         this.q = var1;
         if (var1 && this.o == null) {
            this.o = new c.b.a.p.g();
         }

         if (c.b.c.a.c) {
            StringBuilder var2 = new StringBuilder();
            var2.append("References: ");
            var2.append(var1);
            c.b.c.a.b("kryo", var2.toString());
         }

         return var1 ^ true;
      }
   }

   public void setRegistrationRequired(boolean var1) {
      this.h = var1;
      if (c.b.c.a.c) {
         StringBuilder var2 = new StringBuilder();
         var2.append("Registration required: ");
         var2.append(var1);
         c.b.c.a.b("kryo", var2.toString());
      }

   }

   public void setStreamFactory(l var1) {
      this.z = var1;
   }

   public j writeClass(c.b.a.n.b var1, Class var2) {
      if (var1 != null) {
         j var11;
         label116: {
            Throwable var10000;
            label117: {
               boolean var10001;
               c.b.a.a var3;
               try {
                  var3 = this.d;
               } catch (Throwable var9) {
                  var10000 = var9;
                  var10001 = false;
                  break label117;
               }

               c.b.a.p.a var12 = (c.b.a.p.a)var3;

               label106:
               try {
                  var11 = var12.a(var1, var2);
                  break label116;
               } catch (Throwable var8) {
                  var10000 = var8;
                  var10001 = false;
                  break label106;
               }
            }

            Throwable var10 = var10000;
            if (this.i == 0 && this.k) {
               this.reset();
            }

            throw var10;
         }

         if (this.i == 0 && this.k) {
            this.reset();
         }

         return var11;
      } else {
         throw new IllegalArgumentException("output cannot be null.");
      }
   }

   public void writeClassAndObject(c.b.a.n.b var1, Object var2) {
      if (var1 == null) {
         throw new IllegalArgumentException("output cannot be null.");
      } else {
         this.a();
         int var3;
         Throwable var10000;
         boolean var10001;
         if (var2 == null) {
            label528: {
               try {
                  this.writeClass(var1, (Class)null);
               } catch (Throwable var30) {
                  var10000 = var30;
                  var10001 = false;
                  break label528;
               }

               var3 = this.i - 1;
               this.i = var3;
               if (var3 == 0 && this.k) {
                  this.reset();
               }

               return;
            }
         } else {
            label532: {
               label529: {
                  j var4;
                  try {
                     var4 = this.writeClass(var1, var2.getClass());
                     if (this.q && this.a(var1, var2, false)) {
                        var4.c.setGenerics(this, (Class[])null);
                        break label529;
                     }
                  } catch (Throwable var34) {
                     var10000 = var34;
                     var10001 = false;
                     break label532;
                  }

                  label510: {
                     try {
                        if (!c.b.c.a.c && (!c.b.c.a.b || this.i != 1)) {
                           break label510;
                        }
                     } catch (Throwable var33) {
                        var10000 = var33;
                        var10001 = false;
                        break label532;
                     }

                     try {
                        c.b.a.p.i.a("Write", var2);
                     } catch (Throwable var32) {
                        var10000 = var32;
                        var10001 = false;
                        break label532;
                     }
                  }

                  try {
                     var4.c.write(this, var1, var2);
                  } catch (Throwable var31) {
                     var10000 = var31;
                     var10001 = false;
                     break label532;
                  }

                  var3 = this.i - 1;
                  this.i = var3;
                  if (var3 == 0 && this.k) {
                     this.reset();
                  }

                  return;
               }

               var3 = this.i - 1;
               this.i = var3;
               if (var3 == 0 && this.k) {
                  this.reset();
               }

               return;
            }
         }

         Throwable var35 = var10000;
         var3 = this.i - 1;
         this.i = var3;
         if (var3 == 0 && this.k) {
            this.reset();
         }

         throw var35;
      }
   }

   public void writeObject(c.b.a.n.b var1, Object var2) {
      if (var1 == null) {
         throw new IllegalArgumentException("output cannot be null.");
      } else if (var2 != null) {
         this.a();

         try {
            if (!this.q || !this.a(var1, var2, false)) {
               if (c.b.c.a.c || c.b.c.a.b && this.i == 1) {
                  c.b.a.p.i.a("Write", var2);
               }

               this.getRegistration(var2.getClass()).c.write(this, var1, var2);
               return;
            }

            this.getRegistration(var2.getClass()).c.setGenerics(this, (Class[])null);
         } finally {
            int var3 = this.i - 1;
            this.i = var3;
            if (var3 == 0 && this.k) {
               this.reset();
            }

         }

      } else {
         throw new IllegalArgumentException("object cannot be null.");
      }
   }

   public void writeObject(c.b.a.n.b var1, Object var2, k var3) {
      if (var1 != null) {
         if (var2 == null) {
            throw new IllegalArgumentException("object cannot be null.");
         } else if (var3 != null) {
            this.a();

            try {
               if (!this.q || !this.a(var1, var2, false)) {
                  if (c.b.c.a.c || c.b.c.a.b && this.i == 1) {
                     c.b.a.p.i.a("Write", var2);
                  }

                  var3.write(this, var1, var2);
                  return;
               }

               var3.setGenerics(this, (Class[])null);
            } finally {
               int var4 = this.i - 1;
               this.i = var4;
               if (var4 == 0 && this.k) {
                  this.reset();
               }

            }

         } else {
            throw new IllegalArgumentException("serializer cannot be null.");
         }
      } else {
         throw new IllegalArgumentException("output cannot be null.");
      }
   }

   public void writeObjectOrNull(c.b.a.n.b var1, Object var2, k var3) {
      if (var1 == null) {
         throw new IllegalArgumentException("output cannot be null.");
      } else if (var3 != null) {
         this.a();

         int var5;
         label1391: {
            Throwable var10000;
            label1392: {
               boolean var4;
               boolean var10001;
               try {
                  var4 = this.q;
               } catch (Throwable var114) {
                  var10000 = var114;
                  var10001 = false;
                  break label1392;
               }

               if (var4) {
                  try {
                     if (this.a(var1, var2, true)) {
                        var3.setGenerics(this, (Class[])null);
                        break label1391;
                     }
                  } catch (Throwable var112) {
                     var10000 = var112;
                     var10001 = false;
                     break label1392;
                  }
               } else {
                  label1393: {
                     try {
                        if (var3.getAcceptsNull()) {
                           break label1393;
                        }
                     } catch (Throwable var115) {
                        var10000 = var115;
                        var10001 = false;
                        break label1392;
                     }

                     if (var2 == null) {
                        label1350: {
                           try {
                              if (!c.b.c.a.c && (!c.b.c.a.b || this.i != 1)) {
                                 break label1350;
                              }
                           } catch (Throwable var108) {
                              var10000 = var108;
                              var10001 = false;
                              break label1392;
                           }

                           try {
                              c.b.a.p.i.a("Write", (Object)null);
                           } catch (Throwable var107) {
                              var10000 = var107;
                              var10001 = false;
                              break label1392;
                           }
                        }

                        try {
                           var1.a((byte)0);
                        } catch (Throwable var106) {
                           var10000 = var106;
                           var10001 = false;
                           break label1392;
                        }

                        var5 = this.i - 1;
                        this.i = var5;
                        if (var5 == 0 && this.k) {
                           this.reset();
                        }

                        return;
                     }

                     try {
                        var1.a((byte)1);
                     } catch (Throwable var113) {
                        var10000 = var113;
                        var10001 = false;
                        break label1392;
                     }
                  }
               }

               label1365: {
                  try {
                     if (!c.b.c.a.c && (!c.b.c.a.b || this.i != 1)) {
                        break label1365;
                     }
                  } catch (Throwable var111) {
                     var10000 = var111;
                     var10001 = false;
                     break label1392;
                  }

                  try {
                     c.b.a.p.i.a("Write", var2);
                  } catch (Throwable var110) {
                     var10000 = var110;
                     var10001 = false;
                     break label1392;
                  }
               }

               try {
                  var3.write(this, var1, var2);
               } catch (Throwable var109) {
                  var10000 = var109;
                  var10001 = false;
                  break label1392;
               }

               var5 = this.i - 1;
               this.i = var5;
               if (var5 == 0 && this.k) {
                  this.reset();
               }

               return;
            }

            Throwable var116 = var10000;
            var5 = this.i - 1;
            this.i = var5;
            if (var5 == 0 && this.k) {
               this.reset();
            }

            throw var116;
         }

         var5 = this.i - 1;
         this.i = var5;
         if (var5 == 0 && this.k) {
            this.reset();
         }

      } else {
         throw new IllegalArgumentException("serializer cannot be null.");
      }
   }

   public void writeObjectOrNull(c.b.a.n.b var1, Object var2, Class var3) {
      if (var1 != null) {
         this.a();

         int var5;
         label1326: {
            Throwable var10000;
            label1327: {
               boolean var4;
               boolean var10001;
               k var117;
               try {
                  var117 = this.getRegistration(var3).c;
                  var4 = this.q;
               } catch (Throwable var114) {
                  var10000 = var114;
                  var10001 = false;
                  break label1327;
               }

               if (var4) {
                  try {
                     if (this.a(var1, var2, true)) {
                        var117.setGenerics(this, (Class[])null);
                        break label1326;
                     }
                  } catch (Throwable var112) {
                     var10000 = var112;
                     var10001 = false;
                     break label1327;
                  }
               } else {
                  label1328: {
                     try {
                        if (var117.getAcceptsNull()) {
                           break label1328;
                        }
                     } catch (Throwable var115) {
                        var10000 = var115;
                        var10001 = false;
                        break label1327;
                     }

                     if (var2 == null) {
                        label1287: {
                           try {
                              if (!c.b.c.a.c && (!c.b.c.a.b || this.i != 1)) {
                                 break label1287;
                              }
                           } catch (Throwable var108) {
                              var10000 = var108;
                              var10001 = false;
                              break label1327;
                           }

                           try {
                              c.b.a.p.i.a("Write", var2);
                           } catch (Throwable var107) {
                              var10000 = var107;
                              var10001 = false;
                              break label1327;
                           }
                        }

                        try {
                           var1.a((byte)0);
                        } catch (Throwable var106) {
                           var10000 = var106;
                           var10001 = false;
                           break label1327;
                        }

                        var5 = this.i - 1;
                        this.i = var5;
                        if (var5 == 0 && this.k) {
                           this.reset();
                        }

                        return;
                     }

                     try {
                        var1.a((byte)1);
                     } catch (Throwable var113) {
                        var10000 = var113;
                        var10001 = false;
                        break label1327;
                     }
                  }
               }

               label1302: {
                  try {
                     if (!c.b.c.a.c && (!c.b.c.a.b || this.i != 1)) {
                        break label1302;
                     }
                  } catch (Throwable var111) {
                     var10000 = var111;
                     var10001 = false;
                     break label1327;
                  }

                  try {
                     c.b.a.p.i.a("Write", var2);
                  } catch (Throwable var110) {
                     var10000 = var110;
                     var10001 = false;
                     break label1327;
                  }
               }

               try {
                  var117.write(this, var1, var2);
               } catch (Throwable var109) {
                  var10000 = var109;
                  var10001 = false;
                  break label1327;
               }

               var5 = this.i - 1;
               this.i = var5;
               if (var5 == 0 && this.k) {
                  this.reset();
               }

               return;
            }

            Throwable var116 = var10000;
            var5 = this.i - 1;
            this.i = var5;
            if (var5 == 0 && this.k) {
               this.reset();
            }

            throw var116;
         }

         var5 = this.i - 1;
         this.i = var5;
         if (var5 == 0 && this.k) {
            this.reset();
         }

      } else {
         throw new IllegalArgumentException("output cannot be null.");
      }
   }

   public static class a implements d.a.b.a {
      public d.a.b.a a;

      public d.a.a.a a(final Class var1) {
         d.a.a.a var10;
         if (!c.b.a.p.i.a) {
            boolean var2;
            if (var1.getEnclosingClass() != null && var1.isMemberClass() && !Modifier.isStatic(var1.getModifiers())) {
               var2 = true;
            } else {
               var2 = false;
            }

            if (!var2) {
               try {
                  var10 = new d.a.a.a(this, c.b.d.b.a(var1)) {
                     // $FF: synthetic field
                     public final c.b.d.b a;

                     public {
                        this.a = var2;
                     }

                     public Object a() {
                        try {
                           Object var4 = this.a.a();
                           return var4;
                        } catch (Exception var3) {
                           StringBuilder var1x = c.a.b.a.a.b("Error constructing instance of class: ");
                           var1x.append(c.b.a.p.i.a(var1));
                           throw new f(var1x.toString(), var3);
                        }
                     }
                  };
                  return var10;
               } catch (Exception var7) {
               }
            }
         }

         label45: {
            boolean var10001;
            final Constructor var3;
            try {
               var3 = var1.getConstructor((Class[])null);
            } catch (Exception var6) {
               try {
                  var3 = var1.getDeclaredConstructor((Class[])null);
                  var3.setAccessible(true);
               } catch (Exception var5) {
                  var10001 = false;
                  break label45;
               }
            }

            try {
               var10 = new d.a.a.a(this) {
                  public Object a() {
                     try {
                        Object var1x = var3.newInstance();
                        return var1x;
                     } catch (Exception var3x) {
                        StringBuilder var2 = c.a.b.a.a.b("Error constructing instance of class: ");
                        var2.append(c.b.a.p.i.a(var1));
                        throw new f(var2.toString(), var3x);
                     }
                  }
               };
               return var10;
            } catch (Exception var4) {
               var10001 = false;
            }
         }

         d.a.b.a var8 = this.a;
         if (var8 == null) {
            StringBuilder var9;
            if (var1.isMemberClass() && !Modifier.isStatic(var1.getModifiers())) {
               var9 = c.a.b.a.a.b("Class cannot be created (non-static member class): ");
               var9.append(c.b.a.p.i.a(var1));
               throw new f(var9.toString());
            } else {
               var9 = c.a.b.a.a.b("Class cannot be created (missing no-arg constructor): ");
               var9.append(c.b.a.p.i.a(var1));
               throw new f(var9.toString());
            }
         } else {
            return ((d.a)var8).a(var1);
         }
      }
   }

   public static final class b {
      public final Class a;
      public final c.b.a.m.c b;

      public b(Class var1, c.b.a.m.c var2) {
         this.a = var1;
         this.b = var2;
      }
   }
}
