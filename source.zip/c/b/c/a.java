package c.b.c;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;

public class a {
   public static int a;
   public static boolean b;
   public static boolean c;
   public static c.b.c.a.a d;

   static {
      int var0 = a;
      var0 = a;
      var0 = a;
      var0 = a;
      boolean var1 = false;
      boolean var2;
      if (var0 <= 2) {
         var2 = true;
      } else {
         var2 = false;
      }

      b = var2;
      var2 = var1;
      if (a <= 1) {
         var2 = true;
      }

      c = var2;
      d = new c.b.c.a.a();
   }

   public static void a(String var0, String var1) {
      if (b) {
         d.a(2, var0, var1, (Throwable)null);
      }

   }

   public static void b(String var0, String var1) {
      if (c) {
         d.a(1, var0, var1, (Throwable)null);
      }

   }

   public static class a {
      public long a = (new Date()).getTime();

      public void a(int var1, String var2, String var3, Throwable var4) {
         StringBuilder var5 = new StringBuilder(256);
         long var6 = (new Date()).getTime() - this.a;
         long var8 = var6 / 60000L;
         var6 = var6 / 1000L % 60L;
         if (var8 <= 9L) {
            var5.append('0');
         }

         var5.append(var8);
         var5.append(':');
         if (var6 <= 9L) {
            var5.append('0');
         }

         var5.append(var6);
         if (var1 != 1) {
            if (var1 != 2) {
               if (var1 != 3) {
                  if (var1 != 4) {
                     if (var1 == 5) {
                        var5.append(" ERROR: ");
                     }
                  } else {
                     var5.append("  WARN: ");
                  }
               } else {
                  var5.append("  INFO: ");
               }
            } else {
               var5.append(" DEBUG: ");
            }
         } else {
            var5.append(" TRACE: ");
         }

         if (var2 != null) {
            var5.append('[');
            var5.append(var2);
            var5.append("] ");
         }

         var5.append(var3);
         if (var4 != null) {
            StringWriter var10 = new StringWriter(256);
            var4.printStackTrace(new PrintWriter(var10));
            var5.append('\n');
            var5.append(var10.toString().trim());
         }

         var2 = var5.toString();
         System.out.println(var2);
      }
   }
}
