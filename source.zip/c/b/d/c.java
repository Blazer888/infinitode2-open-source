package c.b.d;

import c.b.d.e.a.a.a.f;
import c.b.d.e.a.a.a.m;
import c.b.d.e.a.a.a.n;
import c.b.d.e.a.a.a.p;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

public abstract class c {
   public String[] a;
   public Class[] b;

   public static c a(Class var0) {
      ArrayList var1 = new ArrayList();
      Class var2 = var0;

      while(true) {
         int var3 = 0;
         int var5;
         if (var2 == Object.class) {
            String[] var8 = new String[var1.size()];
            Class[] var45 = new Class[var1.size()];
            var5 = var8.length;

            for(var3 = 0; var3 < var5; ++var3) {
               var8[var3] = ((Field)var1.get(var3)).getName();
               var45[var3] = ((Field)var1.get(var3)).getType();
            }

            String var9 = var0.getName();
            String var46 = c.a.b.a.a.a(var9, "FieldAccess");
            String var44 = var46;
            if (var46.startsWith("java.")) {
               var44 = c.a.b.a.a.a("reflectasm.", var46);
            }

            a var47 = c.b.d.a.a(var0);
            synchronized(var47){}

            label406: {
               Throwable var10000;
               boolean var10001;
               label408: {
                  label380: {
                     try {
                        try {
                           var0 = var47.loadClass(var44);
                           break label380;
                        } catch (ClassNotFoundException var39) {
                        }
                     } catch (Throwable var40) {
                        var10000 = var40;
                        var10001 = false;
                        break label408;
                     }

                     try {
                        String var10 = var44.replace('.', '/');
                        String var41 = var9.replace('.', '/');
                        f var48 = new f(0);
                        var48.a(196653, 33, var10, (String)null, "com/esotericsoftware/reflectasm/FieldAccess", (String[])null);
                        n var49 = var48.a(1, "<init>", "()V", (String)null, (String[])null);
                        var49.e(25, 0);
                        var49.b(183, "com/esotericsoftware/reflectasm/FieldAccess", "<init>", "()V");
                        var49.a(177);
                        var49.d(1, 1);
                        a(var48, var41, var1);
                        c(var48, var41, var1);
                        a(var48, var41, var1, p.f);
                        b(var48, var41, var1, p.f);
                        a(var48, var41, var1, p.h);
                        b(var48, var41, var1, p.h);
                        a(var48, var41, var1, p.i);
                        b(var48, var41, var1, p.i);
                        a(var48, var41, var1, p.j);
                        b(var48, var41, var1, p.j);
                        a(var48, var41, var1, p.l);
                        b(var48, var41, var1, p.l);
                        a(var48, var41, var1, p.m);
                        b(var48, var41, var1, p.m);
                        a(var48, var41, var1, p.k);
                        b(var48, var41, var1, p.k);
                        a(var48, var41, var1, p.g);
                        b(var48, var41, var1, p.g);
                        b(var48, var41, var1);
                        var0 = var47.a(var44, var48.c());
                     } catch (Throwable var38) {
                        var10000 = var38;
                        var10001 = false;
                        break label408;
                     }
                  }

                  label372:
                  try {
                     break label406;
                  } catch (Throwable var37) {
                     var10000 = var37;
                     var10001 = false;
                     break label372;
                  }
               }

               while(true) {
                  Throwable var42 = var10000;

                  try {
                     throw var42;
                  } catch (Throwable var36) {
                     var10000 = var36;
                     var10001 = false;
                     continue;
                  }
               }
            }

            try {
               c var43 = (c)var0.newInstance();
               var43.a = var8;
               var43.b = var45;
               return var43;
            } catch (Exception var35) {
               throw new RuntimeException(c.a.b.a.a.a("Error constructing field access class: ", var44), var35);
            }
         }

         Field[] var4 = var2.getDeclaredFields();

         for(var5 = var4.length; var3 < var5; ++var3) {
            Field var6 = var4[var3];
            int var7 = var6.getModifiers();
            if (!Modifier.isStatic(var7) && !Modifier.isPrivate(var7)) {
               var1.add(var6);
            }
         }

         var2 = var2.getSuperclass();
      }
   }

   public static n a(n var0) {
      var0.a(187, (String)"java/lang/IllegalArgumentException");
      var0.a(89);
      var0.a(187, (String)"java/lang/StringBuilder");
      var0.a(89);
      var0.b("Field not found: ");
      var0.b(183, "java/lang/StringBuilder", "<init>", "(Ljava/lang/String;)V");
      var0.e(21, 2);
      var0.b(182, "java/lang/StringBuilder", "append", "(I)Ljava/lang/StringBuilder;");
      var0.b(182, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
      var0.b(183, "java/lang/IllegalArgumentException", "<init>", "(Ljava/lang/String;)V");
      var0.a(191);
      return var0;
   }

   public static n a(n var0, String var1) {
      var0.a(187, (String)"java/lang/IllegalArgumentException");
      var0.a(89);
      var0.a(187, (String)"java/lang/StringBuilder");
      var0.a(89);
      StringBuilder var2 = new StringBuilder();
      var2.append("Field not declared as ");
      var2.append(var1);
      var2.append(": ");
      var0.b(var2.toString());
      var0.b(183, "java/lang/StringBuilder", "<init>", "(Ljava/lang/String;)V");
      var0.e(21, 2);
      var0.b(182, "java/lang/StringBuilder", "append", "(I)Ljava/lang/StringBuilder;");
      var0.b(182, "java/lang/StringBuilder", "toString", "()Ljava/lang/String;");
      var0.b(183, "java/lang/IllegalArgumentException", "<init>", "(Ljava/lang/String;)V");
      var0.a(191);
      return var0;
   }

   public static void a(f var0, String var1, ArrayList var2) {
      n var3 = var0.a(1, "get", "(Ljava/lang/Object;I)Ljava/lang/Object;", (String)null, (String[])null);
      var3.e(21, 2);
      byte var11;
      if (!var2.isEmpty()) {
         byte var4 = 5;
         m[] var10 = new m[var2.size()];
         int var5 = var10.length;
         byte var6 = 0;

         int var7;
         for(var7 = 0; var7 < var5; ++var7) {
            var10[var7] = new m();
         }

         m var8 = new m();
         var3.a(0, var10.length - 1, var8, var10);
         var5 = var10.length;

         for(var7 = var6; var7 < var5; ++var7) {
            Field var9 = (Field)var2.get(var7);
            var3.a(var10[var7]);
            var3.a(3, 0, (Object[])null, 0, (Object[])null);
            var3.e(25, 1);
            var3.a(192, (String)var1);
            var3.a(180, var1, var9.getName(), p.a(var9.getType()));
            switch(p.b(var9.getType()).a) {
            case 1:
               var3.b(184, "java/lang/Boolean", "valueOf", "(Z)Ljava/lang/Boolean;");
               break;
            case 2:
               var3.b(184, "java/lang/Character", "valueOf", "(C)Ljava/lang/Character;");
               break;
            case 3:
               var3.b(184, "java/lang/Byte", "valueOf", "(B)Ljava/lang/Byte;");
               break;
            case 4:
               var3.b(184, "java/lang/Short", "valueOf", "(S)Ljava/lang/Short;");
               break;
            case 5:
               var3.b(184, "java/lang/Integer", "valueOf", "(I)Ljava/lang/Integer;");
               break;
            case 6:
               var3.b(184, "java/lang/Float", "valueOf", "(F)Ljava/lang/Float;");
               break;
            case 7:
               var3.b(184, "java/lang/Long", "valueOf", "(J)Ljava/lang/Long;");
               break;
            case 8:
               var3.b(184, "java/lang/Double", "valueOf", "(D)Ljava/lang/Double;");
            }

            var3.a(176);
         }

         var3.a(var8);
         var3.a(3, 0, (Object[])null, 0, (Object[])null);
         var11 = var4;
      } else {
         var11 = 6;
      }

      a(var3);
      var3.d(var11, 3);
   }

   public static void a(f var0, String var1, ArrayList var2, p var3) {
      String var4 = var3.b();
      int var5 = var3.a;
      short var6 = 172;
      String var7;
      switch(var5) {
      case 1:
         var7 = "getBoolean";
         break;
      case 2:
         var7 = "getChar";
         break;
      case 3:
         var7 = "getByte";
         break;
      case 4:
         var7 = "getShort";
         break;
      case 5:
         var7 = "getInt";
         break;
      case 6:
         var6 = 174;
         var7 = "getFloat";
         break;
      case 7:
         var6 = 173;
         var7 = "getLong";
         break;
      case 8:
         var6 = 175;
         var7 = "getDouble";
         break;
      default:
         var6 = 176;
         var7 = "get";
      }

      n var8 = var0.a(1, var7, c.a.b.a.a.a("(Ljava/lang/Object;I)", var4), (String)null, (String[])null);
      var8.e(21, 2);
      byte var16;
      if (!var2.isEmpty()) {
         m[] var9 = new m[var2.size()];
         m var14 = new m();
         int var10 = var9.length;
         byte var11 = 0;
         int var12 = 0;

         boolean var15;
         for(var15 = false; var12 < var10; ++var12) {
            if (p.b(((Field)var2.get(var12)).getType()).equals(var3)) {
               var9[var12] = new m();
            } else {
               var9[var12] = var14;
               var15 = true;
            }
         }

         m var13 = new m();
         var8.a(0, var9.length - 1, var13, var9);
         var10 = var9.length;

         for(var12 = var11; var12 < var10; ++var12) {
            Field var17 = (Field)var2.get(var12);
            if (!var9[var12].equals(var14)) {
               var8.a(var9[var12]);
               var8.a(3, 0, (Object[])null, 0, (Object[])null);
               var8.e(25, 1);
               var8.a(192, (String)var1);
               var8.a(180, var1, var17.getName(), var4);
               var8.a(var6);
            }
         }

         if (var15) {
            var8.a(var14);
            var8.a(3, 0, (Object[])null, 0, (Object[])null);
            a(var8, var3.a());
         }

         var8.a(var13);
         var8.a(3, 0, (Object[])null, 0, (Object[])null);
         var16 = 5;
      } else {
         var16 = 6;
      }

      a(var8);
      var8.d(var16, 3);
   }

   public static void b(f var0, String var1, ArrayList var2) {
      n var3 = var0.a(1, "getString", "(Ljava/lang/Object;I)Ljava/lang/String;", (String)null, (String[])null);
      var3.e(21, 2);
      byte var12;
      if (!var2.isEmpty()) {
         byte var4 = 5;
         m[] var11 = new m[var2.size()];
         m var5 = new m();
         int var6 = var11.length;
         int var7 = 0;
         int var8 = 0;

         boolean var9;
         for(var9 = false; var8 < var6; ++var8) {
            if (((Field)var2.get(var8)).getType().equals(String.class)) {
               var11[var8] = new m();
            } else {
               var11[var8] = var5;
               var9 = true;
            }
         }

         m var10 = new m();
         var3.a(0, var11.length - 1, var10, var11);

         for(var8 = var11.length; var7 < var8; ++var7) {
            if (!var11[var7].equals(var5)) {
               var3.a(var11[var7]);
               var3.a(3, 0, (Object[])null, 0, (Object[])null);
               var3.e(25, 1);
               var3.a(192, (String)var1);
               var3.a(180, var1, ((Field)var2.get(var7)).getName(), "Ljava/lang/String;");
               var3.a(176);
            }
         }

         if (var9) {
            var3.a(var5);
            var3.a(3, 0, (Object[])null, 0, (Object[])null);
            a(var3, "String");
         }

         var3.a(var10);
         var3.a(3, 0, (Object[])null, 0, (Object[])null);
         var12 = var4;
      } else {
         var12 = 6;
      }

      a(var3);
      var3.d(var12, 3);
   }

   public static void b(f var0, String var1, ArrayList var2, p var3) {
      String var4;
      byte var6;
      String var7;
      byte var15;
      label60: {
         label59: {
            var4 = var3.b();
            int var5 = var3.a;
            var6 = 4;
            switch(var5) {
            case 1:
               var7 = "setBoolean";
               break;
            case 2:
               var7 = "setChar";
               break;
            case 3:
               var7 = "setByte";
               break;
            case 4:
               var7 = "setShort";
               break;
            case 5:
               var7 = "setInt";
               break;
            case 6:
               var15 = 23;
               var7 = "setFloat";
               break label60;
            case 7:
               var15 = 22;
               var7 = "setLong";
               break label59;
            case 8:
               var15 = 24;
               var7 = "setDouble";
               break label59;
            default:
               var7 = "set";
               var15 = 25;
               break label60;
            }

            var15 = 21;
            break label60;
         }

         var6 = 5;
      }

      n var16 = var0.a(1, var7, c.a.b.a.a.a("(Ljava/lang/Object;I", var4, ")V"), (String)null, (String[])null);
      var16.e(21, 2);
      if (!var2.isEmpty()) {
         m[] var8 = new m[var2.size()];
         m var14 = new m();
         int var9 = var8.length;
         byte var10 = 0;
         int var11 = 0;

         boolean var12;
         for(var12 = false; var11 < var9; ++var11) {
            if (p.b(((Field)var2.get(var11)).getType()).equals(var3)) {
               var8[var11] = new m();
            } else {
               var8[var11] = var14;
               var12 = true;
            }
         }

         m var13 = new m();
         var16.a(0, var8.length - 1, var13, var8);
         var9 = var8.length;

         for(var11 = var10; var11 < var9; ++var11) {
            if (!var8[var11].equals(var14)) {
               var16.a(var8[var11]);
               var16.a(3, 0, (Object[])null, 0, (Object[])null);
               var16.e(25, 1);
               var16.a(192, (String)var1);
               var16.e(var15, 3);
               var16.a(181, var1, ((Field)var2.get(var11)).getName(), var4);
               var16.a(177);
            }
         }

         if (var12) {
            var16.a(var14);
            var16.a(3, 0, (Object[])null, 0, (Object[])null);
            a(var16, var3.a());
         }

         var16.a(var13);
         var16.a(3, 0, (Object[])null, 0, (Object[])null);
         var15 = 5;
      } else {
         var15 = 6;
      }

      a(var16);
      var16.d(var15, var6);
   }

   public static void c(f var0, String var1, ArrayList var2) {
      n var10 = var0.a(1, "set", "(Ljava/lang/Object;ILjava/lang/Object;)V", (String)null, (String[])null);
      var10.e(21, 2);
      byte var11;
      if (!var2.isEmpty()) {
         m[] var3 = new m[var2.size()];
         int var4 = var3.length;
         byte var5 = 0;

         int var6;
         for(var6 = 0; var6 < var4; ++var6) {
            var3[var6] = new m();
         }

         m var7 = new m();
         var10.a(0, var3.length - 1, var7, var3);
         var4 = var3.length;

         for(var6 = var5; var6 < var4; ++var6) {
            Field var8 = (Field)var2.get(var6);
            p var9 = p.b(var8.getType());
            var10.a(var3[var6]);
            var10.a(3, 0, (Object[])null, 0, (Object[])null);
            var10.e(25, 1);
            var10.a(192, (String)var1);
            var10.e(25, 3);
            switch(var9.a) {
            case 1:
               var10.a(192, (String)"java/lang/Boolean");
               var10.b(182, "java/lang/Boolean", "booleanValue", "()Z");
               break;
            case 2:
               var10.a(192, (String)"java/lang/Character");
               var10.b(182, "java/lang/Character", "charValue", "()C");
               break;
            case 3:
               var10.a(192, (String)"java/lang/Byte");
               var10.b(182, "java/lang/Byte", "byteValue", "()B");
               break;
            case 4:
               var10.a(192, (String)"java/lang/Short");
               var10.b(182, "java/lang/Short", "shortValue", "()S");
               break;
            case 5:
               var10.a(192, (String)"java/lang/Integer");
               var10.b(182, "java/lang/Integer", "intValue", "()I");
               break;
            case 6:
               var10.a(192, (String)"java/lang/Float");
               var10.b(182, "java/lang/Float", "floatValue", "()F");
               break;
            case 7:
               var10.a(192, (String)"java/lang/Long");
               var10.b(182, "java/lang/Long", "longValue", "()J");
               break;
            case 8:
               var10.a(192, (String)"java/lang/Double");
               var10.b(182, "java/lang/Double", "doubleValue", "()D");
               break;
            case 9:
               var10.a(192, (String)var9.b());
               break;
            case 10:
               var10.a(192, (String)(new String(var9.b, var9.c, var9.d)));
            }

            var10.a(181, var1, var8.getName(), var9.b());
            var10.a(177);
         }

         var10.a(var7);
         var10.a(3, 0, (Object[])null, 0, (Object[])null);
         var11 = 5;
      } else {
         var11 = 6;
      }

      a(var10);
      var10.d(var11, 4);
   }

   public int a(String var1) {
      int var2 = this.a.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         if (this.a[var3].equals(var1)) {
            return var3;
         }
      }

      IllegalArgumentException var4 = new IllegalArgumentException(c.a.b.a.a.a("Unable to find public field: ", var1));
      throw var4;
   }

   public abstract Object a(Object var1, int var2);

   public abstract void a(Object var1, int var2, byte var3);

   public abstract void a(Object var1, int var2, char var3);

   public abstract void a(Object var1, int var2, double var3);

   public abstract void a(Object var1, int var2, float var3);

   public abstract void a(Object var1, int var2, int var3);

   public abstract void a(Object var1, int var2, long var3);

   public abstract void a(Object var1, int var2, Object var3);

   public abstract void a(Object var1, int var2, short var3);

   public abstract void a(Object var1, int var2, boolean var3);

   public abstract boolean b(Object var1, int var2);

   public abstract byte c(Object var1, int var2);

   public abstract char d(Object var1, int var2);

   public abstract double e(Object var1, int var2);

   public abstract float f(Object var1, int var2);

   public abstract int g(Object var1, int var2);

   public abstract long h(Object var1, int var2);

   public abstract short i(Object var1, int var2);

   public abstract String j(Object var1, int var2);
}
