package c.b.d;

public abstract class d {
}
