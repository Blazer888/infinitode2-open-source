package c.b.d;

import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.security.ProtectionDomain;
import java.util.WeakHashMap;

public class a extends ClassLoader {
   public static final WeakHashMap a = new WeakHashMap();
   public static final ClassLoader b;
   public static volatile a c;

   static {
      ClassLoader var0 = a.class.getClassLoader();
      ClassLoader var1 = var0;
      if (var0 == null) {
         var1 = ClassLoader.getSystemClassLoader();
      }

      b = var1;
      c = new a(b);
   }

   public a(ClassLoader var1) {
      super(var1);
   }

   public static a a(Class var0) {
      ClassLoader var1 = var0.getClassLoader();
      ClassLoader var95 = var1;
      if (var1 == null) {
         var95 = ClassLoader.getSystemClassLoader();
      }

      Throwable var10000;
      boolean var10001;
      if (b.equals(var95)) {
         if (c == null) {
            WeakHashMap var98 = a;
            synchronized(var98){}

            label844: {
               try {
                  if (c == null) {
                     a var99 = new a(b);
                     c = var99;
                  }
               } catch (Throwable var89) {
                  var10000 = var89;
                  var10001 = false;
                  break label844;
               }

               label841:
               try {
                  return c;
               } catch (Throwable var88) {
                  var10000 = var88;
                  var10001 = false;
                  break label841;
               }
            }

            while(true) {
               Throwable var100 = var10000;

               try {
                  throw var100;
               } catch (Throwable var86) {
                  var10000 = var86;
                  var10001 = false;
                  continue;
               }
            }
         } else {
            return c;
         }
      } else {
         WeakHashMap var96 = a;
         synchronized(var96){}

         label872: {
            WeakReference var2;
            try {
               var2 = (WeakReference)a.get(var95);
            } catch (Throwable var94) {
               var10000 = var94;
               var10001 = false;
               break label872;
            }

            if (var2 != null) {
               a var101;
               try {
                  var101 = (a)var2.get();
               } catch (Throwable var93) {
                  var10000 = var93;
                  var10001 = false;
                  break label872;
               }

               if (var101 != null) {
                  try {
                     return var101;
                  } catch (Throwable var90) {
                     var10000 = var90;
                     var10001 = false;
                     break label872;
                  }
               }

               try {
                  a.remove(var95);
               } catch (Throwable var92) {
                  var10000 = var92;
                  var10001 = false;
                  break label872;
               }
            }

            label853:
            try {
               a var3 = new a(var95);
               WeakHashMap var4 = a;
               var2 = new WeakReference(var3);
               var4.put(var95, var2);
               return var3;
            } catch (Throwable var91) {
               var10000 = var91;
               var10001 = false;
               break label853;
            }
         }

         while(true) {
            Throwable var97 = var10000;

            try {
               throw var97;
            } catch (Throwable var87) {
               var10000 = var87;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public Class a(String var1, byte[] var2) {
      try {
         Class var3 = Integer.TYPE;
         Class var4 = Integer.TYPE;
         Method var6 = ClassLoader.class.getDeclaredMethod("defineClass", String.class, byte[].class, var3, var4, ProtectionDomain.class);
         if (!var6.isAccessible()) {
            var6.setAccessible(true);
         }

         var4 = (Class)var6.invoke(this.getParent(), var1, var2, 0, var2.length, this.getClass().getProtectionDomain());
         return var4;
      } catch (Exception var5) {
         return this.defineClass(var1, var2, 0, var2.length, a.class.getProtectionDomain());
      }
   }

   public Class loadClass(String var1, boolean var2) {
      synchronized(this){}

      Throwable var10000;
      label220: {
         boolean var10001;
         boolean var3;
         try {
            var3 = var1.equals(c.class.getName());
         } catch (Throwable var23) {
            var10000 = var23;
            var10001 = false;
            break label220;
         }

         if (var3) {
            return c.class;
         }

         try {
            var3 = var1.equals(d.class.getName());
         } catch (Throwable var22) {
            var10000 = var22;
            var10001 = false;
            break label220;
         }

         if (var3) {
            return d.class;
         }

         try {
            var3 = var1.equals(b.class.getName());
         } catch (Throwable var21) {
            var10000 = var21;
            var10001 = false;
            break label220;
         }

         if (var3) {
            return b.class;
         }

         Class var25;
         try {
            var25 = super.loadClass(var1, var2);
         } catch (Throwable var20) {
            var10000 = var20;
            var10001 = false;
            break label220;
         }

         return var25;
      }

      Throwable var24 = var10000;
      throw var24;
   }
}
