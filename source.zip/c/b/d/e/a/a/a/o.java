package c.b.d.e.a.a.a;

public interface o {
   Integer a = new Integer(0);
   Integer b = new Integer(1);
   Integer c = new Integer(2);
   Integer d = new Integer(3);
   Integer e = new Integer(4);
   Integer f = new Integer(5);
   Integer g = new Integer(6);
}
