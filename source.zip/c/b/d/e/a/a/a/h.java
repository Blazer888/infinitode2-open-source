package c.b.d.e.a.a.a;

public final class h {
   public h a = null;
   public final f b;
   public final int c;
   public final int d;
   public final int e;
   public int f;
   public int g;
   public a h;
   public a i;
   public b j;

   public h(f var1, int var2, String var3, String var4, String var5, Object var6) {
      if (var1.E == null) {
         var1.E = this;
      } else {
         var1.F.a = this;
      }

      var1.F = this;
      this.b = var1;
      this.c = var2;
      this.d = var1.d(var3);
      this.e = var1.d(var4);
      if (var5 != null) {
         this.f = var1.d(var5);
      }

      if (var6 != null) {
         this.g = var1.a(var6).a;
      }

   }

   public a a(String var1, boolean var2) {
      c var3 = new c();
      var3.d(this.b.d(var1));
      var3.d(0);
      a var4 = new a(this.b, true, var3, var3, 2);
      if (var2) {
         var4.g = this.h;
         this.h = var4;
      } else {
         var4.g = this.i;
         this.i = var4;
      }

      return var4;
   }

   public void a() {
   }

   public void a(b var1) {
      var1.c = this.j;
      this.j = var1;
   }
}
