package c.b.d.e.a.a.a;

public class f extends e {
   public static final byte[] L;
   public int A;
   public c B;
   public int C;
   public c D;
   public h E;
   public h F;
   public n G;
   public n H;
   public final boolean I;
   public final boolean J;
   public boolean K;
   public d a;
   public int b;
   public int c;
   public final c d;
   public l[] e;
   public int f;
   public final l g;
   public final l h;
   public final l i;
   public final l j;
   public l[] k;
   public short l;
   public int m;
   public int n;
   public String o;
   public int p;
   public int q;
   public int r;
   public int[] s;
   public int t;
   public c u;
   public int v;
   public int w;
   public a x;
   public a y;
   public b z;

   static {
      byte[] var0 = new byte[220];

      for(int var1 = 0; var1 < var0.length; ++var1) {
         var0[var1] = (byte)((byte)("AAAAAAAAAAAAAAAABCLMMDDDDDEEEEEEEEEEEEEEEEEEEEAAAAAAAADDDDDEEEEEEEEEEEEEEEEEEEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANAAAAAAAAAAAAAAAAAAAAJJJJJJJJJJJJJJJJDOPAAAAAAGGGGGGGHIFBFAAFFAARQJJKKJJJJJJJJJJJJJJJJJJ".charAt(var1) - 65));
      }

      L = var0;
   }

   public f(int var1) {
      super(262144);
      boolean var2 = true;
      this.c = 1;
      this.d = new c();
      this.e = new l[256];
      double var3 = (double)this.e.length;
      Double.isNaN(var3);
      this.f = (int)(var3 * 0.75D);
      this.g = new l();
      this.h = new l();
      this.i = new l();
      this.j = new l();
      boolean var5;
      if ((var1 & 1) != 0) {
         var5 = true;
      } else {
         var5 = false;
      }

      this.I = var5;
      if ((var1 & 2) != 0) {
         var5 = var2;
      } else {
         var5 = false;
      }

      this.J = var5;
   }

   public int a(String var1, int var2) {
      l var3 = this.g;
      var3.b = 31;
      var3.c = var2;
      var3.e = var1;
      var3.h = var1.hashCode() + 31 + var2 & Integer.MAX_VALUE;
      var3 = this.a(this.g);
      l var4 = var3;
      if (var3 == null) {
         var4 = this.b();
      }

      return var4.a;
   }

   public final a a(String var1, boolean var2) {
      c var3 = new c();
      var3.d(this.d(var1));
      var3.d(0);
      a var4 = new a(this, true, var3, var3, 2);
      if (var2) {
         var4.g = this.x;
         this.x = var4;
      } else {
         var4.g = this.y;
         this.y = var4;
      }

      return var4;
   }

   public final h a(int var1, String var2, String var3, String var4, Object var5) {
      return new h(this, var1, var2, var3, var4, var5);
   }

   public l a(double var1) {
      l var3 = this.g;
      var3.b = 6;
      var3.d = Double.doubleToRawLongBits(var1);
      var3.h = Integer.MAX_VALUE & var3.b + (int)var1;
      l var4 = this.a(this.g);
      var3 = var4;
      if (var4 == null) {
         c var5 = this.d;
         var5.b(6);
         var5.a(this.g.d);
         var3 = new l(this.c, this.g);
         this.c += 2;
         this.b(var3);
      }

      return var3;
   }

   public l a(float var1) {
      l var2 = this.g;
      var2.b = 4;
      var2.c = Float.floatToRawIntBits(var1);
      var2.h = Integer.MAX_VALUE & var2.b + (int)var1;
      l var3 = this.a(this.g);
      var2 = var3;
      if (var3 == null) {
         c var5 = this.d;
         var5.b(4);
         var5.c(this.g.c);
         int var4 = this.c++;
         var2 = new l(var4, this.g);
         this.b(var2);
      }

      return var2;
   }

   public l a(int var1) {
      l var2 = this.g;
      var2.b = 3;
      var2.c = var1;
      var2.h = var2.b + var1 & Integer.MAX_VALUE;
      l var3 = this.a(var2);
      var2 = var3;
      if (var3 == null) {
         c var4 = this.d;
         var4.b(3);
         var4.c(var1);
         var1 = this.c++;
         var2 = new l(var1, this.g);
         this.b(var2);
      }

      return var2;
   }

   public l a(int var1, String var2, String var3, String var4) {
      this.j.a(var1 + 20, var2, var3, var4);
      l var5 = this.a(this.j);
      l var6 = var5;
      if (var5 == null) {
         int var7;
         if (var1 <= 4) {
            var7 = this.b(var2, var3, var4).a;
         } else {
            boolean var8;
            if (var1 == 9) {
               var8 = true;
            } else {
               var8 = false;
            }

            var7 = this.a(var2, var3, var4, var8).a;
         }

         c var9 = this.d;
         var9.a(15, var1);
         var9.d(var7);
         var1 = this.c++;
         var6 = new l(var1, this.j);
         this.b(var6);
      }

      return var6;
   }

   public l a(long var1) {
      l var3 = this.g;
      var3.b = 5;
      var3.d = var1;
      var3.h = var3.b + (int)var1 & Integer.MAX_VALUE;
      l var4 = this.a(var3);
      var3 = var4;
      if (var4 == null) {
         c var5 = this.d;
         var5.b(5);
         var5.a(var1);
         var3 = new l(this.c, this.g);
         this.c += 2;
         this.b(var3);
      }

      return var3;
   }

   public final l a(l var1) {
      l[] var2 = this.e;

      l var6;
      for(var6 = var2[var1.h % var2.length]; var6 != null; var6 = var6.i) {
         int var3 = var6.b;
         int var4 = var1.b;
         if (var3 == var4) {
            boolean var5;
            label69: {
               label68: {
                  var5 = true;
                  if (var4 != 1) {
                     if (var4 == 12) {
                        if (var6.e.equals(var1.e) && var6.f.equals(var1.f)) {
                           break label69;
                        }
                        break label68;
                     }

                     if (var4 != 16) {
                        if (var4 == 18) {
                           if (var6.d == var1.d && var6.e.equals(var1.e) && var6.f.equals(var1.f)) {
                              break label69;
                           }
                           break label68;
                        }

                        label61:
                        switch(var4) {
                        case 3:
                        case 4:
                           if (var6.c == var1.c) {
                              break label69;
                           }
                           break label68;
                        case 7:
                        case 8:
                           break;
                        default:
                           switch(var4) {
                           case 30:
                              break label61;
                           case 31:
                              if (var6.c == var1.c && var6.e.equals(var1.e)) {
                                 break label69;
                              }
                              break label68;
                           case 32:
                              break;
                           default:
                              if (var6.e.equals(var1.e) && var6.f.equals(var1.f) && var6.g.equals(var1.g)) {
                                 break label69;
                              }
                              break label68;
                           }
                        case 5:
                        case 6:
                           if (var6.d == var1.d) {
                              break label69;
                           }
                           break label68;
                        }
                     }
                  }

                  var5 = var6.e.equals(var1.e);
                  break label69;
               }

               var5 = false;
            }

            if (var5) {
               break;
            }
         }
      }

      return var6;
   }

   public l a(Object var1) {
      if (var1 instanceof Integer) {
         return this.a((Integer)var1);
      } else if (var1 instanceof Byte) {
         return this.a(((Byte)var1).intValue());
      } else if (var1 instanceof Character) {
         return this.a((Character)var1);
      } else if (var1 instanceof Short) {
         return this.a(((Short)var1).intValue());
      } else if (var1 instanceof Boolean) {
         return this.a((Boolean)var1);
      } else if (var1 instanceof Float) {
         return this.a((Float)var1);
      } else if (var1 instanceof Long) {
         return this.a((Long)var1);
      } else if (var1 instanceof Double) {
         return this.a((Double)var1);
      } else {
         String var2;
         int var4;
         l var7;
         l var8;
         if (var1 instanceof String) {
            var2 = (String)var1;
            this.h.a(8, var2, (String)null, (String)null);
            var8 = this.a(this.h);
            var7 = var8;
            if (var8 == null) {
               this.d.b(8, this.d(var2));
               var4 = this.c++;
               var7 = new l(var4, this.h);
               this.b(var7);
            }

            return var7;
         } else if (var1 instanceof p) {
            p var6 = (p)var1;
            var4 = var6.a;
            if (var4 == 9) {
               return this.a(var6.b());
            } else if (var4 == 10) {
               return this.a(new String(var6.b, var6.c, var6.d));
            } else {
               var2 = var6.b();
               this.h.a(16, var2, (String)null, (String)null);
               var8 = this.a(this.h);
               var7 = var8;
               if (var8 == null) {
                  this.d.b(16, this.d(var2));
                  var4 = this.c++;
                  var7 = new l(var4, this.h);
                  this.b(var7);
               }

               return var7;
            }
         } else if (var1 instanceof j) {
            j var5 = (j)var1;
            return this.a(var5.a, var5.b, var5.c, var5.d);
         } else {
            StringBuffer var3 = new StringBuffer();
            var3.append("value ");
            var3.append(var1);
            throw new IllegalArgumentException(var3.toString());
         }
      }
   }

   public l a(String var1) {
      this.h.a(7, var1, (String)null, (String)null);
      l var2 = this.a(this.h);
      l var3 = var2;
      if (var2 == null) {
         this.d.b(7, this.d(var1));
         int var4 = this.c++;
         var3 = new l(var4, this.h);
         this.b(var3);
      }

      return var3;
   }

   public l a(String var1, String var2, String var3, boolean var4) {
      byte var5;
      if (var4) {
         var5 = 11;
      } else {
         var5 = 10;
      }

      this.i.a(var5, var1, var2, var3);
      l var6 = this.a(this.i);
      l var7 = var6;
      if (var6 == null) {
         this.a(var5, this.a(var1).a, this.b(var2, var3));
         int var8 = this.c++;
         var7 = new l(var8, this.i);
         this.b(var7);
      }

      return var7;
   }

   public final n a(int var1, String var2, String var3, String var4, String[] var5) {
      return new n(this, var1, var2, var3, var4, var5, this.I, this.J);
   }

   public final void a() {
   }

   public final void a(int var1, int var2, int var3) {
      c var4 = this.d;
      var4.b(var1, var2);
      var4.d(var3);
   }

   public final void a(int var1, int var2, String var3, String var4, String var5, String[] var6) {
      this.b = var1;
      this.m = var2;
      this.n = this.a(var3).a;
      this.o = var3;
      if (var4 != null) {
         this.p = this.d(var4);
      }

      byte var7 = 0;
      if (var5 == null) {
         var1 = 0;
      } else {
         var1 = this.a(var5).a;
      }

      this.q = var1;
      if (var6 != null && var6.length > 0) {
         this.r = var6.length;
         this.s = new int[this.r];

         for(var1 = var7; var1 < this.r; ++var1) {
            this.s[var1] = this.c(var6[var1]);
         }
      }

   }

   public final void a(b var1) {
      var1.c = this.z;
      this.z = var1;
   }

   public final void a(String var1, String var2) {
      if (var1 != null) {
         this.t = this.d(var1);
      }

      if (var2 != null) {
         c var3 = new c();
         var3.a(var2);
         this.u = var3;
      }

   }

   public final void a(String var1, String var2, String var3) {
      this.v = this.a(var1).a;
      if (var2 != null && var3 != null) {
         this.w = this.b(var2, var3);
      }

   }

   public final void a(String var1, String var2, String var3, int var4) {
      if (this.B == null) {
         this.B = new c();
      }

      ++this.A;
      c var5 = this.B;
      byte var6 = 0;
      int var7;
      if (var1 == null) {
         var7 = 0;
      } else {
         var7 = this.a(var1).a;
      }

      var5.d(var7);
      c var8 = this.B;
      if (var2 == null) {
         var7 = 0;
      } else {
         var7 = this.a(var2).a;
      }

      var8.d(var7);
      var8 = this.B;
      if (var3 == null) {
         var7 = var6;
      } else {
         var7 = this.d(var3);
      }

      var8.d(var7);
      this.B.d(var4);
   }

   public int b(String var1) {
      this.g.a(30, var1, (String)null, (String)null);
      l var2 = this.a(this.g);
      l var3 = var2;
      if (var2 == null) {
         var3 = this.b();
      }

      return var3.a;
   }

   public int b(String var1, String var2) {
      this.h.a(12, var1, var2, (String)null);
      l var3 = this.a(this.h);
      l var4 = var3;
      if (var3 == null) {
         this.a(12, this.d(var1), this.d(var2));
         int var5 = this.c++;
         var4 = new l(var5, this.h);
         this.b(var4);
      }

      return var4.a;
   }

   public final l b() {
      this.l = (short)((short)(this.l + 1));
      l var1 = new l(this.l, this.g);
      this.b(var1);
      if (this.k == null) {
         this.k = new l[16];
      }

      short var2 = this.l;
      l[] var3 = this.k;
      if (var2 == var3.length) {
         l[] var4 = new l[var3.length * 2];
         System.arraycopy(var3, 0, var4, 0, var3.length);
         this.k = var4;
      }

      this.k[this.l] = var1;
      return var1;
   }

   public l b(String var1, String var2, String var3) {
      this.i.a(9, var1, var2, var3);
      l var4 = this.a(this.i);
      l var5 = var4;
      if (var4 == null) {
         this.a(9, this.a(var1).a, this.b(var2, var3));
         int var6 = this.c++;
         var5 = new l(var6, this.i);
         this.b(var5);
      }

      return var5;
   }

   public final void b(l var1) {
      int var2;
      if (this.c + this.l > this.f) {
         var2 = this.e.length;
         int var3 = var2 * 2 + 1;
         l[] var4 = new l[var3];
         --var2;

         while(var2 >= 0) {
            l var7;
            for(l var5 = this.e[var2]; var5 != null; var5 = var7) {
               int var6 = var5.h % var4.length;
               var7 = var5.i;
               var5.i = var4[var6];
               var4[var6] = var5;
            }

            --var2;
         }

         this.e = var4;
         double var8 = (double)var3;
         Double.isNaN(var8);
         this.f = (int)(var8 * 0.75D);
      }

      var2 = var1.h;
      l[] var10 = this.e;
      var2 %= var10.length;
      var1.i = var10[var2];
      var10[var2] = var1;
   }

   public int c(String var1) {
      return this.a(var1).a;
   }

   public byte[] c() {
      if (this.c > 32767) {
         RuntimeException var33 = new RuntimeException("Class file too large!");
         throw var33;
      } else {
         int var2 = this.r * 2 + 24;
         h var3 = this.E;

         int var4;
         int var5;
         int var7;
         int var21;
         for(var4 = 0; var3 != null; var4 = var5) {
            var5 = var4 + 1;
            byte var6;
            if (var3.g != 0) {
               var3.b.d("ConstantValue");
               var6 = 16;
            } else {
               var6 = 8;
            }

            var7 = var3.c;
            var4 = var6;
            if ((var7 & 4096) != 0) {
               label653: {
                  if ((var3.b.b & '\uffff') >= 49) {
                     var4 = var6;
                     if ((var7 & 262144) == 0) {
                        break label653;
                     }
                  }

                  var3.b.d("Synthetic");
                  var4 = var6 + 6;
               }
            }

            var21 = var4;
            if ((var3.c & 131072) != 0) {
               var3.b.d("Deprecated");
               var21 = var4 + 6;
            }

            var4 = var21;
            if (var3.f != 0) {
               var3.b.d("Signature");
               var4 = var21 + 8;
            }

            var21 = var4;
            if (var3.h != null) {
               var3.b.d("RuntimeVisibleAnnotations");
               var21 = var4 + var3.h.a() + 8;
            }

            var4 = var21;
            if (var3.i != null) {
               var3.b.d("RuntimeInvisibleAnnotations");
               var4 = var21 + var3.i.a() + 8;
            }

            b var8 = var3.j;
            var21 = var4;
            if (var8 != null) {
               var21 = var4 + var8.a(var3.b, (byte[])null, 0, -1, -1);
            }

            var2 += var21;
            var3 = var3.a;
         }

         n var24 = this.G;
         int var9 = 0;

         while(true) {
            f var1 = this;
            int var12;
            c var17;
            b var19;
            byte var23;
            b var40;
            if (var24 == null) {
               var17 = this.D;
               if (var17 != null) {
                  var21 = var17.b;
                  this.d("BootstrapMethods");
                  var21 = var2 + var21 + 8;
                  var23 = 1;
               } else {
                  var23 = 0;
                  var21 = var2;
               }

               var5 = var23;
               var2 = var21;
               if (this.p != 0) {
                  var5 = var23 + 1;
                  var2 = var21 + 8;
                  this.d("Signature");
               }

               var7 = var5;
               var21 = var2;
               if (this.t != 0) {
                  var7 = var5 + 1;
                  var21 = var2 + 8;
                  this.d("SourceFile");
               }

               var17 = this.u;
               if (var17 != null) {
                  var5 = var7 + 1;
                  var2 = var21 + var17.b + 4;
                  this.d("SourceDebugExtension");
               } else {
                  var2 = var21;
                  var5 = var7;
               }

               var7 = var5;
               var21 = var2;
               if (this.v != 0) {
                  var7 = var5 + 1;
                  var21 = var2 + 10;
                  this.d("EnclosingMethod");
               }

               var5 = var7;
               var2 = var21;
               if ((this.m & 131072) != 0) {
                  var5 = var7 + 1;
                  var2 = var21 + 6;
                  this.d("Deprecated");
               }

               var12 = this.m;
               var7 = var5;
               var21 = var2;
               if ((var12 & 4096) != 0) {
                  label462: {
                     if ((this.b & '\uffff') >= 49) {
                        var7 = var5;
                        var21 = var2;
                        if ((var12 & 262144) == 0) {
                           break label462;
                        }
                     }

                     var7 = var5 + 1;
                     var21 = var2 + 6;
                     this.d("Synthetic");
                  }
               }

               var17 = this.B;
               if (var17 != null) {
                  ++var7;
                  var21 += var17.b + 8;
                  this.d("InnerClasses");
               }

               a var26 = this.x;
               var5 = var7;
               var2 = var21;
               if (var26 != null) {
                  var5 = var7 + 1;
                  var2 = var21 + var26.a() + 8;
                  this.d("RuntimeVisibleAnnotations");
               }

               var26 = this.y;
               var21 = var5;
               var7 = var2;
               if (var26 != null) {
                  var21 = var5 + 1;
                  var7 = var2 + var26.a() + 8;
                  this.d("RuntimeInvisibleAnnotations");
               }

               var19 = this.z;
               if (var19 != null) {
                  var2 = var19.a();
                  var7 += this.z.a(this, (byte[])null, 0, -1, -1);
                  var21 += var2;
               }

               c var25 = new c(var7 + this.d.b);
               var25.c(-889275714);
               var25.c(this.b);
               var25.d(this.c);
               var17 = this.d;
               var25.a(var17.a, 0, var17.b);
               var2 = this.m;
               var25.d(~(393216 | (var2 & 262144) / 64) & var2);
               var25.d(this.n);
               var25.d(this.q);
               var25.d(this.r);

               for(var2 = 0; var2 < var1.r; ++var2) {
                  var25.d(var1.s[var2]);
               }

               var25.d(var4);

               for(var3 = var1.E; var3 != null; var3 = var3.a) {
                  var2 = var3.c;
                  var25.d(var2 & ~((var2 & 262144) / 64 | 393216));
                  var25.d(var3.d);
                  var25.d(var3.e);
                  byte var27;
                  if (var3.g != 0) {
                     var27 = 1;
                  } else {
                     var27 = 0;
                  }

                  var5 = var3.c;
                  var2 = var27;
                  if ((var5 & 4096) != 0) {
                     label446: {
                        if ((var3.b.b & '\uffff') >= 49) {
                           var2 = var27;
                           if ((var5 & 262144) == 0) {
                              break label446;
                           }
                        }

                        var2 = var27 + 1;
                     }
                  }

                  var4 = var2;
                  if ((var3.c & 131072) != 0) {
                     var4 = var2 + 1;
                  }

                  var2 = var4;
                  if (var3.f != 0) {
                     var2 = var4 + 1;
                  }

                  var4 = var2;
                  if (var3.h != null) {
                     var4 = var2 + 1;
                  }

                  var2 = var4;
                  if (var3.i != null) {
                     var2 = var4 + 1;
                  }

                  var40 = var3.j;
                  var4 = var2;
                  if (var40 != null) {
                     var4 = var2 + var40.a();
                  }

                  var25.d(var4);
                  if (var3.g != 0) {
                     var25.d(var3.b.d("ConstantValue"));
                     var25.c(2);
                     var25.d(var3.g);
                  }

                  var2 = var3.c;
                  if ((var2 & 4096) != 0 && ((var3.b.b & '\uffff') < 49 || (var2 & 262144) != 0)) {
                     var25.d(var3.b.d("Synthetic"));
                     var25.c(0);
                  }

                  if ((var3.c & 131072) != 0) {
                     var25.d(var3.b.d("Deprecated"));
                     var25.c(0);
                  }

                  if (var3.f != 0) {
                     var25.d(var3.b.d("Signature"));
                     var25.c(2);
                     var25.d(var3.f);
                  }

                  if (var3.h != null) {
                     var25.d(var3.b.d("RuntimeVisibleAnnotations"));
                     var3.h.a(var25);
                  }

                  if (var3.i != null) {
                     var25.d(var3.b.d("RuntimeInvisibleAnnotations"));
                     var3.i.a(var25);
                  }

                  var40 = var3.j;
                  if (var40 != null) {
                     var40.a(var3.b, (byte[])null, 0, -1, -1, var25);
                  }
               }

               var25.d(var9);

               for(n var30 = var1.G; var30 != null; var30 = var30.a) {
                  var30.a(var25);
               }

               var25.d(var21);
               if (var1.D != null) {
                  var25.d(var1.d("BootstrapMethods"));
                  var25.c(var1.D.b + 2);
                  var25.d(var1.C);
                  var17 = var1.D;
                  var25.a(var17.a, 0, var17.b);
               }

               if (var1.p != 0) {
                  var25.d(var1.d("Signature"));
                  var25.c(2);
                  var25.d(var1.p);
               }

               if (var1.t != 0) {
                  var25.d(var1.d("SourceFile"));
                  var25.c(2);
                  var25.d(var1.t);
               }

               var17 = var1.u;
               if (var17 != null) {
                  var2 = var17.b - 2;
                  var25.d(var1.d("SourceDebugExtension"));
                  var25.c(var2);
                  var25.a(var1.u.a, 2, var2);
               }

               if (var1.v != 0) {
                  var25.d(var1.d("EnclosingMethod"));
                  var25.c(4);
                  var25.d(var1.v);
                  var25.d(var1.w);
               }

               if ((var1.m & 131072) != 0) {
                  var25.d(var1.d("Deprecated"));
                  var25.c(0);
               }

               var2 = var1.m;
               if ((var2 & 4096) != 0 && ((var1.b & '\uffff') < 49 || (var2 & 262144) != 0)) {
                  var25.d(var1.d("Synthetic"));
                  var25.c(0);
               }

               if (var1.B != null) {
                  var25.d(var1.d("InnerClasses"));
                  var25.c(var1.B.b + 2);
                  var25.d(var1.A);
                  var17 = var1.B;
                  var25.a(var17.a, 0, var17.b);
               }

               if (var1.x != null) {
                  var25.d(var1.d("RuntimeVisibleAnnotations"));
                  var1.x.a(var25);
               }

               if (var1.y != null) {
                  var25.d(var1.d("RuntimeInvisibleAnnotations"));
                  var1.y.a(var25);
               }

               var19 = var1.z;
               if (var19 != null) {
                  var19.a(this, (byte[])null, 0, -1, -1, var25);
               }

               if (var1.K) {
                  f var32 = new f(2);
                  (new d(var25.a)).a(var32, new b[0], 4);
                  return var32.c();
               }

               return var25.a;
            }

            var5 = var9 + 1;
            if (var24.h != 0) {
               var9 = var24.i + 6;
               var21 = var5;
               var7 = var4;
               var5 = var9;
               var4 = var21;
               var21 = var7;
               var7 = var2;
            } else {
               if (var24.M) {
                  var17 = var24.s;
                  byte[] var10 = var17.a;
                  boolean[] var11 = new boolean[var17.b];
                  int[] var18 = new int[0];
                  int[] var16 = new int[0];
                  var23 = 3;
                  var21 = var4;
                  var4 = var5;
                  var5 = var23;

                  label638:
                  while(true) {
                     var7 = var5;
                     if (var5 == 3) {
                        var7 = 2;
                     }

                     var12 = 0;
                     var5 = var2;

                     while(true) {
                        while(true) {
                           var2 = var10.length;
                           if (var12 >= var2) {
                              var2 = var7;
                              if (var7 < 3) {
                                 var2 = var7 - 1;
                              }

                              var7 = var2;
                              if (var2 == 0) {
                                 c var31 = new c(var24.s.b);
                                 var2 = 0;

                                 while(true) {
                                    while(var2 < var24.s.b) {
                                       label586: {
                                          label585: {
                                             label584: {
                                                var7 = var10[var2] & 255;
                                                label581:
                                                switch(L[var7]) {
                                                case 0:
                                                case 4:
                                                   var31.b(var7);
                                                   ++var2;
                                                   continue;
                                                case 1:
                                                case 3:
                                                case 11:
                                                   var31.a(var10, var2, 2);
                                                   var2 += 2;
                                                   continue;
                                                case 2:
                                                case 5:
                                                case 6:
                                                case 12:
                                                case 13:
                                                   var31.a(var10, var2, 3);
                                                   break label584;
                                                case 7:
                                                case 8:
                                                   var31.a(var10, var2, 5);
                                                   break label586;
                                                case 9:
                                                   if (var7 > 201) {
                                                      if (var7 < 218) {
                                                         var7 -= 49;
                                                      } else {
                                                         var7 -= 20;
                                                      }

                                                      var9 = c.b.d.e.a.a.a.n.c(var10, var2 + 1);
                                                   } else {
                                                      var9 = c.b.d.e.a.a.a.n.b(var10, var2 + 1);
                                                   }

                                                   var9 = c.b.d.e.a.a.a.n.a(var18, var16, var2, var9 + var2);
                                                   if (var11[var2]) {
                                                      label573: {
                                                         short var34;
                                                         if (var7 == 167) {
                                                            var34 = 200;
                                                         } else {
                                                            if (var7 != 168) {
                                                               if (var7 <= 166) {
                                                                  var7 = (var7 + 1 ^ 1) - 1;
                                                               } else {
                                                                  var7 ^= 1;
                                                               }

                                                               var31.b(var7);
                                                               var31.d(8);
                                                               var31.b(200);
                                                               var7 = var9 - 3;
                                                               break label573;
                                                            }

                                                            var34 = 201;
                                                         }

                                                         var31.b(var34);
                                                         var7 = var9;
                                                      }

                                                      var31.c(var7);
                                                   } else {
                                                      var31.b(var7);
                                                      var31.d(var9);
                                                   }
                                                   break label584;
                                                case 10:
                                                   var9 = c.b.d.e.a.a.a.n.a(var18, var16, var2, c.b.d.e.a.a.a.n.a(var10, var2 + 1) + var2);
                                                   var31.b(var7);
                                                   var31.c(var9);
                                                   break label586;
                                                case 14:
                                                   var9 = var2 + 4 - (var2 & 3);
                                                   var31.b(170);
                                                   var31.a((byte[])null, 0, (4 - var31.b % 4) % 4);
                                                   var7 = c.b.d.e.a.a.a.n.a(var10, var9);
                                                   var9 += 4;
                                                   var31.c(c.b.d.e.a.a.a.n.a(var18, var16, var2, var7 + var2));
                                                   var7 = c.b.d.e.a.a.a.n.a(var10, var9);
                                                   var9 += 4;
                                                   var31.c(var7);
                                                   var12 = c.b.d.e.a.a.a.n.a(var10, var9) - var7 + 1;
                                                   var7 = var9 + 4;
                                                   var31.c(c.b.d.e.a.a.a.n.a(var10, var7 - 4));

                                                   while(true) {
                                                      var9 = var7;
                                                      if (var12 <= 0) {
                                                         break label581;
                                                      }

                                                      var9 = c.b.d.e.a.a.a.n.a(var10, var7);
                                                      var7 += 4;
                                                      var31.c(c.b.d.e.a.a.a.n.a(var18, var16, var2, var9 + var2));
                                                      --var12;
                                                   }
                                                case 15:
                                                   var9 = var2 + 4 - (var2 & 3);
                                                   var31.b(171);
                                                   var31.a((byte[])null, 0, (4 - var31.b % 4) % 4);
                                                   var7 = c.b.d.e.a.a.a.n.a(var10, var9);
                                                   var9 += 4;
                                                   var31.c(c.b.d.e.a.a.a.n.a(var18, var16, var2, var7 + var2));
                                                   var12 = c.b.d.e.a.a.a.n.a(var10, var9);
                                                   var7 = var9 + 4;
                                                   var31.c(var12);

                                                   while(true) {
                                                      var9 = var7;
                                                      if (var12 <= 0) {
                                                         break label581;
                                                      }

                                                      var31.c(c.b.d.e.a.a.a.n.a(var10, var7));
                                                      var7 += 4;
                                                      var9 = c.b.d.e.a.a.a.n.a(var10, var7);
                                                      var7 += 4;
                                                      var31.c(c.b.d.e.a.a.a.n.a(var18, var16, var2, var9 + var2));
                                                      --var12;
                                                   }
                                                case 16:
                                                default:
                                                   break label585;
                                                case 17:
                                                   if ((var10[var2 + 1] & 255) == 132) {
                                                      var31.a(var10, var2, 6);
                                                      var2 += 6;
                                                      continue;
                                                   }
                                                   break label585;
                                                }

                                                var2 = var9;
                                                continue;
                                             }

                                             var2 += 3;
                                             continue;
                                          }

                                          var31.a(var10, var2, 4);
                                          var2 += 4;
                                          continue;
                                       }

                                       var2 += 5;
                                    }

                                    if (var24.w > 0) {
                                       if (var24.O != 0) {
                                          var24.b.K = true;
                                       } else {
                                          var24.w = 0;
                                          var24.x = null;
                                          var24.z = null;
                                          var24.B = null;
                                          i var28 = new i();
                                          var28.a = var24.P;
                                          p[] var35 = c.b.d.e.a.a.a.p.a(var24.f);
                                          var28.a(var24.b, var24.c, var35, var24.u);
                                          var24.a(var28);

                                          for(m var36 = var24.P; var36 != null; var36 = var36.i) {
                                             var2 = var36.c - 3;
                                             if ((var36.a & 32) != 0 || var2 >= 0 && var11[var2]) {
                                                c.b.d.e.a.a.a.n.a(var18, var16, var36);
                                                var24.a(var36.h);
                                             }
                                          }
                                       }
                                    }

                                    for(k var37 = var24.D; var37 != null; var37 = var37.f) {
                                       c.b.d.e.a.a.a.n.a(var18, var16, var37.a);
                                       c.b.d.e.a.a.a.n.a(var18, var16, var37.b);
                                       c.b.d.e.a.a.a.n.a(var18, var16, var37.c);
                                    }

                                    c var38;
                                    for(var2 = 0; var2 < 2; ++var2) {
                                       if (var2 == 0) {
                                          var38 = var24.G;
                                       } else {
                                          var38 = var24.I;
                                       }

                                       if (var38 != null) {
                                          byte[] var29 = var38.a;

                                          for(var7 = 0; var7 < var38.b; var7 += 10) {
                                             var12 = c.b.d.e.a.a.a.n.c(var29, var7);
                                             int var15 = c.b.d.e.a.a.a.n.a(var18, var16, 0, var12);
                                             var29[var7] = (byte)((byte)(var15 >>> 8));
                                             var29[var7 + 1] = (byte)((byte)var15);
                                             var9 = var7 + 2;
                                             var12 = c.b.d.e.a.a.a.n.a(var18, var16, 0, c.b.d.e.a.a.a.n.c(var29, var9) + var12) - var15;
                                             var29[var9] = (byte)((byte)(var12 >>> 8));
                                             var29[var9 + 1] = (byte)((byte)var12);
                                          }
                                       }
                                    }

                                    var38 = var24.K;
                                    if (var38 != null) {
                                       byte[] var39 = var38.a;

                                       for(var2 = 0; var2 < var24.K.b; var2 += 4) {
                                          var7 = c.b.d.e.a.a.a.n.a(var18, var16, 0, c.b.d.e.a.a.a.n.c(var39, var2));
                                          var39[var2] = (byte)((byte)(var7 >>> 8));
                                          var39[var2 + 1] = (byte)((byte)var7);
                                       }
                                    }

                                    for(var19 = var24.L; var19 != null; var19 = var19.c) {
                                    }

                                    var24.s = var31;
                                    break label638;
                                 }
                              }

                              var2 = var5;
                              var5 = var7;
                              continue label638;
                           }

                           label699: {
                              label623: {
                                 var2 = var10[var12] & 255;
                                 switch(L[var2]) {
                                 case 0:
                                 case 4:
                                    var2 = var12 + 1;
                                    break;
                                 case 1:
                                 case 3:
                                 case 11:
                                    var2 = var12 + 2;
                                    break;
                                 case 2:
                                 case 5:
                                 case 6:
                                 case 12:
                                 case 13:
                                    var2 = var12 + 3;
                                    break;
                                 case 7:
                                 case 8:
                                 case 10:
                                    var2 = var12 + 5;
                                    break;
                                 case 9:
                                    if (var2 > 201) {
                                       if (var2 < 218) {
                                          var2 -= 49;
                                       } else {
                                          var2 -= 20;
                                       }

                                       var9 = c.b.d.e.a.a.a.n.c(var10, var12 + 1);
                                    } else {
                                       var9 = c.b.d.e.a.a.a.n.b(var10, var12 + 1);
                                    }

                                    var9 = c.b.d.e.a.a.a.n.a(var18, var16, var12, var9 + var12);
                                    if ((var9 < -32768 || var9 > 32767) && !var11[var12]) {
                                       if (var2 != 167 && var2 != 168) {
                                          var9 = 5;
                                       } else {
                                          var9 = 2;
                                       }

                                       var11[var12] = true;
                                    } else {
                                       var9 = 0;
                                    }

                                    var2 = var12 + 3;
                                    break label699;
                                 case 14:
                                    if (var7 == 1) {
                                       var2 = -(c.b.d.e.a.a.a.n.a(var18, var16, 0, var12) & 3);
                                    } else if (!var11[var12]) {
                                       var2 = var12 & 3;
                                       var11[var12] = true;
                                    } else {
                                       var2 = 0;
                                    }

                                    var12 = var12 + 4 - (var12 & 3);
                                    var9 = (c.b.d.e.a.a.a.n.a(var10, var12 + 8) - c.b.d.e.a.a.a.n.a(var10, var12 + 4) + 1) * 4 + 12;
                                    break label623;
                                 case 15:
                                    if (var7 == 1) {
                                       var2 = -(c.b.d.e.a.a.a.n.a(var18, var16, 0, var12) & 3);
                                    } else if (!var11[var12]) {
                                       var2 = var12 & 3;
                                       var11[var12] = true;
                                    } else {
                                       var2 = 0;
                                    }

                                    var12 = var12 + 4 - (var12 & 3);
                                    var9 = c.b.d.e.a.a.a.n.a(var10, var12 + 4) * 8 + 8;
                                    break label623;
                                 case 17:
                                    if ((var10[var12 + 1] & 255) == 132) {
                                       var2 = var12 + 6;
                                       break;
                                    }
                                 case 16:
                                 default:
                                    var2 = var12 + 4;
                                 }

                                 var9 = 0;
                                 break label699;
                              }

                              var12 += var9;
                              var9 = var2;
                              var2 = var12;
                           }

                           if (var9 != 0) {
                              int[] var13 = new int[var18.length + 1];
                              int[] var14 = new int[var16.length + 1];
                              System.arraycopy(var18, 0, var13, 0, var18.length);
                              System.arraycopy(var16, 0, var14, 0, var16.length);
                              var13[var18.length] = var2;
                              var14[var16.length] = var9;
                              if (var9 > 0) {
                                 var18 = var13;
                                 var16 = var14;
                                 var7 = 3;
                                 var12 = var2;
                                 continue;
                              }

                              var18 = var13;
                              var16 = var14;
                           }

                           var12 = var2;
                        }
                     }
                  }
               } else {
                  var21 = var2;
                  var2 = var5;
                  var5 = var21;
                  var21 = var4;
                  var4 = var2;
               }

               var2 = var24.s.b;
               if (var2 > 0) {
                  if (var2 > 65536) {
                     throw new RuntimeException("Method code too large!");
                  }

                  var24.b.d("Code");
                  var2 = var24.s.b;
                  var7 = var24.C * 8 + var2 + 18 + 8;
                  var2 = var7;
                  if (var24.G != null) {
                     var24.b.d("LocalVariableTable");
                     var2 = var7 + var24.G.b + 8;
                  }

                  var7 = var2;
                  if (var24.I != null) {
                     var24.b.d("LocalVariableTypeTable");
                     var7 = var2 + var24.I.b + 8;
                  }

                  var2 = var7;
                  if (var24.K != null) {
                     var24.b.d("LineNumberTable");
                     var2 = var7 + var24.K.b + 8;
                  }

                  var7 = var2;
                  if (var24.x != null) {
                     boolean var41;
                     if ((var24.b.b & '\uffff') >= 50) {
                        var41 = true;
                     } else {
                        var41 = false;
                     }

                     var1 = var24.b;
                     String var20;
                     if (var41) {
                        var20 = "StackMapTable";
                     } else {
                        var20 = "StackMap";
                     }

                     var1.d(var20);
                     var7 = var24.x.b + 8 + var2;
                  }

                  var40 = var24.L;
                  var2 = var7;
                  if (var40 != null) {
                     var1 = var24.b;
                     var17 = var24.s;
                     var2 = var7 + var40.a(var1, var17.a, var17.b, var24.t, var24.u);
                  }
               } else {
                  var2 = 8;
               }

               var7 = var2;
               if (var24.j > 0) {
                  var24.b.d("Exceptions");
                  var7 = var2 + var24.j * 2 + 8;
               }

               var9 = var24.c;
               var2 = var7;
               if ((var9 & 4096) != 0) {
                  label499: {
                     if ((var24.b.b & '\uffff') >= 49) {
                        var2 = var7;
                        if ((var9 & 262144) == 0) {
                           break label499;
                        }
                     }

                     var24.b.d("Synthetic");
                     var2 = var7 + 6;
                  }
               }

               var7 = var2;
               if ((var24.c & 131072) != 0) {
                  var24.b.d("Deprecated");
                  var7 = var2 + 6;
               }

               var2 = var7;
               if (var24.g != null) {
                  var24.b.d("Signature");
                  var24.b.d(var24.g);
                  var2 = var7 + 8;
               }

               var7 = var2;
               if (var24.l != null) {
                  var24.b.d("AnnotationDefault");
                  var7 = var2 + var24.l.b + 6;
               }

               if (var24.m != null) {
                  var24.b.d("RuntimeVisibleAnnotations");
                  var2 = var7 + var24.m.a() + 8;
               } else {
                  var2 = var7;
               }

               var7 = var2;
               if (var24.n != null) {
                  var24.b.d("RuntimeInvisibleAnnotations");
                  var7 = var2 + var24.n.a() + 8;
               }

               var2 = var7;
               a[] var22;
               if (var24.o != null) {
                  var24.b.d("RuntimeVisibleParameterAnnotations");
                  var22 = var24.o;
                  var2 = var22.length;
                  var12 = var24.q;
                  var9 = var22.length - 1;
                  var7 += (var2 - var12) * 2 + 7;

                  while(true) {
                     var2 = var7;
                     if (var9 < var24.q) {
                        break;
                     }

                     var22 = var24.o;
                     if (var22[var9] == null) {
                        var2 = 0;
                     } else {
                        var2 = var22[var9].a();
                     }

                     var7 += var2;
                     --var9;
                  }
               }

               var7 = var2;
               if (var24.p != null) {
                  var24.b.d("RuntimeInvisibleParameterAnnotations");
                  var22 = var24.p;
                  var7 = var22.length;
                  var12 = var24.q;
                  var9 = var22.length - 1;
                  var2 += (var7 - var12) * 2 + 7;

                  while(true) {
                     var7 = var2;
                     if (var9 < var24.q) {
                        break;
                     }

                     var22 = var24.p;
                     if (var22[var9] == null) {
                        var7 = 0;
                     } else {
                        var7 = var22[var9].a();
                     }

                     var2 += var7;
                     --var9;
                  }
               }

               var19 = var24.r;
               var2 = var7;
               if (var19 != null) {
                  var2 = var7 + var19.a(var24.b, (byte[])null, 0, -1, -1);
               }

               var7 = var5;
               var5 = var2;
            }

            var2 = var7 + var5;
            var24 = var24.a;
            var9 = var4;
            var4 = var21;
         }
      }
   }

   public int d(String var1) {
      this.g.a(1, var1, (String)null, (String)null);
      l var2 = this.a(this.g);
      l var3 = var2;
      if (var2 == null) {
         c var5 = this.d;
         var5.b(1);
         var5.a(var1);
         int var4 = this.c++;
         var3 = new l(var4, this.g);
         this.b(var3);
      }

      return var3.a;
   }
}
