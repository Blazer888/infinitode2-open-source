package c.b.d.e.a.a.a;

public final class i {
   public static final int[] i;
   public m a;
   public int[] b;
   public int[] c;
   public int[] d;
   public int[] e;
   public int f;
   public int g;
   public int[] h;

   static {
      int[] var0 = new int[202];

      for(int var1 = 0; var1 < var0.length; ++var1) {
         var0[var1] = "EFFFFFFFFGGFFFGGFFFEEFGFGFEEEEEEEEEEEEEEEEEEEEDEDEDDDDDCDCDEEEEEEEEEEEEEEEEEEEEBABABBBBDCFFFGGGEDCDCDCDCDCDCDCDCDCDCEEEEDDDDDDDCDCDCEFEFDDEEFFDEDEEEBDDBBDDDDDDCCCCCCCCEFEDDDCDCDEEEEEEEEEEFEEEEEEDDEEDDEE".charAt(var1) - 69;
      }

      i = var0;
   }

   public static boolean a(f var0, int var1, int[] var2, int var3) {
      int var4 = var2[var3];
      if (var4 == var1) {
         return false;
      } else {
         int var5 = var1;
         if ((268435455 & var1) == 16777221) {
            if (var4 == 16777221) {
               return false;
            }

            var5 = 16777221;
         }

         if (var4 == 0) {
            var2[var3] = var5;
            return true;
         } else {
            var1 = var4 & 267386880;
            int var6 = 16777216;
            if (var1 != 24117248 && (var4 & -268435456) == 0) {
               var1 = var6;
               if (var4 == 16777221) {
                  label79: {
                     if ((var5 & 267386880) != 24117248) {
                        var1 = var6;
                        if ((var5 & -268435456) == 0) {
                           break label79;
                        }
                     }

                     var1 = var5;
                  }
               }
            } else {
               label97: {
                  if (var5 == 16777221) {
                     return false;
                  }

                  String var7 = "java/lang/Object";
                  if ((var5 & -1048576) == (-1048576 & var4)) {
                     if (var1 == 24117248) {
                        var1 = var5 & 1048575;
                        var6 = 1048575 & var4;
                        l var8 = var0.h;
                        var8.b = 32;
                        var8.d = (long)var1 | (long)var6 << 32;
                        var8.h = var1 + 32 + var6 & Integer.MAX_VALUE;
                        l var9 = var0.a(var8);
                        var8 = var9;
                        if (var9 == null) {
                           l[] var16 = var0.k;
                           String var15 = var16[var1].e;
                           String var10 = var16[var6].e;
                           l var11 = var0.h;
                           ClassLoader var12 = f.class.getClassLoader();

                           Class var17;
                           Class var19;
                           try {
                              var17 = Class.forName(var15.replace('/', '.'), false, var12);
                              var19 = Class.forName(var10.replace('/', '.'), false, var12);
                           } catch (Exception var13) {
                              throw new RuntimeException(var13.toString());
                           }

                           if (!var17.isAssignableFrom(var19)) {
                              if (var19.isAssignableFrom(var17)) {
                                 var15 = var10;
                              } else {
                                 var15 = var7;
                                 if (!var17.isInterface()) {
                                    Class var18 = var17;
                                    if (var19.isInterface()) {
                                       var15 = var7;
                                    } else {
                                       Class var14;
                                       do {
                                          var14 = var18.getSuperclass();
                                          var18 = var14;
                                       } while(!var14.isAssignableFrom(var19));

                                       var15 = var14.getName().replace('.', '/');
                                    }
                                 }
                              }
                           }

                           var11.c = var0.b(var15);
                           var8 = new l(0, var0.h);
                           var0.b(var8);
                        }

                        var1 = var5 & -268435456 | 24117248 | var8.c;
                        break label97;
                     }
                  } else if ((var5 & 267386880) != 24117248) {
                     var1 = var6;
                     if ((var5 & -268435456) == 0) {
                        break label97;
                     }
                  }

                  var1 = var0.b("java/lang/Object") | 24117248;
               }
            }

            if (var4 != var1) {
               var2[var3] = var1;
               return true;
            } else {
               return false;
            }
         }
      }
   }

   public static int b(f var0, String var1) {
      int var2;
      if (var1.charAt(0) == '(') {
         var2 = var1.indexOf(41) + 1;
      } else {
         var2 = 0;
      }

      char var3 = var1.charAt(var2);
      int var4 = 16777218;
      if (var3 != 'F') {
         if (var3 == 'L') {
            return var0.b(var1.substring(var2 + 1, var1.length() - 1)) | 24117248;
         } else {
            if (var3 != 'S') {
               if (var3 == 'V') {
                  return 0;
               }

               if (var3 != 'Z' && var3 != 'I') {
                  if (var3 == 'J') {
                     return 16777220;
                  }

                  switch(var3) {
                  case 'B':
                  case 'C':
                     break;
                  case 'D':
                     return 16777219;
                  default:
                     int var6;
                     for(var6 = var2 + 1; var1.charAt(var6) == '['; ++var6) {
                     }

                     char var5 = var1.charAt(var6);
                     if (var5 != 'F') {
                        if (var5 != 'S') {
                           if (var5 != 'Z') {
                              if (var5 != 'I') {
                                 if (var5 != 'J') {
                                    switch(var5) {
                                    case 'B':
                                       var4 = 16777226;
                                       break;
                                    case 'C':
                                       var4 = 16777227;
                                       break;
                                    case 'D':
                                       var4 = 16777219;
                                       break;
                                    default:
                                       var4 = var0.b(var1.substring(var6 + 1, var1.length() - 1)) | 24117248;
                                    }
                                 } else {
                                    var4 = 16777220;
                                 }
                              } else {
                                 var4 = 16777217;
                              }
                           } else {
                              var4 = 16777225;
                           }
                        } else {
                           var4 = 16777228;
                        }
                     }

                     return var6 - var2 << 28 | var4;
                  }
               }
            }

            return 16777217;
         }
      } else {
         return 16777218;
      }
   }

   public final int a() {
      int var1 = this.f;
      if (var1 > 0) {
         int[] var3 = this.e;
         --var1;
         this.f = var1;
         return var3[var1];
      } else {
         m var2 = this.a;
         var1 = var2.f - 1;
         var2.f = var1;
         return 50331648 | -var1;
      }
   }

   public final int a(int var1) {
      int[] var2 = this.d;
      if (var2 != null && var1 < var2.length) {
         int var3 = var2[var1];
         int var4 = var3;
         if (var3 == 0) {
            var4 = var1 | 33554432;
            var2[var1] = var4;
         }

         return var4;
      } else {
         return var1 | 33554432;
      }
   }

   public final int a(f var1, int var2) {
      String var3;
      if (var2 == 16777222) {
         var3 = var1.o;
      } else {
         if ((-1048576 & var2) != 25165824) {
            return var2;
         }

         var3 = var1.k[1048575 & var2].e;
      }

      int var4 = var1.b(var3);

      for(int var5 = 0; var5 < this.g; ++var5) {
         int var8;
         label28: {
            int var6 = this.h[var5];
            int var7 = 251658240 & var6;
            if (var7 == 33554432) {
               var8 = this.b[var6 & 8388607];
            } else {
               var8 = var6;
               if (var7 != 50331648) {
                  break label28;
               }

               int[] var9 = this.c;
               var8 = var9[var9.length - (var6 & 8388607)];
            }

            var8 += -268435456 & var6;
         }

         if (var2 == var8) {
            return var4 | 24117248;
         }
      }

      return var2;
   }

   public final void a(int var1, int var2) {
      if (this.d == null) {
         this.d = new int[10];
      }

      int var3 = this.d.length;
      if (var1 >= var3) {
         int[] var4 = new int[Math.max(var1 + 1, var3 * 2)];
         System.arraycopy(this.d, 0, var4, 0, var3);
         this.d = var4;
      }

      this.d[var1] = var2;
   }

   public void a(int var1, int var2, f var3, l var4) {
      String var8;
      label443: {
         label444: {
            label445: {
               label446: {
                  label447: {
                     label448: {
                        label449: {
                           if (var1 != 198 && var1 != 199) {
                              label381: {
                                 label315: {
                                    label382: {
                                       label383: {
                                          label309: {
                                             label384: {
                                                label305: {
                                                   label294:
                                                   switch(var1) {
                                                   case 0:
                                                      return;
                                                   case 1:
                                                      var1 = 16777221;
                                                      break label449;
                                                   case 2:
                                                   case 3:
                                                   case 4:
                                                   case 5:
                                                   case 6:
                                                   case 7:
                                                   case 8:
                                                   case 16:
                                                   case 17:
                                                      break label448;
                                                   case 9:
                                                   case 10:
                                                      break;
                                                   case 11:
                                                   case 12:
                                                   case 13:
                                                      break label446;
                                                   case 14:
                                                   case 15:
                                                      break label305;
                                                   case 18:
                                                      var1 = var4.b;
                                                      if (var1 == 16) {
                                                         var8 = "java/lang/invoke/MethodType";
                                                         break label309;
                                                      }

                                                      switch(var1) {
                                                      case 3:
                                                         break label448;
                                                      case 4:
                                                         break label446;
                                                      case 5:
                                                         break label294;
                                                      case 6:
                                                         break label305;
                                                      case 7:
                                                         var8 = "java/lang/Class";
                                                         break label309;
                                                      case 8:
                                                         var8 = "java/lang/String";
                                                         break label309;
                                                      default:
                                                         var8 = "java/lang/invoke/MethodHandle";
                                                         break label309;
                                                      }
                                                   default:
                                                      switch(var1) {
                                                      case 21:
                                                         break label448;
                                                      case 22:
                                                         break;
                                                      case 23:
                                                         break label446;
                                                      case 24:
                                                         break label305;
                                                      case 25:
                                                         var1 = this.a(var2);
                                                         break label449;
                                                      default:
                                                         label451: {
                                                            label452: {
                                                               int var6;
                                                               switch(var1) {
                                                               case 46:
                                                               case 51:
                                                               case 52:
                                                               case 53:
                                                                  break label383;
                                                               case 47:
                                                                  break;
                                                               case 48:
                                                                  break label382;
                                                               case 49:
                                                                  break label452;
                                                               case 50:
                                                                  this.c(1);
                                                                  var1 = this.a() - 268435456;
                                                                  break label449;
                                                               case 54:
                                                               case 56:
                                                               case 58:
                                                                  this.a(var2, this.a());
                                                                  if (var2 <= 0) {
                                                                     return;
                                                                  }

                                                                  --var2;
                                                                  var6 = this.a(var2);
                                                                  var1 = var2;
                                                                  if (var6 != 16777220) {
                                                                     if (var6 != 16777219) {
                                                                        if ((var6 & 251658240) == 16777216) {
                                                                           return;
                                                                        }

                                                                        var1 = var6;
                                                                        break label444;
                                                                     }

                                                                     var1 = var2;
                                                                  }
                                                                  break label445;
                                                               case 55:
                                                               case 57:
                                                                  this.c(1);
                                                                  this.a(var2, this.a());
                                                                  this.a(var2 + 1, 16777216);
                                                                  if (var2 <= 0) {
                                                                     return;
                                                                  }

                                                                  --var2;
                                                                  var6 = this.a(var2);
                                                                  var1 = var2;
                                                                  if (var6 != 16777220) {
                                                                     if (var6 != 16777219) {
                                                                        if ((var6 & 251658240) == 16777216) {
                                                                           return;
                                                                        }

                                                                        var1 = var6;
                                                                        break label444;
                                                                     }

                                                                     var1 = var2;
                                                                  }
                                                                  break label445;
                                                               default:
                                                                  label450: {
                                                                     label281: {
                                                                        label280: {
                                                                           String var5;
                                                                           switch(var1) {
                                                                           case 79:
                                                                           case 81:
                                                                           case 83:
                                                                           case 84:
                                                                           case 85:
                                                                           case 86:
                                                                              this.c(3);
                                                                              return;
                                                                           case 80:
                                                                           case 82:
                                                                              this.c(4);
                                                                              return;
                                                                           case 87:
                                                                           case 153:
                                                                           case 154:
                                                                           case 155:
                                                                           case 156:
                                                                           case 157:
                                                                           case 158:
                                                                           case 170:
                                                                           case 171:
                                                                           case 172:
                                                                           case 174:
                                                                           case 176:
                                                                           case 191:
                                                                           case 194:
                                                                           case 195:
                                                                              break label381;
                                                                           case 88:
                                                                           case 159:
                                                                           case 160:
                                                                           case 161:
                                                                           case 162:
                                                                           case 163:
                                                                           case 164:
                                                                           case 165:
                                                                           case 166:
                                                                           case 173:
                                                                           case 175:
                                                                              this.c(2);
                                                                              return;
                                                                           case 89:
                                                                              var1 = this.a();
                                                                              this.b(var1);
                                                                              break label449;
                                                                           case 90:
                                                                              var1 = this.a();
                                                                              var2 = this.a();
                                                                              break label280;
                                                                           case 91:
                                                                              var1 = this.a();
                                                                              var2 = this.a();
                                                                              var6 = this.a();
                                                                              break;
                                                                           case 92:
                                                                              var1 = this.a();
                                                                              var2 = this.a();
                                                                              this.b(var2);
                                                                              break label280;
                                                                           case 93:
                                                                              var1 = this.a();
                                                                              var2 = this.a();
                                                                              var6 = this.a();
                                                                              this.b(var2);
                                                                              break;
                                                                           case 94:
                                                                              var1 = this.a();
                                                                              var2 = this.a();
                                                                              var6 = this.a();
                                                                              int var7 = this.a();
                                                                              this.b(var2);
                                                                              this.b(var1);
                                                                              this.b(var7);
                                                                              break label281;
                                                                           case 95:
                                                                              var1 = this.a();
                                                                              var2 = this.a();
                                                                              this.b(var1);
                                                                              this.b(var2);
                                                                              return;
                                                                           case 96:
                                                                           case 100:
                                                                           case 104:
                                                                           case 108:
                                                                           case 112:
                                                                           case 120:
                                                                           case 122:
                                                                           case 124:
                                                                           case 126:
                                                                           case 128:
                                                                           case 130:
                                                                           case 136:
                                                                           case 142:
                                                                           case 149:
                                                                           case 150:
                                                                              break label383;
                                                                           case 97:
                                                                           case 101:
                                                                           case 105:
                                                                           case 109:
                                                                           case 113:
                                                                           case 127:
                                                                           case 129:
                                                                           case 131:
                                                                              this.c(4);
                                                                              break label451;
                                                                           case 98:
                                                                           case 102:
                                                                           case 106:
                                                                           case 110:
                                                                           case 114:
                                                                           case 137:
                                                                           case 144:
                                                                              break label382;
                                                                           case 99:
                                                                           case 103:
                                                                           case 107:
                                                                           case 111:
                                                                           case 115:
                                                                              this.c(4);
                                                                              break label305;
                                                                           case 116:
                                                                           case 117:
                                                                           case 118:
                                                                           case 119:
                                                                           case 145:
                                                                           case 146:
                                                                           case 147:
                                                                           case 167:
                                                                           case 177:
                                                                              return;
                                                                           case 121:
                                                                           case 123:
                                                                           case 125:
                                                                              this.c(3);
                                                                              break label451;
                                                                           case 132:
                                                                              this.a(var2, 16777217);
                                                                              return;
                                                                           case 133:
                                                                           case 140:
                                                                              this.c(1);
                                                                              break label451;
                                                                           case 134:
                                                                              this.c(1);
                                                                              break label446;
                                                                           case 135:
                                                                           case 141:
                                                                              this.c(1);
                                                                              break label305;
                                                                           case 138:
                                                                              break label452;
                                                                           case 139:
                                                                           case 190:
                                                                           case 193:
                                                                              this.c(1);
                                                                              break label448;
                                                                           case 143:
                                                                              break label450;
                                                                           case 148:
                                                                           case 151:
                                                                           case 152:
                                                                              this.c(4);
                                                                              break label448;
                                                                           case 168:
                                                                           case 169:
                                                                              throw new RuntimeException("JSR/RET are not supported with computeFrames option");
                                                                           case 178:
                                                                              break label315;
                                                                           case 179:
                                                                              this.a(var4.g);
                                                                              return;
                                                                           case 180:
                                                                              this.c(1);
                                                                              break label315;
                                                                           case 181:
                                                                              this.a(var4.g);
                                                                              this.a();
                                                                              return;
                                                                           case 182:
                                                                           case 183:
                                                                           case 184:
                                                                           case 185:
                                                                              this.a(var4.g);
                                                                              if (var1 != 184) {
                                                                                 var2 = this.a();
                                                                                 if (var1 == 183 && var4.f.charAt(0) == '<') {
                                                                                    if (this.h == null) {
                                                                                       this.h = new int[2];
                                                                                    }

                                                                                    var6 = this.h.length;
                                                                                    var1 = this.g;
                                                                                    int[] var9;
                                                                                    if (var1 >= var6) {
                                                                                       var9 = new int[Math.max(var1 + 1, var6 * 2)];
                                                                                       System.arraycopy(this.h, 0, var9, 0, var6);
                                                                                       this.h = var9;
                                                                                    }

                                                                                    var9 = this.h;
                                                                                    var1 = this.g++;
                                                                                    var9[var1] = var2;
                                                                                 }
                                                                              }
                                                                              break label315;
                                                                           case 186:
                                                                              this.a(var4.f);
                                                                              var8 = var4.f;
                                                                              break label443;
                                                                           case 187:
                                                                              var1 = 25165824 | var3.a(var4.e, var2);
                                                                              break label449;
                                                                           case 188:
                                                                              this.a();
                                                                              switch(var2) {
                                                                              case 4:
                                                                                 var1 = 285212681;
                                                                                 break label449;
                                                                              case 5:
                                                                                 var1 = 285212683;
                                                                                 break label449;
                                                                              case 6:
                                                                                 var1 = 285212674;
                                                                                 break label449;
                                                                              case 7:
                                                                                 var1 = 285212675;
                                                                                 break label449;
                                                                              case 8:
                                                                                 var1 = 285212682;
                                                                                 break label449;
                                                                              case 9:
                                                                                 var1 = 285212684;
                                                                                 break label449;
                                                                              case 10:
                                                                                 var1 = 285212673;
                                                                                 break label449;
                                                                              default:
                                                                                 var1 = 285212676;
                                                                                 break label449;
                                                                              }
                                                                           case 189:
                                                                              var5 = var4.e;
                                                                              this.a();
                                                                              if (var5.charAt(0) == '[') {
                                                                                 StringBuffer var10 = new StringBuffer();
                                                                                 var10.append('[');
                                                                                 var10.append(var5);
                                                                                 var8 = var10.toString();
                                                                                 break label443;
                                                                              }

                                                                              var1 = var3.b(var5) | 292552704;
                                                                              break label449;
                                                                           case 192:
                                                                              var5 = var4.e;
                                                                              this.a();
                                                                              var8 = var5;
                                                                              if (var5.charAt(0) == '[') {
                                                                                 var8 = var5;
                                                                                 break label443;
                                                                              }
                                                                              break label309;
                                                                           default:
                                                                              this.c(var2);
                                                                              var8 = var4.e;
                                                                              break label443;
                                                                           }

                                                                           this.b(var1);
                                                                           break label281;
                                                                        }

                                                                        this.b(var1);
                                                                        break label384;
                                                                     }

                                                                     this.b(var6);
                                                                     break label384;
                                                                  }
                                                               }

                                                               this.c(2);
                                                               break label451;
                                                            }

                                                            this.c(2);
                                                            break label305;
                                                         }
                                                      }
                                                   }

                                                   this.b(16777220);
                                                   break label447;
                                                }

                                                this.b(16777219);
                                                break label447;
                                             }

                                             this.b(var2);
                                             break label449;
                                          }

                                          var1 = var3.b(var8) | 24117248;
                                          break label449;
                                       }

                                       this.c(2);
                                       break label448;
                                    }

                                    this.c(2);
                                    break label446;
                                 }

                                 var8 = var4.g;
                                 break label443;
                              }
                           }

                           this.c(1);
                           return;
                        }

                        this.b(var1);
                        return;
                     }

                     this.b(16777217);
                     return;
                  }

                  this.b(16777216);
                  return;
               }

               this.b(16777218);
               return;
            }

            this.a(var1, 16777216);
            return;
         }

         this.a(var2, var1 | 8388608);
         return;
      }

      this.a(var3, var8);
   }

   public void a(f var1, int var2, p[] var3, int var4) {
      this.b = new int[var4];
      int var5 = 0;
      this.c = new int[0];
      byte var6 = 1;
      if ((var2 & 8) == 0) {
         if ((var2 & 262144) == 0) {
            this.b[0] = 24117248 | var1.b(var1.o);
            var2 = var6;
         } else {
            this.b[0] = 16777222;
            var2 = var6;
         }
      } else {
         var2 = 0;
      }

      while(true) {
         int var9 = var2;
         if (var5 >= var3.length) {
            while(var9 < var4) {
               this.b[var9] = 16777216;
               ++var9;
            }

            return;
         }

         int var7 = b(var1, var3[var5].b());
         int[] var8 = this.b;
         var9 = var2 + 1;
         var8[var2] = var7;
         if (var7 != 16777220 && var7 != 16777219) {
            var2 = var9;
         } else {
            var8 = this.b;
            var2 = var9 + 1;
            var8[var9] = 16777216;
         }

         ++var5;
      }
   }

   public final void a(f var1, String var2) {
      int var3 = b(var1, var2);
      if (var3 != 0) {
         this.b(var3);
         if (var3 == 16777220 || var3 == 16777219) {
            this.b(16777216);
         }
      }

   }

   public final void a(String var1) {
      char var2 = var1.charAt(0);
      if (var2 == '(') {
         this.c((p.b(var1) >> 2) - 1);
      } else if (var2 != 'J' && var2 != 'D') {
         this.c(1);
      } else {
         this.c(2);
      }

   }

   public final void b(int var1) {
      if (this.e == null) {
         this.e = new int[10];
      }

      int var2 = this.e.length;
      int var3 = this.f;
      int[] var4;
      if (var3 >= var2) {
         var4 = new int[Math.max(var3 + 1, var2 * 2)];
         System.arraycopy(this.e, 0, var4, 0, var2);
         this.e = var4;
      }

      var4 = this.e;
      var3 = this.f++;
      var4[var3] = var1;
      m var5 = this.a;
      var1 = var5.f + this.f;
      if (var1 > var5.g) {
         var5.g = var1;
      }

   }

   public final void c(int var1) {
      int var2 = this.f;
      if (var2 >= var1) {
         this.f = var2 - var1;
      } else {
         m var3 = this.a;
         var3.f -= var1 - var2;
         this.f = 0;
      }

   }
}
