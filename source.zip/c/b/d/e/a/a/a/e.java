package c.b.d.e.a.a.a;

public abstract class e {
   public e(int var1) {
   }

   public abstract a a(String var1, boolean var2);

   public abstract h a(int var1, String var2, String var3, String var4, Object var5);

   public abstract n a(int var1, String var2, String var3, String var4, String[] var5);

   public abstract void a();

   public abstract void a(int var1, int var2, String var3, String var4, String var5, String[] var6);

   public abstract void a(b var1);

   public abstract void a(String var1, String var2);

   public abstract void a(String var1, String var2, String var3);

   public abstract void a(String var1, String var2, String var3, int var4);
}
