package c.b.d.e.a.a.a;

public final class l {
   public int a;
   public int b;
   public int c;
   public long d;
   public String e;
   public String f;
   public String g;
   public int h;
   public l i;

   public l() {
   }

   public l(int var1) {
      this.a = var1;
   }

   public l(int var1, l var2) {
      this.a = var1;
      this.b = var2.b;
      this.c = var2.c;
      this.d = var2.d;
      this.e = var2.e;
      this.f = var2.f;
      this.g = var2.g;
      this.h = var2.h;
   }

   public void a(int var1, String var2, String var3, String var4) {
      label25: {
         int var6;
         label24: {
            this.b = var1;
            this.e = var2;
            this.f = var3;
            this.g = var4;
            if (var1 != 1) {
               if (var1 == 12) {
                  var6 = var2.hashCode();
                  var1 = var3.hashCode() * var6 + var1 & Integer.MAX_VALUE;
                  break label25;
               }

               if (var1 != 16 && var1 != 30 && var1 != 7 && var1 != 8) {
                  int var5 = var2.hashCode();
                  var6 = var3.hashCode();
                  var6 = var4.hashCode() * var6 * var5;
                  break label24;
               }
            }

            var6 = var2.hashCode();
         }

         var1 = var6 + var1 & Integer.MAX_VALUE;
      }

      this.h = var1;
   }
}
