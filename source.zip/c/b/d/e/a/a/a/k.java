package c.b.d.e.a.a.a;

public class k {
   public m a;
   public m b;
   public m c;
   public String d;
   public int e;
   public k f;

   public static k a(k var0, m var1, m var2) {
      if (var0 == null) {
         return null;
      } else {
         var0.f = a(var0.f, var1, var2);
         int var3 = var0.a.c;
         int var4 = var0.b.c;
         int var5 = var1.c;
         int var6;
         if (var2 == null) {
            var6 = Integer.MAX_VALUE;
         } else {
            var6 = var2.c;
         }

         k var7 = var0;
         if (var5 < var4) {
            var7 = var0;
            if (var6 > var3) {
               if (var5 <= var3) {
                  if (var6 >= var4) {
                     var7 = var0.f;
                  } else {
                     var0.a = var2;
                     var7 = var0;
                  }
               } else if (var6 >= var4) {
                  var0.b = var1;
                  var7 = var0;
               } else {
                  var7 = new k();
                  var7.a = var2;
                  var7.b = var0.b;
                  var7.c = var0.c;
                  var7.d = var0.d;
                  var7.e = var0.e;
                  var7.f = var0.f;
                  var0.b = var1;
                  var0.f = var7;
                  var7 = var0;
               }
            }
         }

         return var7;
      }
   }
}
