package c.b.d.e.a.a.a;

public class c {
   public byte[] a;
   public int b;

   public c() {
      this.a = new byte[64];
   }

   public c(int var1) {
      this.a = new byte[var1];
   }

   public c a(int var1, int var2) {
      int var3 = this.b;
      if (var3 + 2 > this.a.length) {
         this.a(2);
      }

      byte[] var4 = this.a;
      int var5 = var3 + 1;
      var4[var3] = (byte)((byte)var1);
      var4[var5] = (byte)((byte)var2);
      this.b = var5 + 1;
      return this;
   }

   public c a(long var1) {
      int var3 = this.b;
      if (var3 + 8 > this.a.length) {
         this.a(8);
      }

      byte[] var4 = this.a;
      int var5 = (int)(var1 >>> 32);
      int var6 = var3 + 1;
      var4[var3] = (byte)((byte)(var5 >>> 24));
      var3 = var6 + 1;
      var4[var6] = (byte)((byte)(var5 >>> 16));
      var6 = var3 + 1;
      var4[var3] = (byte)((byte)(var5 >>> 8));
      var3 = var6 + 1;
      var4[var6] = (byte)((byte)var5);
      var5 = (int)var1;
      var6 = var3 + 1;
      var4[var3] = (byte)((byte)(var5 >>> 24));
      var3 = var6 + 1;
      var4[var6] = (byte)((byte)(var5 >>> 16));
      var6 = var3 + 1;
      var4[var3] = (byte)((byte)(var5 >>> 8));
      var4[var6] = (byte)((byte)var5);
      this.b = var6 + 1;
      return this;
   }

   public c a(String var1) {
      int var2 = var1.length();
      int var3 = this.b;
      if (var3 + 2 + var2 > this.a.length) {
         this.a(var2 + 2);
      }

      byte[] var4 = this.a;
      int var5 = var3 + 1;
      var4[var3] = (byte)((byte)(var2 >>> 8));
      var3 = var5 + 1;
      var4[var5] = (byte)((byte)var2);
      var5 = 0;

      int var6;
      label67:
      while(true) {
         var6 = var3;
         if (var5 >= var2) {
            break;
         }

         char var7 = var1.charAt(var5);
         if (var7 < 1 || var7 > 127) {
            var6 = var5;

            int var8;
            int var12;
            for(var8 = var5; var8 < var2; var6 = var12) {
               var7 = var1.charAt(var8);
               if (var7 >= 1 && var7 <= 127) {
                  var12 = var6 + 1;
               } else if (var7 > 2047) {
                  var12 = var6 + 3;
               } else {
                  var12 = var6 + 2;
               }

               ++var8;
            }

            int var9 = this.b;
            var4[var9] = (byte)((byte)(var6 >>> 8));
            var4[var9 + 1] = (byte)((byte)var6);
            var12 = var3;
            byte[] var10 = var4;
            var8 = var5;
            if (var9 + 2 + var6 > var4.length) {
               this.b = var3;
               this.a(var6 + 2);
               var10 = this.a;
               var8 = var5;
               var12 = var3;
            }

            while(true) {
               var6 = var12;
               if (var8 >= var2) {
                  break label67;
               }

               label78: {
                  char var11 = var1.charAt(var8);
                  if (var11 >= 1 && var11 <= 127) {
                     var5 = var12 + 1;
                     var10[var12] = (byte)((byte)var11);
                  } else {
                     var5 = var12 + 1;
                     if (var11 <= 2047) {
                        var10[var12] = (byte)((byte)(var11 >> 6 & 31 | 192));
                        var12 = var5 + 1;
                        var10[var5] = (byte)((byte)(var11 & 63 | 128));
                        break label78;
                     }

                     var10[var12] = (byte)((byte)(var11 >> 12 & 15 | 224));
                     var12 = var5 + 1;
                     var10[var5] = (byte)((byte)(var11 >> 6 & 63 | 128));
                     var5 = var12 + 1;
                     var10[var12] = (byte)((byte)(var11 & 63 | 128));
                  }

                  var12 = var5;
               }

               ++var8;
            }
         }

         var4[var3] = (byte)((byte)var7);
         ++var5;
         ++var3;
      }

      this.b = var6;
      return this;
   }

   public c a(byte[] var1, int var2, int var3) {
      if (this.b + var3 > this.a.length) {
         this.a(var3);
      }

      if (var1 != null) {
         System.arraycopy(var1, var2, this.a, this.b, var3);
      }

      this.b += var3;
      return this;
   }

   public final void a(int var1) {
      int var2 = this.a.length * 2;
      int var3 = var1 + this.b;
      var1 = var3;
      if (var2 > var3) {
         var1 = var2;
      }

      byte[] var4 = new byte[var1];
      System.arraycopy(this.a, 0, var4, 0, this.b);
      this.a = var4;
   }

   public c b(int var1) {
      int var2 = this.b;
      int var3 = var2 + 1;
      if (var3 > this.a.length) {
         this.a(1);
      }

      this.a[var2] = (byte)((byte)var1);
      this.b = var3;
      return this;
   }

   public c b(int var1, int var2) {
      int var3 = this.b;
      if (var3 + 3 > this.a.length) {
         this.a(3);
      }

      byte[] var4 = this.a;
      int var5 = var3 + 1;
      var4[var3] = (byte)((byte)var1);
      var1 = var5 + 1;
      var4[var5] = (byte)((byte)(var2 >>> 8));
      var4[var1] = (byte)((byte)var2);
      this.b = var1 + 1;
      return this;
   }

   public c c(int var1) {
      int var2 = this.b;
      if (var2 + 4 > this.a.length) {
         this.a(4);
      }

      byte[] var3 = this.a;
      int var4 = var2 + 1;
      var3[var2] = (byte)((byte)(var1 >>> 24));
      var2 = var4 + 1;
      var3[var4] = (byte)((byte)(var1 >>> 16));
      var4 = var2 + 1;
      var3[var2] = (byte)((byte)(var1 >>> 8));
      var3[var4] = (byte)((byte)var1);
      this.b = var4 + 1;
      return this;
   }

   public c d(int var1) {
      int var2 = this.b;
      if (var2 + 2 > this.a.length) {
         this.a(2);
      }

      byte[] var3 = this.a;
      int var4 = var2 + 1;
      var3[var2] = (byte)((byte)(var1 >>> 8));
      var3[var4] = (byte)((byte)var1);
      this.b = var4 + 1;
      return this;
   }
}
