package c.b.d.e.a.a.a;

public class m {
   public int a;
   public int b;
   public int c;
   public int d;
   public int[] e;
   public int f;
   public int g;
   public i h;
   public m i;
   public g j;
   public m k;

   public m a() {
      i var1 = this.h;
      m var2;
      if (var1 == null) {
         var2 = this;
      } else {
         var2 = var1.a;
      }

      return var2;
   }

   public final void a(int var1, int var2) {
      if (this.e == null) {
         this.e = new int[6];
      }

      int var3 = this.d;
      int[] var4 = this.e;
      if (var3 >= var4.length) {
         int[] var5 = new int[var4.length + 6];
         System.arraycopy(var4, 0, var5, 0, var4.length);
         this.e = var5;
      }

      var4 = this.e;
      var3 = this.d++;
      var4[var3] = var1;
      var1 = this.d++;
      var4[var1] = var2;
   }

   public void a(c var1, int var2, boolean var3) {
      if ((this.a & 2) == 0) {
         if (var3) {
            this.a(-1 - var2, var1.b);
            var1.c(-1);
         } else {
            this.a(var2, var1.b);
            var1.d(-1);
         }
      } else if (var3) {
         var1.c(this.c - var2);
      } else {
         var1.d(this.c - var2);
      }

   }

   public void a(m var1, long var2, int var4) {
      m var16;
      for(m var5 = this; var5 != null; var5 = var16) {
         m var6 = var5.k;
         var5.k = null;
         boolean var7 = false;
         boolean var8 = false;
         int var9;
         int[] var10;
         boolean var14;
         if (var1 != null) {
            var9 = var5.a;
            if ((var9 & 2048) != 0) {
               var16 = var6;
               continue;
            }

            var5.a = var9 | 2048;
            int var13 = var5.a;
            if ((var13 & 256) != 0) {
               var14 = var8;
               if ((var13 & 1024) != 0) {
                  if ((var1.a & 1024) == 0) {
                     var14 = var8;
                  } else {
                     var13 = 0;

                     while(true) {
                        var10 = var5.e;
                        var14 = var8;
                        if (var13 >= var10.length) {
                           break;
                        }

                        if ((var10[var13] & var1.e[var13]) != 0) {
                           var14 = true;
                           break;
                        }

                        ++var13;
                     }
                  }
               }

               if (!var14) {
                  g var15 = new g();
                  var15.a = var5.f;
                  var15.b = var1.j.b;
                  var15.c = var5.j;
                  var5.j = var15;
               }
            }
         } else {
            var14 = var7;
            if ((var5.a & 1024) != 0) {
               var14 = var7;
               if ((var5.e[(int)(var2 >>> 32)] & (int)var2) != 0) {
                  var14 = true;
               }
            }

            if (var14) {
               var16 = var6;
               continue;
            }

            var9 = var5.a;
            if ((var9 & 1024) == 0) {
               var5.a = var9 | 1024;
               var5.e = new int[(var4 - 1) / 32 + 1];
            }

            var10 = var5.e;
            var9 = (int)(var2 >>> 32);
            var10[var9] |= (int)var2;
         }

         g var11 = var5.j;

         while(true) {
            var16 = var6;
            if (var11 == null) {
               break;
            }

            label53: {
               if ((var5.a & 128) != 0) {
                  var16 = var6;
                  if (var11 == var5.j.c) {
                     break label53;
                  }
               }

               m var12 = var11.b;
               var16 = var6;
               if (var12.k == null) {
                  var12.k = var6;
                  var16 = var12;
               }
            }

            var11 = var11.c;
            var6 = var16;
         }
      }

   }

   public boolean a(int var1, byte[] var2) {
      this.a |= 2;
      this.c = var1;
      int var3 = 0;

      boolean var4;
      int var6;
      for(var4 = false; var3 < this.d; var3 = var6 + 1) {
         int[] var5 = this.e;
         var6 = var3 + 1;
         int var7 = var5[var3];
         var3 = var5[var6];
         int var9;
         if (var7 < 0) {
            var7 = var7 + var1 + 1;
            var9 = var3 + 1;
            var2[var3] = (byte)((byte)(var7 >>> 24));
            var3 = var9 + 1;
            var2[var9] = (byte)((byte)(var7 >>> 16));
            var2[var3] = (byte)((byte)(var7 >>> 8));
            var2[var3 + 1] = (byte)((byte)var7);
         } else {
            var7 = var1 - var7;
            if (var7 < -32768 || var7 > 32767) {
               int var8 = var3 - 1;
               var9 = var2[var8] & 255;
               if (var9 <= 168) {
                  var2[var8] = (byte)((byte)(var9 + 49));
               } else {
                  var2[var8] = (byte)((byte)(var9 + 20));
               }

               var4 = true;
            }

            var2[var3] = (byte)((byte)(var7 >>> 8));
            var2[var3 + 1] = (byte)((byte)var7);
         }
      }

      return var4;
   }

   public String toString() {
      StringBuffer var1 = c.a.b.a.a.a("L");
      var1.append(System.identityHashCode(this));
      return var1.toString();
   }
}
