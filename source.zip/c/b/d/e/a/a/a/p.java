package c.b.d.e.a.a.a;

public class p {
   public static final p e = new p(0, (char[])null, 1443168256, 1);
   public static final p f = new p(1, (char[])null, 1509950721, 1);
   public static final p g = new p(2, (char[])null, 1124075009, 1);
   public static final p h = new p(3, (char[])null, 1107297537, 1);
   public static final p i = new p(4, (char[])null, 1392510721, 1);
   public static final p j = new p(5, (char[])null, 1224736769, 1);
   public static final p k = new p(6, (char[])null, 1174536705, 1);
   public static final p l = new p(7, (char[])null, 1241579778, 1);
   public static final p m = new p(8, (char[])null, 1141048066, 1);
   public final int a;
   public final char[] b;
   public final int c;
   public final int d;

   public p(int var1, char[] var2, int var3, int var4) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
   }

   public static p a(char[] var0, int var1) {
      char var2 = var0[var1];
      if (var2 == 'F') {
         return k;
      } else {
         int var5;
         if (var2 != 'L') {
            if (var2 == 'S') {
               return i;
            } else if (var2 == 'V') {
               return e;
            } else if (var2 == 'I') {
               return j;
            } else if (var2 == 'J') {
               return l;
            } else if (var2 == 'Z') {
               return f;
            } else if (var2 != '[') {
               switch(var2) {
               case 'B':
                  return h;
               case 'C':
                  return g;
               case 'D':
                  return m;
               default:
                  return new p(11, var0, 0, var0.length);
               }
            } else {
               var5 = 1;

               while(true) {
                  int var3 = var1 + var5;
                  if (var0[var3] != '[') {
                     int var4 = var5;
                     if (var0[var3] == 'L') {
                        while(true) {
                           ++var5;
                           var4 = var5;
                           if (var0[var1 + var5] != ';') {
                              continue;
                           }
                        }
                     }

                     return new p(9, var0, var1, var4 + 1);
                  }

                  ++var5;
               }
            }
         } else {
            for(var5 = 1; var0[var1 + var5] != ';'; ++var5) {
            }

            return new p(10, var0, var1 + 1, var5 - 1);
         }
      }
   }

   public static String a(Class var0) {
      StringBuffer var1 = new StringBuffer();

      char var8;
      while(true) {
         byte var7;
         if (var0.isPrimitive()) {
            if (var0 == Integer.TYPE) {
               var7 = 73;
               var8 = (char)var7;
            } else if (var0 == Void.TYPE) {
               var7 = 86;
               var8 = (char)var7;
            } else if (var0 == Boolean.TYPE) {
               var7 = 90;
               var8 = (char)var7;
            } else if (var0 == Byte.TYPE) {
               var7 = 66;
               var8 = (char)var7;
            } else if (var0 == Character.TYPE) {
               var7 = 67;
               var8 = (char)var7;
            } else if (var0 == Short.TYPE) {
               var7 = 83;
               var8 = (char)var7;
            } else if (var0 == Double.TYPE) {
               var7 = 68;
               var8 = (char)var7;
            } else if (var0 == Float.TYPE) {
               var7 = 70;
               var8 = (char)var7;
            } else {
               var7 = 74;
               var8 = (char)var7;
            }
            break;
         }

         if (!var0.isArray()) {
            var1.append('L');
            String var6 = var0.getName();
            int var4 = var6.length();

            for(int var2 = 0; var2 < var4; ++var2) {
               char var5 = var6.charAt(var2);
               char var3 = var5;
               if (var5 == '.') {
                  byte var9 = 47;
                  var3 = (char)var9;
               }

               var1.append(var3);
            }

            var7 = 59;
            var8 = (char)var7;
            break;
         }

         var1.append('[');
         var0 = var0.getComponentType();
      }

      var1.append(var8);
      return var1.toString();
   }

   public static p[] a(String var0) {
      char[] var7 = var0.toCharArray();
      byte var1 = 1;
      int var2 = 1;
      int var3 = 0;

      while(true) {
         while(true) {
            int var4 = var2 + 1;
            char var8 = var7[var2];
            int var6;
            if (var8 == ')') {
               p[] var5 = new p[var3];
               var3 = 0;

               for(var2 = var1; var7[var2] != ')'; ++var3) {
                  var5[var3] = a(var7, var2);
                  var6 = var5[var3].d;
                  byte var9;
                  if (var5[var3].a == 10) {
                     var9 = 2;
                  } else {
                     var9 = 0;
                  }

                  var2 += var6 + var9;
               }

               return var5;
            }

            if (var8 == 'L') {
               while(true) {
                  var2 = var4 + 1;
                  if (var7[var4] == ';') {
                     ++var3;
                     break;
                  }

                  var4 = var2;
               }
            } else {
               var6 = var3;
               if (var8 != '[') {
                  var6 = var3 + 1;
               }

               var2 = var4;
               var3 = var6;
            }
         }
      }
   }

   public static int b(String var0) {
      byte var1 = 1;
      int var2 = 1;
      int var3 = 1;

      while(true) {
         while(true) {
            int var4 = var2 + 1;
            char var5 = var0.charAt(var2);
            if (var5 == ')') {
               char var7 = var0.charAt(var4);
               byte var9;
               if (var7 == 'V') {
                  var9 = 0;
               } else {
                  if (var7 != 'D') {
                     var9 = var1;
                     if (var7 != 'J') {
                        return var3 << 2 | var9;
                     }
                  }

                  var9 = 2;
               }

               return var3 << 2 | var9;
            }

            if (var5 == 'L') {
               while(true) {
                  var2 = var4 + 1;
                  if (var0.charAt(var4) == ';') {
                     ++var3;
                     break;
                  }

                  var4 = var2;
               }
            } else {
               int var8;
               if (var5 != '[') {
                  if (var5 != 'D' && var5 != 'J') {
                     var8 = var3 + 1;
                     var2 = var4;
                  } else {
                     var8 = var3 + 2;
                     var2 = var4;
                  }
               } else {
                  while(true) {
                     char var6 = var0.charAt(var4);
                     if (var6 != '[') {
                        if (var6 != 'D') {
                           var8 = var3;
                           var2 = var4;
                           if (var6 != 'J') {
                              break;
                           }
                        }

                        var8 = var3 - 1;
                        var2 = var4;
                        break;
                     }

                     ++var4;
                  }
               }

               var3 = var8;
            }
         }
      }
   }

   public static p b(Class var0) {
      if (var0.isPrimitive()) {
         if (var0 == Integer.TYPE) {
            return j;
         } else if (var0 == Void.TYPE) {
            return e;
         } else if (var0 == Boolean.TYPE) {
            return f;
         } else if (var0 == Byte.TYPE) {
            return h;
         } else if (var0 == Character.TYPE) {
            return g;
         } else if (var0 == Short.TYPE) {
            return i;
         } else if (var0 == Double.TYPE) {
            return m;
         } else {
            return var0 == Float.TYPE ? k : l;
         }
      } else {
         return e(a(var0));
      }
   }

   public static p c(String var0) {
      return a(var0.toCharArray(), 0);
   }

   public static p d(String var0) {
      char[] var2 = var0.toCharArray();
      byte var1;
      if (var2[0] == '[') {
         var1 = 9;
      } else {
         var1 = 10;
      }

      return new p(var1, var2, 0, var2.length);
   }

   public static p e(String var0) {
      return a(var0.toCharArray(), 0);
   }

   public String a() {
      switch(this.a) {
      case 0:
         return "void";
      case 1:
         return "boolean";
      case 2:
         return "char";
      case 3:
         return "byte";
      case 4:
         return "short";
      case 5:
         return "int";
      case 6:
         return "float";
      case 7:
         return "long";
      case 8:
         return "double";
      case 9:
         char[] var1 = this.b;
         int var2 = this.c;
         byte var3 = 1;

         int var4;
         for(var4 = 1; this.b[this.c + var4] == '['; ++var4) {
         }

         StringBuffer var5 = new StringBuffer(a(var1, var4 + var2).a());
         var4 = var3;

         while(true) {
            int var6 = var4;
            if (this.b[this.c + var4] != '[') {
               while(var6 > 0) {
                  var5.append("[]");
                  --var6;
               }

               return var5.toString();
            }

            ++var4;
         }
      case 10:
         return (new String(this.b, this.c, this.d)).replace('/', '.');
      default:
         return null;
      }
   }

   public String b() {
      StringBuffer var1 = new StringBuffer();
      char[] var2 = this.b;
      char var4;
      if (var2 == null) {
         char var3 = (char)((this.c & -16777216) >>> 24);
         var4 = var3;
      } else {
         if (this.a != 10) {
            var1.append(var2, this.c, this.d);
            return var1.toString();
         }

         var1.append('L');
         var1.append(this.b, this.c, this.d);
         byte var5 = 59;
         var4 = (char)var5;
      }

      var1.append(var4);
      return var1.toString();
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof p)) {
         return false;
      } else {
         p var6 = (p)var1;
         int var2 = this.a;
         if (var2 != var6.a) {
            return false;
         } else {
            if (var2 >= 9) {
               int var3 = this.d;
               if (var3 != var6.d) {
                  return false;
               }

               int var4 = this.c;
               int var5 = var6.c;

               for(var2 = var4; var2 < var3 + var4; ++var5) {
                  if (this.b[var2] != var6.b[var5]) {
                     return false;
                  }

                  ++var2;
               }
            }

            return true;
         }
      }
   }

   public int hashCode() {
      int var1 = this.a;
      int var2 = var1 * 13;
      int var3 = var2;
      if (var1 >= 9) {
         var1 = this.c;
         int var4 = this.d;
         var3 = var1;

         while(true) {
            int var5 = var3;
            var3 = var2;
            if (var5 >= var4 + var1) {
               break;
            }

            var2 = (var2 + this.b[var5]) * 17;
            var3 = var5 + 1;
         }
      }

      return var3;
   }

   public String toString() {
      return this.b();
   }
}
