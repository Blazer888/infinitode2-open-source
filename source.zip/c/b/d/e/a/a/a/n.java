package c.b.d.e.a.a.a;

public class n {
   public int A;
   public int[] B;
   public int C;
   public k D;
   public k E;
   public int F;
   public c G;
   public int H;
   public c I;
   public int J;
   public c K;
   public b L;
   public boolean M;
   public int N;
   public final int O;
   public m P;
   public m Q;
   public m R;
   public int S;
   public int T;
   public n a = null;
   public final f b;
   public int c;
   public final int d;
   public final int e;
   public final String f;
   public String g;
   public int h;
   public int i;
   public int j;
   public int[] k;
   public c l;
   public a m;
   public a n;
   public a[] o;
   public a[] p;
   public int q;
   public b r;
   public c s = new c();
   public int t;
   public int u;
   public int v;
   public int w;
   public c x;
   public int y;
   public int[] z;

   public n(f var1, int var2, String var3, String var4, String var5, String[] var6, boolean var7, boolean var8) {
      if (var1.G == null) {
         var1.G = this;
      } else {
         var1.H.a = this;
      }

      var1.H = this;
      this.b = var1;
      this.c = var2;
      this.d = var1.d(var3);
      this.e = var1.d(var4);
      this.f = var4;
      this.g = var5;
      byte var9 = 0;
      int var10;
      if (var6 != null && var6.length > 0) {
         this.j = var6.length;
         this.k = new int[this.j];

         for(var10 = 0; var10 < this.j; ++var10) {
            this.k[var10] = var1.c(var6[var10]);
         }
      }

      byte var13;
      if (var8) {
         var13 = var9;
      } else if (var7) {
         var13 = 1;
      } else {
         var13 = 2;
      }

      this.O = var13;
      if (var7 || var8) {
         if (var8 && "<init>".equals(var3)) {
            this.c |= 262144;
         }

         int var12 = c.b.d.e.a.a.a.p.b(this.f) >> 2;
         var10 = var12;
         if ((var2 & 8) != 0) {
            var10 = var12 - 1;
         }

         this.u = var10;
         this.v = var10;
         this.P = new m();
         m var11 = this.P;
         var11.a |= 8;
         this.a(var11);
      }

   }

   public static int a(byte[] var0, int var1) {
      byte var2 = var0[var1];
      byte var3 = var0[var1 + 1];
      byte var4 = var0[var1 + 2];
      return var0[var1 + 3] & 255 | (var2 & 255) << 24 | (var3 & 255) << 16 | (var4 & 255) << 8;
   }

   public static int a(int[] var0, int[] var1, int var2, int var3) {
      int var4 = var3 - var2;

      int var6;
      for(int var5 = 0; var5 < var0.length; var4 = var6) {
         if (var2 < var0[var5] && var0[var5] <= var3) {
            var6 = var4 + var1[var5];
         } else {
            var6 = var4;
            if (var3 < var0[var5]) {
               var6 = var4;
               if (var0[var5] <= var2) {
                  var6 = var4 - var1[var5];
               }
            }
         }

         ++var5;
      }

      return var4;
   }

   public static void a(int[] var0, int[] var1, m var2) {
      if ((var2.a & 4) == 0) {
         var2.c = a(var0, var1, 0, var2.c);
         var2.a |= 4;
      }

   }

   public static short b(byte[] var0, int var1) {
      byte var2 = var0[var1];
      return (short)(var0[var1 + 1] & 255 | (var2 & 255) << 8);
   }

   public static int c(byte[] var0, int var1) {
      byte var2 = var0[var1];
      return var0[var1 + 1] & 255 | (var2 & 255) << 8;
   }

   public a a(int var1, String var2, boolean var3) {
      c var4 = new c();
      if ("Ljava/lang/Synthetic;".equals(var2)) {
         this.q = Math.max(this.q, var1 + 1);
         return new a(this.b, false, var4, (c)null, 0);
      } else {
         var4.d(this.b.d(var2));
         var4.d(0);
         a var5 = new a(this.b, true, var4, var4, 2);
         a[] var6;
         if (var3) {
            if (this.o == null) {
               this.o = new a[c.b.d.e.a.a.a.p.a(this.f).length];
            }

            var6 = this.o;
            var5.g = var6[var1];
            var6[var1] = var5;
         } else {
            if (this.p == null) {
               this.p = new a[c.b.d.e.a.a.a.p.a(this.f).length];
            }

            var6 = this.p;
            var5.g = var6[var1];
            var6[var1] = var5;
         }

         return var5;
      }
   }

   public a a(String var1, boolean var2) {
      c var3 = new c();
      var3.d(this.b.d(var1));
      var3.d(0);
      a var4 = new a(this.b, true, var3, var3, 2);
      if (var2) {
         var4.g = this.m;
         this.m = var4;
      } else {
         var4.g = this.n;
         this.n = var4;
      }

      return var4;
   }

   public final void a() {
      if (this.z != null) {
         if (this.x == null) {
            this.x = new c();
         }

         label98: {
            int[] var1 = this.B;
            int var2 = var1[1];
            int var3 = var1[2];
            int var4 = this.b.b;
            int var5 = 0;
            if ((var4 & '\uffff') < 50) {
               c var14 = this.x;
               var14.d(var1[0]);
               var14.d(var2);
               var4 = var2 + 3;
               this.a(3, var4);
            } else {
               label97: {
                  int[] var6 = this.z;
                  var4 = var6[1];
                  int var7;
                  if (this.w == 0) {
                     var7 = var1[0];
                  } else {
                     var7 = var1[0] - var6[0] - 1;
                  }

                  int var8;
                  int var9;
                  short var13;
                  if (var3 == 0) {
                     var8 = var2 - var4;
                     switch(var8) {
                     case -3:
                     case -2:
                     case -1:
                        var9 = var2;
                        var13 = 248;
                        break;
                     case 0:
                        var9 = var4;
                        if (var7 < 64) {
                           var13 = 0;
                        } else {
                           var13 = 251;
                        }
                        break;
                     case 1:
                     case 2:
                     case 3:
                        var9 = var4;
                        var13 = 252;
                        break;
                     default:
                        var9 = var4;
                        var13 = 255;
                     }
                  } else {
                     short var15;
                     if (var2 == var4 && var3 == 1) {
                        if (var7 < 63) {
                           var15 = 64;
                        } else {
                           var15 = 247;
                        }
                     } else {
                        var15 = 255;
                     }

                     var13 = var15;
                     byte var10 = 0;
                     var9 = var4;
                     var8 = var10;
                  }

                  short var16 = var13;
                  if (var13 != 255) {
                     int var11 = 3;

                     while(true) {
                        var16 = var13;
                        if (var5 >= var9) {
                           break;
                        }

                        if (this.B[var11] != this.z[var11]) {
                           var16 = 255;
                           break;
                        }

                        ++var11;
                        ++var5;
                     }
                  }

                  if (var16 == 0) {
                     this.x.b(var7);
                     break label98;
                  }

                  if (var16 != 64) {
                     c var12;
                     if (var16 != 247) {
                        if (var16 != 248) {
                           if (var16 != 251) {
                              if (var16 == 252) {
                                 var12 = this.x;
                                 var12.b(var8 + 251);
                                 var12.d(var7);
                                 this.a(var9 + 3, var2 + 3);
                                 break label98;
                              }

                              var12 = this.x;
                              var12.b(255);
                              var12.d(var7);
                              var12.d(var2);
                              var4 = var2 + 3;
                              this.a(3, var4);
                              break label97;
                           }

                           var12 = this.x;
                           var12.b(251);
                        } else {
                           var12 = this.x;
                           var12.b(var8 + 251);
                        }

                        var12.d(var7);
                        break label98;
                     }

                     var12 = this.x;
                     var12.b(247);
                     var12.d(var7);
                  } else {
                     this.x.b(var7 + 64);
                  }

                  this.a(var2 + 3, var2 + 4);
                  break label98;
               }
            }

            this.x.d(var3);
            this.a(var4, var3 + var4);
         }

         ++this.w;
      }

      this.z = this.B;
      this.B = null;
   }

   public void a(int var1) {
      this.s.b(var1);
      m var2 = this.R;
      if (var2 != null) {
         if (this.O == 0) {
            var2.h.a(var1, 0, (f)null, (l)null);
         } else {
            int var3 = this.S + c.b.d.e.a.a.a.i.i[var1];
            if (var3 > this.T) {
               this.T = var3;
            }

            this.S = var3;
         }

         if (var1 >= 172 && var1 <= 177 || var1 == 191) {
            this.b();
         }
      }

   }

   public final void a(int var1, int var2) {
      for(int var3 = var1; var3 < var2; ++var3) {
         int var4 = this.B[var3];
         var1 = -268435456 & var4;
         c var5;
         if (var1 == 0) {
            var1 = var4 & 1048575;
            var4 &= 267386880;
            if (var4 != 24117248) {
               if (var4 != 25165824) {
                  this.x.b(var1);
                  continue;
               }

               var5 = this.x;
               var5.b(8);
               var1 = this.b.k[var1].c;
            } else {
               var5 = this.x;
               var5.b(7);
               f var6 = this.b;
               var1 = var6.c(var6.k[var1].e);
            }
         } else {
            StringBuffer var9 = new StringBuffer();

            for(var1 >>= 28; var1 > 0; --var1) {
               var9.append('[');
            }

            char var7;
            byte var8;
            if ((var4 & 267386880) == 24117248) {
               var9.append('L');
               var9.append(this.b.k[var4 & 1048575].e);
               var8 = 59;
               var7 = (char)var8;
            } else {
               var1 = var4 & 15;
               if (var1 != 1) {
                  if (var1 != 2) {
                     if (var1 != 3) {
                        switch(var1) {
                        case 9:
                           var8 = 90;
                           var7 = (char)var8;
                           break;
                        case 10:
                           var8 = 66;
                           var7 = (char)var8;
                           break;
                        case 11:
                           var8 = 67;
                           var7 = (char)var8;
                           break;
                        case 12:
                           var8 = 83;
                           var7 = (char)var8;
                           break;
                        default:
                           var8 = 74;
                           var7 = (char)var8;
                        }
                     } else {
                        var8 = 68;
                        var7 = (char)var8;
                     }
                  } else {
                     var8 = 70;
                     var7 = (char)var8;
                  }
               } else {
                  var8 = 73;
                  var7 = (char)var8;
               }
            }

            var9.append(var7);
            var5 = this.x;
            var5.b(7);
            var1 = this.b.c(var9.toString());
         }

         var5.d(var1);
      }

   }

   public final void a(int var1, int var2, int var3) {
      int var4 = var2 + 3 + var3;
      int[] var5 = this.B;
      if (var5 == null || var5.length < var4) {
         this.B = new int[var4];
      }

      var5 = this.B;
      var5[0] = var1;
      var5[1] = var2;
      var5[2] = var3;
      this.A = 3;
   }

   public void a(int var1, int var2, m var3, m... var4) {
      c var5 = this.s;
      int var6 = var5.b;
      var5.b(170);
      var5 = this.s;
      int var7 = var5.b;
      byte var8 = 0;
      var5.a((byte[])null, 0, (4 - var7 % 4) % 4);
      var3.a(this.s, var6, true);
      var5 = this.s;
      var5.c(var1);
      var5.c(var2);

      for(var1 = var8; var1 < var4.length; ++var1) {
         var4[var1].a(this.s, var6, true);
      }

      this.a(var3, var4);
   }

   public void a(int var1, int var2, Object[] var3, int var4, Object[] var5) {
      if (this.O != 0) {
         byte var6 = 0;
         byte var7 = 0;
         byte var8 = 0;
         int var9;
         if (var1 == -1) {
            this.v = var2;
            this.a(this.s.b, var2, var4);
            var1 = 0;

            while(true) {
               var9 = var8;
               if (var1 >= var2) {
                  for(; var9 < var4; ++var9) {
                     int[] var11;
                     if (var5[var9] instanceof String) {
                        var11 = this.B;
                        var1 = this.A++;
                        var11[var1] = this.b.b((String)var5[var9]) | 24117248;
                     } else if (var5[var9] instanceof Integer) {
                        var11 = this.B;
                        var1 = this.A++;
                        var11[var1] = (Integer)var5[var9];
                     } else {
                        var11 = this.B;
                        var1 = this.A++;
                        var11[var1] = this.b.a("", ((m)var5[var9]).c) | 25165824;
                     }
                  }

                  this.a();
                  break;
               }

               int[] var10;
               if (var3[var1] instanceof String) {
                  var10 = this.B;
                  var9 = this.A++;
                  var10[var9] = 24117248 | this.b.b((String)var3[var1]);
               } else if (var3[var1] instanceof Integer) {
                  var10 = this.B;
                  var9 = this.A++;
                  var10[var9] = (Integer)var3[var1];
               } else {
                  var10 = this.B;
                  var9 = this.A++;
                  var10[var9] = this.b.a("", ((m)var3[var1]).c) | 25165824;
               }

               ++var1;
            }
         } else {
            if (this.x == null) {
               this.x = new c();
               var9 = this.s.b;
            } else {
               int var14 = this.s.b - this.y - 1;
               var9 = var14;
               if (var14 < 0) {
                  if (var1 == 3) {
                     return;
                  }

                  throw new IllegalStateException();
               }
            }

            if (var1 != 0) {
               c var13;
               if (var1 != 1) {
                  label73: {
                     short var15 = 251;
                     c var12;
                     if (var1 != 2) {
                        if (var1 != 3) {
                           if (var1 == 4) {
                              var12 = this.x;
                              if (var9 < 64) {
                                 var12.b(var9 + 64);
                              } else {
                                 var12.b(247);
                                 var12.d(var9);
                              }

                              this.a(var5[0]);
                           }
                           break label73;
                        }

                        var13 = this.x;
                        var1 = var15;
                        var12 = var13;
                        if (var9 < 64) {
                           var13.b(var9);
                           break label73;
                        }
                     } else {
                        this.v -= var2;
                        var12 = this.x;
                        var1 = 251 - var2;
                     }

                     var12.b(var1);
                     var12.d(var9);
                  }
               } else {
                  this.v += var2;
                  var13 = this.x;
                  var13.b(var2 + 251);
                  var13.d(var9);

                  for(var1 = var6; var1 < var2; ++var1) {
                     this.a(var3[var1]);
                  }
               }
            } else {
               this.v = var2;
               c var16 = this.x;
               var16.b(255);
               var16.d(var9);
               var16.d(var2);

               for(var1 = 0; var1 < var2; ++var1) {
                  this.a(var3[var1]);
               }

               this.x.d(var4);

               for(var1 = var7; var1 < var4; ++var1) {
                  this.a(var5[var1]);
               }
            }

            this.y = this.s.b;
            ++this.w;
         }

         this.t = Math.max(this.t, var4);
         this.u = Math.max(this.u, this.v);
      }
   }

   public final void a(int var1, m var2) {
      g var3 = new g();
      var3.a = var1;
      var3.b = var2;
      var2 = this.R;
      var3.c = var2.j;
      var2.j = var3;
   }

   public void a(int var1, String var2) {
      l var3 = this.b.a(var2);
      m var5 = this.R;
      if (var5 != null) {
         if (this.O == 0) {
            var5.h.a(var1, this.s.b, this.b, var3);
         } else if (var1 == 187) {
            int var4 = this.S + 1;
            if (var4 > this.T) {
               this.T = var4;
            }

            this.S = var4;
         }
      }

      this.s.b(var1, var3.a);
   }

   public void a(int var1, String var2, String var3, String var4) {
      l var10 = this.b.b(var2, var3, var4);
      m var11 = this.R;
      if (var11 != null) {
         if (this.O == 0) {
            var11.h.a(var1, 0, this.b, var10);
         } else {
            int var15;
            label47: {
               byte var8;
               int var9;
               label46: {
                  char var5 = var4.charAt(0);
                  byte var6 = 1;
                  byte var7 = -2;
                  int var12;
                  int var13;
                  byte var14;
                  switch(var1) {
                  case 178:
                     var13 = this.S;
                     if (var5 != 'D') {
                        var9 = var13;
                        var8 = var6;
                        if (var5 != 'J') {
                           break label46;
                        }
                     }

                     var8 = 2;
                     var9 = var13;
                     break label46;
                  case 179:
                     var12 = this.S;
                     var14 = var7;
                     var9 = var12;
                     if (var5 != 'D') {
                        if (var5 == 'J') {
                           var14 = var7;
                           var9 = var12;
                        } else {
                           var14 = -1;
                           var9 = var12;
                        }
                     }
                     break;
                  case 180:
                     var13 = this.S;
                     var9 = var13;
                     var8 = var6;
                     if (var5 != 'D') {
                        if (var5 == 'J') {
                           var9 = var13;
                           var8 = var6;
                        } else {
                           var8 = 0;
                           var9 = var13;
                        }
                     }
                     break label46;
                  default:
                     label43: {
                        var12 = this.S;
                        if (var5 != 'D') {
                           var14 = var7;
                           var9 = var12;
                           if (var5 != 'J') {
                              break label43;
                           }
                        }

                        var14 = -3;
                        var9 = var12;
                     }
                  }

                  var15 = var14 + var9;
                  break label47;
               }

               var15 = var9 + var8;
            }

            if (var15 > this.T) {
               this.T = var15;
            }

            this.S = var15;
         }
      }

      this.s.b(var1, var10.a);
   }

   public void a(b var1) {
      var1.b();
      var1.c = this.r;
      this.r = var1;
   }

   public final void a(c var1) {
      int var2 = this.c;
      var1.d(var2 & ~((var2 & 262144) / 64 | 393216));
      var1.d(this.d);
      var1.d(this.e);
      var2 = this.h;
      if (var2 != 0) {
         var1.a(this.b.a.a, var2, this.i);
      } else {
         var2 = this.s.b;
         boolean var3 = true;
         byte var4;
         if (var2 > 0) {
            var4 = 1;
         } else {
            var4 = 0;
         }

         var2 = var4;
         if (this.j > 0) {
            var2 = var4 + 1;
         }

         int var5 = this.c;
         int var9 = var2;
         if ((var5 & 4096) != 0) {
            label192: {
               if ((this.b.b & '\uffff') >= 49) {
                  var9 = var2;
                  if ((var5 & 262144) == 0) {
                     break label192;
                  }
               }

               var9 = var2 + 1;
            }
         }

         var2 = var9;
         if ((this.c & 131072) != 0) {
            var2 = var9 + 1;
         }

         var5 = var2;
         if (this.g != null) {
            var5 = var2 + 1;
         }

         var9 = var5;
         if (this.l != null) {
            var9 = var5 + 1;
         }

         var2 = var9;
         if (this.m != null) {
            var2 = var9 + 1;
         }

         var9 = var2;
         if (this.n != null) {
            var9 = var2 + 1;
         }

         var5 = var9;
         if (this.o != null) {
            var5 = var9 + 1;
         }

         var2 = var5;
         if (this.p != null) {
            var2 = var5 + 1;
         }

         b var6 = this.r;
         var9 = var2;
         if (var6 != null) {
            var9 = var2 + var6.a();
         }

         var1.d(var9);
         var2 = this.s.b;
         c var10;
         if (var2 > 0) {
            var2 = this.C * 8 + var2 + 12;
            var10 = this.G;
            var9 = var2;
            if (var10 != null) {
               var9 = var2 + var10.b + 8;
            }

            var10 = this.I;
            var2 = var9;
            if (var10 != null) {
               var2 = var9 + var10.b + 8;
            }

            var10 = this.K;
            var9 = var2;
            if (var10 != null) {
               var9 = var2 + var10.b + 8;
            }

            var10 = this.x;
            var2 = var9;
            if (var10 != null) {
               var2 = var9 + var10.b + 8;
            }

            var6 = this.L;
            var9 = var2;
            c var8;
            if (var6 != null) {
               f var7 = this.b;
               var8 = this.s;
               var9 = var2 + var6.a(var7, var8.a, var8.b, this.t, this.u);
            }

            var1.d(this.b.d("Code"));
            var1.c(var9);
            var1.d(this.t);
            var1.d(this.u);
            var1.c(this.s.b);
            var10 = this.s;
            var1.a(var10.a, 0, var10.b);
            var1.d(this.C);
            if (this.C > 0) {
               for(k var12 = this.D; var12 != null; var12 = var12.f) {
                  var1.d(var12.a.c);
                  var1.d(var12.b.c);
                  var1.d(var12.c.c);
                  var1.d(var12.e);
               }
            }

            if (this.G != null) {
               var4 = 1;
            } else {
               var4 = 0;
            }

            var2 = var4;
            if (this.I != null) {
               var2 = var4 + 1;
            }

            var9 = var2;
            if (this.K != null) {
               var9 = var2 + 1;
            }

            var2 = var9;
            if (this.x != null) {
               var2 = var9 + 1;
            }

            var6 = this.L;
            var9 = var2;
            if (var6 != null) {
               var9 = var2 + var6.a();
            }

            var1.d(var9);
            if (this.G != null) {
               var1.d(this.b.d("LocalVariableTable"));
               var1.c(this.G.b + 2);
               var1.d(this.F);
               var10 = this.G;
               var1.a(var10.a, 0, var10.b);
            }

            if (this.I != null) {
               var1.d(this.b.d("LocalVariableTypeTable"));
               var1.c(this.I.b + 2);
               var1.d(this.H);
               var10 = this.I;
               var1.a(var10.a, 0, var10.b);
            }

            if (this.K != null) {
               var1.d(this.b.d("LineNumberTable"));
               var1.c(this.K.b + 2);
               var1.d(this.J);
               var10 = this.K;
               var1.a(var10.a, 0, var10.b);
            }

            if (this.x != null) {
               boolean var15;
               if ((this.b.b & '\uffff') >= 50) {
                  var15 = var3;
               } else {
                  var15 = false;
               }

               f var13 = this.b;
               String var14;
               if (var15) {
                  var14 = "StackMapTable";
               } else {
                  var14 = "StackMap";
               }

               var1.d(var13.d(var14));
               var1.c(this.x.b + 2);
               var1.d(this.w);
               var10 = this.x;
               var1.a(var10.a, 0, var10.b);
            }

            b var11 = this.L;
            if (var11 != null) {
               f var16 = this.b;
               var8 = this.s;
               var11.a(var16, var8.a, var8.b, this.u, this.t, var1);
            }
         }

         if (this.j > 0) {
            var1.d(this.b.d("Exceptions"));
            var1.c(this.j * 2 + 2);
            var1.d(this.j);

            for(var2 = 0; var2 < this.j; ++var2) {
               var1.d(this.k[var2]);
            }
         }

         var2 = this.c;
         if ((var2 & 4096) != 0 && ((this.b.b & '\uffff') < 49 || (var2 & 262144) != 0)) {
            var1.d(this.b.d("Synthetic"));
            var1.c(0);
         }

         if ((this.c & 131072) != 0) {
            var1.d(this.b.d("Deprecated"));
            var1.c(0);
         }

         if (this.g != null) {
            var1.d(this.b.d("Signature"));
            var1.c(2);
            var1.d(this.b.d(this.g));
         }

         if (this.l != null) {
            var1.d(this.b.d("AnnotationDefault"));
            var1.c(this.l.b);
            var10 = this.l;
            var1.a(var10.a, 0, var10.b);
         }

         if (this.m != null) {
            var1.d(this.b.d("RuntimeVisibleAnnotations"));
            this.m.a(var1);
         }

         if (this.n != null) {
            var1.d(this.b.d("RuntimeInvisibleAnnotations"));
            this.n.a(var1);
         }

         if (this.o != null) {
            var1.d(this.b.d("RuntimeVisibleParameterAnnotations"));
            c.b.d.e.a.a.a.a.a(this.o, this.q, var1);
         }

         if (this.p != null) {
            var1.d(this.b.d("RuntimeInvisibleParameterAnnotations"));
            c.b.d.e.a.a.a.a.a(this.p, this.q, var1);
         }

         var6 = this.r;
         if (var6 != null) {
            var6.a(this.b, (byte[])null, 0, -1, -1, var1);
         }

      }
   }

   public final void a(i var1) {
      int[] var2 = var1.b;
      int[] var3 = var1.c;
      byte var4 = 0;
      int var5 = 0;
      int var6 = 0;

      int var7;
      int var8;
      int var9;
      for(var7 = 0; var5 < var2.length; var5 = var9 + 1) {
         var8 = var2[var5];
         ++var7;
         if (var8 != 16777216) {
            var6 += var7;
            var7 = 0;
         }

         if (var8 != 16777220) {
            var9 = var5;
            if (var8 != 16777219) {
               continue;
            }
         }

         var9 = var5 + 1;
      }

      var5 = 0;

      for(var7 = 0; var5 < var3.length; var7 = var9) {
         label53: {
            var8 = var3[var5];
            var9 = var7 + 1;
            if (var8 != 16777220) {
               var7 = var5;
               if (var8 != 16777219) {
                  break label53;
               }
            }

            var7 = var5 + 1;
         }

         var5 = var7 + 1;
      }

      this.a(var1.a.c, var6, var7);
      var5 = 0;
      var7 = var6;

      while(true) {
         var6 = var4;
         int[] var10;
         if (var7 <= 0) {
            for(; var6 < var3.length; var6 = var5 + 1) {
               var7 = var3[var6];
               var10 = this.B;
               var5 = this.A++;
               var10[var5] = var7;
               if (var7 != 16777220) {
                  var5 = var6;
                  if (var7 != 16777219) {
                     continue;
                  }
               }

               var5 = var6 + 1;
            }

            this.a();
            return;
         }

         label44: {
            var9 = var2[var5];
            var10 = this.B;
            var6 = this.A++;
            var10[var6] = var9;
            if (var9 != 16777220) {
               var6 = var5;
               if (var9 != 16777219) {
                  break label44;
               }
            }

            var6 = var5 + 1;
         }

         var5 = var6 + 1;
         --var7;
      }
   }

   public void a(m var1) {
      boolean var2 = this.M;
      c var3 = this.s;
      this.M = var2 | var1.a(var3.b, var3.a);
      int var4 = var1.a;
      if ((var4 & 1) == 0) {
         label41: {
            int var5 = this.O;
            m var7;
            if (var5 == 0) {
               var7 = this.R;
               if (var7 != null) {
                  if (var1.c == var7.c) {
                     var7.a |= var4 & 16;
                     var1.h = var7.h;
                     return;
                  }

                  this.a(0, (m)var1);
               }

               this.R = var1;
               if (var1.h == null) {
                  var1.h = new i();
                  var1.h.a = var1;
               }

               m var6 = this.Q;
               if (var6 == null) {
                  break label41;
               }

               var7 = var6;
               if (var1.c == var6.c) {
                  var6.a |= var1.a & 16;
                  var1.h = var6.h;
                  this.R = var6;
                  return;
               }
            } else {
               if (var5 != 1) {
                  return;
               }

               var7 = this.R;
               if (var7 != null) {
                  var7.g = this.T;
                  this.a(this.S, var1);
               }

               this.R = var1;
               this.S = 0;
               this.T = 0;
               var7 = this.Q;
               if (var7 == null) {
                  break label41;
               }
            }

            var7.i = var1;
         }

         this.Q = var1;
      }
   }

   public void a(m var1, m var2, m var3, String var4) {
      ++this.C;
      k var5 = new k();
      var5.a = var1;
      var5.b = var2;
      var5.c = var3;
      var5.d = var4;
      int var6;
      if (var4 != null) {
         var6 = this.b.a(var4).a;
      } else {
         var6 = 0;
      }

      var5.e = var6;
      k var7 = this.E;
      if (var7 == null) {
         this.D = var5;
      } else {
         var7.f = var5;
      }

      this.E = var5;
   }

   public void a(m var1, int[] var2, m[] var3) {
      c var4 = this.s;
      int var5 = var4.b;
      var4.b(171);
      var4 = this.s;
      int var6 = var4.b;
      int var7 = 0;
      var4.a((byte[])null, 0, (4 - var6 % 4) % 4);
      var1.a(this.s, var5, true);
      this.s.c(var3.length);

      while(var7 < var3.length) {
         this.s.c(var2[var7]);
         var3[var7].a(this.s, var5, true);
         ++var7;
      }

      this.a(var1, var3);
   }

   public final void a(m var1, m[] var2) {
      m var3 = this.R;
      if (var3 != null) {
         int var4 = this.O;
         int var5 = 0;
         if (var4 == 0) {
            var3.h.a(171, 0, (f)null, (l)null);
            this.a(0, (m)var1);
            var1 = var1.a();
            var1.a |= 16;

            for(var5 = 0; var5 < var2.length; ++var5) {
               this.a(0, (m)var2[var5]);
               var1 = var2[var5].a();
               var1.a |= 16;
            }
         } else {
            --this.S;
            this.a(this.S, var1);

            while(var5 < var2.length) {
               this.a(this.S, var2[var5]);
               ++var5;
            }
         }

         this.b();
      }

   }

   public final void a(Object var1) {
      c var2;
      int var3;
      c var4;
      if (var1 instanceof String) {
         var2 = this.x;
         var2.b(7);
         var3 = this.b.c((String)var1);
         var4 = var2;
      } else {
         if (var1 instanceof Integer) {
            this.x.b((Integer)var1);
            return;
         }

         var2 = this.x;
         var2.b(8);
         var3 = ((m)var1).c;
         var4 = var2;
      }

      var4.d(var3);
   }

   public void a(String var1, int var2) {
      l var4 = this.b.a(var1);
      m var3 = this.R;
      if (var3 != null) {
         if (this.O == 0) {
            var3.h.a(197, var2, this.b, var4);
         } else {
            this.S += 1 - var2;
         }
      }

      c var5 = this.s;
      var5.b(197, var4.a);
      var5.b(var2);
   }

   public void a(String var1, String var2, j var3, Object... var4) {
      f var5 = this.b;
      c var6 = var5.D;
      c var7 = var6;
      if (var6 == null) {
         var7 = new c();
         var5.D = var7;
      }

      int var8 = var7.b;
      int var9 = var3.hashCode();
      var7.d(var5.a(var3.a, var3.b, var3.c, var3.d).a);
      int var10 = var4.length;
      var7.d(var10);

      int var11;
      for(var11 = 0; var11 < var10; ++var11) {
         Object var14 = var4[var11];
         var9 ^= var14.hashCode();
         var7.d(var5.a(var14).a);
      }

      byte[] var17 = var7.a;
      var11 = var9 & Integer.MAX_VALUE;
      l[] var15 = var5.e;

      l var16;
      label60:
      for(var16 = var15[var11 % var15.length]; var16 != null; var16 = var16.i) {
         if (var16.b == 33 && var16.h == var11) {
            int var12 = var16.c;
            var9 = 0;

            while(true) {
               if (var9 >= var10 + 2 << 1) {
                  break label60;
               }

               if (var17[var8 + var9] != var17[var12 + var9]) {
                  break;
               }

               ++var9;
            }
         }
      }

      if (var16 != null) {
         var9 = var16.a;
         var7.b = var8;
      } else {
         var9 = var5.C++;
         var16 = new l(var9);
         var16.b = 33;
         var16.c = var8;
         var16.h = var11;
         var5.b(var16);
      }

      var16 = var5.i;
      var16.b = 18;
      var16.d = (long)var9;
      var16.e = var1;
      var16.f = var2;
      var11 = var16.e.hashCode();
      var16.h = var16.f.hashCode() * var11 * var9 + 18 & Integer.MAX_VALUE;
      l var18 = var5.a(var5.i);
      var16 = var18;
      if (var18 == null) {
         var5.a(18, var9, var5.b(var1, var2));
         var9 = var5.c++;
         var16 = new l(var9, var5.i);
         var5.b(var16);
      }

      var11 = var16.c;
      m var13 = this.R;
      if (var13 != null) {
         if (this.O == 0) {
            var13.h.a(186, 0, this.b, var16);
         } else {
            var9 = var11;
            if (var11 == 0) {
               var9 = c.b.d.e.a.a.a.p.b(var2);
               var16.c = var9;
            }

            var9 = this.S - (var9 >> 2) + (var9 & 3) + 1;
            if (var9 > this.T) {
               this.T = var9;
            }

            this.S = var9;
         }
      }

      this.s.b(186, var16.a);
      this.s.d(0);
   }

   public void a(String var1, String var2, String var3, m var4, m var5, int var6) {
      if (var3 != null) {
         if (this.I == null) {
            this.I = new c();
         }

         ++this.H;
         c var7 = this.I;
         var7.d(var4.c);
         var7.d(var5.c - var4.c);
         var7.d(this.b.d(var1));
         var7.d(this.b.d(var3));
         var7.d(var6);
      }

      if (this.G == null) {
         this.G = new c();
      }

      ++this.F;
      c var11 = this.G;
      var11.d(var4.c);
      var11.d(var5.c - var4.c);
      var11.d(this.b.d(var1));
      var11.d(this.b.d(var2));
      var11.d(var6);
      int var8 = this.O;
      byte var9 = 2;
      if (var8 != 2) {
         char var10 = var2.charAt(0);
         byte var12 = var9;
         if (var10 != 'J') {
            if (var10 == 'D') {
               var12 = var9;
            } else {
               var12 = 1;
            }
         }

         var6 += var12;
         if (var6 > this.u) {
            this.u = var6;
         }
      }

   }

   public final void b() {
      if (this.O == 0) {
         m var1 = new m();
         var1.h = new i();
         var1.h.a = var1;
         c var2 = this.s;
         var1.a(var2.b, var2.a);
         this.Q.i = var1;
         this.Q = var1;
      } else {
         this.R.g = this.T;
      }

      this.R = null;
   }

   public void b(int var1, int var2) {
      m var3 = this.R;
      if (var3 != null && this.O == 0) {
         var3.h.a(132, var1, (f)null, (l)null);
      }

      if (this.O != 2) {
         int var4 = var1 + 1;
         if (var4 > this.u) {
            this.u = var4;
         }
      }

      c var5;
      if (var1 <= 255 && var2 <= 127 && var2 >= -128) {
         var5 = this.s;
         var5.b(132);
         var5.a(var1, var2);
      } else {
         var5 = this.s;
         var5.b(196);
         var5.b(132, var1);
         var5.d(var2);
      }

   }

   public void b(int var1, m var2) {
      m var3 = this.R;
      c var4 = null;
      m var5 = var4;
      int var6;
      if (var3 != null) {
         if (this.O == 0) {
            var3.h.a(var1, 0, (f)null, (l)null);
            var5 = var2.a();
            var5.a |= 16;
            this.a(0, (m)var2);
            var5 = var4;
            if (var1 != 167) {
               var5 = new m();
            }
         } else if (var1 == 168) {
            var6 = var2.a;
            if ((var6 & 512) == 0) {
               var2.a = var6 | 512;
               ++this.N;
            }

            var5 = this.R;
            var5.a |= 128;
            this.a(this.S + 1, var2);
            var5 = new m();
         } else {
            this.S += c.b.d.e.a.a.a.i.i[var1];
            this.a(this.S, var2);
            var5 = var4;
         }
      }

      label57: {
         if ((var2.a & 2) != 0) {
            var6 = var2.c;
            var4 = this.s;
            if (var6 - var4.b < -32768) {
               label52: {
                  short var7 = 200;
                  if (var1 != 167) {
                     if (var1 != 168) {
                        if (var5 != null) {
                           var5.a |= 16;
                        }

                        var4 = this.s;
                        if (var1 <= 166) {
                           var6 = (var1 + 1 ^ 1) - 1;
                        } else {
                           var6 = var1 ^ 1;
                        }

                        var4.b(var6);
                        this.s.d(8);
                        this.s.b(200);
                        break label52;
                     }

                     var7 = 201;
                  }

                  var4.b(var7);
               }

               var4 = this.s;
               var2.a(var4, var4.b - 1, true);
               break label57;
            }
         }

         this.s.b(var1);
         var4 = this.s;
         var2.a(var4, var4.b - 1, false);
      }

      if (this.R != null) {
         if (var5 != null) {
            this.a(var5);
         }

         if (var1 == 167) {
            this.b();
         }
      }

   }

   public void b(int var1, String var2, String var3, String var4) {
      boolean var5;
      if (var1 == 185) {
         var5 = true;
      } else {
         var5 = false;
      }

      l var8 = this.b.a(var2, var3, var4, var5);
      int var6 = var8.c;
      m var9 = this.R;
      int var7 = var6;
      if (var9 != null) {
         if (this.O == 0) {
            var9.h.a(var1, 0, this.b, var8);
            var7 = var6;
         } else {
            var7 = var6;
            if (var6 == 0) {
               var7 = c.b.d.e.a.a.a.p.b(var4);
               var8.c = var7;
            }

            if (var1 == 184) {
               var6 = this.S - (var7 >> 2) + (var7 & 3) + 1;
            } else {
               var6 = (var7 & 3) + (this.S - (var7 >> 2));
            }

            if (var6 > this.T) {
               this.T = var6;
            }

            this.S = var6;
         }
      }

      if (var5) {
         var1 = var7;
         if (var7 == 0) {
            var1 = c.b.d.e.a.a.a.p.b(var4);
            var8.c = var1;
         }

         c var10 = this.s;
         var10.b(185, var8.a);
         var10.a(var1 >> 2, 0);
      } else {
         this.s.b(var1, var8.a);
      }

   }

   public void b(Object var1) {
      l var2 = this.b.a(var1);
      m var5 = this.R;
      int var3;
      if (var5 != null) {
         if (this.O == 0) {
            var5.h.a(18, 0, this.b, var2);
         } else {
            var3 = var2.b;
            if (var3 != 5 && var3 != 6) {
               var3 = this.S + 1;
            } else {
               var3 = this.S + 2;
            }

            if (var3 > this.T) {
               this.T = var3;
            }

            this.S = var3;
         }
      }

      int var4 = var2.a;
      var3 = var2.b;
      c var6;
      byte var7;
      if (var3 != 5 && var3 != 6) {
         if (var4 < 256) {
            this.s.a(18, var4);
            return;
         }

         var6 = this.s;
         var7 = 19;
      } else {
         var6 = this.s;
         var7 = 20;
      }

      var6.b(var7, var4);
   }

   public a c() {
      this.l = new c();
      return new a(this.b, false, this.l, (c)null, 0);
   }

   public void c(int var1, int var2) {
      m var3 = this.R;
      if (var3 != null) {
         if (this.O == 0) {
            var3.h.a(var1, var2, (f)null, (l)null);
         } else if (var1 != 188) {
            int var4 = this.S + 1;
            if (var4 > this.T) {
               this.T = var4;
            }

            this.S = var4;
         }
      }

      if (var1 == 17) {
         this.s.b(var1, var2);
      } else {
         this.s.a(var1, var2);
      }

   }

   public void c(int var1, m var2) {
      if (this.K == null) {
         this.K = new c();
      }

      ++this.J;
      this.K.d(var2.c);
      this.K.d(var1);
   }

   public void d() {
   }

   public void d(int var1, int var2) {
      int var3 = this.O;
      m var4 = null;
      k var5;
      m var7;
      int var11;
      int var15;
      m var20;
      m var30;
      g var32;
      if (var3 == 0) {
         var5 = this.D;

         while(true) {
            String var6 = "java/lang/Throwable";
            if (var5 == null) {
               i var31 = this.P.h;
               p[] var19 = c.b.d.e.a.a.a.p.a(this.f);
               var31.a(this.b, this.c, var19, this.u);
               this.a(var31);
               var20 = this.P;
               var1 = 0;

               while(var20 != null) {
                  var7 = var20.k;
                  var20.k = var4;
                  i var21 = var20.h;
                  var2 = var20.a;
                  if ((var2 & 16) != 0) {
                     var20.a = var2 | 32;
                  }

                  var20.a |= 64;
                  var11 = var21.c.length + var20.g;
                  var2 = var1;
                  if (var11 > var1) {
                     var2 = var11;
                  }

                  var32 = var20.j;
                  var20 = var7;

                  for(var1 = var2; var32 != null; var20 = var7) {
                     var4 = var32.b.a();
                     f var25 = this.b;
                     i var26 = var4.h;
                     int var12 = var32.a;
                     int var13 = var21.b.length;
                     int var14 = var21.c.length;
                     boolean var17;
                     if (var26.b == null) {
                        var26.b = new int[var13];
                        var17 = true;
                     } else {
                        var17 = false;
                     }

                     int var16;
                     for(var3 = 0; var3 < var13; ++var3) {
                        int[] var28 = var21.d;
                        if (var28 != null && var3 < var28.length) {
                           var15 = var28[var3];
                           if (var15 == 0) {
                              var1 = var21.b[var3];
                           } else {
                              var1 = var15 & 251658240;
                              if (var1 == 16777216) {
                                 var1 = var15;
                              } else {
                                 if (var1 == 33554432) {
                                    var1 = var21.b[var15 & 8388607];
                                 } else {
                                    var1 = var21.c[var14 - (var15 & 8388607)];
                                 }

                                 var16 = var1 + (var15 & -268435456);
                                 var1 = var16;
                                 if ((var15 & 8388608) != 0) {
                                    label358: {
                                       if (var16 != 16777220) {
                                          var1 = var16;
                                          if (var16 != 16777219) {
                                             break label358;
                                          }
                                       }

                                       var1 = 16777216;
                                    }
                                 }
                              }
                           }
                        } else {
                           var1 = var21.b[var3];
                        }

                        var15 = var1;
                        if (var21.h != null) {
                           var15 = var21.a(var25, var1);
                        }

                        var17 |= c.b.d.e.a.a.a.i.a(var25, var15, var26.b, var3);
                     }

                     boolean var23;
                     if (var12 > 0) {
                        var23 = var17;

                        for(var2 = 0; var2 < var13; ++var2) {
                           var23 |= c.b.d.e.a.a.a.i.a(var25, var21.b[var2], var26.b, var2);
                        }

                        if (var26.c == null) {
                           var26.c = new int[1];
                           var23 = true;
                        }

                        var23 |= c.b.d.e.a.a.a.i.a(var25, var12, (int[])var26.c, 0);
                     } else {
                        var12 = var21.c.length + var21.a.f;
                        if (var26.c == null) {
                           var26.c = new int[var21.f + var12];
                           var17 = true;
                        }

                        for(var1 = 0; var1 < var12; ++var1) {
                           var15 = var21.c[var1];
                           var3 = var15;
                           if (var21.h != null) {
                              var3 = var21.a(var25, var15);
                           }

                           var17 |= c.b.d.e.a.a.a.i.a(var25, var3, var26.c, var1);
                        }

                        var3 = 0;

                        while(true) {
                           var23 = var17;
                           if (var3 >= var21.f) {
                              break;
                           }

                           var15 = var21.e[var3];
                           var1 = var15 & 251658240;
                           if (var1 == 16777216) {
                              var1 = var15;
                           } else {
                              if (var1 == 33554432) {
                                 var1 = var21.b[var15 & 8388607];
                              } else {
                                 var1 = var21.c[var14 - (var15 & 8388607)];
                              }

                              var16 = (var15 & -268435456) + var1;
                              if ((var15 & 8388608) != 0) {
                                 label289: {
                                    if (var16 != 16777220) {
                                       var1 = var16;
                                       if (var16 != 16777219) {
                                          break label289;
                                       }
                                    }

                                    var1 = 16777216;
                                 }
                              } else {
                                 var1 = var16;
                              }
                           }

                           var15 = var1;
                           if (var21.h != null) {
                              var15 = var21.a(var25, var1);
                           }

                           var17 |= c.b.d.e.a.a.a.i.a(var25, var15, var26.c, var12 + var3);
                           ++var3;
                        }
                     }

                     var7 = var20;
                     if (var23) {
                        var7 = var20;
                        if (var4.k == null) {
                           var4.k = var20;
                           var7 = var4;
                        }
                     }

                     var32 = var32.c;
                     var1 = var1;
                     var4 = null;
                  }
               }

               for(var20 = this.P; var20 != null; var20 = var20.i) {
                  var31 = var20.h;
                  if ((var20.a & 32) != 0) {
                     this.a(var31);
                  }

                  if ((var20.a & 64) == 0) {
                     var7 = var20.i;
                     var11 = var20.c;
                     if (var7 == null) {
                        var2 = this.s.b;
                     } else {
                        var2 = var7.c;
                     }

                     var3 = var2 - 1;
                     if (var3 >= var11) {
                        var2 = Math.max(var1, 1);

                        for(var1 = var11; var1 < var3; ++var1) {
                           this.s.a[var1] = (byte)0;
                        }

                        this.s.a[var3] = (byte)-65;
                        this.a(var11, 0, 1);
                        int[] var33 = this.B;
                        var1 = this.A++;
                        var33[var1] = this.b.b("java/lang/Throwable") | 24117248;
                        this.a();
                        this.D = c.b.d.e.a.a.a.k.a(this.D, var20, var7);
                        var1 = var2;
                     }
                  }
               }

               var5 = this.D;

               for(this.C = 0; var5 != null; var5 = var5.f) {
                  ++this.C;
               }

               this.t = var1;
               break;
            }

            var7 = var5.a.a();
            m var8 = var5.c.a();
            m var9 = var5.b.a();
            String var10 = var5.d;
            if (var10 == null) {
               var10 = var6;
            }

            var1 = this.b.b(var10);
            var8.a |= 16;

            for(var30 = var7; var30 != var9; var30 = var30.i) {
               g var24 = new g();
               var24.a = 24117248 | var1;
               var24.b = var8;
               var24.c = var30.j;
               var30.j = var24;
            }

            var5 = var5.f;
         }
      } else {
         var11 = 0;
         if (var3 == 1) {
            for(var5 = this.D; var5 != null; var5 = var5.f) {
               var30 = var5.a;
               var4 = var5.c;

               for(var7 = var5.b; var30 != var7; var30 = var30.i) {
                  g var27 = new g();
                  var27.a = Integer.MAX_VALUE;
                  var27.b = var4;
                  if ((var30.a & 128) == 0) {
                     var27.c = var30.j;
                     var30.j = var27;
                  } else {
                     g var22 = var30.j;
                     var27.c = var22.c.c;
                     var22.c.c = var27;
                  }
               }
            }

            var2 = this.N;
            if (var2 > 0) {
               this.P.a((m)null, 1L, var2);
               var20 = this.P;

               for(var2 = 0; var20 != null; var20 = var20.i) {
                  if ((var20.a & 128) != 0) {
                     var30 = var20.j.c.b;
                     if ((var30.a & 1024) == 0) {
                        ++var2;
                        var30.a((m)null, (long)var2 / 32L << 32 | 1L << var2 % 32, this.N);
                     }
                  }
               }

               for(var20 = this.P; var20 != null; var20 = var20.i) {
                  if ((var20.a & 128) != 0) {
                     for(var30 = this.P; var30 != null; var30 = var30.i) {
                        var30.a &= -2049;
                     }

                     var20.j.c.b.a(var20, 0L, this.N);
                  }
               }
            }

            var7 = this.P;

            while(var7 != null) {
               var30 = var7.k;
               var15 = var7.f;
               var3 = var7.g + var15;
               var2 = var11;
               if (var3 > var11) {
                  var2 = var3;
               }

               g var18 = var7.j;
               g var29 = var18;
               if ((var7.a & 128) != 0) {
                  var29 = var18.c;
               }

               var32 = var29;
               var20 = var30;

               while(true) {
                  var7 = var20;
                  var11 = var2;
                  if (var32 == null) {
                     break;
                  }

                  var4 = var32.b;
                  var7 = var20;
                  if ((var4.a & 8) == 0) {
                     var11 = var32.a;
                     if (var11 == Integer.MAX_VALUE) {
                        var11 = 1;
                     } else {
                        var11 += var15;
                     }

                     var4.f = var11;
                     var4.a |= 8;
                     var4.k = var20;
                     var7 = var4;
                  }

                  var32 = var32.c;
                  var20 = var7;
               }
            }

            this.t = Math.max(var1, var11);
         } else {
            this.t = var1;
            this.u = var2;
         }
      }

   }

   public void e() {
   }

   public void e(int var1, int var2) {
      m var3 = this.R;
      int var4;
      if (var3 != null) {
         if (this.O == 0) {
            var3.h.a(var1, var2, (f)null, (l)null);
         } else if (var1 == 169) {
            var3.a |= 256;
            var3.f = this.S;
            this.b();
         } else {
            var4 = this.S + c.b.d.e.a.a.a.i.i[var1];
            if (var4 > this.T) {
               this.T = var4;
            }

            this.S = var4;
         }
      }

      if (this.O != 2) {
         if (var1 != 22 && var1 != 24 && var1 != 55 && var1 != 57) {
            var4 = var2 + 1;
         } else {
            var4 = var2 + 2;
         }

         if (var4 > this.u) {
            this.u = var4;
         }
      }

      if (var2 < 4 && var1 != 169) {
         if (var1 < 54) {
            var4 = (var1 - 21 << 2) + 26;
         } else {
            var4 = (var1 - 54 << 2) + 59;
         }

         this.s.b(var4 + var2);
      } else {
         c var5 = this.s;
         if (var2 >= 256) {
            var5.b(196);
            var5.b(var1, var2);
         } else {
            var5.a(var1, var2);
         }
      }

      if (var1 >= 54 && this.O == 0 && this.C > 0) {
         this.a(new m());
      }

   }
}
