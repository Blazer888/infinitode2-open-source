package c.b.d.e.a.a.a;

public final class j {
   public final int a;
   public final String b;
   public final String c;
   public final String d;

   public j(int var1, String var2, String var3, String var4) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
   }

   public boolean equals(Object var1) {
      boolean var2 = true;
      if (var1 == this) {
         return true;
      } else if (!(var1 instanceof j)) {
         return false;
      } else {
         j var3 = (j)var1;
         if (this.a != var3.a || !this.b.equals(var3.b) || !this.c.equals(var3.c) || !this.d.equals(var3.d)) {
            var2 = false;
         }

         return var2;
      }
   }

   public int hashCode() {
      int var1 = this.a;
      int var2 = this.b.hashCode();
      int var3 = this.c.hashCode();
      return this.d.hashCode() * var3 * var2 + var1;
   }

   public String toString() {
      StringBuffer var1 = new StringBuffer();
      var1.append(this.b);
      var1.append('.');
      var1.append(this.c);
      var1.append(this.d);
      var1.append(" (");
      var1.append(this.a);
      var1.append(')');
      return var1.toString();
   }
}
