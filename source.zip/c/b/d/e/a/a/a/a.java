package c.b.d.e.a.a.a;

public final class a {
   public final f a;
   public int b;
   public final boolean c;
   public final c d;
   public final c e;
   public final int f;
   public a g;
   public a h;

   public a(f var1, boolean var2, c var3, c var4, int var5) {
      this.a = var1;
      this.c = var2;
      this.d = var3;
      this.e = var4;
      this.f = var5;
   }

   public static void a(a[] var0, int var1, c var2) {
      int var3 = (var0.length - var1) * 2 + 1;
      int var4 = var1;

      while(true) {
         int var5 = var0.length;
         int var6 = 0;
         if (var4 >= var5) {
            var2.c(var3);
            var2.b(var0.length - var1);

            while(var1 < var0.length) {
               a var7 = var0[var1];
               a var8 = null;

               a var9;
               for(var4 = 0; var7 != null; var7 = var9) {
                  ++var4;
                  var7.b();
                  var7.h = var8;
                  var9 = var7.g;
                  var8 = var7;
               }

               var2.d(var4);

               while(var8 != null) {
                  c var10 = var8.d;
                  var2.a(var10.a, 0, var10.b);
                  var8 = var8.h;
               }

               ++var1;
            }

            return;
         }

         if (var0[var4] != null) {
            var6 = var0[var4].a();
         }

         var3 += var6;
         ++var4;
      }
   }

   public int a() {
      int var1 = 0;

      for(a var2 = this; var2 != null; var2 = var2.g) {
         var1 += var2.d.b;
      }

      return var1;
   }

   public a a(String var1) {
      ++this.b;
      if (this.c) {
         this.d.d(this.a.d(var1));
      }

      this.d.b(91, 0);
      f var2 = this.a;
      c var3 = this.d;
      return new a(var2, false, var3, var3, var3.b - 2);
   }

   public void a(c var1) {
      int var2 = 2;
      int var3 = 0;
      a var4 = null;

      a var6;
      for(a var5 = this; var5 != null; var5 = var6) {
         ++var3;
         var2 += var5.d.b;
         var5.b();
         var5.h = var4;
         var6 = var5.g;
         var4 = var5;
      }

      var1.c(var2);
      var1.d(var3);

      while(var4 != null) {
         c var7 = var4.d;
         var1.a(var7.a, 0, var7.b);
         var4 = var4.h;
      }

   }

   public void a(String var1, Object var2) {
      ++this.b;
      if (this.c) {
         this.d.d(this.a.d(var1));
      }

      byte var3;
      int var6;
      c var14;
      label116: {
         f var4;
         String var5;
         f var16;
         if (var2 instanceof String) {
            var14 = this.d;
            var3 = 115;
            var4 = this.a;
            var5 = (String)var2;
            var16 = var4;
         } else {
            boolean var7 = var2 instanceof Byte;
            var3 = 66;
            if (var7) {
               var14 = this.d;
               var6 = this.a.a((Byte)var2).a;
               break label116;
            }

            if (var2 instanceof Boolean) {
               var3 = (Boolean)var2;
               this.d.b(90, this.a.a(var3).a);
               return;
            }

            if (var2 instanceof Character) {
               this.d.b(67, this.a.a((Character)var2).a);
               return;
            }

            if (var2 instanceof Short) {
               this.d.b(83, this.a.a((Short)var2).a);
               return;
            }

            if (!(var2 instanceof p)) {
               var7 = var2 instanceof byte[];
               byte var26 = 0;
               byte var8 = 0;
               byte var9 = 0;
               byte var10 = 0;
               byte var11 = 0;
               byte var12 = 0;
               byte var13 = 0;
               int var22 = 0;
               if (var7) {
                  byte[] var15 = (byte[])var2;
                  this.d.b(91, var15.length);

                  while(var22 < var15.length) {
                     this.d.b(66, this.a.a(var15[var22]).a);
                     ++var22;
                  }

                  return;
               } else if (var2 instanceof boolean[]) {
                  boolean[] var17 = (boolean[])var2;
                  this.d.b(91, var17.length);

                  for(var22 = var26; var22 < var17.length; ++var22) {
                     this.d.b(90, this.a.a(var17[var22]).a);
                  }

                  return;
               } else if (var2 instanceof short[]) {
                  short[] var18 = (short[])var2;
                  this.d.b(91, var18.length);

                  for(var22 = var8; var22 < var18.length; ++var22) {
                     this.d.b(83, this.a.a(var18[var22]).a);
                  }

                  return;
               } else if (var2 instanceof char[]) {
                  char[] var19 = (char[])var2;
                  this.d.b(91, var19.length);

                  for(var22 = var9; var22 < var19.length; ++var22) {
                     this.d.b(67, this.a.a(var19[var22]).a);
                  }

                  return;
               } else if (var2 instanceof int[]) {
                  int[] var20 = (int[])var2;
                  this.d.b(91, var20.length);

                  for(var22 = var10; var22 < var20.length; ++var22) {
                     this.d.b(73, this.a.a(var20[var22]).a);
                  }

                  return;
               } else if (var2 instanceof long[]) {
                  long[] var21 = (long[])var2;
                  this.d.b(91, var21.length);

                  for(var22 = var11; var22 < var21.length; ++var22) {
                     this.d.b(74, this.a.a(var21[var22]).a);
                  }

                  return;
               } else if (var2 instanceof float[]) {
                  float[] var23 = (float[])var2;
                  this.d.b(91, var23.length);

                  for(var22 = var12; var22 < var23.length; ++var22) {
                     this.d.b(70, this.a.a(var23[var22]).a);
                  }

                  return;
               } else if (var2 instanceof double[]) {
                  double[] var24 = (double[])var2;
                  this.d.b(91, var24.length);

                  for(var22 = var13; var22 < var24.length; ++var22) {
                     this.d.b(68, this.a.a(var24[var22]).a);
                  }

                  return;
               } else {
                  l var25 = this.a.a(var2);
                  this.d.b(".s.IFJDCS".charAt(var25.b), var25.a);
                  return;
               }
            }

            var14 = this.d;
            var3 = 99;
            var4 = this.a;
            var5 = ((p)var2).b();
            var16 = var4;
         }

         var6 = var16.d(var5);
      }

      var14.b(var3, var6);
   }

   public void b() {
      c var1 = this.e;
      if (var1 != null) {
         byte[] var4 = var1.a;
         int var2 = this.f;
         int var3 = this.b;
         var4[var2] = (byte)((byte)(var3 >>> 8));
         var4[var2 + 1] = (byte)((byte)var3);
      }

   }
}
