package c.b.d.e.a.a.a;

public class d {
   public final byte[] a;
   public final int[] b;
   public final String[] c;
   public final int d;
   public final int e;

   public d(byte[] var1) {
      int var2 = var1.length;
      super();
      this.a = var1;
      if (this.c(6) > 51) {
         IllegalArgumentException var12 = new IllegalArgumentException();
         throw var12;
      } else {
         this.b = new int[this.d(8)];
         int var3 = this.b.length;
         this.c = new String[var3];
         int var4 = 1;
         int var5 = 0;

         int var6;
         int var11;
         for(var6 = 10; var4 < var3; var5 = var11) {
            int[] var7 = this.b;
            var2 = var6 + 1;
            var7[var4] = var2;
            byte var8 = var1[var6];
            byte var9 = 5;
            int var10;
            if (var8 != 1) {
               if (var8 != 15) {
                  var10 = var4;
                  var11 = var5;
                  var2 = var9;
                  if (var8 != 18) {
                     var10 = var4;
                     var11 = var5;
                     var2 = var9;
                     if (var8 != 3) {
                        var10 = var4;
                        var11 = var5;
                        var2 = var9;
                        if (var8 != 4) {
                           if (var8 != 5 && var8 != 6) {
                              var10 = var4;
                              var11 = var5;
                              var2 = var9;
                              switch(var8) {
                              case 9:
                              case 10:
                              case 11:
                              case 12:
                                 break;
                              default:
                                 var2 = 3;
                                 var10 = var4;
                                 var11 = var5;
                              }
                           } else {
                              var2 = 9;
                              var10 = var4 + 1;
                              var11 = var5;
                           }
                        }
                     }
                  }
               } else {
                  var2 = 4;
                  var10 = var4;
                  var11 = var5;
               }
            } else {
               int var13 = this.d(var2) + 3;
               var10 = var4;
               var11 = var5;
               var2 = var13;
               if (var13 > var5) {
                  var11 = var13;
                  var2 = var13;
                  var10 = var4;
               }
            }

            var6 += var2;
            var4 = var10 + 1;
         }

         this.d = var5;
         this.e = var6;
      }
   }

   public int a(int var1) {
      byte[] var2 = this.a;
      byte var3 = var2[var1];
      byte var4 = var2[var1 + 1];
      byte var5 = var2[var1 + 2];
      return var2[var1 + 3] & 255 | (var3 & 255) << 24 | (var4 & 255) << 16 | (var5 & 255) << 8;
   }

   public final int a(int var1, char[] var2, String var3, a var4) {
      byte var5 = 0;
      byte var6 = 0;
      byte var7 = 0;
      byte var8 = 0;
      byte var9 = 0;
      byte var10 = 0;
      int var11 = 0;
      if (var4 == null) {
         var11 = this.a[var1] & 255;
         if (var11 != 64) {
            if (var11 != 91) {
               return var11 != 101 ? var1 + 3 : var1 + 5;
            } else {
               return this.a(var1 + 1, var2, false, (a)null);
            }
         } else {
            return this.a(var1 + 3, var2, true, (a)null);
         }
      } else {
         byte[] var12 = this.a;
         int var13 = var1 + 1;
         var1 = var12[var1] & 255;
         c var17;
         String var28;
         if (var1 != 64) {
            Object var16;
            label181: {
               if (var1 != 70) {
                  if (var1 == 83) {
                     var16 = new Short((short)this.a(this.b[this.d(var13)]));
                     break label181;
                  }

                  if (var1 == 99) {
                     var16 = p.e(this.c(var13, var2));
                     break label181;
                  }

                  if (var1 == 101) {
                     var28 = this.c(var13, var2);
                     String var27 = this.c(var13 + 2, var2);
                     ++var4.b;
                     if (var4.c) {
                        var4.d.d(var4.a.d(var3));
                     }

                     var17 = var4.d;
                     var17.b(101, var4.a.d(var28));
                     var17.d(var4.a.d(var27));
                     var1 = var13 + 4;
                     return var1;
                  }

                  if (var1 == 115) {
                     var16 = this.c(var13, var2);
                     break label181;
                  }

                  if (var1 != 73 && var1 != 74) {
                     if (var1 == 90) {
                        if (this.a(this.b[this.d(var13)]) == 0) {
                           var16 = Boolean.FALSE;
                        } else {
                           var16 = Boolean.TRUE;
                        }
                        break label181;
                     }

                     if (var1 == 91) {
                        int var14 = this.d(var13);
                        var13 += 2;
                        if (var14 == 0) {
                           return this.a(var13 - 2, var2, false, var4.a(var3));
                        }

                        var12 = this.a;
                        var1 = var13 + 1;
                        var13 = var12[var13] & 255;
                        if (var13 != 70) {
                           if (var13 != 83) {
                              if (var13 != 90) {
                                 if (var13 != 73) {
                                    if (var13 != 74) {
                                       switch(var13) {
                                       case 66:
                                          byte[] var20 = new byte[var14];

                                          for(var11 = var6; var11 < var14; ++var11) {
                                             var20[var11] = (byte)((byte)this.a(this.b[this.d(var1)]));
                                             var1 += 3;
                                          }

                                          var4.a(var3, var20);
                                          break;
                                       case 67:
                                          var2 = new char[var14];

                                          for(var11 = var5; var11 < var14; ++var11) {
                                             var2[var11] = (char)((char)this.a(this.b[this.d(var1)]));
                                             var1 += 3;
                                          }

                                          var4.a(var3, var2);
                                          break;
                                       case 68:
                                          double[] var18;
                                          for(var18 = new double[var14]; var11 < var14; ++var11) {
                                             var18[var11] = Double.longBitsToDouble(this.b(this.b[this.d(var1)]));
                                             var1 += 3;
                                          }

                                          var4.a(var3, var18);
                                          break;
                                       default:
                                          var1 = this.a(var1 - 3, var2, false, var4.a(var3));
                                          return var1;
                                       }
                                    } else {
                                       long[] var22 = new long[var14];

                                       for(var11 = var7; var11 < var14; ++var11) {
                                          var22[var11] = this.b(this.b[this.d(var1)]);
                                          var1 += 3;
                                       }

                                       var4.a(var3, var22);
                                    }
                                 } else {
                                    int[] var23 = new int[var14];

                                    for(var11 = var8; var11 < var14; ++var11) {
                                       var23[var11] = this.a(this.b[this.d(var1)]);
                                       var1 += 3;
                                    }

                                    var4.a(var3, var23);
                                 }
                              } else {
                                 boolean[] var24 = new boolean[var14];

                                 for(var11 = 0; var11 < var14; ++var11) {
                                    boolean var15;
                                    if (this.a(this.b[this.d(var1)]) != 0) {
                                       var15 = true;
                                    } else {
                                       var15 = false;
                                    }

                                    var24[var11] = var15;
                                    var1 += 3;
                                 }

                                 var4.a(var3, var24);
                              }
                           } else {
                              short[] var25 = new short[var14];

                              for(var11 = var9; var11 < var14; ++var11) {
                                 var25[var11] = (short)((short)this.a(this.b[this.d(var1)]));
                                 var1 += 3;
                              }

                              var4.a(var3, var25);
                           }
                        } else {
                           float[] var26 = new float[var14];

                           for(var11 = var10; var11 < var14; ++var11) {
                              var26[var11] = Float.intBitsToFloat(this.a(this.b[this.d(var1)]));
                              var1 += 3;
                           }

                           var4.a(var3, var26);
                        }

                        --var1;
                        return var1;
                     }

                     switch(var1) {
                     case 66:
                        var16 = new Byte((byte)this.a(this.b[this.d(var13)]));
                        break label181;
                     case 67:
                        var16 = new Character((char)this.a(this.b[this.d(var13)]));
                        break label181;
                     case 68:
                        break;
                     default:
                        var1 = var13;
                        return var1;
                     }
                  }
               }

               var16 = this.b(this.d(var13), var2);
            }

            var4.a(var3, var16);
            var1 = var13 + 2;
         } else {
            var28 = this.c(var13, var2);
            ++var4.b;
            if (var4.c) {
               var4.d.d(var4.a.d(var3));
            }

            var17 = var4.d;
            var17.b(64, var4.a.d(var28));
            var17.d(0);
            f var19 = var4.a;
            c var21 = var4.d;
            var1 = this.a(var13 + 2, var2, true, new a(var19, true, var21, var21, var21.b - 2));
         }

         return var1;
      }
   }

   public final int a(int var1, char[] var2, boolean var3, a var4) {
      int var5 = this.d(var1);
      int var6 = var1 + 2;
      int var7 = var5;
      var1 = var6;
      if (var3) {
         var1 = var6;
         var7 = var5;

         while(true) {
            var5 = var1;
            if (var7 <= 0) {
               break;
            }

            var1 = this.a(var1 + 2, var2, this.c(var1, var2), var4);
            --var7;
         }
      } else {
         while(true) {
            var5 = var1;
            if (var7 <= 0) {
               break;
            }

            var1 = this.a(var1, var2, (String)null, var4);
            --var7;
         }
      }

      if (var4 != null) {
         var4.b();
      }

      return var5;
   }

   public final int a(Object[] var1, int var2, int var3, char[] var4, m[] var5) {
      byte[] var6 = this.a;
      int var7 = var3 + 1;
      switch(var6[var3] & 255) {
      case 0:
         var1[var2] = o.a;
         var2 = var7;
         return var2;
      case 1:
         var1[var2] = o.b;
         var2 = var7;
         return var2;
      case 2:
         var1[var2] = o.c;
         var2 = var7;
         return var2;
      case 3:
         var1[var2] = o.d;
         var2 = var7;
         return var2;
      case 4:
         var1[var2] = o.e;
         var2 = var7;
         return var2;
      case 5:
         var1[var2] = o.f;
         var2 = var7;
         return var2;
      case 6:
         var1[var2] = o.g;
         var2 = var7;
         return var2;
      case 7:
         var1[var2] = this.a(var7, var4);
         break;
      default:
         var1[var2] = this.a(this.d(var7), var5);
      }

      var2 = var7 + 2;
      return var2;
   }

   public final b a(b[] var1, String var2, int var3, int var4, char[] var5, int var6, m[] var7) {
      var6 = 0;

      b var8;
      while(true) {
         if (var6 >= var1.length) {
            var8 = new b(var2);
            break;
         }

         if (var1[var6].a.equals(var2)) {
            var8 = var1[var6];
            break;
         }

         ++var6;
      }

      return var8.a(this, var3, var4);
   }

   public m a(int var1, m[] var2) {
      if (var2[var1] == null) {
         var2[var1] = new m();
      }

      return var2[var1];
   }

   public final String a(int var1, int var2, char[] var3) {
      byte[] var4 = this.a;
      int var5 = 0;
      byte var6 = 0;
      char var7 = 0;
      int var8 = var1;

      while(true) {
         int var9 = var8;
         if (var8 >= var2 + var1) {
            return new String(var3, 0, var5);
         }

         byte var11;
         label45: {
            byte var10 = var4[var8];
            if (var6 != 0) {
               if (var6 == 1) {
                  var3[var5] = (char)((char)(var10 & 63 | var7 << 6));
                  ++var5;
                  var11 = 0;
                  break label45;
               }

               if (var6 != 2) {
                  var11 = var6;
                  break label45;
               }

               var8 = var10 & 63 | var7 << 6;
            } else {
               var8 = var10 & 255;
               if (var8 < 128) {
                  var3[var5] = (char)((char)var8);
                  ++var5;
                  var11 = var6;
                  break label45;
               }

               if (var8 >= 224 || var8 <= 191) {
                  var7 = (char)(var8 & 15);
                  var11 = 2;
                  break label45;
               }

               var8 &= 31;
            }

            var7 = (char)var8;
            var11 = 1;
         }

         ++var9;
         var6 = var11;
         var8 = var9;
      }
   }

   public String a(int var1, char[] var2) {
      return this.c(this.b[this.d(var1)], var2);
   }

   public final void a(int var1, String var2, char[] var3, boolean var4, n var5) {
      byte[] var6 = this.a;
      int var7 = var1 + 1;
      int var8 = var6[var1] & 255;
      int var9 = p.a(var2).length - var8;
      var1 = 0;

      while(true) {
         int var10 = var7;
         int var11 = var1;
         if (var1 >= var9) {
            while(var11 < var8 + var9) {
               var7 = this.d(var10);
               var1 = var10 + 2;

               for(var10 = var7; var10 > 0; --var10) {
                  var1 = this.a(var1 + 2, var3, true, var5.a(var11, this.c(var1, var3), var4));
               }

               ++var11;
               var10 = var1;
            }

            return;
         }

         var5.a(var1, "Ljava/lang/Synthetic;", false).b();
         ++var1;
      }
   }

   public void a(e var1, b[] var2, int var3) {
      byte[] var4 = this.a;
      char[] var5 = new char[this.d];
      int var6 = this.e;
      int var7 = this.d(var6);
      String var8 = this.a(var6 + 2, var5);
      int var9 = this.b[this.d(var6 + 4)];
      String var10;
      if (var9 == 0) {
         var10 = null;
      } else {
         var10 = this.c(var9, var5);
      }

      String[] var11 = new String[this.d(var6 + 6)];
      int var12 = var6 + 8;

      for(var9 = 0; var9 < var11.length; ++var9) {
         var11[var9] = this.a(var12, var5);
         var12 += 2;
      }

      boolean var13;
      if ((var3 & 1) != 0) {
         var13 = true;
      } else {
         var13 = false;
      }

      boolean var14;
      if ((var3 & 2) != 0) {
         var14 = true;
      } else {
         var14 = false;
      }

      boolean var15;
      if ((var3 & 8) != 0) {
         var15 = true;
      } else {
         var15 = false;
      }

      var6 = this.d(var12);
      int var16 = var12 + 2;

      int var17;
      for(var9 = var16; var6 > 0; --var6) {
         var17 = this.d(var9 + 6);

         for(var9 += 8; var17 > 0; --var17) {
            var9 += this.a(var9 + 2) + 6;
         }
      }

      var6 = this.d(var9);

      for(var9 += 2; var6 > 0; --var6) {
         var17 = this.d(var9 + 6);

         for(var9 += 8; var17 > 0; --var17) {
            var9 += this.a(var9 + 2) + 6;
         }
      }

      int var18 = this.d(var9);
      int var19 = var9 + 2;
      b var20 = null;
      String var21 = null;
      String var22 = null;
      String var23 = null;
      String var24 = null;
      String var25 = null;
      String var26 = null;
      var9 = 0;
      var6 = 0;
      var17 = 0;
      int[] var27 = null;

      while(true) {
         String var28 = "Deprecated";
         String var29 = "RuntimeInvisibleAnnotations";
         int var30 = 266240;
         String var31;
         int var32;
         int var33;
         if (var18 <= 0) {
            var18 = this.a(4);
            var31 = "RuntimeVisibleAnnotations";
            String var34 = "Signature";
            var1.a(var18, var7, var8, var25, var10, var11);
            if (!var14 && (var21 != null || var22 != null)) {
               var1.a(var21, var22);
            }

            e var66 = var1;
            var22 = "Synthetic";
            if (var23 != null) {
               var1.a(var23, var24, var26);
            }

            var7 = 1;

            while(true) {
               b var64 = var20;
               boolean var35;
               if (var7 < 0) {
                  b var58;
                  while(var64 != null) {
                     var58 = var64.c;
                     var64.c = null;
                     var66.a(var64);
                     var64 = var58;
                  }

                  String var57;
                  if (var17 != 0) {
                     var9 = this.d(var17);

                     for(var6 = var17 + 2; var9 > 0; --var9) {
                        if (this.d(var6) == 0) {
                           var24 = null;
                        } else {
                           var24 = this.a(var6, var5);
                        }

                        var17 = var6 + 2;
                        if (this.d(var17) == 0) {
                           var21 = null;
                        } else {
                           var21 = this.a(var17, var5);
                        }

                        var17 = var6 + 4;
                        if (this.d(var17) == 0) {
                           var57 = null;
                        } else {
                           var57 = this.c(var17, var5);
                        }

                        var66.a(var24, var21, var57, this.d(var6 + 6));
                        var6 += 8;
                     }
                  }

                  var6 = this.d(var12);
                  var9 = var16;
                  var24 = var34;
                  var25 = var29;
                  var16 = var6;
                  var21 = var28;

                  b var62;
                  for(var57 = var22; var16 > 0; var21 = var26) {
                     var12 = this.d(var9);
                     var10 = this.c(var9 + 2, var5);
                     String var49 = this.c(var9 + 4, var5);
                     var18 = this.d(var9 + 6);
                     var9 += 8;
                     var7 = 0;
                     var22 = null;
                     var23 = null;
                     var6 = 0;
                     var17 = 0;
                     var26 = var21;

                     for(var58 = var22; var18 > 0; --var18) {
                        var28 = this.c(var9, var5);
                        if ("ConstantValue".equals(var28)) {
                           var7 = this.d(var9 + 6);
                        } else if (var24.equals(var28)) {
                           var23 = this.c(var9 + 6, var5);
                        } else {
                           label1052: {
                              if (var26.equals(var28)) {
                                 var19 = 131072;
                              } else {
                                 if (!var57.equals(var28)) {
                                    if (var31.equals(var28)) {
                                       var6 = var9 + 6;
                                    } else if (var25.equals(var28)) {
                                       var17 = var9 + 6;
                                    } else {
                                       var19 = this.a(var9 + 2);
                                       var24 = var24;
                                       b var60 = this.a(var2, var28, var9 + 6, var19, var5, -1, (m[])null);
                                       if (var60 != null) {
                                          var60.c = var58;
                                          var58 = var60;
                                       }
                                    }
                                    break label1052;
                                 }

                                 var19 = 266240;
                              }

                              var12 |= var19;
                           }
                        }

                        var9 += this.a(var9 + 2) + 6;
                     }

                     Object var61;
                     if (var7 == 0) {
                        var61 = null;
                     } else {
                        var61 = this.b(var7, var5);
                     }

                     h var65 = var1.a(var12, var10, var49, var23, var61);
                     var7 = 1;

                     while(true) {
                        var62 = var58;
                        if (var7 < 0) {
                           while(var62 != null) {
                              var58 = var62.c;
                              var62.c = null;
                              var65.a(var62);
                              var62 = var58;
                           }

                           var65.a();
                           --var16;
                           break;
                        }

                        if (var7 == 0) {
                           var12 = var17;
                        } else {
                           var12 = var6;
                        }

                        if (var12 != 0) {
                           var18 = this.d(var12);
                           var19 = var12 + 2;
                           var12 = var18;

                           for(var18 = var19; var12 > 0; --var12) {
                              var23 = this.c(var18, var5);
                              if (var7 != 0) {
                                 var35 = true;
                              } else {
                                 var35 = false;
                              }

                              var18 = this.a(var18 + 2, var5, true, var65.a(var23, var35));
                           }
                        }

                        --var7;
                     }
                  }

                  var22 = var57;
                  var57 = var25;
                  var26 = var21;
                  var17 = this.d(var9);
                  var9 += 2;
                  var25 = var24;
                  var24 = var57;
                  var21 = var31;

                  for(var57 = var26; var17 > 0; var21 = var26) {
                     int var36 = var9 + 6;
                     var19 = this.d(var9);
                     var34 = this.c(var9 + 2, var5);
                     var10 = this.c(var9 + 4, var5);
                     var32 = this.d(var36);
                     var9 += 8;
                     b var68 = null;
                     var6 = 0;
                     var23 = null;
                     var18 = 0;
                     var7 = 0;
                     var12 = 0;
                     var16 = 0;
                     var30 = 0;

                     int var37;
                     int var38;
                     for(var33 = 0; var32 > 0; --var32) {
                        var31 = this.c(var9, var5);
                        var37 = this.a(var9 + 2);
                        var9 += 6;
                        if ("Code".equals(var31)) {
                           if (!var13) {
                              var7 = var9;
                           }
                        } else if ("Exceptions".equals(var31)) {
                           var6 = var9;
                        } else if (var25.equals(var31)) {
                           var23 = this.c(var9, var5);
                        } else {
                           label1045: {
                              if (var57.equals(var31)) {
                                 var38 = 131072;
                              } else {
                                 if (var21.equals(var31)) {
                                    var12 = var9;
                                    break label1045;
                                 }

                                 if ("AnnotationDefault".equals(var31)) {
                                    var18 = var9;
                                    break label1045;
                                 }

                                 if (!var22.equals(var31)) {
                                    if (var24.equals(var31)) {
                                       var16 = var9;
                                    } else if ("RuntimeVisibleParameterAnnotations".equals(var31)) {
                                       var30 = var9;
                                       var24 = var24;
                                    } else if ("RuntimeInvisibleParameterAnnotations".equals(var31)) {
                                       var33 = var9;
                                       var24 = var24;
                                    } else {
                                       b var51 = this.a(var2, var31, var9, var37, var5, -1, (m[])null);
                                       if (var51 != null) {
                                          var51.c = var68;
                                          var68 = var51;
                                       }
                                    }
                                    break label1045;
                                 }

                                 var38 = 266240;
                              }

                              var19 |= var38;
                           }
                        }

                        var9 += var37;
                     }

                     var31 = var10;
                     String[] var69;
                     if (var6 == 0) {
                        var69 = null;
                        var32 = var6;
                     } else {
                        var69 = new String[this.d(var6)];
                        var6 += 2;

                        for(var32 = 0; var32 < var69.length; ++var32) {
                           var69[var32] = this.a(var6, var5);
                           var6 += 2;
                        }

                        var32 = var6;
                     }

                     label1007: {
                        var6 = var9;
                        n var50 = var1.a(var19, var34, var10, var23, var69);
                        if (var50.b.a == this && var23 == var50.g) {
                           boolean var55;
                           label857: {
                              label856: {
                                 if (var69 == null) {
                                    if (var50.j == 0) {
                                       break label856;
                                    }
                                 } else if (var69.length == var50.j) {
                                    var9 = var69.length - 1;

                                    while(true) {
                                       if (var9 < 0) {
                                          break label856;
                                       }

                                       var32 -= 2;
                                       if (var50.k[var9] != this.d(var32)) {
                                          break;
                                       }

                                       --var9;
                                    }
                                 }

                                 var55 = false;
                                 break label857;
                              }

                              var55 = true;
                           }

                           if (var55) {
                              var50.h = var36;
                              var50.i = var9 - var36;
                              var9 = var9;
                              var26 = var21;
                              var21 = var57;
                              var57 = var26;
                              var6 = var17;
                              break label1007;
                           }
                        }

                        if (var18 != 0) {
                           a var73 = var50.c();
                           this.a(var18, var5, (String)null, var73);
                           var73.b();
                        }

                        for(var9 = 1; var9 >= 0; --var9) {
                           if (var9 == 0) {
                              var18 = var16;
                           } else {
                              var18 = var12;
                           }

                           if (var18 != 0) {
                              var32 = this.d(var18);
                              var38 = var18 + 2;
                              var18 = var32;

                              for(var32 = var38; var18 > 0; --var18) {
                                 var26 = this.c(var32, var5);
                                 if (var9 != 0) {
                                    var35 = true;
                                 } else {
                                    var35 = false;
                                 }

                                 var32 = this.a(var32 + 2, var5, true, var50.a(var26, var35));
                              }
                           }
                        }

                        if (var30 != 0) {
                           this.a(var30, var10, var5, true, var50);
                        }

                        Object var78 = var50;
                        var62 = var68;
                        if (var33 != 0) {
                           this.a(var33, var10, var5, false, var50);
                           var62 = var68;
                        }

                        while(var62 != null) {
                           b var52 = var62.c;
                           var62.c = null;
                           ((n)var78).a(var62);
                           var62 = var52;
                        }

                        if (var7 != 0) {
                           int var39 = this.d(var7);
                           var36 = this.d(var7 + 2);
                           var37 = this.a(var7 + 4);
                           int var40 = var7 + 8;
                           int var41 = var40 + var37;
                           ((n)var78).d();
                           m[] var76 = new m[var37 + 2];
                           this.a(var37 + 1, var76);
                           var9 = var40;

                           while(true) {
                              label817:
                              while(var9 < var41) {
                                 var16 = var9 - var40;
                                 byte var48 = var4[var9];
                                 switch(f.L[var48 & 255]) {
                                 case 0:
                                 case 4:
                                    ++var9;
                                    break;
                                 case 1:
                                 case 3:
                                 case 11:
                                    var9 += 2;
                                    break;
                                 case 9:
                                    this.a(this.c(var9 + 1) + var16, var76);
                                 case 2:
                                 case 5:
                                 case 6:
                                 case 12:
                                 case 13:
                                    var9 += 3;
                                    break;
                                 case 10:
                                    this.a(this.a(var9 + 1) + var16, var76);
                                 case 7:
                                 case 8:
                                    var9 += 5;
                                    break;
                                 case 14:
                                    var9 = var9 + 4 - (var16 & 3);
                                    this.a(this.a(var9) + var16, var76);
                                    var12 = this.a(var9 + 8) - this.a(var9 + 4) + 1;
                                    var7 = var9 + 12;

                                    while(true) {
                                       var9 = var7;
                                       if (var12 <= 0) {
                                          continue label817;
                                       }

                                       this.a(this.a(var7) + var16, var76);
                                       var7 += 4;
                                       --var12;
                                    }
                                 case 15:
                                    var9 = var9 + 4 - (var16 & 3);
                                    this.a(this.a(var9) + var16, var76);
                                    var12 = this.a(var9 + 4);
                                    var7 = var9 + 8;

                                    while(true) {
                                       var9 = var7;
                                       if (var12 <= 0) {
                                          continue label817;
                                       }

                                       this.a(this.a(var7 + 4) + var16, var76);
                                       var7 += 8;
                                       --var12;
                                    }
                                 case 17:
                                    if ((255 & var4[var9 + 1]) == 132) {
                                       var9 += 6;
                                       break;
                                    }
                                 case 16:
                                 default:
                                    var9 += 4;
                                 }
                              }

                              var7 = this.d(var9);

                              for(var9 += 2; var7 > 0; --var7) {
                                 m var53 = this.a(this.d(var9), var76);
                                 m var71 = this.a(this.d(var9 + 2), var76);
                                 m var54 = this.a(this.d(var9 + 4), var76);
                                 var12 = this.d(var9 + 6);
                                 if (var12 == 0) {
                                    var23 = null;
                                 } else {
                                    var23 = this.c(this.b[var12], var5);
                                 }

                                 ((n)var78).a(var53, var71, var54, var23);
                                 var9 += 8;
                              }

                              int var42 = var6;
                              int var43 = var17;
                              var10 = var21;
                              var33 = this.d(var9);
                              var30 = var9 + 2;
                              var7 = 0;
                              var6 = 0;
                              var17 = 0;
                              var58 = null;
                              var9 = 0;
                              var18 = 0;
                              boolean var56 = true;

                              Object var59;
                              for(var59 = var78; var33 > 0; --var33) {
                                 label791: {
                                    label790: {
                                       label789: {
                                          var23 = this.c(var30, var5);
                                          m var81;
                                          if ("LocalVariableTable".equals(var23)) {
                                             if (!var14) {
                                                var6 = var30 + 6;
                                                var16 = this.d(var6);
                                                var32 = var30 + 8;

                                                while(true) {
                                                   if (var16 <= 0) {
                                                      break label791;
                                                   }

                                                   var38 = this.d(var32);
                                                   if (var76[var38] == null) {
                                                      var81 = this.a(var38, var76);
                                                      var81.a |= 1;
                                                   }

                                                   var38 += this.d(var32 + 2);
                                                   if (var76[var38] == null) {
                                                      var81 = this.a(var38, var76);
                                                      var81.a |= 1;
                                                   }

                                                   var32 += 10;
                                                   --var16;
                                                }
                                             }

                                             var16 = var6;
                                          } else {
                                             if ("LocalVariableTypeTable".equals(var23)) {
                                                var17 = var30 + 6;
                                                var59 = var59;
                                                break label791;
                                             }

                                             if ("LineNumberTable".equals(var23)) {
                                                var16 = var6;
                                                if (!var14) {
                                                   var32 = this.d(var30 + 6);
                                                   var38 = var30 + 8;

                                                   while(true) {
                                                      var16 = var6;
                                                      if (var32 <= 0) {
                                                         break;
                                                      }

                                                      var16 = this.d(var38);
                                                      if (var76[var16] == null) {
                                                         var81 = this.a(var16, var76);
                                                         var81.a |= 1;
                                                      }

                                                      var76[var16].b = this.d(var38 + 2);
                                                      var38 += 4;
                                                      --var32;
                                                   }
                                                }
                                             } else if ("StackMapTable".equals(var23)) {
                                                var16 = var6;
                                                if ((var3 & 4) == 0) {
                                                   var7 = var30 + 8;
                                                   var16 = this.a(var30 + 2);
                                                   var9 = this.d(var30 + 6);
                                                   break label790;
                                                }
                                             } else {
                                                if (!"StackMap".equals(var23)) {
                                                   var32 = 0;

                                                   while(true) {
                                                      var68 = var58;
                                                      var16 = var6;
                                                      if (var32 >= var2.length) {
                                                         break label789;
                                                      }

                                                      if (var2[var32].a.equals(var23)) {
                                                         var68 = var2[var32].a(this, var30 + 6, this.a(var30 + 2));
                                                         var68.c = var58;
                                                         var58 = var68;
                                                      }

                                                      ++var32;
                                                   }
                                                }

                                                var16 = var6;
                                                if ((var3 & 4) == 0) {
                                                   var7 = var30 + 8;
                                                   var16 = this.a(var30 + 2);
                                                   var9 = this.d(var30 + 6);
                                                   var56 = false;
                                                   break label790;
                                                }
                                             }
                                          }

                                          var68 = var58;
                                       }

                                       var58 = var68;
                                       var6 = var16;
                                       break label791;
                                    }

                                    var18 = var16;
                                 }

                                 var30 += this.a(var30 + 2) + 6;
                              }

                              var33 = var9;
                              byte var67;
                              Object[] var72;
                              Object[] var88;
                              if (var7 == 0) {
                                 var67 = 0;
                                 var88 = null;
                                 var9 = 0;
                                 var72 = null;
                              } else {
                                 var72 = new Object[var36];
                                 var88 = new Object[var39];
                                 if (var15) {
                                    if ((var19 & 8) == 0) {
                                       if ("<init>".equals(var34)) {
                                          var72[0] = o.g;
                                       } else {
                                          var72[0] = this.a(this.e + 2, var5);
                                       }

                                       var9 = 1;
                                    } else {
                                       var9 = 0;
                                    }

                                    var19 = 1;
                                    var59 = var31;

                                    label751:
                                    while(true) {
                                       while(true) {
                                          var30 = var19 + 1;
                                          char var91 = ((String)var59).charAt(var19);
                                          if (var91 != 'F') {
                                             label1020: {
                                                if (var91 == 'L') {
                                                   for(var16 = var30; ((String)var59).charAt(var16) != ';'; ++var16) {
                                                   }

                                                   var72[var9] = ((String)var59).substring(var30, var16);
                                                   ++var9;
                                                   var19 = var16 + 1;
                                                   continue;
                                                }

                                                if (var91 != 'S' && var91 != 'I') {
                                                   if (var91 == 'J') {
                                                      var16 = var9 + 1;
                                                      var72[var9] = o.e;
                                                      var9 = var16;
                                                      break label1020;
                                                   }

                                                   if (var91 != 'Z') {
                                                      var16 = var30;
                                                      if (var91 == '[') {
                                                         while(((String)var59).charAt(var16) == '[') {
                                                            ++var16;
                                                         }

                                                         var30 = var16;
                                                         if (((String)var59).charAt(var16) == 'L') {
                                                            do {
                                                               ++var16;
                                                               var30 = var16;
                                                            } while(((String)var59).charAt(var16) != ';');
                                                         }

                                                         var16 = var9 + 1;
                                                         ++var30;
                                                         var72[var9] = ((String)var59).substring(var19, var30);
                                                         var9 = var16;
                                                         break label1020;
                                                      }

                                                      switch(var91) {
                                                      case 'B':
                                                      case 'C':
                                                         break;
                                                      case 'D':
                                                         var16 = var9 + 1;
                                                         var72[var9] = o.d;
                                                         var9 = var16;
                                                         break label1020;
                                                      default:
                                                         break label751;
                                                      }
                                                   }
                                                }

                                                var16 = var9 + 1;
                                                var72[var9] = o.b;
                                                var9 = var16;
                                             }
                                          } else {
                                             var16 = var9 + 1;
                                             var72[var9] = o.c;
                                             var9 = var16;
                                          }

                                          var19 = var30;
                                       }
                                    }
                                 } else {
                                    var9 = 0;
                                 }

                                 for(var16 = var7; var16 < var7 + var18 - 2; ++var16) {
                                    if (var4[var16] == 8) {
                                       var19 = this.d(var16 + 1);
                                       if (var19 >= 0 && var19 < var37 && (var4[var40 + var19] & 255) == 187) {
                                          this.a(var19, var76);
                                       }
                                    }
                                 }

                                 var67 = -1;
                              }

                              var32 = var67;
                              var37 = var40;
                              var19 = 0;
                              byte var44 = 0;
                              var38 = 0;
                              var59 = var59;
                              var16 = var33;
                              Object[] var89 = var72;
                              var18 = var9;
                              var72 = var88;
                              var33 = var41;
                              m[] var90 = var76;

                              for(byte var74 = var44; var37 < var33; var16 = var36) {
                                 int var45 = var37 - var40;
                                 var36 = var19;
                                 m var79 = var90[var45];
                                 if (var79 != null) {
                                    ((n)var59).a(var79);
                                    if (!var14) {
                                       var19 = var79.b;
                                       if (var19 > 0) {
                                          ((n)var59).c(var19, var79);
                                       }
                                    }
                                 }

                                 var19 = var16;
                                 var16 = var32;
                                 m[] var63 = var90;
                                 var78 = var59;
                                 byte var92 = var74;

                                 while(true) {
                                    m[] var77;
                                    while(var89 != null && (var16 == var45 || var16 == -1)) {
                                       if (var56 && !var15) {
                                          if (var16 != -1) {
                                             ((n)var78).a(var92, var38, var89, var36, var72);
                                          }
                                       } else {
                                          ((n)var78).a(-1, var18, var89, var36, var72);
                                       }

                                       if (var19 > 0) {
                                          if (var56) {
                                             var9 = var4[var7] & 255;
                                             var32 = var7 + 1;
                                             var7 = var9;
                                             var9 = var32;
                                             var36 = var16;
                                          } else {
                                             var9 = var7;
                                             var7 = 255;
                                             var36 = -1;
                                          }

                                          byte var70;
                                          label646: {
                                             label645: {
                                                label1064: {
                                                   if (var7 >= 64) {
                                                      label1048: {
                                                         if (var7 < 128) {
                                                            var16 = var7 - 64;
                                                            var7 = this.a(var72, 0, var9, var5, var63);
                                                            var9 = var16;
                                                         } else {
                                                            var77 = var63;
                                                            var32 = this.d(var9);
                                                            var9 += 2;
                                                            if (var7 != 247) {
                                                               if (var7 >= 248 && var7 < 251) {
                                                                  var7 = 251 - var7;
                                                                  var38 = var18 - var7;
                                                                  var18 = var7;
                                                                  var70 = 2;
                                                                  var7 = var9;
                                                                  break label1064;
                                                               }

                                                               if (var7 != 251) {
                                                                  if (var7 >= 255) {
                                                                     var7 = this.d(var9);
                                                                     var9 += 2;
                                                                     var16 = var7;

                                                                     for(var18 = 0; var16 > 0; ++var18) {
                                                                        var9 = this.a(var89, var18, var9, var5, var77);
                                                                        --var16;
                                                                     }

                                                                     var16 = this.d(var9);
                                                                     var9 += 2;
                                                                     var18 = var16;

                                                                     for(var38 = 0; var18 > 0; ++var38) {
                                                                        var9 = this.a(var72, var38, var9, var5, var77);
                                                                        --var18;
                                                                     }

                                                                     var41 = var9;
                                                                     var18 = var7;
                                                                     var44 = 0;
                                                                     var9 = var16;
                                                                     var38 = var7;
                                                                     var7 = var41;
                                                                     var70 = var44;
                                                                     break label646;
                                                                  }

                                                                  if (var15) {
                                                                     var16 = var18;
                                                                  } else {
                                                                     var16 = 0;
                                                                  }

                                                                  var7 -= 251;
                                                                  var38 = var16;

                                                                  for(var16 = var7; var16 > 0; ++var38) {
                                                                     var9 = this.a(var89, var38, var9, var5, var77);
                                                                     --var16;
                                                                  }

                                                                  var41 = var7;
                                                                  var38 = var18 + var7;
                                                                  var70 = 1;
                                                                  var7 = var9;
                                                                  var18 = var41;
                                                                  break label1064;
                                                               }

                                                               var7 = var32;
                                                               break label1048;
                                                            }

                                                            var7 = this.a(var72, 0, var9, var5, var63);
                                                            var9 = var32;
                                                         }

                                                         var70 = 4;
                                                         var92 = 1;
                                                         break label645;
                                                      }
                                                   }

                                                   var16 = var9;
                                                   var9 = var7;
                                                   byte var93 = 3;
                                                   var92 = 0;
                                                   var7 = var16;
                                                   var70 = var93;
                                                   break label645;
                                                }

                                                var9 = 0;
                                                break label646;
                                             }

                                             var44 = 0;
                                             var38 = var18;
                                             var32 = var9;
                                             var9 = var92;
                                             var18 = var44;
                                          }

                                          var36 += var32 + 1;
                                          this.a(var36, var63);
                                          var41 = var19 - 1;
                                          var19 = var18;
                                          var92 = var70;
                                          var18 = var38;
                                          var16 = var36;
                                          var38 = var19;
                                          var36 = var9;
                                          var19 = var41;
                                       } else {
                                          var89 = null;
                                       }
                                    }

                                    label1090: {
                                       label1091: {
                                          label692: {
                                             label691: {
                                                label690: {
                                                   var9 = var4[var37] & 255;
                                                   int var95;
                                                   switch(f.L[var9]) {
                                                   case 0:
                                                      ((n)var78).a(var9);
                                                      break label690;
                                                   case 1:
                                                      ((n)var78).c(var9, var4[var37 + 1]);
                                                      break label691;
                                                   case 2:
                                                      ((n)var78).c(var9, this.c(var37 + 1));
                                                      break label692;
                                                   case 3:
                                                      ((n)var78).e(var9, var4[var37 + 1] & 255);
                                                      break label691;
                                                   case 4:
                                                      if (var9 > 54) {
                                                         var41 = var9 - 59;
                                                         var9 = (var41 >> 2) + 54;
                                                      } else {
                                                         var41 = var9 - 26;
                                                         var9 = (var41 >> 2) + 21;
                                                      }

                                                      ((n)var78).e(var9, 3 & var41);
                                                      break label690;
                                                   case 5:
                                                      ((n)var78).a(var9, this.a(var37 + 1, var5));
                                                      break label692;
                                                   case 6:
                                                   case 7:
                                                      var41 = this.b[this.d(var37 + 1)];
                                                      var28 = this.a(var41, var5);
                                                      var41 = this.b[this.d(var41 + 2)];
                                                      var34 = this.c(var41, var5);
                                                      var29 = this.c(var41 + 2, var5);
                                                      if (var9 < 182) {
                                                         ((n)var78).a(var9, var28, var34, var29);
                                                      } else {
                                                         ((n)var78).b(var9, var28, var34, var29);
                                                      }

                                                      if (var9 != 185) {
                                                         break label692;
                                                      }
                                                      break;
                                                   case 8:
                                                      var9 = this.b[this.d(var37 + 1)];
                                                      var41 = var27[this.d(var9)];
                                                      var9 = this.b[this.d(var9 + 2)];
                                                      var34 = this.c(var9, var5);
                                                      var28 = this.c(var9 + 2, var5);
                                                      j var83 = (j)this.b(this.d(var41), var5);
                                                      var9 = this.d(var41 + 2);
                                                      Object[] var47 = new Object[var9];
                                                      var41 += 4;

                                                      for(var95 = 0; var95 < var9; ++var95) {
                                                         var47[var95] = this.b(this.d(var41), var5);
                                                         var41 += 2;
                                                      }

                                                      ((n)var78).a(var34, var28, var83, var47);
                                                      break;
                                                   case 9:
                                                      ((n)var78).b(var9, var63[this.c(var37 + 1) + var45]);
                                                      break label692;
                                                   case 10:
                                                      ((n)var78).b(var9 - 33, var63[this.a(var37 + 1) + var45]);
                                                      break;
                                                   case 11:
                                                      ((n)var78).b(this.b(var4[var37 + 1] & 255, var5));
                                                      break label691;
                                                   case 12:
                                                      ((n)var78).b(this.b(this.d(var37 + 1), var5));
                                                      break label692;
                                                   case 13:
                                                      ((n)var78).b(var4[var37 + 1] & 255, var4[var37 + 2]);
                                                      break label692;
                                                   case 14:
                                                      var9 = var37 + 4 - (var45 & 3);
                                                      var41 = this.a(var9);
                                                      int var46 = this.a(var9 + 4);
                                                      var95 = this.a(var9 + 8);
                                                      var77 = new m[var95 - var46 + 1];
                                                      var9 += 12;

                                                      for(var37 = 0; var37 < var77.length; ++var37) {
                                                         var77[var37] = var63[this.a(var9) + var45];
                                                         var9 += 4;
                                                      }

                                                      ((n)var78).a(var46, var95, var63[var41 + var45], var77);
                                                      break label1091;
                                                   case 15:
                                                      var9 = var37 + 4 - (var45 & 3);
                                                      var41 = this.a(var9);
                                                      var37 = this.a(var9 + 4);
                                                      int[] var80 = new int[var37];
                                                      var76 = new m[var37];
                                                      var9 += 8;

                                                      for(var37 = 0; var37 < var80.length; ++var37) {
                                                         var80[var37] = this.a(var9);
                                                         var76[var37] = var63[this.a(var9 + 4) + var45];
                                                         var9 += 8;
                                                      }

                                                      ((n)var78).a(var63[var41 + var45], var80, var76);
                                                      break label1091;
                                                   case 16:
                                                   default:
                                                      ((n)var78).a(this.a(var37 + 1, var5), var4[var37 + 3] & 255);
                                                      var37 += 4;
                                                      break label1090;
                                                   case 17:
                                                      var9 = var4[var37 + 1] & 255;
                                                      if (var9 == 132) {
                                                         ((n)var78).b(this.d(var37 + 2), this.c(var37 + 4));
                                                         var9 = var37 + 6;
                                                      } else {
                                                         ((n)var78).e(var9, this.d(var37 + 2));
                                                         var9 = var37 + 4;
                                                      }
                                                      break label1091;
                                                   }

                                                   var9 = var37 + 5;
                                                   break label1091;
                                                }

                                                var9 = var37 + 1;
                                                break label1091;
                                             }

                                             var9 = var37 + 2;
                                             break label1091;
                                          }

                                          var9 = var37 + 3;
                                       }

                                       var37 = var9;
                                    }

                                    var9 = var36;
                                    var36 = var19;
                                    var59 = var78;
                                    var19 = var9;
                                    var74 = var92;
                                    var90 = var63;
                                    var72 = var72;
                                    var32 = var16;
                                    break;
                                 }
                              }

                              m var84 = var90[var33 - var40];
                              if (var84 != null) {
                                 ((n)var59).a(var84);
                              }

                              if (!var14 && var6 != 0) {
                                 int[] var85;
                                 if (var17 != 0) {
                                    var7 = this.d(var17) * 3;
                                    var9 = var17 + 2;
                                    var85 = new int[var7];

                                    for(var17 = var7; var17 > 0; var9 += 10) {
                                       --var17;
                                       var85[var17] = var9 + 6;
                                       --var17;
                                       var85[var17] = this.d(var9 + 8);
                                       --var17;
                                       var85[var17] = this.d(var9);
                                    }
                                 } else {
                                    var85 = null;
                                 }

                                 var9 = this.d(var6);

                                 for(var6 += 2; var9 > 0; --var9) {
                                    label569: {
                                       var7 = this.d(var6);
                                       var16 = this.d(var6 + 2);
                                       var12 = this.d(var6 + 8);
                                       if (var85 != null) {
                                          for(var17 = 0; var17 < var85.length; var17 += 3) {
                                             if (var85[var17] == var7 && var85[var17 + 1] == var12) {
                                                var31 = this.c(var85[var17 + 2], var5);
                                                break label569;
                                             }
                                          }
                                       }

                                       var31 = null;
                                    }

                                    ((n)var59).a(this.c(var6 + 4, var5), this.c(var6 + 6, var5), var31, var90[var7], var90[var7 + var16], var12);
                                    var6 += 10;
                                 }
                              }

                              while(var58 != null) {
                                 var68 = var58.c;
                                 var58.c = null;
                                 ((n)var59).a(var58);
                                 var58 = var68;
                              }

                              ((n)var59).d(var39, var36);
                              var78 = var59;
                              var9 = var42;
                              var21 = var57;
                              var57 = var10;
                              var6 = var43;
                              break;
                           }
                        } else {
                           var9 = var6;
                           var6 = var17;
                           var23 = var57;
                           var57 = var21;
                           var21 = var23;
                        }

                        ((n)var78).e();
                     }

                     var17 = var6 - 1;
                     var26 = var57;
                     var57 = var21;
                  }

                  var1.a();
                  return;
               }

               if (var7 == 0) {
                  var18 = var6;
               } else {
                  var18 = var9;
               }

               if (var18 != 0) {
                  var19 = this.d(var18);
                  var30 = var18 + 2;
                  var18 = var19;

                  for(var19 = var30; var18 > 0; --var18) {
                     var24 = this.c(var19, var5);
                     if (var7 != 0) {
                        var35 = true;
                     } else {
                        var35 = false;
                     }

                     var19 = this.a(var19 + 2, var5, true, var66.a(var24, var35));
                  }
               }

               --var7;
            }
         }

         var31 = this.c(var19, var5);
         if ("SourceFile".equals(var31)) {
            var21 = this.c(var19 + 6, var5);
         } else if ("InnerClasses".equals(var31)) {
            var17 = var19 + 6;
         } else if ("EnclosingMethod".equals(var31)) {
            var23 = this.a(var19 + 6, var5);
            var30 = this.d(var19 + 8);
            if (var30 != 0) {
               var24 = this.c(this.b[var30], var5);
               var26 = this.c(this.b[var30] + 2, var5);
            }
         } else if ("Signature".equals(var31)) {
            var25 = this.c(var19 + 6, var5);
         } else if ("RuntimeVisibleAnnotations".equals(var31)) {
            var9 = var19 + 6;
         } else {
            label1058: {
               if ("Deprecated".equals(var31)) {
                  var30 = 131072;
               } else if (!"Synthetic".equals(var31)) {
                  if ("SourceDebugExtension".equals(var31)) {
                     var30 = this.a(var19 + 2);
                     var22 = this.a(var19 + 6, var30, new char[var30]);
                     break label1058;
                  }

                  if ("RuntimeInvisibleAnnotations".equals(var31)) {
                     var6 = var19 + 6;
                     break label1058;
                  }

                  if ("BootstrapMethods".equals(var31)) {
                     var32 = this.d(var19 + 6);
                     var27 = new int[var32];
                     var30 = var19 + 8;
                     var33 = 0;

                     while(true) {
                        if (var33 >= var32) {
                           break label1058;
                        }

                        var27[var33] = var30;
                        var30 += this.d(var30 + 2) + 2 << 1;
                        ++var33;
                     }
                  }

                  b var87 = this.a(var2, var31, var19 + 6, this.a(var19 + 2), var5, -1, (m[])null);
                  if (var87 != null) {
                     var87.c = var20;
                     var20 = var87;
                  }
                  break label1058;
               }

               var7 |= var30;
            }
         }

         var19 += this.a(var19 + 2) + 6;
         --var18;
      }
   }

   public long b(int var1) {
      return (long)this.a(var1) << 32 | (long)this.a(var1 + 4) & 4294967295L;
   }

   public Object b(int var1, char[] var2) {
      int[] var3 = this.b;
      int var4 = var3[var1];
      byte[] var5 = this.a;
      byte var6 = var5[var4 - 1];
      if (var6 != 16) {
         switch(var6) {
         case 3:
            return new Integer(this.a(var4));
         case 4:
            return new Float(Float.intBitsToFloat(this.a(var4)));
         case 5:
            return new Long(this.b(var4));
         case 6:
            return new Double(Double.longBitsToDouble(this.b(var4)));
         case 7:
            return p.d(this.c(var4, var2));
         case 8:
            return this.c(var4, var2);
         default:
            var6 = var5[var4];
            var4 = var3[this.d(var4 + 1)];
            String var7 = this.a(var4, var2);
            var4 = var3[this.d(var4 + 2)];
            return new j(var6 & 255, var7, this.c(var4, var2), this.c(var4 + 2, var2));
         }
      } else {
         return p.c(this.c(var4, var2));
      }
   }

   public String c(int var1, char[] var2) {
      int var3 = this.d(var1);
      String[] var4 = this.c;
      String var5 = var4[var3];
      if (var5 != null) {
         return var5;
      } else {
         var1 = this.b[var3];
         String var6 = this.a(var1 + 2, this.d(var1), var2);
         var4[var3] = var6;
         return var6;
      }
   }

   public short c(int var1) {
      byte[] var2 = this.a;
      byte var3 = var2[var1];
      return (short)(var2[var1 + 1] & 255 | (var3 & 255) << 8);
   }

   public int d(int var1) {
      byte[] var2 = this.a;
      byte var3 = var2[var1];
      return var2[var1 + 1] & 255 | (var3 & 255) << 8;
   }
}
