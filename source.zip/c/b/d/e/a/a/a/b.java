package c.b.d.e.a.a.a;

public class b {
   public final String a;
   public byte[] b;
   public b c;

   public b(String var1) {
      this.a = var1;
   }

   public final int a() {
      int var1 = 0;

      for(b var2 = this; var2 != null; var2 = var2.c) {
         ++var1;
      }

      return var1;
   }

   public final int a(f var1, byte[] var2, int var3, int var4, int var5) {
      var3 = 0;

      for(b var6 = this; var6 != null; var6 = var6.c) {
         var1.d(var6.a);
         var3 += var6.b.length + 6;
      }

      return var3;
   }

   public b a(d var1, int var2, int var3) {
      b var4 = new b(this.a);
      var4.b = new byte[var3];
      System.arraycopy(var1.a, var2, var4.b, 0, var3);
      return var4;
   }

   public final void a(f var1, byte[] var2, int var3, int var4, int var5, c var6) {
      for(b var8 = this; var8 != null; var8 = var8.c) {
         byte[] var7 = var8.b;
         var3 = var7.length;
         var6.d(var1.d(var8.a));
         var6.c(var3);
         var6.a(var7, 0, var3);
      }

   }

   public boolean b() {
      return false;
   }
}
