package c.b.d;

import c.b.d.e.a.a.a.f;
import c.b.d.e.a.a.a.n;

public abstract class b {
   public boolean a;

   public static b a(Class param0) {
      // $FF: Couldn't be decompiled
   }

   public static void a(f var0, String var1, String var2) {
      n var3 = var0.a(1, "newInstance", "(Ljava/lang/Object;)Ljava/lang/Object;", (String)null, (String[])null);
      if (var2 != null) {
         var3.a(187, (String)var1);
         var3.a(89);
         var3.e(25, 1);
         var3.a(192, (String)var2);
         var3.a(89);
         var3.b(182, "java/lang/Object", "getClass", "()Ljava/lang/Class;");
         var3.a(87);
         StringBuilder var4 = new StringBuilder();
         var4.append("(L");
         var4.append(var2);
         var4.append(";)V");
         var3.b(183, var1, "<init>", var4.toString());
         var3.a(176);
         var3.d(4, 2);
      } else {
         var3.a(187, (String)"java/lang/UnsupportedOperationException");
         var3.a(89);
         var3.b("Not an inner class.");
         var3.b(183, "java/lang/UnsupportedOperationException", "<init>", "(Ljava/lang/String;)V");
         var3.a(191);
         var3.d(3, 2);
      }

   }

   public abstract Object a();
}
