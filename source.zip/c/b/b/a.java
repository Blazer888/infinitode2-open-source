package c.b.b;

public interface a {
   public static class a implements c.b.b.a {
   }

   public static class b implements c.b.b.a {
   }

   public static class c implements c.b.b.a {
   }

   public static class d implements c.b.b.a {
   }

   public static class e implements c.b.b.a {
   }
}
