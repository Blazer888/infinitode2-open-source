package a.a.a.a;

import android.app.Notification;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public interface a extends IInterface {
   public abstract static class a extends Binder implements a.a.a.a.a {
      public static a.a.a.a.a a(IBinder var0) {
         if (var0 == null) {
            return null;
         } else {
            IInterface var1 = var0.queryLocalInterface("android.support.v4.app.INotificationSideChannel");
            return (a.a.a.a.a)(var1 != null && var1 instanceof a.a.a.a.a ? (a.a.a.a.a)var1 : new a.a.a.a.a.a.a(var0));
         }
      }

      public static class a implements a.a.a.a.a {
         public IBinder a;

         public a(IBinder var1) {
            this.a = var1;
         }

         public void a(String var1, int var2, String var3, Notification var4) {
            Parcel var5 = Parcel.obtain();

            label166: {
               Throwable var10000;
               label170: {
                  boolean var10001;
                  try {
                     var5.writeInterfaceToken("android.support.v4.app.INotificationSideChannel");
                     var5.writeString(var1);
                     var5.writeInt(var2);
                     var5.writeString(var3);
                  } catch (Throwable var25) {
                     var10000 = var25;
                     var10001 = false;
                     break label170;
                  }

                  if (var4 != null) {
                     try {
                        var5.writeInt(1);
                        var4.writeToParcel(var5, 0);
                     } catch (Throwable var24) {
                        var10000 = var24;
                        var10001 = false;
                        break label170;
                     }
                  } else {
                     try {
                        var5.writeInt(0);
                     } catch (Throwable var23) {
                        var10000 = var23;
                        var10001 = false;
                        break label170;
                     }
                  }

                  label156:
                  try {
                     this.a.transact(1, var5, (Parcel)null, 1);
                     break label166;
                  } catch (Throwable var22) {
                     var10000 = var22;
                     var10001 = false;
                     break label156;
                  }
               }

               Throwable var26 = var10000;
               var5.recycle();
               throw var26;
            }

            var5.recycle();
         }

         public IBinder asBinder() {
            return this.a;
         }
      }
   }
}
