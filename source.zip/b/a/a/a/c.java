package b.a.a.a;

public abstract class c {
   public abstract void a(Runnable var1);

   public abstract boolean a();

   public abstract void b(Runnable var1);
}
