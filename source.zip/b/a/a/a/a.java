package b.a.a.a;

import java.util.concurrent.Executor;

public class a extends c {
   public static volatile a c;
   public static final Executor d;
   public c a;
   public c b = new b();

   static {
      Executor var0 = new Executor() {
         public void execute(Runnable var1) {
            b.a.a.a.a.b().a.b(var1);
         }
      };
      d = new Executor() {
         public void execute(Runnable var1) {
            b.a.a.a.a.b().a(var1);
         }
      };
   }

   public a() {
      this.a = this.b;
   }

   public static a b() {
      if (c != null) {
         return c;
      } else {
         synchronized(a.class){}

         Throwable var10000;
         boolean var10001;
         label145: {
            try {
               if (c == null) {
                  a var0 = new a();
                  c = var0;
               }
            } catch (Throwable var12) {
               var10000 = var12;
               var10001 = false;
               break label145;
            }

            label142:
            try {
               return c;
            } catch (Throwable var11) {
               var10000 = var11;
               var10001 = false;
               break label142;
            }
         }

         while(true) {
            Throwable var13 = var10000;

            try {
               throw var13;
            } catch (Throwable var10) {
               var10000 = var10;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public void a(Runnable var1) {
      this.a.a(var1);
   }

   public boolean a() {
      return this.a.a();
   }

   public void b(Runnable var1) {
      this.a.b(var1);
   }
}
