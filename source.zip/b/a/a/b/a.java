package b.a.a.b;

import java.util.HashMap;

public class a extends b.a.a.b.b {
   public HashMap e = new HashMap();

   public b.a.a.b.b.c a(Object var1) {
      return (b.a.a.b.b.c)this.e.get(var1);
   }

   public Object b(Object var1, Object var2) {
      b.a.a.b.b.c var3 = (b.a.a.b.b.c)this.e.get(var1);
      if (var3 != null) {
         return var3.b;
      } else {
         this.e.put(var1, this.a(var1, var2));
         return null;
      }
   }

   public boolean contains(Object var1) {
      return this.e.containsKey(var1);
   }

   public Object remove(Object var1) {
      Object var2 = super.remove(var1);
      this.e.remove(var1);
      return var2;
   }
}
