package b.a.a.b;

import java.util.Iterator;
import java.util.WeakHashMap;
import java.util.Map.Entry;

public class b implements Iterable {
   public b.a.a.b.b.c a;
   public b.a.a.b.b.c b;
   public WeakHashMap c = new WeakHashMap();
   public int d = 0;

   public b.a.a.b.b.c a(Object var1) {
      b.a.a.b.b.c var2;
      for(var2 = this.a; var2 != null && !var2.a.equals(var1); var2 = var2.c) {
      }

      return var2;
   }

   public b.a.a.b.b.c a(Object var1, Object var2) {
      b.a.a.b.b.c var4 = new b.a.a.b.b.c(var1, var2);
      ++this.d;
      b.a.a.b.b.c var3 = this.b;
      if (var3 == null) {
         this.a = var4;
         this.b = this.a;
         return var4;
      } else {
         var3.c = var4;
         var4.d = var3;
         this.b = var4;
         return var4;
      }
   }

   public b.a.a.b.b.d a() {
      b.a.a.b.b.d var1 = new b.a.a.b.b.d();
      this.c.put(var1, false);
      return var1;
   }

   public Object b(Object var1, Object var2) {
      b.a.a.b.b.c var3 = this.a(var1);
      if (var3 != null) {
         return var3.b;
      } else {
         this.a(var1, var2);
         return null;
      }
   }

   public boolean equals(Object var1) {
      boolean var2 = true;
      if (var1 == this) {
         return true;
      } else if (!(var1 instanceof b.a.a.b.b)) {
         return false;
      } else {
         b.a.a.b.b var3 = (b.a.a.b.b)var1;
         if (this.d != var3.d) {
            return false;
         } else {
            Iterator var6 = this.iterator();
            Iterator var4 = var3.iterator();

            while(true) {
               if (var6.hasNext() && var4.hasNext()) {
                  Entry var7 = (Entry)var6.next();
                  Object var5 = var4.next();
                  if ((var7 != null || var5 == null) && (var7 == null || var7.equals(var5))) {
                     continue;
                  }

                  return false;
               }

               if (var6.hasNext() || var4.hasNext()) {
                  var2 = false;
               }

               return var2;
            }
         }
      }
   }

   public int hashCode() {
      Iterator var1 = this.iterator();

      int var2;
      for(var2 = 0; var1.hasNext(); var2 += ((Entry)var1.next()).hashCode()) {
      }

      return var2;
   }

   public Iterator iterator() {
      b.a.a.b.b.a var1 = new b.a.a.b.b.a(this.a, this.b);
      this.c.put(var1, false);
      return var1;
   }

   public Object remove(Object var1) {
      b.a.a.b.b.c var3 = this.a(var1);
      if (var3 == null) {
         return null;
      } else {
         --this.d;
         if (!this.c.isEmpty()) {
            Iterator var2 = this.c.keySet().iterator();

            while(var2.hasNext()) {
               ((b.a.a.b.b.f)var2.next()).a(var3);
            }
         }

         b.a.a.b.b.c var4 = var3.d;
         if (var4 != null) {
            var4.c = var3.c;
         } else {
            this.a = var3.c;
         }

         var4 = var3.c;
         if (var4 != null) {
            var4.d = var3.d;
         } else {
            this.b = var3.d;
         }

         var3.c = null;
         var3.d = null;
         return var3.b;
      }
   }

   public String toString() {
      StringBuilder var1 = c.a.b.a.a.b("[");
      Iterator var2 = this.iterator();

      while(var2.hasNext()) {
         var1.append(((Entry)var2.next()).toString());
         if (var2.hasNext()) {
            var1.append(", ");
         }
      }

      var1.append("]");
      return var1.toString();
   }

   public static class a extends b.a.a.b.b.e {
      public a(b.a.a.b.b.c var1, b.a.a.b.b.c var2) {
         super(var1, var2);
      }

      public b.a.a.b.b.c b(b.a.a.b.b.c var1) {
         return var1.d;
      }

      public b.a.a.b.b.c c(b.a.a.b.b.c var1) {
         return var1.c;
      }
   }

   public static class b extends b.a.a.b.b.e {
      public b(b.a.a.b.b.c var1, b.a.a.b.b.c var2) {
         super(var1, var2);
      }

      public b.a.a.b.b.c b(b.a.a.b.b.c var1) {
         return var1.c;
      }

      public b.a.a.b.b.c c(b.a.a.b.b.c var1) {
         return var1.d;
      }
   }

   public static class c implements Entry {
      public final Object a;
      public final Object b;
      public b.a.a.b.b.c c;
      public b.a.a.b.b.c d;

      public c(Object var1, Object var2) {
         this.a = var1;
         this.b = var2;
      }

      public boolean equals(Object var1) {
         boolean var2 = true;
         if (var1 == this) {
            return true;
         } else if (!(var1 instanceof b.a.a.b.b.c)) {
            return false;
         } else {
            b.a.a.b.b.c var3 = (b.a.a.b.b.c)var1;
            if (!this.a.equals(var3.a) || !this.b.equals(var3.b)) {
               var2 = false;
            }

            return var2;
         }
      }

      public Object getKey() {
         return this.a;
      }

      public Object getValue() {
         return this.b;
      }

      public int hashCode() {
         return this.a.hashCode() ^ this.b.hashCode();
      }

      public Object setValue(Object var1) {
         throw new UnsupportedOperationException("An entry modification is not supported");
      }

      public String toString() {
         StringBuilder var1 = new StringBuilder();
         var1.append(this.a);
         var1.append("=");
         var1.append(this.b);
         return var1.toString();
      }
   }

   public class d implements Iterator, b.a.a.b.b.f {
      public b.a.a.b.b.c a;
      public boolean b = true;

      public void a(b.a.a.b.b.c var1) {
         b.a.a.b.b.c var2 = this.a;
         if (var1 == var2) {
            this.a = var2.d;
            boolean var3;
            if (this.a == null) {
               var3 = true;
            } else {
               var3 = false;
            }

            this.b = var3;
         }

      }

      public boolean hasNext() {
         boolean var1 = this.b;
         boolean var2 = true;
         boolean var3 = true;
         if (var1) {
            if (b.this.a == null) {
               var3 = false;
            }

            return var3;
         } else {
            b.a.a.b.b.c var4 = this.a;
            if (var4 != null && var4.c != null) {
               var3 = var2;
            } else {
               var3 = false;
            }

            return var3;
         }
      }

      public Object next() {
         if (this.b) {
            this.b = false;
            this.a = b.this.a;
         } else {
            b.a.a.b.b.c var1 = this.a;
            if (var1 != null) {
               var1 = var1.c;
            } else {
               var1 = null;
            }

            this.a = var1;
         }

         return this.a;
      }
   }

   public abstract static class e implements Iterator, b.a.a.b.b.f {
      public b.a.a.b.b.c a;
      public b.a.a.b.b.c b;

      public e(b.a.a.b.b.c var1, b.a.a.b.b.c var2) {
         this.a = var2;
         this.b = var1;
      }

      public final b.a.a.b.b.c a() {
         b.a.a.b.b.c var1 = this.b;
         b.a.a.b.b.c var2 = this.a;
         return var1 != var2 && var2 != null ? this.c(var1) : null;
      }

      public void a(b.a.a.b.b.c var1) {
         b.a.a.b.b.c var2 = this.a;
         Object var3 = null;
         if (var2 == var1 && var1 == this.b) {
            this.b = null;
            this.a = null;
         }

         var2 = this.a;
         if (var2 == var1) {
            this.a = this.b(var2);
         }

         var2 = this.b;
         if (var2 == var1) {
            b.a.a.b.b.c var4 = this.a;
            var1 = (b.a.a.b.b.c)var3;
            if (var2 != var4) {
               if (var4 == null) {
                  var1 = (b.a.a.b.b.c)var3;
               } else {
                  var1 = this.c(var2);
               }
            }

            this.b = var1;
         }

      }

      public abstract b.a.a.b.b.c b(b.a.a.b.b.c var1);

      public abstract b.a.a.b.b.c c(b.a.a.b.b.c var1);

      public boolean hasNext() {
         boolean var1;
         if (this.b != null) {
            var1 = true;
         } else {
            var1 = false;
         }

         return var1;
      }

      public Object next() {
         b.a.a.b.b.c var1 = this.b;
         this.b = this.a();
         return var1;
      }
   }

   public interface f {
      void a(b.a.a.b.b.c var1);
   }
}
