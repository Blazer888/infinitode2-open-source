package b.d.a;

import android.util.AndroidRuntimeException;

public final class c0 extends AndroidRuntimeException {
   public c0(String var1) {
      super(var1);
   }
}
