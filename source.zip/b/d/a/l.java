package b.d.a;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;

public class l extends AnimatorListenerAdapter {
   // $FF: synthetic field
   public final ViewGroup a;
   // $FF: synthetic field
   public final View b;
   // $FF: synthetic field
   public final d c;
   // $FF: synthetic field
   public final j d;

   public l(j var1, ViewGroup var2, View var3, d var4) {
      this.d = var1;
      this.a = var2;
      this.b = var3;
      this.c = var4;
   }

   public void onAnimationEnd(Animator var1) {
      this.a.endViewTransition(this.b);
      var1 = this.c.e();
      this.c.a((Animator)null);
      if (var1 != null && this.a.indexOfChild(this.b) < 0) {
         j var2 = this.d;
         d var3 = this.c;
         var2.a(var3, var3.k(), 0, 0, false);
      }

   }
}
