package b.d.a;

import android.graphics.Rect;
import android.view.View;

public final class t implements Runnable {
   // $FF: synthetic field
   public final d a;
   // $FF: synthetic field
   public final d b;
   // $FF: synthetic field
   public final boolean c;
   // $FF: synthetic field
   public final b.b.a d;
   // $FF: synthetic field
   public final View e;
   // $FF: synthetic field
   public final a0 f;
   // $FF: synthetic field
   public final Rect g;

   public t(d var1, d var2, boolean var3, b.b.a var4, View var5, a0 var6, Rect var7) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
      this.f = var6;
      this.g = var7;
   }

   public void run() {
      v.a(this.a, this.b, this.c, this.d, false);
      View var1 = this.e;
      if (var1 != null) {
         this.f.a(var1, this.g);
      }

   }
}
