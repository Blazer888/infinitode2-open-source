package b.d.a;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public final class o implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public Object createFromParcel(Parcel var1) {
         return new o(var1);
      }

      public Object[] newArray(int var1) {
         return new o[var1];
      }
   };
   public p[] a;
   public int[] b;
   public b[] c;
   public int d = -1;
   public int e;

   public o() {
   }

   public o(Parcel var1) {
      this.a = (p[])var1.createTypedArray(p.CREATOR);
      this.b = var1.createIntArray();
      this.c = (b[])var1.createTypedArray(b.d.a.b.CREATOR);
      this.d = var1.readInt();
      this.e = var1.readInt();
   }

   public int describeContents() {
      return 0;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeTypedArray(this.a, var2);
      var1.writeIntArray(this.b);
      var1.writeTypedArray(this.c, var2);
      var1.writeInt(this.d);
      var1.writeInt(this.e);
   }
}
