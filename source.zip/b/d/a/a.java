package b.d.a;

import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

public final class a extends q implements i.a, j.i {
   public final j a;
   public ArrayList b = new ArrayList();
   public int c;
   public int d;
   public int e;
   public int f;
   public int g;
   public int h;
   public boolean i;
   public String j;
   public boolean k;
   public int l = -1;
   public int m;
   public CharSequence n;
   public int o;
   public CharSequence p;
   public ArrayList q;
   public ArrayList r;
   public boolean s = false;
   public ArrayList t;

   public a(j var1) {
      this.a = var1;
   }

   public static boolean b(b.d.a.a.a var0) {
      d var2 = var0.b;
      boolean var1;
      if (var2 != null && var2.k && var2.I != null && !var2.B && !var2.A && var2.p()) {
         var1 = true;
      } else {
         var1 = false;
      }

      return var1;
   }

   public int a() {
      return this.a(false);
   }

   public int a(boolean var1) {
      if (!this.k) {
         this.k = true;
         if (this.i) {
            this.l = this.a.a(this);
         } else {
            this.l = -1;
         }

         this.a.a((j.i)this, var1);
         return this.l;
      } else {
         throw new IllegalStateException("commit already called");
      }
   }

   public q a(d var1, String var2) {
      Class var3 = var1.getClass();
      int var4 = var3.getModifiers();
      if (var3.isAnonymousClass() || !Modifier.isPublic(var4) || var3.isMemberClass() && !Modifier.isStatic(var4)) {
         StringBuilder var5 = c.a.b.a.a.b("Fragment ");
         var5.append(var3.getCanonicalName());
         var5.append(" must be a public static class to be  properly recreated from");
         var5.append(" instance state.");
         throw new IllegalStateException(var5.toString());
      } else {
         var1.r = this.a;
         if (var2 != null) {
            String var6 = var1.z;
            if (var6 != null && !var2.equals(var6)) {
               StringBuilder var7 = new StringBuilder();
               var7.append("Can't change tag of fragment ");
               var7.append(var1);
               var7.append(": was ");
               throw new IllegalStateException(c.a.b.a.a.a(var7, var1.z, " now ", var2));
            }

            var1.z = var2;
         }

         this.a(new b.d.a.a.a(1, var1));
         return this;
      }
   }

   public void a(int var1) {
      if (this.i) {
         int var2 = this.b.size();

         for(int var3 = 0; var3 < var2; ++var3) {
            d var4 = ((b.d.a.a.a)this.b.get(var3)).b;
            if (var4 != null) {
               var4.q += var1;
            }
         }

      }
   }

   public void a(b.d.a.a.a var1) {
      this.b.add(var1);
      var1.c = this.c;
      var1.d = this.d;
      var1.e = this.e;
      var1.f = this.f;
   }

   public void a(String var1, PrintWriter var2, boolean var3) {
      if (var3) {
         var2.print(var1);
         var2.print("mName=");
         var2.print(this.j);
         var2.print(" mIndex=");
         var2.print(this.l);
         var2.print(" mCommitted=");
         var2.println(this.k);
         if (this.g != 0) {
            var2.print(var1);
            var2.print("mTransition=#");
            var2.print(Integer.toHexString(this.g));
            var2.print(" mTransitionStyle=#");
            var2.println(Integer.toHexString(this.h));
         }

         if (this.c != 0 || this.d != 0) {
            var2.print(var1);
            var2.print("mEnterAnim=#");
            var2.print(Integer.toHexString(this.c));
            var2.print(" mExitAnim=#");
            var2.println(Integer.toHexString(this.d));
         }

         if (this.e != 0 || this.f != 0) {
            var2.print(var1);
            var2.print("mPopEnterAnim=#");
            var2.print(Integer.toHexString(this.e));
            var2.print(" mPopExitAnim=#");
            var2.println(Integer.toHexString(this.f));
         }

         if (this.m != 0 || this.n != null) {
            var2.print(var1);
            var2.print("mBreadCrumbTitleRes=#");
            var2.print(Integer.toHexString(this.m));
            var2.print(" mBreadCrumbTitleText=");
            var2.println(this.n);
         }

         if (this.o != 0 || this.p != null) {
            var2.print(var1);
            var2.print("mBreadCrumbShortTitleRes=#");
            var2.print(Integer.toHexString(this.o));
            var2.print(" mBreadCrumbShortTitleText=");
            var2.println(this.p);
         }
      }

      if (!this.b.isEmpty()) {
         var2.print(var1);
         var2.println("Operations:");
         StringBuilder var4 = new StringBuilder();
         var4.append(var1);
         var4.append("    ");
         var4.toString();
         int var5 = this.b.size();

         for(int var6 = 0; var6 < var5; ++var6) {
            b.d.a.a.a var7 = (b.d.a.a.a)this.b.get(var6);
            String var8;
            switch(var7.a) {
            case 0:
               var8 = "NULL";
               break;
            case 1:
               var8 = "ADD";
               break;
            case 2:
               var8 = "REPLACE";
               break;
            case 3:
               var8 = "REMOVE";
               break;
            case 4:
               var8 = "HIDE";
               break;
            case 5:
               var8 = "SHOW";
               break;
            case 6:
               var8 = "DETACH";
               break;
            case 7:
               var8 = "ATTACH";
               break;
            case 8:
               var8 = "SET_PRIMARY_NAV";
               break;
            case 9:
               var8 = "UNSET_PRIMARY_NAV";
               break;
            default:
               var4 = c.a.b.a.a.b("cmd=");
               var4.append(var7.a);
               var8 = var4.toString();
            }

            var2.print(var1);
            var2.print("  Op #");
            var2.print(var6);
            var2.print(": ");
            var2.print(var8);
            var2.print(" ");
            var2.println(var7.b);
            if (var3) {
               if (var7.c != 0 || var7.d != 0) {
                  var2.print(var1);
                  var2.print("enterAnim=#");
                  var2.print(Integer.toHexString(var7.c));
                  var2.print(" exitAnim=#");
                  var2.println(Integer.toHexString(var7.d));
               }

               if (var7.e != 0 || var7.f != 0) {
                  var2.print(var1);
                  var2.print("popEnterAnim=#");
                  var2.print(Integer.toHexString(var7.e));
                  var2.print(" popExitAnim=#");
                  var2.println(Integer.toHexString(var7.f));
               }
            }
         }
      }

   }

   public boolean a(ArrayList var1, int var2, int var3) {
      if (var3 == var2) {
         return false;
      } else {
         int var4 = this.b.size();
         int var5 = 0;

         int var9;
         for(int var6 = -1; var5 < var4; var6 = var9) {
            d var7 = ((b.d.a.a.a)this.b.get(var5)).b;
            int var8;
            if (var7 != null) {
               var8 = var7.y;
            } else {
               var8 = 0;
            }

            var9 = var6;
            if (var8 != 0) {
               var9 = var6;
               if (var8 != var6) {
                  var6 = var2;

                  while(true) {
                     if (var6 >= var3) {
                        var9 = var8;
                        break;
                     }

                     b.d.a.a var10 = (b.d.a.a)var1.get(var6);
                     int var11 = var10.b.size();

                     for(var9 = 0; var9 < var11; ++var9) {
                        var7 = ((b.d.a.a.a)var10.b.get(var9)).b;
                        int var12;
                        if (var7 != null) {
                           var12 = var7.y;
                        } else {
                           var12 = 0;
                        }

                        if (var12 == var8) {
                           return true;
                        }
                     }

                     ++var6;
                  }
               }
            }

            ++var5;
         }

         return false;
      }
   }

   public boolean a(ArrayList var1, ArrayList var2) {
      var1.add(this);
      var2.add(false);
      if (this.i) {
         j var3 = this.a;
         if (var3.f == null) {
            var3.f = new ArrayList();
         }

         var3.f.add(this);
      }

      return true;
   }

   public int b() {
      return this.a(true);
   }

   public void b(boolean var1) {
      for(int var2 = this.b.size() - 1; var2 >= 0; --var2) {
         b.d.a.a.a var3 = (b.d.a.a.a)this.b.get(var2);
         d var4 = var3.b;
         if (var4 != null) {
            var4.a(b.d.a.j.d(this.g), this.h);
         }

         switch(var3.a) {
         case 1:
            var4.a(var3.f);
            this.a.g(var4);
            break;
         case 2:
         default:
            StringBuilder var6 = c.a.b.a.a.b("Unknown cmd: ");
            var6.append(var3.a);
            throw new IllegalArgumentException(var6.toString());
         case 3:
            var4.a(var3.e);
            this.a.a(var4, false);
            break;
         case 4:
            var4.a(var3.e);
            this.a.j(var4);
            break;
         case 5:
            var4.a(var3.f);
            this.a.c(var4);
            break;
         case 6:
            var4.a(var3.e);
            this.a.a(var4);
            break;
         case 7:
            var4.a(var3.f);
            this.a.b(var4);
            break;
         case 8:
            this.a.i((d)null);
            break;
         case 9:
            this.a.i(var4);
         }

         if (!this.s && var3.a != 3 && var4 != null) {
            this.a.e(var4);
         }
      }

      if (!this.s && var1) {
         j var5 = this.a;
         var5.a(var5.l, true);
      }

   }

   public boolean b(int var1) {
      int var2 = this.b.size();

      for(int var3 = 0; var3 < var2; ++var3) {
         d var4 = ((b.d.a.a.a)this.b.get(var3)).b;
         int var5;
         if (var4 != null) {
            var5 = var4.y;
         } else {
            var5 = 0;
         }

         if (var5 != 0 && var5 == var1) {
            return true;
         }
      }

      return false;
   }

   public void c() {
      int var1 = this.b.size();

      for(int var2 = 0; var2 < var1; ++var2) {
         b.d.a.a.a var3 = (b.d.a.a.a)this.b.get(var2);
         d var4 = var3.b;
         if (var4 != null) {
            var4.a(this.g, this.h);
         }

         switch(var3.a) {
         case 1:
            var4.a(var3.c);
            this.a.a(var4, false);
            break;
         case 2:
         default:
            StringBuilder var6 = c.a.b.a.a.b("Unknown cmd: ");
            var6.append(var3.a);
            throw new IllegalArgumentException(var6.toString());
         case 3:
            var4.a(var3.d);
            this.a.g(var4);
            break;
         case 4:
            var4.a(var3.d);
            this.a.c(var4);
            break;
         case 5:
            var4.a(var3.c);
            this.a.j(var4);
            break;
         case 6:
            var4.a(var3.d);
            this.a.b(var4);
            break;
         case 7:
            var4.a(var3.c);
            this.a.a(var4);
            break;
         case 8:
            this.a.i(var4);
            break;
         case 9:
            this.a.i((d)null);
         }

         if (!this.s && var3.a != 1 && var4 != null) {
            this.a.e(var4);
         }
      }

      if (!this.s) {
         j var5 = this.a;
         var5.a(var5.l, true);
      }

   }

   public String toString() {
      StringBuilder var1 = new StringBuilder(128);
      var1.append("BackStackEntry{");
      var1.append(Integer.toHexString(System.identityHashCode(this)));
      if (this.l >= 0) {
         var1.append(" #");
         var1.append(this.l);
      }

      if (this.j != null) {
         var1.append(" ");
         var1.append(this.j);
      }

      var1.append("}");
      return var1.toString();
   }

   public static final class a {
      public int a;
      public d b;
      public int c;
      public int d;
      public int e;
      public int f;

      public a() {
      }

      public a(int var1, d var2) {
         this.a = var1;
         this.b = var2;
      }
   }
}
