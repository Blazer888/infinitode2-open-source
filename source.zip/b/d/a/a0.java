package b.d.a;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public abstract class a0 {
   public static boolean a(List var0) {
      boolean var1;
      if (var0 != null && !var0.isEmpty()) {
         var1 = false;
      } else {
         var1 = true;
      }

      return var1;
   }

   public static boolean a(List var0, View var1, int var2) {
      for(int var3 = 0; var3 < var2; ++var3) {
         if (var0.get(var3) == var1) {
            return true;
         }
      }

      return false;
   }

   public abstract Object a(Object var1, Object var2, Object var3);

   public void a(View var1, Rect var2) {
      int[] var3 = new int[2];
      var1.getLocationOnScreen(var3);
      int var4 = var3[0];
      int var5 = var3[1];
      int var6 = var3[0];
      int var7 = var1.getWidth();
      int var8 = var3[1];
      var2.set(var4, var5, var7 + var6, var1.getHeight() + var8);
   }

   public abstract void a(ViewGroup var1, Object var2);

   public abstract void a(Object var1, Rect var2);

   public abstract void a(Object var1, View var2);

   public abstract void a(Object var1, View var2, ArrayList var3);

   public abstract void a(Object var1, Object var2, ArrayList var3, Object var4, ArrayList var5, Object var6, ArrayList var7);

   public abstract void a(Object var1, ArrayList var2);

   public abstract void a(Object var1, ArrayList var2, ArrayList var3);

   public void a(ArrayList var1, View var2) {
      if (var2.getVisibility() == 0) {
         if (var2 instanceof ViewGroup) {
            ViewGroup var7 = (ViewGroup)var2;
            int var3 = VERSION.SDK_INT;
            int var4 = 0;
            boolean var5;
            if (var3 >= 21) {
               var5 = var7.isTransitionGroup();
            } else {
               Boolean var6 = (Boolean)var7.getTag(b.c.a.tag_transition_group);
               if ((var6 == null || !var6) && var7.getBackground() == null && b.c.e.c.a(var7) == null) {
                  var5 = false;
               } else {
                  var5 = true;
               }
            }

            if (var5) {
               var1.add(var7);
            } else {
               for(var3 = var7.getChildCount(); var4 < var3; ++var4) {
                  this.a(var1, var7.getChildAt(var4));
               }
            }
         } else {
            var1.add(var2);
         }
      }

   }

   public void a(Map var1, View var2) {
      if (var2.getVisibility() == 0) {
         String var3 = b.c.e.c.a(var2);
         if (var3 != null) {
            var1.put(var3, var2);
         }

         if (var2 instanceof ViewGroup) {
            ViewGroup var6 = (ViewGroup)var2;
            int var4 = var6.getChildCount();

            for(int var5 = 0; var5 < var4; ++var5) {
               this.a(var1, var6.getChildAt(var5));
            }
         }
      }

   }

   public abstract boolean a(Object var1);

   public abstract Object b(Object var1);

   public abstract Object b(Object var1, Object var2, Object var3);

   public abstract void b(Object var1, View var2);

   public abstract void b(Object var1, View var2, ArrayList var3);

   public abstract void b(Object var1, ArrayList var2, ArrayList var3);
}
