package b.d.a;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import java.util.ArrayList;

public final class b implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public Object createFromParcel(Parcel var1) {
         return new b(var1);
      }

      public Object[] newArray(int var1) {
         return new b[var1];
      }
   };
   public final int[] a;
   public final int b;
   public final int c;
   public final String d;
   public final int e;
   public final int f;
   public final CharSequence g;
   public final int h;
   public final CharSequence i;
   public final ArrayList j;
   public final ArrayList k;
   public final boolean l;

   public b(Parcel var1) {
      this.a = var1.createIntArray();
      this.b = var1.readInt();
      this.c = var1.readInt();
      this.d = var1.readString();
      this.e = var1.readInt();
      this.f = var1.readInt();
      this.g = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(var1);
      this.h = var1.readInt();
      this.i = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(var1);
      this.j = var1.createStringArrayList();
      this.k = var1.createStringArrayList();
      boolean var2;
      if (var1.readInt() != 0) {
         var2 = true;
      } else {
         var2 = false;
      }

      this.l = var2;
   }

   public b(a var1) {
      int var2 = var1.b.size();
      this.a = new int[var2 * 6];
      if (var1.i) {
         int var3 = 0;

         for(int var4 = 0; var3 < var2; ++var3) {
            a.a var5 = (a.a)var1.b.get(var3);
            int[] var6 = this.a;
            int var7 = var4 + 1;
            var6[var4] = var5.a;
            int var8 = var7 + 1;
            d var9 = var5.b;
            if (var9 != null) {
               var4 = var9.e;
            } else {
               var4 = -1;
            }

            var6[var7] = var4;
            int[] var11 = this.a;
            var4 = var8 + 1;
            var11[var8] = var5.c;
            var8 = var4 + 1;
            var11[var4] = var5.d;
            var7 = var8 + 1;
            var11[var8] = var5.e;
            var4 = var7 + 1;
            var11[var7] = var5.f;
         }

         this.b = var1.g;
         this.c = var1.h;
         this.d = var1.j;
         this.e = var1.l;
         this.f = var1.m;
         this.g = var1.n;
         this.h = var1.o;
         this.i = var1.p;
         this.j = var1.q;
         this.k = var1.r;
         this.l = var1.s;
      } else {
         IllegalStateException var10 = new IllegalStateException("Not on back stack");
         throw var10;
      }
   }

   public a a(j var1) {
      a var2 = new a(var1);
      int var3 = 0;

      while(var3 < this.a.length) {
         a.a var4 = new a.a();
         int[] var5 = this.a;
         int var6 = var3 + 1;
         var4.a = var5[var3];
         var3 = var6 + 1;
         var6 = var5[var6];
         if (var6 >= 0) {
            var4.b = (d)var1.e.get(var6);
         } else {
            var4.b = null;
         }

         var5 = this.a;
         var6 = var3 + 1;
         var4.c = var5[var3];
         var3 = var6 + 1;
         var4.d = var5[var6];
         var6 = var3 + 1;
         var4.e = var5[var3];
         var3 = var6 + 1;
         var4.f = var5[var6];
         var2.c = var4.c;
         var2.d = var4.d;
         var2.e = var4.e;
         var2.f = var4.f;
         var2.a(var4);
      }

      var2.g = this.b;
      var2.h = this.c;
      var2.j = this.d;
      var2.l = this.e;
      var2.i = true;
      var2.m = this.f;
      var2.n = this.g;
      var2.o = this.h;
      var2.p = this.i;
      var2.q = this.j;
      var2.r = this.k;
      var2.s = this.l;
      var2.a(1);
      return var2;
   }

   public int describeContents() {
      return 0;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeIntArray(this.a);
      var1.writeInt(this.b);
      var1.writeInt(this.c);
      var1.writeString(this.d);
      var1.writeInt(this.e);
      var1.writeInt(this.f);
      TextUtils.writeToParcel(this.g, var1, 0);
      var1.writeInt(this.h);
      TextUtils.writeToParcel(this.i, var1, 0);
      var1.writeStringList(this.j);
      var1.writeStringList(this.k);
      var1.writeInt(this.l);
   }
}
