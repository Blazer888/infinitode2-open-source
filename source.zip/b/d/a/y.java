package b.d.a;

import android.view.View;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class y implements Runnable {
   // $FF: synthetic field
   public final ArrayList a;
   // $FF: synthetic field
   public final Map b;

   public y(a0 var1, ArrayList var2, Map var3) {
      this.a = var2;
      this.b = var3;
   }

   public void run() {
      int var1 = this.a.size();

      for(int var2 = 0; var2 < var1; ++var2) {
         View var3 = (View)this.a.get(var2);
         String var4 = b.c.e.c.a(var3);
         if (var4 != null) {
            Iterator var5 = this.b.entrySet().iterator();

            String var6;
            while(true) {
               if (var5.hasNext()) {
                  Entry var7 = (Entry)var5.next();
                  if (!var4.equals(var7.getValue())) {
                     continue;
                  }

                  var6 = (String)var7.getKey();
                  break;
               }

               var6 = null;
               break;
            }

            b.c.e.c.a(var3, var6);
         }
      }

   }
}
