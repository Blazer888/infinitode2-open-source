package b.d.a;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.transition.Transition.EpicenterCallback;
import android.transition.Transition.TransitionListener;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

public class w extends a0 {
   public static boolean a(Transition var0) {
      boolean var1;
      if (a0.a(var0.getTargetIds()) && a0.a(var0.getTargetNames()) && a0.a(var0.getTargetTypes())) {
         var1 = false;
      } else {
         var1 = true;
      }

      return var1;
   }

   public Object a(Object var1, Object var2, Object var3) {
      var1 = (Transition)var1;
      Transition var4 = (Transition)var2;
      Transition var6 = (Transition)var3;
      if (var1 != null && var4 != null) {
         var1 = (new TransitionSet()).addTransition((Transition)var1).addTransition(var4).setOrdering(1);
      } else if (var1 == null) {
         if (var4 != null) {
            var1 = var4;
         } else {
            var1 = null;
         }
      }

      if (var6 != null) {
         TransitionSet var5 = new TransitionSet();
         if (var1 != null) {
            var5.addTransition((Transition)var1);
         }

         var5.addTransition(var6);
         return var5;
      } else {
         return var1;
      }
   }

   public void a(ViewGroup var1, Object var2) {
      TransitionManager.beginDelayedTransition(var1, (Transition)var2);
   }

   public void a(Object var1, final Rect var2) {
      if (var1 != null) {
         ((Transition)var1).setEpicenterCallback(new EpicenterCallback(this) {
            public Rect onGetEpicenter(Transition var1) {
               Rect var2x = var2;
               return var2x != null && !var2x.isEmpty() ? var2 : null;
            }
         });
      }

   }

   public void a(Object var1, View var2) {
      if (var1 != null) {
         ((Transition)var1).removeTarget(var2);
      }

   }

   public void a(Object var1, final View var2, final ArrayList var3) {
      ((Transition)var1).addListener(new TransitionListener(this) {
         public void onTransitionCancel(Transition var1) {
         }

         public void onTransitionEnd(Transition var1) {
            var1.removeListener(this);
            var2.setVisibility(8);
            int var2x = var3.size();

            for(int var3x = 0; var3x < var2x; ++var3x) {
               ((View)var3.get(var3x)).setVisibility(0);
            }

         }

         public void onTransitionPause(Transition var1) {
         }

         public void onTransitionResume(Transition var1) {
         }

         public void onTransitionStart(Transition var1) {
         }
      });
   }

   public void a(Object var1, final Object var2, final ArrayList var3, final Object var4, final ArrayList var5, final Object var6, final ArrayList var7) {
      ((Transition)var1).addListener(new TransitionListener() {
         public void onTransitionCancel(Transition var1) {
         }

         public void onTransitionEnd(Transition var1) {
         }

         public void onTransitionPause(Transition var1) {
         }

         public void onTransitionResume(Transition var1) {
         }

         public void onTransitionStart(Transition var1) {
            Object var2x = var2;
            if (var2x != null) {
               w.this.a(var2x, (ArrayList)var3, (ArrayList)null);
            }

            var2x = var4;
            if (var2x != null) {
               w.this.a(var2x, (ArrayList)var5, (ArrayList)null);
            }

            var2x = var6;
            if (var2x != null) {
               w.this.a(var2x, (ArrayList)var7, (ArrayList)null);
            }

         }
      });
   }

   public void a(Object var1, ArrayList var2) {
      Transition var7 = (Transition)var1;
      if (var7 != null) {
         boolean var3 = var7 instanceof TransitionSet;
         byte var4 = 0;
         int var5 = 0;
         if (var3) {
            TransitionSet var8 = (TransitionSet)var7;

            for(int var9 = var8.getTransitionCount(); var5 < var9; ++var5) {
               this.a((Object)var8.getTransitionAt(var5), (ArrayList)var2);
            }
         } else if (!a(var7) && a0.a(var7.getTargets())) {
            int var6 = var2.size();

            for(var5 = var4; var5 < var6; ++var5) {
               var7.addTarget((View)var2.get(var5));
            }
         }

      }
   }

   public void a(Object var1, ArrayList var2, ArrayList var3) {
      Transition var8 = (Transition)var1;
      boolean var4 = var8 instanceof TransitionSet;
      int var5 = 0;
      int var6 = 0;
      if (var4) {
         TransitionSet var9 = (TransitionSet)var8;

         for(var5 = var9.getTransitionCount(); var6 < var5; ++var6) {
            this.a(var9.getTransitionAt(var6), (ArrayList)var2, (ArrayList)var3);
         }
      } else if (!a(var8)) {
         List var7 = var8.getTargets();
         if (var7 != null && var7.size() == var2.size() && var7.containsAll(var2)) {
            if (var3 == null) {
               var6 = 0;
            } else {
               var6 = var3.size();
            }

            while(var5 < var6) {
               var8.addTarget((View)var3.get(var5));
               ++var5;
            }

            for(var6 = var2.size() - 1; var6 >= 0; --var6) {
               var8.removeTarget((View)var2.get(var6));
            }
         }
      }

   }

   public boolean a(Object var1) {
      return var1 instanceof Transition;
   }

   public Object b(Object var1) {
      Transition var2;
      if (var1 != null) {
         var2 = ((Transition)var1).clone();
      } else {
         var2 = null;
      }

      return var2;
   }

   public Object b(Object var1, Object var2, Object var3) {
      TransitionSet var4 = new TransitionSet();
      if (var1 != null) {
         var4.addTransition((Transition)var1);
      }

      if (var2 != null) {
         var4.addTransition((Transition)var2);
      }

      if (var3 != null) {
         var4.addTransition((Transition)var3);
      }

      return var4;
   }

   public void b(Object var1, View var2) {
      if (var2 != null) {
         Transition var4 = (Transition)var1;
         final Rect var3 = new Rect();
         this.a(var2, var3);
         var4.setEpicenterCallback(new EpicenterCallback(this) {
            public Rect onGetEpicenter(Transition var1) {
               return var3;
            }
         });
      }

   }

   public void b(Object var1, View var2, ArrayList var3) {
      TransitionSet var4 = (TransitionSet)var1;
      List var13 = var4.getTargets();
      var13.clear();
      int var5 = var3.size();

      for(int var6 = 0; var6 < var5; ++var6) {
         View var7 = (View)var3.get(var6);
         int var8 = var13.size();
         if (!a0.a(var13, var7, var8)) {
            var13.add(var7);

            for(int var9 = var8; var9 < var13.size(); ++var9) {
               var7 = (View)var13.get(var9);
               if (var7 instanceof ViewGroup) {
                  ViewGroup var14 = (ViewGroup)var7;
                  int var10 = var14.getChildCount();

                  for(int var11 = 0; var11 < var10; ++var11) {
                     View var12 = var14.getChildAt(var11);
                     if (!a0.a(var13, var12, var8)) {
                        var13.add(var12);
                     }
                  }
               }
            }
         }
      }

      var13.add(var2);
      var3.add(var2);
      this.a((Object)var4, (ArrayList)var3);
   }

   public void b(Object var1, ArrayList var2, ArrayList var3) {
      TransitionSet var4 = (TransitionSet)var1;
      if (var4 != null) {
         var4.getTargets().clear();
         var4.getTargets().addAll(var3);
         this.a(var4, (ArrayList)var2, (ArrayList)var3);
      }

   }
}
