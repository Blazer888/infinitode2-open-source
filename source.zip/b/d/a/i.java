package b.d.a;

import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public abstract class i {
   public abstract d a(String var1);

   public abstract q a();

   public abstract void a(int var1, int var2);

   public abstract void a(String var1, FileDescriptor var2, PrintWriter var3, String[] var4);

   public abstract List b();

   public abstract boolean c();

   public abstract boolean d();

   public interface a {
   }

   public abstract static class b {
   }

   public interface c {
      void a();
   }
}
