package b.d.a;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewGroup;

public class m extends AnimatorListenerAdapter {
   // $FF: synthetic field
   public final ViewGroup a;
   // $FF: synthetic field
   public final View b;
   // $FF: synthetic field
   public final d c;

   public m(j var1, ViewGroup var2, View var3, d var4) {
      this.a = var2;
      this.b = var3;
      this.c = var4;
   }

   public void onAnimationEnd(Animator var1) {
      this.a.endViewTransition(this.b);
      var1.removeListener(this);
      View var2 = this.c.I;
      if (var2 != null) {
         var2.setVisibility(8);
      }

   }
}
