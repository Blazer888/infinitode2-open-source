package b.d.a;

public class g {
   public final h a;

   public g(h var1) {
      this.a = var1;
   }

   public boolean a() {
      return this.a.d.p();
   }

   public i b() {
      return this.a.d;
   }

   public void c() {
      this.a.d.r();
   }
}
