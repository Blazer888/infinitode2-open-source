package b.d.a;

import android.view.View;
import java.util.ArrayList;
import java.util.Map;

public class z implements Runnable {
   // $FF: synthetic field
   public final ArrayList a;
   // $FF: synthetic field
   public final Map b;

   public z(a0 var1, ArrayList var2, Map var3) {
      this.a = var2;
      this.b = var3;
   }

   public void run() {
      int var1 = this.a.size();

      for(int var2 = 0; var2 < var1; ++var2) {
         View var3 = (View)this.a.get(var2);
         String var4 = b.c.e.c.a(var3);
         b.c.e.c.a(var3, (String)this.b.get(var4));
      }

   }
}
