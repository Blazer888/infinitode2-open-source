package b.d.a;

public abstract class q {
   public abstract int a();

   public abstract q a(d var1, String var2);

   public abstract int b();
}
