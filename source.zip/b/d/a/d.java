package b.d.a;

import android.animation.Animator;
import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Build.VERSION;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater.Factory;
import android.view.LayoutInflater.Factory2;
import android.view.View.OnCreateContextMenuListener;
import android.view.animation.Animation;
import androidx.lifecycle.LiveData;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;

public class d implements ComponentCallbacks, OnCreateContextMenuListener, b.f.h, b.f.v {
   public static final b.b.f W = new b.b.f();
   public static final Object X = new Object();
   public boolean A;
   public boolean B;
   public boolean C;
   public boolean D;
   public boolean E;
   public boolean F = true;
   public boolean G;
   public ViewGroup H;
   public View I;
   public View J;
   public boolean K;
   public boolean L = true;
   public b.d.a.d.d M;
   public boolean N;
   public boolean O;
   public float P;
   public LayoutInflater Q;
   public boolean R;
   public b.f.i S = new b.f.i(this);
   public b.f.i T;
   public b.f.h U;
   public b.f.n V = new b.f.n();
   public int a = 0;
   public Bundle b;
   public SparseArray c;
   public Boolean d;
   public int e = -1;
   public String f;
   public Bundle g;
   public b.d.a.d h;
   public int i = -1;
   public int j;
   public boolean k;
   public boolean l;
   public boolean m;
   public boolean n;
   public boolean o;
   public boolean p;
   public int q;
   public j r;
   public h s;
   public j t;
   public n u;
   public b.f.u v;
   public b.d.a.d w;
   public int x;
   public int y;
   public String z;

   public static boolean a(Context var0, String var1) {
      boolean var10001;
      Class var2;
      try {
         var2 = (Class)W.get(var1);
      } catch (ClassNotFoundException var7) {
         var10001 = false;
         return false;
      }

      Class var3 = var2;
      if (var2 == null) {
         try {
            var3 = var0.getClassLoader().loadClass(var1);
            W.put(var1, var3);
         } catch (ClassNotFoundException var6) {
            var10001 = false;
            return false;
         }
      }

      try {
         boolean var4 = b.d.a.d.class.isAssignableFrom(var3);
         return var4;
      } catch (ClassNotFoundException var5) {
         var10001 = false;
         return false;
      }
   }

   public static b.d.a.d instantiate(Context var0, String var1) {
      return instantiate(var0, var1, (Bundle)null);
   }

   public static b.d.a.d instantiate(Context var0, String var1, Bundle var2) {
      NoSuchMethodException var32;
      label79: {
         InvocationTargetException var10000;
         label78: {
            StringBuilder var28;
            ClassNotFoundException var35;
            label77: {
               InstantiationException var34;
               label76: {
                  IllegalAccessException var33;
                  label82: {
                     Class var3;
                     boolean var10001;
                     try {
                        var3 = (Class)W.get(var1);
                     } catch (ClassNotFoundException var20) {
                        var35 = var20;
                        var10001 = false;
                        break label77;
                     } catch (InstantiationException var21) {
                        var34 = var21;
                        var10001 = false;
                        break label76;
                     } catch (IllegalAccessException var22) {
                        var33 = var22;
                        var10001 = false;
                        break label82;
                     } catch (NoSuchMethodException var23) {
                        var32 = var23;
                        var10001 = false;
                        break label79;
                     } catch (InvocationTargetException var24) {
                        var10000 = var24;
                        var10001 = false;
                        break label78;
                     }

                     Class var4 = var3;
                     if (var3 == null) {
                        try {
                           var4 = var0.getClassLoader().loadClass(var1);
                           W.put(var1, var4);
                        } catch (ClassNotFoundException var15) {
                           var35 = var15;
                           var10001 = false;
                           break label77;
                        } catch (InstantiationException var16) {
                           var34 = var16;
                           var10001 = false;
                           break label76;
                        } catch (IllegalAccessException var17) {
                           var33 = var17;
                           var10001 = false;
                           break label82;
                        } catch (NoSuchMethodException var18) {
                           var32 = var18;
                           var10001 = false;
                           break label79;
                        } catch (InvocationTargetException var19) {
                           var10000 = var19;
                           var10001 = false;
                           break label78;
                        }
                     }

                     b.d.a.d var25;
                     try {
                        var25 = (b.d.a.d)var4.getConstructor().newInstance();
                     } catch (ClassNotFoundException var10) {
                        var35 = var10;
                        var10001 = false;
                        break label77;
                     } catch (InstantiationException var11) {
                        var34 = var11;
                        var10001 = false;
                        break label76;
                     } catch (IllegalAccessException var12) {
                        var33 = var12;
                        var10001 = false;
                        break label82;
                     } catch (NoSuchMethodException var13) {
                        var32 = var13;
                        var10001 = false;
                        break label79;
                     } catch (InvocationTargetException var14) {
                        var10000 = var14;
                        var10001 = false;
                        break label78;
                     }

                     if (var2 == null) {
                        return var25;
                     }

                     try {
                        var2.setClassLoader(var25.getClass().getClassLoader());
                        var25.setArguments(var2);
                        return var25;
                     } catch (ClassNotFoundException var5) {
                        var35 = var5;
                        var10001 = false;
                        break label77;
                     } catch (InstantiationException var6) {
                        var34 = var6;
                        var10001 = false;
                        break label76;
                     } catch (IllegalAccessException var7) {
                        var33 = var7;
                        var10001 = false;
                     } catch (NoSuchMethodException var8) {
                        var32 = var8;
                        var10001 = false;
                        break label79;
                     } catch (InvocationTargetException var9) {
                        var10000 = var9;
                        var10001 = false;
                        break label78;
                     }
                  }

                  IllegalAccessException var29 = var33;
                  var28 = new StringBuilder();
                  var28.append("Unable to instantiate fragment ");
                  var28.append(var1);
                  var28.append(": make sure class name exists, is public, and has an");
                  var28.append(" empty constructor that is public");
                  throw new b.d.a.d.e(var28.toString(), var29);
               }

               InstantiationException var30 = var34;
               var28 = new StringBuilder();
               var28.append("Unable to instantiate fragment ");
               var28.append(var1);
               var28.append(": make sure class name exists, is public, and has an");
               var28.append(" empty constructor that is public");
               throw new b.d.a.d.e(var28.toString(), var30);
            }

            ClassNotFoundException var31 = var35;
            var28 = new StringBuilder();
            var28.append("Unable to instantiate fragment ");
            var28.append(var1);
            var28.append(": make sure class name exists, is public, and has an");
            var28.append(" empty constructor that is public");
            throw new b.d.a.d.e(var28.toString(), var31);
         }

         InvocationTargetException var26 = var10000;
         throw new b.d.a.d.e(c.a.b.a.a.a("Unable to instantiate fragment ", var1, ": calling Fragment constructor caused an exception"), var26);
      }

      NoSuchMethodException var27 = var32;
      throw new b.d.a.d.e(c.a.b.a.a.a("Unable to instantiate fragment ", var1, ": could not find Fragment constructor"), var27);
   }

   public b.d.a.d a(String var1) {
      if (var1.equals(this.f)) {
         return this;
      } else {
         j var2 = this.t;
         return var2 != null ? var2.b(var1) : null;
      }
   }

   public void a(int var1) {
      if (this.M != null || var1 != 0) {
         this.c().d = var1;
      }
   }

   public void a(int var1, int var2) {
      if (this.M != null || var1 != 0 || var2 != 0) {
         this.c();
         b.d.a.d.d var3 = this.M;
         var3.e = var1;
         var3.f = var2;
      }
   }

   public final void a(int var1, b.d.a.d var2) {
      this.e = var1;
      if (var2 != null) {
         StringBuilder var3 = new StringBuilder();
         var3.append(var2.f);
         var3.append(":");
         var3.append(this.e);
         this.f = var3.toString();
      } else {
         StringBuilder var4 = c.a.b.a.a.b("android:fragment:");
         var4.append(this.e);
         this.f = var4.toString();
      }

   }

   public void a(Animator var1) {
      this.c().b = var1;
   }

   public void a(Configuration var1) {
      this.onConfigurationChanged(var1);
      j var2 = this.t;
      if (var2 != null) {
         var2.a(var1);
      }

   }

   public void a(Bundle var1) {
      j var2 = this.t;
      if (var2 != null) {
         var2.r();
      }

      this.a = 2;
      this.G = false;
      this.onActivityCreated(var1);
      if (this.G) {
         j var3 = this.t;
         if (var3 != null) {
            var3.h();
         }

      } else {
         throw new c0(c.a.b.a.a.a("Fragment ", this, " did not call through to super.onActivityCreated()"));
      }
   }

   public void a(LayoutInflater var1, ViewGroup var2, Bundle var3) {
      j var4 = this.t;
      if (var4 != null) {
         var4.r();
      }

      this.p = true;
      this.U = new b.f.h() {
         public b.f.e getLifecycle() {
            b.d.a.d var1 = d.this;
            if (var1.T == null) {
               var1.T = new b.f.i(var1.U);
            }

            return d.this.T;
         }
      };
      this.T = null;
      this.I = this.onCreateView(var1, var2, var3);
      if (this.I != null) {
         this.U.getLifecycle();
         this.V.b(this.U);
      } else {
         if (this.T != null) {
            throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
         }

         this.U = null;
      }

   }

   public void a(Menu var1) {
      if (!this.A) {
         if (this.E && this.F) {
            this.onOptionsMenuClosed(var1);
         }

         j var2 = this.t;
         if (var2 != null) {
            var2.a(var1);
         }
      }

   }

   public void a(View var1) {
      this.c().a = var1;
   }

   public void a(b.d.a.d.f var1) {
      this.c();
      b.d.a.d.f var2 = this.M.r;
      if (var1 != var2) {
         if (var1 != null && var2 != null) {
            StringBuilder var4 = new StringBuilder();
            var4.append("Trying to set a replacement startPostponedEnterTransition on ");
            var4.append(this);
            throw new IllegalStateException(var4.toString());
         } else {
            b.d.a.d.d var5 = this.M;
            if (var5.q) {
               var5.r = var1;
            }

            if (var1 != null) {
               j.k var3 = (j.k)var1;
               ++var3.c;
            }

         }
      }
   }

   public void a(boolean var1) {
      this.onMultiWindowModeChanged(var1);
      j var2 = this.t;
      if (var2 != null) {
         var2.a(var1);
      }

   }

   public boolean a(Menu var1, MenuInflater var2) {
      boolean var3 = this.A;
      boolean var4 = false;
      boolean var5 = false;
      if (!var3) {
         var3 = var5;
         if (this.E) {
            var3 = var5;
            if (this.F) {
               this.onCreateOptionsMenu(var1, var2);
               var3 = true;
            }
         }

         j var6 = this.t;
         var4 = var3;
         if (var6 != null) {
            var4 = var3 | var6.a(var1, var2);
         }
      }

      return var4;
   }

   public boolean a(MenuItem var1) {
      if (!this.A) {
         if (this.onContextItemSelected(var1)) {
            return true;
         }

         j var2 = this.t;
         if (var2 != null && var2.a(var1)) {
            return true;
         }
      }

      return false;
   }

   public void b() {
      b.d.a.d.d var1 = this.M;
      b.d.a.d.f var2 = null;
      if (var1 != null) {
         var1.q = false;
         var2 = var1.r;
         var1.r = null;
      }

      if (var2 != null) {
         j.k var3 = (j.k)var2;
         --var3.c;
         if (var3.c == 0) {
            var3.b.a.u();
         }
      }

   }

   public void b(int var1) {
      this.c().c = var1;
   }

   public void b(Bundle var1) {
      j var2 = this.t;
      if (var2 != null) {
         var2.r();
      }

      this.a = 1;
      this.G = false;
      this.onCreate(var1);
      this.R = true;
      if (this.G) {
         this.S.a(b.f.e.a.ON_CREATE);
      } else {
         throw new c0(c.a.b.a.a.a("Fragment ", this, " did not call through to super.onCreate()"));
      }
   }

   public void b(boolean var1) {
      this.onPictureInPictureModeChanged(var1);
      j var2 = this.t;
      if (var2 != null) {
         var2.b(var1);
      }

   }

   public boolean b(Menu var1) {
      boolean var2 = this.A;
      boolean var3 = false;
      boolean var4 = false;
      if (!var2) {
         var2 = var4;
         if (this.E) {
            var2 = var4;
            if (this.F) {
               this.onPrepareOptionsMenu(var1);
               var2 = true;
            }
         }

         j var5 = this.t;
         var3 = var2;
         if (var5 != null) {
            var3 = var2 | var5.b(var1);
         }
      }

      return var3;
   }

   public boolean b(MenuItem var1) {
      if (!this.A) {
         if (this.E && this.F && this.onOptionsItemSelected(var1)) {
            return true;
         }

         j var2 = this.t;
         if (var2 != null && var2.b(var1)) {
            return true;
         }
      }

      return false;
   }

   public LayoutInflater c(Bundle var1) {
      this.Q = this.onGetLayoutInflater(var1);
      return this.Q;
   }

   public final b.d.a.d.d c() {
      if (this.M == null) {
         this.M = new b.d.a.d.d();
      }

      return this.M;
   }

   public void c(boolean var1) {
      this.c().s = var1;
   }

   public View d() {
      b.d.a.d.d var1 = this.M;
      return var1 == null ? null : var1.a;
   }

   public void d(Bundle var1) {
      this.onSaveInstanceState(var1);
      j var2 = this.t;
      if (var2 != null) {
         Parcelable var3 = var2.s();
         if (var3 != null) {
            var1.putParcelable("android:support:fragments", var3);
         }
      }

   }

   public void dump(String var1, FileDescriptor var2, PrintWriter var3, String[] var4) {
      var3.print(var1);
      var3.print("mFragmentId=#");
      var3.print(Integer.toHexString(this.x));
      var3.print(" mContainerId=#");
      var3.print(Integer.toHexString(this.y));
      var3.print(" mTag=");
      var3.println(this.z);
      var3.print(var1);
      var3.print("mState=");
      var3.print(this.a);
      var3.print(" mIndex=");
      var3.print(this.e);
      var3.print(" mWho=");
      var3.print(this.f);
      var3.print(" mBackStackNesting=");
      var3.println(this.q);
      var3.print(var1);
      var3.print("mAdded=");
      var3.print(this.k);
      var3.print(" mRemoving=");
      var3.print(this.l);
      var3.print(" mFromLayout=");
      var3.print(this.m);
      var3.print(" mInLayout=");
      var3.println(this.n);
      var3.print(var1);
      var3.print("mHidden=");
      var3.print(this.A);
      var3.print(" mDetached=");
      var3.print(this.B);
      var3.print(" mMenuVisible=");
      var3.print(this.F);
      var3.print(" mHasMenu=");
      var3.println(this.E);
      var3.print(var1);
      var3.print("mRetainInstance=");
      var3.print(this.C);
      var3.print(" mRetaining=");
      var3.print(this.D);
      var3.print(" mUserVisibleHint=");
      var3.println(this.L);
      if (this.r != null) {
         var3.print(var1);
         var3.print("mFragmentManager=");
         var3.println(this.r);
      }

      if (this.s != null) {
         var3.print(var1);
         var3.print("mHost=");
         var3.println(this.s);
      }

      if (this.w != null) {
         var3.print(var1);
         var3.print("mParentFragment=");
         var3.println(this.w);
      }

      if (this.g != null) {
         var3.print(var1);
         var3.print("mArguments=");
         var3.println(this.g);
      }

      if (this.b != null) {
         var3.print(var1);
         var3.print("mSavedFragmentState=");
         var3.println(this.b);
      }

      if (this.c != null) {
         var3.print(var1);
         var3.print("mSavedViewState=");
         var3.println(this.c);
      }

      if (this.h != null) {
         var3.print(var1);
         var3.print("mTarget=");
         var3.print(this.h);
         var3.print(" mTargetRequestCode=");
         var3.println(this.j);
      }

      if (this.h() != 0) {
         var3.print(var1);
         var3.print("mNextAnim=");
         var3.println(this.h());
      }

      if (this.H != null) {
         var3.print(var1);
         var3.print("mContainer=");
         var3.println(this.H);
      }

      if (this.I != null) {
         var3.print(var1);
         var3.print("mView=");
         var3.println(this.I);
      }

      if (this.J != null) {
         var3.print(var1);
         var3.print("mInnerView=");
         var3.println(this.I);
      }

      if (this.d() != null) {
         var3.print(var1);
         var3.print("mAnimatingAway=");
         var3.println(this.d());
         var3.print(var1);
         var3.print("mStateAfterAnimating=");
         var3.println(this.k());
      }

      if (this.getContext() != null) {
         ((b.g.a.b)b.g.a.a.a(this)).b.a(var1, var2, var3, var4);
      }

      if (this.t != null) {
         var3.print(var1);
         StringBuilder var5 = new StringBuilder();
         var5.append("Child ");
         var5.append(this.t);
         var5.append(":");
         var3.println(var5.toString());
         this.t.a(c.a.b.a.a.a(var1, "  "), var2, var3, var4);
      }

   }

   public Animator e() {
      b.d.a.d.d var1 = this.M;
      return var1 == null ? null : var1.b;
   }

   public void e(Bundle var1) {
      if (var1 != null) {
         Parcelable var2 = var1.getParcelable("android:support:fragments");
         if (var2 != null) {
            if (this.t == null) {
               this.m();
            }

            this.t.a(var2, this.u);
            this.u = null;
            this.t.i();
         }
      }

   }

   public final boolean equals(Object var1) {
      return super.equals(var1);
   }

   public void f() {
      b.d.a.d.d var1 = this.M;
      if (var1 != null) {
         b.c.b.m var2 = var1.o;
      }
   }

   public final void f(Bundle var1) {
      SparseArray var2 = this.c;
      if (var2 != null) {
         this.J.restoreHierarchyState(var2);
         this.c = null;
      }

      this.G = false;
      this.onViewStateRestored(var1);
      if (this.G) {
         if (this.I != null) {
            this.T.a(b.f.e.a.ON_CREATE);
         }

      } else {
         throw new c0(c.a.b.a.a.a("Fragment ", this, " did not call through to super.onViewStateRestored()"));
      }
   }

   public void g() {
      b.d.a.d.d var1 = this.M;
      if (var1 != null) {
         b.c.b.m var2 = var1.p;
      }
   }

   public final b.d.a.e getActivity() {
      h var1 = this.s;
      b.d.a.e var2;
      if (var1 == null) {
         var2 = null;
      } else {
         var2 = (b.d.a.e)var1.a;
      }

      return var2;
   }

   public boolean getAllowEnterTransitionOverlap() {
      b.d.a.d.d var1 = this.M;
      boolean var2;
      if (var1 != null) {
         Boolean var3 = var1.n;
         if (var3 != null) {
            var2 = var3;
            return var2;
         }
      }

      var2 = true;
      return var2;
   }

   public boolean getAllowReturnTransitionOverlap() {
      b.d.a.d.d var1 = this.M;
      boolean var2;
      if (var1 != null) {
         Boolean var3 = var1.m;
         if (var3 != null) {
            var2 = var3;
            return var2;
         }
      }

      var2 = true;
      return var2;
   }

   public final Bundle getArguments() {
      return this.g;
   }

   public final i getChildFragmentManager() {
      if (this.t == null) {
         this.m();
         int var1 = this.a;
         if (var1 >= 4) {
            this.t.m();
         } else if (var1 >= 3) {
            this.t.n();
         } else if (var1 >= 2) {
            this.t.h();
         } else if (var1 >= 1) {
            this.t.i();
         }
      }

      return this.t;
   }

   public Context getContext() {
      h var1 = this.s;
      Context var2;
      if (var1 == null) {
         var2 = null;
      } else {
         var2 = var1.b;
      }

      return var2;
   }

   public Object getEnterTransition() {
      b.d.a.d.d var1 = this.M;
      return var1 == null ? null : var1.g;
   }

   public Object getExitTransition() {
      b.d.a.d.d var1 = this.M;
      return var1 == null ? null : var1.i;
   }

   public final i getFragmentManager() {
      return this.r;
   }

   public final Object getHost() {
      h var1 = this.s;
      b.d.a.e var2;
      if (var1 == null) {
         var2 = null;
      } else {
         var2 = ((b.d.a.e.b)var1).e;
      }

      return var2;
   }

   public final int getId() {
      return this.x;
   }

   public final LayoutInflater getLayoutInflater() {
      LayoutInflater var1 = this.Q;
      LayoutInflater var2 = var1;
      if (var1 == null) {
         var2 = this.c((Bundle)null);
      }

      return var2;
   }

   @Deprecated
   public LayoutInflater getLayoutInflater(Bundle var1) {
      h var4 = this.s;
      if (var4 != null) {
         b.d.a.e.b var5 = (b.d.a.e.b)var4;
         LayoutInflater var2 = var5.e.getLayoutInflater().cloneInContext(var5.e);
         this.getChildFragmentManager();
         j var3 = this.t;
         var3.q();
         var2.setFactory2(var3);
         if (VERSION.SDK_INT < 21) {
            Factory var6 = var2.getFactory();
            if (var6 instanceof Factory2) {
               b.c.b.b.a(var2, (Factory2)var6);
            } else {
               b.c.b.b.a((LayoutInflater)var2, (Factory2)var3);
            }
         }

         return var2;
      } else {
         throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
      }
   }

   public b.f.e getLifecycle() {
      return this.S;
   }

   @Deprecated
   public b.g.a.a getLoaderManager() {
      return b.g.a.a.a(this);
   }

   public final b.d.a.d getParentFragment() {
      return this.w;
   }

   public Object getReenterTransition() {
      b.d.a.d.d var1 = this.M;
      if (var1 == null) {
         return null;
      } else {
         Object var2 = var1.j;
         Object var3 = var2;
         if (var2 == X) {
            var3 = this.getExitTransition();
         }

         return var3;
      }
   }

   public final Resources getResources() {
      return this.requireContext().getResources();
   }

   public final boolean getRetainInstance() {
      return this.C;
   }

   public Object getReturnTransition() {
      b.d.a.d.d var1 = this.M;
      if (var1 == null) {
         return null;
      } else {
         Object var2 = var1.h;
         Object var3 = var2;
         if (var2 == X) {
            var3 = this.getEnterTransition();
         }

         return var3;
      }
   }

   public Object getSharedElementEnterTransition() {
      b.d.a.d.d var1 = this.M;
      return var1 == null ? null : var1.k;
   }

   public Object getSharedElementReturnTransition() {
      b.d.a.d.d var1 = this.M;
      if (var1 == null) {
         return null;
      } else {
         Object var2 = var1.l;
         Object var3 = var2;
         if (var2 == X) {
            var3 = this.getSharedElementEnterTransition();
         }

         return var3;
      }
   }

   public final String getString(int var1) {
      return this.getResources().getString(var1);
   }

   public final String getString(int var1, Object... var2) {
      return this.getResources().getString(var1, var2);
   }

   public final String getTag() {
      return this.z;
   }

   public final b.d.a.d getTargetFragment() {
      return this.h;
   }

   public final int getTargetRequestCode() {
      return this.j;
   }

   public final CharSequence getText(int var1) {
      return this.getResources().getText(var1);
   }

   public boolean getUserVisibleHint() {
      return this.L;
   }

   public View getView() {
      return this.I;
   }

   public b.f.h getViewLifecycleOwner() {
      b.f.h var1 = this.U;
      if (var1 != null) {
         return var1;
      } else {
         throw new IllegalStateException("Can't access the Fragment View's LifecycleOwner when getView() is null i.e., before onCreateView() or after onDestroyView()");
      }
   }

   public LiveData getViewLifecycleOwnerLiveData() {
      return this.V;
   }

   public b.f.u getViewModelStore() {
      if (this.getContext() != null) {
         if (this.v == null) {
            this.v = new b.f.u();
         }

         return this.v;
      } else {
         throw new IllegalStateException("Can't access ViewModels from detached fragment");
      }
   }

   public int h() {
      b.d.a.d.d var1 = this.M;
      return var1 == null ? 0 : var1.d;
   }

   public final boolean hasOptionsMenu() {
      return this.E;
   }

   public final int hashCode() {
      return super.hashCode();
   }

   public int i() {
      b.d.a.d.d var1 = this.M;
      return var1 == null ? 0 : var1.e;
   }

   public final boolean isAdded() {
      boolean var1;
      if (this.s != null && this.k) {
         var1 = true;
      } else {
         var1 = false;
      }

      return var1;
   }

   public final boolean isDetached() {
      return this.B;
   }

   public final boolean isHidden() {
      return this.A;
   }

   public final boolean isInLayout() {
      return this.n;
   }

   public final boolean isMenuVisible() {
      return this.F;
   }

   public final boolean isRemoving() {
      return this.l;
   }

   public final boolean isResumed() {
      boolean var1;
      if (this.a >= 4) {
         var1 = true;
      } else {
         var1 = false;
      }

      return var1;
   }

   public final boolean isStateSaved() {
      j var1 = this.r;
      return var1 == null ? false : var1.c();
   }

   public final boolean isVisible() {
      boolean var2;
      if (this.isAdded() && !this.isHidden()) {
         View var1 = this.I;
         if (var1 != null && var1.getWindowToken() != null && this.I.getVisibility() == 0) {
            var2 = true;
            return var2;
         }
      }

      var2 = false;
      return var2;
   }

   public int j() {
      b.d.a.d.d var1 = this.M;
      return var1 == null ? 0 : var1.f;
   }

   public int k() {
      b.d.a.d.d var1 = this.M;
      return var1 == null ? 0 : var1.c;
   }

   public void l() {
      this.e = -1;
      this.f = null;
      this.k = false;
      this.l = false;
      this.m = false;
      this.n = false;
      this.o = false;
      this.q = 0;
      this.r = null;
      this.t = null;
      this.s = null;
      this.x = 0;
      this.y = 0;
      this.z = null;
      this.A = false;
      this.B = false;
      this.D = false;
   }

   public void m() {
      if (this.s != null) {
         this.t = new j();
         j var1 = this.t;
         h var2 = this.s;
         b.d.a.f var3 = new b.d.a.f() {
            public View a(int var1) {
               View var2 = d.this.I;
               if (var2 != null) {
                  return var2.findViewById(var1);
               } else {
                  throw new IllegalStateException("Fragment does not have a view");
               }
            }

            public b.d.a.d a(Context var1, String var2, Bundle var3) {
               return d.this.s.a(var1, var2, var3);
            }

            public boolean a() {
               boolean var1;
               if (d.this.I != null) {
                  var1 = true;
               } else {
                  var1 = false;
               }

               return var1;
            }
         };
         if (var1.m == null) {
            var1.m = var2;
            var1.n = var3;
            var1.o = this;
         } else {
            throw new IllegalStateException("Already attached");
         }
      } else {
         throw new IllegalStateException("Fragment has not been attached yet.");
      }
   }

   public boolean n() {
      b.d.a.d.d var1 = this.M;
      return var1 == null ? false : var1.s;
   }

   public final boolean o() {
      boolean var1;
      if (this.q > 0) {
         var1 = true;
      } else {
         var1 = false;
      }

      return var1;
   }

   public void onActivityCreated(Bundle var1) {
      this.G = true;
   }

   public void onActivityResult(int var1, int var2, Intent var3) {
   }

   @Deprecated
   public void onAttach(Activity var1) {
      this.G = true;
   }

   public void onAttach(Context var1) {
      this.G = true;
      h var2 = this.s;
      Activity var3;
      if (var2 == null) {
         var3 = null;
      } else {
         var3 = var2.a;
      }

      if (var3 != null) {
         this.G = false;
         this.onAttach(var3);
      }

   }

   public void onAttachFragment(b.d.a.d var1) {
   }

   public void onConfigurationChanged(Configuration var1) {
      this.G = true;
   }

   public boolean onContextItemSelected(MenuItem var1) {
      return false;
   }

   public void onCreate(Bundle var1) {
      boolean var2 = true;
      this.G = true;
      this.e(var1);
      j var3 = this.t;
      if (var3 != null) {
         if (var3.l < 1) {
            var2 = false;
         }

         if (!var2) {
            this.t.i();
         }
      }

   }

   public Animation onCreateAnimation(int var1, boolean var2, int var3) {
      return null;
   }

   public Animator onCreateAnimator(int var1, boolean var2, int var3) {
      return null;
   }

   public void onCreateContextMenu(ContextMenu var1, View var2, ContextMenuInfo var3) {
      this.getActivity().onCreateContextMenu(var1, var2, var3);
   }

   public void onCreateOptionsMenu(Menu var1, MenuInflater var2) {
   }

   public View onCreateView(LayoutInflater var1, ViewGroup var2, Bundle var3) {
      return null;
   }

   public void onDestroy() {
      boolean var1 = true;
      this.G = true;
      b.d.a.e var2 = this.getActivity();
      if (var2 == null || !var2.isChangingConfigurations()) {
         var1 = false;
      }

      b.f.u var3 = this.v;
      if (var3 != null && !var1) {
         var3.a();
      }

   }

   public void onDestroyOptionsMenu() {
   }

   public void onDestroyView() {
      this.G = true;
   }

   public void onDetach() {
      this.G = true;
   }

   public LayoutInflater onGetLayoutInflater(Bundle var1) {
      return this.getLayoutInflater(var1);
   }

   public void onHiddenChanged(boolean var1) {
   }

   @Deprecated
   public void onInflate(Activity var1, AttributeSet var2, Bundle var3) {
      this.G = true;
   }

   public void onInflate(Context var1, AttributeSet var2, Bundle var3) {
      this.G = true;
      h var4 = this.s;
      Activity var5;
      if (var4 == null) {
         var5 = null;
      } else {
         var5 = var4.a;
      }

      if (var5 != null) {
         this.G = false;
         this.onInflate(var5, var2, var3);
      }

   }

   public void onLowMemory() {
      this.G = true;
   }

   public void onMultiWindowModeChanged(boolean var1) {
   }

   public boolean onOptionsItemSelected(MenuItem var1) {
      return false;
   }

   public void onOptionsMenuClosed(Menu var1) {
   }

   public void onPause() {
      this.G = true;
   }

   public void onPictureInPictureModeChanged(boolean var1) {
   }

   public void onPrepareOptionsMenu(Menu var1) {
   }

   public void onRequestPermissionsResult(int var1, String[] var2, int[] var3) {
   }

   public void onResume() {
      this.G = true;
   }

   public void onSaveInstanceState(Bundle var1) {
   }

   public void onStart() {
      this.G = true;
   }

   public void onStop() {
      this.G = true;
   }

   public void onViewCreated(View var1, Bundle var2) {
   }

   public void onViewStateRestored(Bundle var1) {
      this.G = true;
   }

   public boolean p() {
      b.d.a.d.d var1 = this.M;
      return var1 == null ? false : var1.q;
   }

   public void postponeEnterTransition() {
      this.c().q = true;
   }

   public void q() {
      j var1 = this.t;
      if (var1 != null) {
         var1.r();
      }

   }

   public i r() {
      return this.t;
   }

   public void registerForContextMenu(View var1) {
      var1.setOnCreateContextMenuListener(this);
   }

   public final void requestPermissions(String[] var1, int var2) {
      h var3 = this.s;
      if (var3 != null) {
         ((b.d.a.e.b)var3).e.a(this, var1, var2);
      } else {
         throw new IllegalStateException(c.a.b.a.a.a("Fragment ", this, " not attached to Activity"));
      }
   }

   public final b.d.a.e requireActivity() {
      b.d.a.e var1 = this.getActivity();
      if (var1 != null) {
         return var1;
      } else {
         throw new IllegalStateException(c.a.b.a.a.a("Fragment ", this, " not attached to an activity."));
      }
   }

   public final Context requireContext() {
      Context var1 = this.getContext();
      if (var1 != null) {
         return var1;
      } else {
         throw new IllegalStateException(c.a.b.a.a.a("Fragment ", this, " not attached to a context."));
      }
   }

   public final i requireFragmentManager() {
      i var1 = this.getFragmentManager();
      if (var1 != null) {
         return var1;
      } else {
         throw new IllegalStateException(c.a.b.a.a.a("Fragment ", this, " not associated with a fragment manager."));
      }
   }

   public final Object requireHost() {
      Object var1 = this.getHost();
      if (var1 != null) {
         return var1;
      } else {
         throw new IllegalStateException(c.a.b.a.a.a("Fragment ", this, " not attached to a host."));
      }
   }

   public void s() {
      this.S.a(b.f.e.a.ON_DESTROY);
      j var1 = this.t;
      if (var1 != null) {
         var1.j();
      }

      this.a = 0;
      this.G = false;
      this.R = false;
      this.onDestroy();
      if (this.G) {
         this.t = null;
      } else {
         throw new c0(c.a.b.a.a.a("Fragment ", this, " did not call through to super.onDestroy()"));
      }
   }

   public void setAllowEnterTransitionOverlap(boolean var1) {
      this.c().n = var1;
   }

   public void setAllowReturnTransitionOverlap(boolean var1) {
      this.c().m = var1;
   }

   public void setArguments(Bundle var1) {
      if (this.e >= 0 && this.isStateSaved()) {
         throw new IllegalStateException("Fragment already active and state has been saved");
      } else {
         this.g = var1;
      }
   }

   public void setEnterSharedElementCallback(b.c.b.m var1) {
      this.c().o = var1;
   }

   public void setEnterTransition(Object var1) {
      this.c().g = var1;
   }

   public void setExitSharedElementCallback(b.c.b.m var1) {
      this.c().p = var1;
   }

   public void setExitTransition(Object var1) {
      this.c().i = var1;
   }

   public void setHasOptionsMenu(boolean var1) {
      if (this.E != var1) {
         this.E = var1;
         if (this.isAdded() && !this.isHidden()) {
            ((b.d.a.e.b)this.s).e.f();
         }
      }

   }

   public void setInitialSavedState(b.d.a.d.g var1) {
      if (this.e >= 0) {
         throw new IllegalStateException("Fragment already active");
      } else {
         Bundle var2;
         label15: {
            if (var1 != null) {
               var2 = var1.a;
               if (var2 != null) {
                  break label15;
               }
            }

            var2 = null;
         }

         this.b = var2;
      }
   }

   public void setMenuVisibility(boolean var1) {
      if (this.F != var1) {
         this.F = var1;
         if (this.E && this.isAdded() && !this.isHidden()) {
            ((b.d.a.e.b)this.s).e.f();
         }
      }

   }

   public void setReenterTransition(Object var1) {
      this.c().j = var1;
   }

   public void setRetainInstance(boolean var1) {
      this.C = var1;
   }

   public void setReturnTransition(Object var1) {
      this.c().h = var1;
   }

   public void setSharedElementEnterTransition(Object var1) {
      this.c().k = var1;
   }

   public void setSharedElementReturnTransition(Object var1) {
      this.c().l = var1;
   }

   public void setTargetFragment(b.d.a.d var1, int var2) {
      i var3 = this.getFragmentManager();
      i var4;
      if (var1 != null) {
         var4 = var1.getFragmentManager();
      } else {
         var4 = null;
      }

      if (var3 != null && var4 != null && var3 != var4) {
         throw new IllegalArgumentException(c.a.b.a.a.a("Fragment ", var1, " must share the same FragmentManager to be set as a target fragment"));
      } else {
         for(b.d.a.d var5 = var1; var5 != null; var5 = var5.getTargetFragment()) {
            if (var5 == this) {
               StringBuilder var6 = new StringBuilder();
               var6.append("Setting ");
               var6.append(var1);
               var6.append(" as the target of ");
               var6.append(this);
               var6.append(" would create a target cycle");
               throw new IllegalArgumentException(var6.toString());
            }
         }

         this.h = var1;
         this.j = var2;
      }
   }

   public void setUserVisibleHint(boolean var1) {
      if (!this.L && var1 && this.a < 3 && this.r != null && this.isAdded() && this.R) {
         this.r.f(this);
      }

      this.L = var1;
      boolean var2;
      if (this.a < 3 && !var1) {
         var2 = true;
      } else {
         var2 = false;
      }

      this.K = var2;
      if (this.b != null) {
         this.d = var1;
      }

   }

   public boolean shouldShowRequestPermissionRationale(String var1) {
      h var2 = this.s;
      boolean var3 = false;
      boolean var4 = var3;
      if (var2 != null) {
         b.d.a.e var5 = ((b.d.a.e.b)var2).e;
         var4 = var3;
         if (VERSION.SDK_INT >= 23) {
            var4 = var5.shouldShowRequestPermissionRationale(var1);
         }
      }

      return var4;
   }

   public void startActivity(Intent var1) {
      this.startActivity(var1, (Bundle)null);
   }

   public void startActivity(Intent var1, Bundle var2) {
      h var3 = this.s;
      if (var3 != null) {
         ((b.d.a.e.b)var3).e.a(this, var1, -1, var2);
      } else {
         throw new IllegalStateException(c.a.b.a.a.a("Fragment ", this, " not attached to Activity"));
      }
   }

   public void startActivityForResult(Intent var1, int var2) {
      this.startActivityForResult(var1, var2, (Bundle)null);
   }

   public void startActivityForResult(Intent var1, int var2, Bundle var3) {
      h var4 = this.s;
      if (var4 != null) {
         ((b.d.a.e.b)var4).e.a(this, var1, var2, var3);
      } else {
         throw new IllegalStateException(c.a.b.a.a.a("Fragment ", this, " not attached to Activity"));
      }
   }

   public void startIntentSenderForResult(IntentSender var1, int var2, Intent var3, int var4, int var5, int var6, Bundle var7) {
      h var8 = this.s;
      if (var8 != null) {
         ((b.d.a.e.b)var8).e.a(this, var1, var2, var3, var4, var5, var6, var7);
      } else {
         throw new IllegalStateException(c.a.b.a.a.a("Fragment ", this, " not attached to Activity"));
      }
   }

   public void startPostponedEnterTransition() {
      j var1 = this.r;
      if (var1 != null && var1.m != null) {
         if (Looper.myLooper() != this.r.m.c.getLooper()) {
            this.r.m.c.postAtFrontOfQueue(new Runnable() {
               public void run() {
                  d.this.b();
               }
            });
         } else {
            this.b();
         }
      } else {
         this.c().q = false;
      }

   }

   public void t() {
      if (this.I != null) {
         this.T.a(b.f.e.a.ON_DESTROY);
      }

      j var1 = this.t;
      if (var1 != null) {
         var1.a(1);
      }

      this.a = 1;
      this.G = false;
      this.onDestroyView();
      if (this.G) {
         ((b.g.a.b)b.g.a.a.a(this)).b.d();
         this.p = false;
      } else {
         throw new c0(c.a.b.a.a.a("Fragment ", this, " did not call through to super.onDestroyView()"));
      }
   }

   public String toString() {
      StringBuilder var1 = new StringBuilder(128);
      b.c.b.b.a((Object)this, (StringBuilder)var1);
      if (this.e >= 0) {
         var1.append(" #");
         var1.append(this.e);
      }

      if (this.x != 0) {
         var1.append(" id=0x");
         var1.append(Integer.toHexString(this.x));
      }

      if (this.z != null) {
         var1.append(" ");
         var1.append(this.z);
      }

      var1.append('}');
      return var1.toString();
   }

   public void u() {
      this.G = false;
      this.onDetach();
      this.Q = null;
      if (this.G) {
         j var1 = this.t;
         if (var1 != null) {
            if (!this.D) {
               StringBuilder var2 = new StringBuilder();
               var2.append("Child FragmentManager of ");
               var2.append(this);
               var2.append(" was not ");
               var2.append(" destroyed and this fragment is not retaining instance");
               throw new IllegalStateException(var2.toString());
            }

            var1.j();
            this.t = null;
         }

      } else {
         throw new c0(c.a.b.a.a.a("Fragment ", this, " did not call through to super.onDetach()"));
      }
   }

   public void unregisterForContextMenu(View var1) {
      var1.setOnCreateContextMenuListener((OnCreateContextMenuListener)null);
   }

   public void v() {
      this.onLowMemory();
      j var1 = this.t;
      if (var1 != null) {
         var1.k();
      }

   }

   public void w() {
      if (this.I != null) {
         this.T.a(b.f.e.a.ON_PAUSE);
      }

      this.S.a(b.f.e.a.ON_PAUSE);
      j var1 = this.t;
      if (var1 != null) {
         var1.a(3);
      }

      this.a = 3;
      this.G = false;
      this.onPause();
      if (!this.G) {
         throw new c0(c.a.b.a.a.a("Fragment ", this, " did not call through to super.onPause()"));
      }
   }

   public void x() {
      j var1 = this.t;
      if (var1 != null) {
         var1.r();
         this.t.p();
      }

      this.a = 4;
      this.G = false;
      this.onResume();
      if (this.G) {
         var1 = this.t;
         if (var1 != null) {
            var1.m();
            this.t.p();
         }

         this.S.a(b.f.e.a.ON_RESUME);
         if (this.I != null) {
            this.T.a(b.f.e.a.ON_RESUME);
         }

      } else {
         throw new c0(c.a.b.a.a.a("Fragment ", this, " did not call through to super.onResume()"));
      }
   }

   public void y() {
      j var1 = this.t;
      if (var1 != null) {
         var1.r();
         this.t.p();
      }

      this.a = 3;
      this.G = false;
      this.onStart();
      if (this.G) {
         var1 = this.t;
         if (var1 != null) {
            var1.n();
         }

         this.S.a(b.f.e.a.ON_START);
         if (this.I != null) {
            this.T.a(b.f.e.a.ON_START);
         }

      } else {
         throw new c0(c.a.b.a.a.a("Fragment ", this, " did not call through to super.onStart()"));
      }
   }

   public void z() {
      if (this.I != null) {
         this.T.a(b.f.e.a.ON_STOP);
      }

      this.S.a(b.f.e.a.ON_STOP);
      j var1 = this.t;
      if (var1 != null) {
         var1.s = true;
         var1.a(2);
      }

      this.a = 2;
      this.G = false;
      this.onStop();
      if (!this.G) {
         throw new c0(c.a.b.a.a.a("Fragment ", this, " did not call through to super.onStop()"));
      }
   }

   public static class d {
      public View a;
      public Animator b;
      public int c;
      public int d;
      public int e;
      public int f;
      public Object g = null;
      public Object h;
      public Object i;
      public Object j;
      public Object k;
      public Object l;
      public Boolean m;
      public Boolean n;
      public b.c.b.m o;
      public b.c.b.m p;
      public boolean q;
      public b.d.a.d.f r;
      public boolean s;

      public d() {
         Object var1 = b.d.a.d.X;
         this.h = var1;
         this.i = null;
         this.j = var1;
         this.k = null;
         this.l = var1;
      }
   }

   public static class e extends RuntimeException {
      public e(String var1, Exception var2) {
         super(var1, var2);
      }
   }

   public interface f {
   }

   public static class g implements Parcelable {
      public static final Creator CREATOR = new ClassLoaderCreator() {
         public Object createFromParcel(Parcel var1) {
            return new b.d.a.d.g(var1, (ClassLoader)null);
         }

         public Object createFromParcel(Parcel var1, ClassLoader var2) {
            return new b.d.a.d.g(var1, var2);
         }

         public Object[] newArray(int var1) {
            return new b.d.a.d.g[var1];
         }
      };
      public final Bundle a;

      public g(Parcel var1, ClassLoader var2) {
         this.a = var1.readBundle();
         if (var2 != null) {
            Bundle var3 = this.a;
            if (var3 != null) {
               var3.setClassLoader(var2);
            }
         }

      }

      public int describeContents() {
         return 0;
      }

      public void writeToParcel(Parcel var1, int var2) {
         var1.writeBundle(this.a);
      }
   }
}
