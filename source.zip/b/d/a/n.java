package b.d.a;

import java.util.List;

public class n {
   public final List a;
   public final List b;
   public final List c;

   public n(List var1, List var2, List var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }
}
