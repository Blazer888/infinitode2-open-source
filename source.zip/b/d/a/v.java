package b.d.a;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.transition.Transition;
import android.transition.TransitionSet;
import android.transition.Transition.EpicenterCallback;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class v {
   public static final int[] a = new int[]{0, 3, 0, 1, 5, 4, 7, 6, 9, 8};
   public static final a0 b;
   public static final a0 c;

   static {
      w var0;
      if (VERSION.SDK_INT >= 21) {
         var0 = new w();
      } else {
         var0 = null;
      }

      b = var0;

      a0 var2;
      try {
         var2 = (a0)Class.forName("androidx.transition.FragmentTransitionSupport").getDeclaredConstructor().newInstance();
      } catch (Exception var1) {
         var2 = null;
      }

      c = var2;
   }

   public static View a(b.b.a var0, v.a var1, Object var2, boolean var3) {
      b.d.a.a var4 = var1.c;
      if (var2 != null && var0 != null) {
         ArrayList var6 = var4.q;
         if (var6 != null && !var6.isEmpty()) {
            String var5;
            if (var3) {
               var5 = (String)var4.q.get(0);
            } else {
               var5 = (String)var4.r.get(0);
            }

            return (View)var0.get(var5);
         }
      }

      return null;
   }

   public static b.b.a a(a0 var0, b.b.a var1, Object var2, v.a var3) {
      d var4 = var3.a;
      View var5 = var4.getView();
      if (!var1.isEmpty() && var2 != null && var5 != null) {
         b.b.a var10 = new b.b.a();
         var0.a((Map)var10, (View)var5);
         b.d.a.a var8 = var3.c;
         ArrayList var9;
         if (var3.b) {
            var4.g();
            var9 = var8.q;
         } else {
            var4.f();
            var9 = var8.r;
         }

         if (var9 != null) {
            b.b.e.a((Map)var10, (Collection)var9);
            b.b.e.a((Map)var10, (Collection)var1.values());
         }

         int var6 = var1.c;

         while(true) {
            int var7 = var6 - 1;
            if (var7 < 0) {
               return var10;
            }

            var6 = var7;
            if (!var10.containsKey((String)var1.d(var7))) {
               var1.c(var7);
               var6 = var7;
            }
         }
      } else {
         var1.clear();
         return null;
      }
   }

   public static a0 a(d var0, d var1) {
      ArrayList var2 = new ArrayList();
      Object var4;
      if (var0 != null) {
         Object var3 = var0.getExitTransition();
         if (var3 != null) {
            var2.add(var3);
         }

         var3 = var0.getReturnTransition();
         if (var3 != null) {
            var2.add(var3);
         }

         var4 = var0.getSharedElementReturnTransition();
         if (var4 != null) {
            var2.add(var4);
         }
      }

      if (var1 != null) {
         var4 = var1.getEnterTransition();
         if (var4 != null) {
            var2.add(var4);
         }

         var4 = var1.getReenterTransition();
         if (var4 != null) {
            var2.add(var4);
         }

         var4 = var1.getSharedElementEnterTransition();
         if (var4 != null) {
            var2.add(var4);
         }
      }

      if (var2.isEmpty()) {
         return null;
      } else {
         a0 var5 = b;
         if (var5 != null && a((a0)var5, (List)var2)) {
            return b;
         } else {
            var5 = c;
            if (var5 != null && a((a0)var5, (List)var2)) {
               return c;
            } else if (b == null && c == null) {
               return null;
            } else {
               throw new IllegalArgumentException("Invalid Transition types");
            }
         }
      }
   }

   public static Object a(a0 var0, d var1, d var2, boolean var3) {
      Object var4 = null;
      TransitionSet var5 = (TransitionSet)var4;
      if (var1 != null) {
         if (var2 == null) {
            var5 = (TransitionSet)var4;
         } else {
            Object var7;
            if (var3) {
               var7 = var2.getSharedElementReturnTransition();
            } else {
               var7 = var1.getSharedElementEnterTransition();
            }

            var7 = var0.b(var7);
            w var6 = (w)var0;
            if (var7 == null) {
               var5 = (TransitionSet)var4;
            } else {
               var5 = new TransitionSet();
               var5.addTransition((Transition)var7);
            }
         }
      }

      return var5;
   }

   public static Object a(a0 var0, d var1, boolean var2) {
      if (var1 == null) {
         return null;
      } else {
         Object var3;
         if (var2) {
            var3 = var1.getReenterTransition();
         } else {
            var3 = var1.getEnterTransition();
         }

         return var0.b(var3);
      }
   }

   public static Object a(a0 var0, Object var1, Object var2, Object var3, d var4, boolean var5) {
      if (var1 != null && var2 != null && var4 != null) {
         if (var5) {
            var5 = var4.getAllowReturnTransitionOverlap();
         } else {
            var5 = var4.getAllowEnterTransitionOverlap();
         }
      } else {
         var5 = true;
      }

      Object var6;
      if (var5) {
         var6 = var0.b(var2, var1, var3);
      } else {
         var6 = var0.a(var2, var1, var3);
      }

      return var6;
   }

   public static ArrayList a(a0 var0, Object var1, d var2, ArrayList var3, View var4) {
      ArrayList var7;
      if (var1 != null) {
         ArrayList var5 = new ArrayList();
         View var6 = var2.getView();
         if (var6 != null) {
            var0.a(var5, var6);
         }

         if (var3 != null) {
            var5.removeAll(var3);
         }

         var7 = var5;
         if (!var5.isEmpty()) {
            var5.add(var4);
            var0.a(var1, var5);
            var7 = var5;
         }
      } else {
         var7 = null;
      }

      return var7;
   }

   public static void a(a0 var0, Object var1, Object var2, b.b.a var3, boolean var4, b.d.a.a var5) {
      // $FF: Couldn't be decompiled
   }

   public static void a(b.d.a.a var0, b.d.a.a.a var1, SparseArray var2, boolean var3, boolean var4) {
      d var5 = var1.b;
      if (var5 != null) {
         int var6 = var5.y;
         if (var6 != 0) {
            int var7;
            if (var3) {
               var7 = a[var1.a];
            } else {
               var7 = var1.a;
            }

            boolean var8;
            boolean var9;
            boolean var10;
            boolean var15;
            label153: {
               label152: {
                  label151: {
                     label150: {
                        label149: {
                           label148: {
                              label147: {
                                 label146: {
                                    label160: {
                                       var8 = false;
                                       if (var7 != 1) {
                                          if (var7 == 3) {
                                             break label147;
                                          }

                                          if (var7 == 4) {
                                             if (var4) {
                                                if (var5.O && var5.k && var5.A) {
                                                   break label150;
                                                }
                                             } else if (var5.k && !var5.A) {
                                                break label150;
                                             }
                                             break label149;
                                          }

                                          if (var7 == 5) {
                                             if (!var4) {
                                                var9 = var5.A;
                                                break label148;
                                             }

                                             if (var5.O && !var5.A && var5.k) {
                                                break label146;
                                             }
                                             break label160;
                                          }

                                          if (var7 == 6) {
                                             break label147;
                                          }

                                          if (var7 != 7) {
                                             var9 = false;
                                             var15 = false;
                                             break label151;
                                          }
                                       }

                                       if (var4) {
                                          var9 = var5.N;
                                          break label148;
                                       }

                                       if (!var5.k && !var5.A) {
                                          break label146;
                                       }
                                    }

                                    var9 = false;
                                    break label148;
                                 }

                                 var9 = true;
                                 break label148;
                              }

                              if (var4) {
                                 if (!var5.k) {
                                    View var13 = var5.I;
                                    if (var13 != null && var13.getVisibility() == 0 && var5.P >= 0.0F) {
                                       break label150;
                                    }
                                 }
                              } else if (var5.k && !var5.A) {
                                 break label150;
                              }
                              break label149;
                           }

                           var15 = true;
                           break label151;
                        }

                        var15 = false;
                        break label152;
                     }

                     var15 = true;
                     break label152;
                  }

                  var8 = false;
                  var10 = false;
                  break label153;
               }

               var10 = var15;
               var9 = false;
               boolean var11 = true;
               var15 = var8;
               var8 = var11;
            }

            v.a var12 = (v.a)var2.get(var6);
            v.a var14 = var12;
            if (var9) {
               var14 = var12;
               if (var12 == null) {
                  var14 = new v.a();
                  var2.put(var6, var14);
               }

               var14.a = var5;
               var14.b = var3;
               var14.c = var0;
            }

            if (!var4 && var15) {
               if (var14 != null && var14.d == var5) {
                  var14.d = null;
               }

               j var16 = var0.a;
               if (var5.a < 1 && var16.l >= 1 && !var0.s) {
                  var16.d(var5);
                  var16.a(var5, 1, 0, 0, false);
               }
            }

            var12 = var14;
            if (var10) {
               label162: {
                  if (var14 != null) {
                     var12 = var14;
                     if (var14.d != null) {
                        break label162;
                     }
                  }

                  var12 = var14;
                  if (var14 == null) {
                     var12 = new v.a();
                     var2.put(var6, var12);
                  }

                  var12.d = var5;
                  var12.e = var3;
                  var12.f = var0;
               }
            }

            if (!var4 && var8 && var12 != null && var12.a == var5) {
               var12.a = null;
            }

         }
      }
   }

   public static void a(d var0, d var1, boolean var2, b.b.a var3, boolean var4) {
      if (var2) {
         var1.f();
      } else {
         var0.f();
      }

   }

   public static void a(j var0, ArrayList var1, ArrayList var2, int var3, int var4, boolean var5) {
      boolean var7 = var5;
      if (var0.l >= 1) {
         SparseArray var8 = new SparseArray();

         int var9;
         int var11;
         int var12;
         for(var9 = var3; var9 < var4; ++var9) {
            b.d.a.a var10 = (b.d.a.a)var1.get(var9);
            if ((Boolean)var2.get(var9)) {
               if (var10.a.n.a()) {
                  for(var11 = var10.b.size() - 1; var11 >= 0; --var11) {
                     a(var10, (b.d.a.a.a)var10.b.get(var11), var8, true, var7);
                  }
               }
            } else {
               var12 = var10.b.size();

               for(var11 = 0; var11 < var12; ++var11) {
                  a(var10, (b.d.a.a.a)var10.b.get(var11), var8, false, var7);
               }
            }
         }

         if (var8.size() != 0) {
            View var13 = new View(var0.m.b);
            var11 = var8.size();

            for(var9 = 0; var9 < var11; var9 = var12) {
               int var15 = var8.keyAt(var9);
               b.b.a var34 = new b.b.a();

               ArrayList var6;
               int var17;
               int var19;
               String var21;
               for(var12 = var4 - 1; var12 >= var3; --var12) {
                  b.d.a.a var16 = (b.d.a.a)var1.get(var12);
                  if (var16.b(var15)) {
                     var7 = (Boolean)var2.get(var12);
                     var6 = var16.q;
                     if (var6 != null) {
                        var17 = var6.size();
                        ArrayList var18;
                        if (var7) {
                           var18 = var16.q;
                           var6 = var16.r;
                        } else {
                           var6 = var16.q;
                           var18 = var16.r;
                        }

                        for(var19 = 0; var19 < var17; ++var19) {
                           String var20 = (String)var6.get(var19);
                           String var39 = (String)var18.get(var19);
                           var21 = (String)var34.remove(var39);
                           if (var21 != null) {
                              var34.put(var20, var21);
                           } else {
                              var34.put(var20, var39);
                           }
                        }
                     }
                  }
               }

               label259: {
                  v.a var22 = (v.a)var8.valueAt(var9);
                  d var23;
                  a0 var24;
                  boolean var25;
                  Object var29;
                  d var30;
                  Object var33;
                  ArrayList var38;
                  ViewGroup var45;
                  Rect var48;
                  Object var51;
                  if (var5) {
                     if (var0.n.a()) {
                        var45 = (ViewGroup)var0.n.a(var15);
                     } else {
                        var45 = null;
                     }

                     if (var45 != null) {
                        d var50 = var22.a;
                        var23 = var22.d;
                        var24 = a(var23, var50);
                        if (var24 != null) {
                           var7 = var22.b;
                           var25 = var22.e;
                           ArrayList var26 = new ArrayList();
                           ArrayList var27 = new ArrayList();
                           Object var28 = a(var24, var50, var7);
                           var29 = b(var24, var23, var25);
                           var30 = var22.a;
                           d var31 = var22.d;
                           if (var30 != null) {
                              var30.getView().setVisibility(0);
                           }

                           label312: {
                              if (var30 != null && var31 != null) {
                                 var25 = var22.b;
                                 if (var34.isEmpty()) {
                                    var33 = null;
                                 } else {
                                    var33 = a(var24, var30, var31, var25);
                                 }

                                 b.b.a var14 = b(var24, var34, var33, var22);
                                 b.b.a var32 = a(var24, var34, var33, var22);
                                 if (var34.isEmpty()) {
                                    if (var14 != null) {
                                       var14.clear();
                                    }

                                    if (var32 != null) {
                                       var32.clear();
                                    }

                                    var33 = null;
                                 } else {
                                    a(var27, var14, var34.keySet());
                                    a(var26, var32, var34.values());
                                 }

                                 if (var28 != null || var29 != null || var33 != null) {
                                    a(var30, var31, var25, var14, true);
                                    Rect var37;
                                    View var41;
                                    if (var33 != null) {
                                       var26.add(var13);
                                       var24.b(var33, var13, var27);
                                       a(var24, var33, var29, var14, var22.e, var22.f);
                                       var48 = new Rect();
                                       View var36 = a(var32, var22, var28, var25);
                                       if (var36 != null) {
                                          var24.a(var28, var48);
                                       }

                                       var41 = var36;
                                       var37 = var48;
                                    } else {
                                       var41 = null;
                                       var37 = null;
                                    }

                                    b0.a(var45, new t(var30, var31, var25, var32, var41, var24, var37));
                                    break label312;
                                 }
                              }

                              var33 = null;
                           }

                           if (var28 != null || var33 != null || var29 != null) {
                              ArrayList var49 = a(var24, var29, var23, var27, var13);
                              var38 = a(var24, var28, var50, var26, var13);
                              a(var38, 4);
                              var51 = a(var24, var28, var29, var33, var50, var7);
                              if (var51 != null) {
                                 if (var23 != null && var29 != null && var23.k && var23.A && var23.O) {
                                    var23.c(true);
                                    var24.a(var29, var23.getView(), var49);
                                    b0.a(var23.H, new r(var49));
                                 }

                                 ArrayList var42 = new ArrayList();
                                 var17 = var26.size();

                                 View var53;
                                 for(var12 = 0; var12 < var17; ++var12) {
                                    var53 = (View)var26.get(var12);
                                    var42.add(b.c.e.c.a(var53));
                                    b.c.e.c.a(var53, (String)null);
                                 }

                                 var24.a(var51, var28, var38, var29, var49, var33, var26);
                                 var24.a(var45, var51);
                                 var19 = var26.size();
                                 var49 = new ArrayList();

                                 for(var12 = 0; var12 < var19; ++var12) {
                                    var53 = (View)var27.get(var12);
                                    var21 = b.c.e.c.a(var53);
                                    var49.add(var21);
                                    if (var21 != null) {
                                       b.c.e.c.a(var53, (String)null);
                                       String var55 = (String)var34.get(var21);

                                       for(var17 = 0; var17 < var19; ++var17) {
                                          if (var55.equals(var42.get(var17))) {
                                             b.c.e.c.a((View)var26.get(var17), var21);
                                             break;
                                          }
                                       }
                                    }
                                 }

                                 b0.a(var45, new x(var24, var19, var26, var42, var27, var49));
                                 a(var38, 0);
                                 var24.b(var33, var27, var26);
                              }
                           }
                        }
                     }
                  } else {
                     if (var0.n.a()) {
                        var45 = (ViewGroup)var0.n.a(var15);
                     } else {
                        var45 = null;
                     }

                     if (var45 != null) {
                        d var58 = var22.a;
                        var23 = var22.d;
                        a0 var59 = a(var23, var58);
                        if (var59 != null) {
                           Object var40;
                           ArrayList var60;
                           label252: {
                              var25 = var22.b;
                              var7 = var22.e;
                              var29 = a(var59, var58, var25);
                              var51 = b(var59, var23, var7);
                              var60 = new ArrayList();
                              var38 = new ArrayList();
                              d var56 = var22.a;
                              var30 = var22.d;
                              if (var56 != null && var30 != null) {
                                 var7 = var22.b;
                                 if (var34.isEmpty()) {
                                    var33 = null;
                                 } else {
                                    var33 = a(var59, var56, var30, var7);
                                 }

                                 b.b.a var43 = b(var59, var34, var33, var22);
                                 if (var34.isEmpty()) {
                                    var33 = null;
                                 } else {
                                    var60.addAll(var43.values());
                                 }

                                 if (var29 != null || var51 != null || var33 != null) {
                                    a(var56, var30, var7, var43, true);
                                    Rect var44;
                                    if (var33 != null) {
                                       var48 = new Rect();
                                       var59.b(var33, var13, var60);
                                       a(var59, var33, var51, var43, var22.e, var22.f);
                                       var44 = var48;
                                       if (var29 != null) {
                                          var59.a(var29, var48);
                                          var44 = var48;
                                       }
                                    } else {
                                       var44 = null;
                                    }

                                    b0.a(var45, new u(var59, var34, var33, var22, var38, var13, var56, var30, var7, var60, var29, var44));
                                    var40 = var33;
                                    var6 = var38;
                                    break label252;
                                 }
                              }

                              var6 = var38;
                              var40 = null;
                           }

                           var24 = null;
                           var17 = var9;
                           if (var29 == null && var40 == null && var51 == null) {
                              var12 = var9;
                              var9 = var11;
                              break label259;
                           }

                           ArrayList var54 = a(var59, var51, var23, var60, var13);
                           Object var35 = var24;
                           if (var54 != null) {
                              if (var54.isEmpty()) {
                                 var35 = var24;
                              } else {
                                 var35 = var51;
                              }
                           }

                           w var47 = (w)var59;
                           if (var29 != null) {
                              ((Transition)var29).addTarget(var13);
                           }

                           Object var46 = a(var59, var29, var35, var40, var58, var22.b);
                           var12 = var9;
                           var9 = var11;
                           if (var46 != null) {
                              ArrayList var57 = new ArrayList();
                              var59.a(var46, var29, var57, var35, var54, var40, var6);
                              b0.a(var45, new s(var29, var59, var13, var58, var6, var57, var54, var35));
                              b0.a(var45, new y(var59, var6, var34));
                              var59.a(var45, var46);
                              b0.a(var45, new z(var59, var6, var34));
                              var9 = var11;
                              var12 = var17;
                           }
                           break label259;
                        }
                     }
                  }

                  var12 = var9;
                  var9 = var11;
               }

               ++var12;
               var11 = var9;
            }
         }

      }
   }

   public static void a(ArrayList var0, int var1) {
      if (var0 != null) {
         for(int var2 = var0.size() - 1; var2 >= 0; --var2) {
            ((View)var0.get(var2)).setVisibility(var1);
         }

      }
   }

   public static void a(ArrayList var0, b.b.a var1, Collection var2) {
      for(int var3 = var1.c - 1; var3 >= 0; --var3) {
         View var4 = (View)var1.d(var3);
         if (var2.contains(b.c.e.c.a(var4))) {
            var0.add(var4);
         }
      }

   }

   public static boolean a(a0 var0, List var1) {
      int var2 = var1.size();

      for(int var3 = 0; var3 < var2; ++var3) {
         if (!var0.a(var1.get(var3))) {
            return false;
         }
      }

      return true;
   }

   public static b.b.a b(a0 var0, b.b.a var1, Object var2, v.a var3) {
      if (!var1.isEmpty() && var2 != null) {
         d var4 = var3.d;
         b.b.a var7 = new b.b.a();
         var0.a((Map)var7, (View)var4.getView());
         b.d.a.a var5 = var3.f;
         ArrayList var6;
         if (var3.e) {
            var4.f();
            var6 = var5.r;
         } else {
            var4.g();
            var6 = var5.q;
         }

         b.b.e.a((Map)var7, (Collection)var6);
         b.b.e.a((Map)var1, (Collection)var7.keySet());
         return var7;
      } else {
         var1.clear();
         return null;
      }
   }

   public static Object b(a0 var0, d var1, boolean var2) {
      if (var1 == null) {
         return null;
      } else {
         Object var3;
         if (var2) {
            var3 = var1.getReturnTransition();
         } else {
            var3 = var1.getExitTransition();
         }

         return var0.b(var3);
      }
   }

   public static class a {
      public d a;
      public boolean b;
      public b.d.a.a c;
      public d d;
      public boolean e;
      public b.d.a.a f;
   }
}
