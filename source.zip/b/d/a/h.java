package b.d.a;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;

public abstract class h extends f {
   public final Activity a;
   public final Context b;
   public final Handler c;
   public final j d;

   public h(e var1) {
      Handler var2 = var1.b;
      super();
      this.d = new j();
      this.a = var1;
      b.c.b.b.a((Object)var1, (Object)"context == null");
      this.b = var1;
      b.c.b.b.a((Object)var2, (Object)"handler == null");
      this.c = var2;
   }
}
