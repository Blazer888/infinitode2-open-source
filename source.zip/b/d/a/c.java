package b.d.a;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

public class c extends b.d.a.d implements OnCancelListener, OnDismissListener {
   public int Y = 0;
   public int Z = 0;
   public boolean a0 = true;
   public boolean b0 = true;
   public int c0 = -1;
   public Dialog d0;
   public boolean e0;
   public boolean f0;
   public boolean g0;

   public Dialog g(Bundle var1) {
      throw null;
   }

   public void onActivityCreated(Bundle var1) {
      super.onActivityCreated(var1);
      if (this.b0) {
         View var2 = this.getView();
         if (var2 != null) {
            if (var2.getParent() != null) {
               throw new IllegalStateException("DialogFragment can not be attached to a container view");
            }

            this.d0.setContentView(var2);
         }

         b.d.a.e var3 = this.getActivity();
         if (var3 != null) {
            this.d0.setOwnerActivity(var3);
         }

         this.d0.setCancelable(this.a0);
         this.d0.setOnCancelListener(this);
         this.d0.setOnDismissListener(this);
         if (var1 != null) {
            var1 = var1.getBundle("android:savedDialogState");
            if (var1 != null) {
               this.d0.onRestoreInstanceState(var1);
            }
         }

      }
   }

   public void onAttach(Context var1) {
      super.onAttach(var1);
      if (!this.g0) {
         this.f0 = false;
      }

   }

   public void onCreate(Bundle var1) {
      super.onCreate(var1);
      boolean var2;
      if (super.y == 0) {
         var2 = true;
      } else {
         var2 = false;
      }

      this.b0 = var2;
      if (var1 != null) {
         this.Y = var1.getInt("android:style", 0);
         this.Z = var1.getInt("android:theme", 0);
         this.a0 = var1.getBoolean("android:cancelable", true);
         this.b0 = var1.getBoolean("android:showsDialog", this.b0);
         this.c0 = var1.getInt("android:backStackId", -1);
      }

   }

   public void onDestroyView() {
      super.onDestroyView();
      Dialog var1 = this.d0;
      if (var1 != null) {
         this.e0 = true;
         var1.dismiss();
         this.d0 = null;
      }

   }

   public void onDetach() {
      super.onDetach();
      if (!this.g0 && !this.f0) {
         this.f0 = true;
      }

   }

   public void onDismiss(DialogInterface var1) {
      if (!this.e0 && !this.f0) {
         this.f0 = true;
         this.g0 = false;
         Dialog var2 = this.d0;
         if (var2 != null) {
            var2.dismiss();
         }

         this.e0 = true;
         if (this.c0 >= 0) {
            this.getFragmentManager().a(this.c0, 1);
            this.c0 = -1;
         } else {
            q var3 = this.getFragmentManager().a();
            ((a)var3).a(new a.a(3, this));
            var3.b();
         }
      }

   }

   public LayoutInflater onGetLayoutInflater(Bundle var1) {
      if (!this.b0) {
         return super.onGetLayoutInflater(var1);
      } else {
         this.d0 = this.g(var1);
         Dialog var3 = this.d0;
         if (var3 == null) {
            return (LayoutInflater)super.s.b.getSystemService("layout_inflater");
         } else {
            int var2 = this.Y;
            if (var2 != 1 && var2 != 2) {
               if (var2 != 3) {
                  return (LayoutInflater)this.d0.getContext().getSystemService("layout_inflater");
               }

               var3.getWindow().addFlags(24);
            }

            var3.requestWindowFeature(1);
            return (LayoutInflater)this.d0.getContext().getSystemService("layout_inflater");
         }
      }
   }

   public void onSaveInstanceState(Bundle var1) {
      super.onSaveInstanceState(var1);
      Dialog var2 = this.d0;
      if (var2 != null) {
         Bundle var5 = var2.onSaveInstanceState();
         if (var5 != null) {
            var1.putBundle("android:savedDialogState", var5);
         }
      }

      int var3 = this.Y;
      if (var3 != 0) {
         var1.putInt("android:style", var3);
      }

      var3 = this.Z;
      if (var3 != 0) {
         var1.putInt("android:theme", var3);
      }

      boolean var4 = this.a0;
      if (!var4) {
         var1.putBoolean("android:cancelable", var4);
      }

      var4 = this.b0;
      if (!var4) {
         var1.putBoolean("android:showsDialog", var4);
      }

      var3 = this.c0;
      if (var3 != -1) {
         var1.putInt("android:backStackId", var3);
      }

   }

   public void onStart() {
      super.onStart();
      Dialog var1 = this.d0;
      if (var1 != null) {
         this.e0 = false;
         var1.show();
      }

   }

   public void onStop() {
      super.onStop();
      Dialog var1 = this.d0;
      if (var1 != null) {
         var1.hide();
      }

   }
}
