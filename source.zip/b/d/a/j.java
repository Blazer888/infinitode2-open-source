package b.d.a;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.content.res.Resources.NotFoundException;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.LayoutInflater.Factory2;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import android.view.animation.Animation.AnimationListener;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public final class j extends b.d.a.i implements Factory2 {
   public static Field E;
   public static final Interpolator F = new DecelerateInterpolator(2.5F);
   public static final Interpolator G = new DecelerateInterpolator(1.5F);
   public SparseArray A = null;
   public ArrayList B;
   public n C;
   public Runnable D = new Runnable() {
      public void run() {
         j.this.p();
      }
   };
   public ArrayList a;
   public boolean b;
   public int c = 0;
   public final ArrayList d = new ArrayList();
   public SparseArray e;
   public ArrayList f;
   public ArrayList g;
   public ArrayList h;
   public ArrayList i;
   public ArrayList j;
   public final CopyOnWriteArrayList k = new CopyOnWriteArrayList();
   public int l = 0;
   public b.d.a.h m;
   public b.d.a.f n;
   public b.d.a.d o;
   public b.d.a.d p;
   public boolean q;
   public boolean r;
   public boolean s;
   public boolean t;
   public String u;
   public boolean v;
   public ArrayList w;
   public ArrayList x;
   public ArrayList y;
   public Bundle z = null;

   static {
      new AccelerateInterpolator(2.5F);
      new AccelerateInterpolator(1.5F);
   }

   public static AnimationListener a(Animation var0) {
      AnimationListener var3;
      try {
         if (E == null) {
            E = Animation.class.getDeclaredField("mListener");
            E.setAccessible(true);
         }

         var3 = (AnimationListener)E.get(var0);
         return var3;
      } catch (NoSuchFieldException var1) {
         Log.e("FragmentManager", "No field with the name mListener is found in Animation class", var1);
      } catch (IllegalAccessException var2) {
         Log.e("FragmentManager", "Cannot access Animation's mListener field", var2);
      }

      var3 = null;
      return var3;
   }

   public static b.d.a.j.d a(float var0, float var1, float var2, float var3) {
      AnimationSet var4 = new AnimationSet(false);
      ScaleAnimation var5 = new ScaleAnimation(var0, var1, var0, var1, 1, 0.5F, 1, 0.5F);
      var5.setInterpolator(F);
      var5.setDuration(220L);
      var4.addAnimation(var5);
      AlphaAnimation var6 = new AlphaAnimation(var2, var3);
      var6.setInterpolator(G);
      var6.setDuration(220L);
      var4.addAnimation(var6);
      return new b.d.a.j.d(var4);
   }

   public static void a(View var0, b.d.a.j.d var1) {
      if (var0 != null && var1 != null) {
         boolean var6;
         label48: {
            int var2 = VERSION.SDK_INT;
            boolean var3 = true;
            if (var2 >= 19 && var0.getLayerType() == 0 && b.c.e.c.b(var0)) {
               boolean var5;
               label43: {
                  Animation var4 = var1.a;
                  if (!(var4 instanceof AlphaAnimation)) {
                     if (!(var4 instanceof AnimationSet)) {
                        var5 = a(var1.b);
                        break label43;
                     }

                     List var7 = ((AnimationSet)var4).getAnimations();
                     var2 = 0;

                     while(true) {
                        if (var2 >= var7.size()) {
                           var5 = false;
                           break label43;
                        }

                        if (var7.get(var2) instanceof AlphaAnimation) {
                           break;
                        }

                        ++var2;
                     }
                  }

                  var5 = true;
               }

               if (var5) {
                  var6 = var3;
                  break label48;
               }
            }

            var6 = false;
         }

         if (var6) {
            Animator var8 = var1.b;
            if (var8 != null) {
               var8.addListener(new b.d.a.j.e(var0));
            } else {
               AnimationListener var9 = a(var1.a);
               var0.setLayerType(2, (Paint)null);
               var1.a.setAnimationListener(new b.d.a.j.b(var0, var9));
            }
         }
      }

   }

   public static void a(n var0) {
      if (var0 != null) {
         List var1 = var0.a;
         if (var1 != null) {
            for(Iterator var4 = var1.iterator(); var4.hasNext(); ((b.d.a.d)var4.next()).D = true) {
            }
         }

         List var2 = var0.b;
         if (var2 != null) {
            Iterator var3 = var2.iterator();

            while(var3.hasNext()) {
               a((n)var3.next());
            }
         }

      }
   }

   public static boolean a(Animator var0) {
      if (var0 == null) {
         return false;
      } else {
         int var1;
         if (var0 instanceof ValueAnimator) {
            PropertyValuesHolder[] var2 = ((ValueAnimator)var0).getValues();

            for(var1 = 0; var1 < var2.length; ++var1) {
               if ("alpha".equals(var2[var1].getPropertyName())) {
                  return true;
               }
            }
         } else if (var0 instanceof AnimatorSet) {
            ArrayList var3 = ((AnimatorSet)var0).getChildAnimations();

            for(var1 = 0; var1 < var3.size(); ++var1) {
               if (a((Animator)var3.get(var1))) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   public static int d(int var0) {
      short var1 = 8194;
      if (var0 != 4097) {
         if (var0 != 4099) {
            if (var0 != 8194) {
               var1 = 0;
            } else {
               var1 = 4097;
            }
         } else {
            var1 = 4099;
         }
      }

      return var1;
   }

   public int a(b.d.a.a var1) {
      synchronized(this){}

      Throwable var10000;
      boolean var10001;
      label302: {
         int var2;
         label303: {
            label295:
            try {
               if (this.i != null && this.i.size() > 0) {
                  break label295;
               }
               break label303;
            } catch (Throwable var33) {
               var10000 = var33;
               var10001 = false;
               break label302;
            }

            try {
               var2 = (Integer)this.i.remove(this.i.size() - 1);
               this.h.set(var2, var1);
               return var2;
            } catch (Throwable var30) {
               var10000 = var30;
               var10001 = false;
               break label302;
            }
         }

         try {
            if (this.h == null) {
               ArrayList var3 = new ArrayList();
               this.h = var3;
            }
         } catch (Throwable var32) {
            var10000 = var32;
            var10001 = false;
            break label302;
         }

         label285:
         try {
            var2 = this.h.size();
            this.h.add(var1);
            return var2;
         } catch (Throwable var31) {
            var10000 = var31;
            var10001 = false;
            break label285;
         }
      }

      while(true) {
         Throwable var34 = var10000;

         try {
            throw var34;
         } catch (Throwable var29) {
            var10000 = var29;
            var10001 = false;
            continue;
         }
      }
   }

   public b.d.a.d a(String var1) {
      int var2;
      b.d.a.d var3;
      if (var1 != null) {
         for(var2 = this.d.size() - 1; var2 >= 0; --var2) {
            var3 = (b.d.a.d)this.d.get(var2);
            if (var3 != null && var1.equals(var3.z)) {
               return var3;
            }
         }
      }

      SparseArray var4 = this.e;
      if (var4 != null && var1 != null) {
         for(var2 = var4.size() - 1; var2 >= 0; --var2) {
            var3 = (b.d.a.d)this.e.valueAt(var2);
            if (var3 != null && var1.equals(var3.z)) {
               return var3;
            }
         }
      }

      return null;
   }

   public b.d.a.j.d a(b.d.a.d var1, int var2, boolean var3, int var4) {
      int var5 = var1.h();
      Animation var6 = var1.onCreateAnimation(var2, var3, var5);
      if (var6 != null) {
         return new b.d.a.j.d(var6);
      } else {
         Animator var16 = var1.onCreateAnimator(var2, var3, var5);
         if (var16 != null) {
            return new b.d.a.j.d(var16);
         } else {
            boolean var7 = false;
            if (var5 != 0) {
               boolean var8;
               boolean var9;
               Animation var17;
               boolean var10001;
               b.d.a.j.d var20;
               label123: {
                  var8 = "anim".equals(this.m.b.getResources().getResourceTypeName(var5));
                  if (var8) {
                     label120: {
                        NotFoundException var10000;
                        label140: {
                           try {
                              var17 = AnimationUtils.loadAnimation(this.m.b, var5);
                           } catch (NotFoundException var14) {
                              var10000 = var14;
                              var10001 = false;
                              break label140;
                           } catch (RuntimeException var15) {
                              var10001 = false;
                              break label120;
                           }

                           if (var17 == null) {
                              var9 = true;
                              break label123;
                           }

                           try {
                              var20 = new b.d.a.j.d(var17);
                              return var20;
                           } catch (NotFoundException var12) {
                              var10000 = var12;
                              var10001 = false;
                           } catch (RuntimeException var13) {
                              var10001 = false;
                              break label120;
                           }
                        }

                        NotFoundException var18 = var10000;
                        throw var18;
                     }
                  }

                  var9 = false;
               }

               if (!var9) {
                  label133: {
                     RuntimeException var27;
                     label134: {
                        try {
                           var16 = AnimatorInflater.loadAnimator(this.m.b, var5);
                        } catch (RuntimeException var11) {
                           var27 = var11;
                           var10001 = false;
                           break label134;
                        }

                        if (var16 == null) {
                           break label133;
                        }

                        try {
                           var20 = new b.d.a.j.d(var16);
                           return var20;
                        } catch (RuntimeException var10) {
                           var27 = var10;
                           var10001 = false;
                        }
                     }

                     RuntimeException var21 = var27;
                     if (var8) {
                        throw var21;
                     }

                     var17 = AnimationUtils.loadAnimation(this.m.b, var5);
                     if (var17 != null) {
                        return new b.d.a.j.d(var17);
                     }
                  }
               }
            }

            if (var2 == 0) {
               return null;
            } else {
               byte var19;
               if (var2 != 4097) {
                  if (var2 != 4099) {
                     if (var2 != 8194) {
                        var19 = -1;
                     } else if (var3) {
                        var19 = 3;
                     } else {
                        var19 = 4;
                     }
                  } else if (var3) {
                     var19 = 5;
                  } else {
                     var19 = 6;
                  }
               } else if (var3) {
                  var19 = 1;
               } else {
                  var19 = 2;
               }

               if (var19 < 0) {
                  return null;
               } else {
                  Context var22;
                  AlphaAnimation var23;
                  switch(var19) {
                  case 1:
                     var22 = this.m.b;
                     return a(1.125F, 1.0F, 0.0F, 1.0F);
                  case 2:
                     var22 = this.m.b;
                     return a(1.0F, 0.975F, 1.0F, 0.0F);
                  case 3:
                     var22 = this.m.b;
                     return a(0.975F, 1.0F, 0.0F, 1.0F);
                  case 4:
                     var22 = this.m.b;
                     return a(1.0F, 1.075F, 1.0F, 0.0F);
                  case 5:
                     var22 = this.m.b;
                     var23 = new AlphaAnimation(0.0F, 1.0F);
                     var23.setInterpolator(G);
                     var23.setDuration(220L);
                     return new b.d.a.j.d(var23);
                  case 6:
                     var22 = this.m.b;
                     var23 = new AlphaAnimation(1.0F, 0.0F);
                     var23.setInterpolator(G);
                     var23.setDuration(220L);
                     return new b.d.a.j.d(var23);
                  default:
                     if (var4 == 0) {
                        b.d.a.h var25 = this.m;
                        boolean var24 = var7;
                        if (((b.d.a.e.b)var25).e.getWindow() != null) {
                           var24 = true;
                        }

                        if (var24) {
                           Window var26 = ((b.d.a.e.b)this.m).e.getWindow();
                           if (var26 != null) {
                              var2 = var26.getAttributes().windowAnimations;
                           }
                        }
                     }

                     return null;
                  }
               }
            }
         }
      }
   }

   public q a() {
      return new b.d.a.a(this);
   }

   public final void a(int var1) {
      try {
         this.b = true;
         this.a(var1, false);
      } finally {
         this.b = false;
      }

      this.p();
   }

   public void a(int var1, int var2) {
      if (var1 >= 0) {
         this.a((b.d.a.j.i)(new b.d.a.j.j((String)null, var1, var2)), false);
      } else {
         throw new IllegalArgumentException(c.a.b.a.a.a("Bad id: ", var1));
      }
   }

   public void a(int var1, b.d.a.a var2) {
      synchronized(this){}

      Throwable var10000;
      boolean var10001;
      label634: {
         ArrayList var3;
         try {
            if (this.h == null) {
               var3 = new ArrayList();
               this.h = var3;
            }
         } catch (Throwable var77) {
            var10000 = var77;
            var10001 = false;
            break label634;
         }

         int var4;
         try {
            var4 = this.h.size();
         } catch (Throwable var76) {
            var10000 = var76;
            var10001 = false;
            break label634;
         }

         int var5 = var4;
         if (var1 < var4) {
            try {
               this.h.set(var1, var2);
            } catch (Throwable var74) {
               var10000 = var74;
               var10001 = false;
               break label634;
            }
         } else {
            while(true) {
               if (var5 >= var1) {
                  try {
                     this.h.add(var2);
                     break;
                  } catch (Throwable var72) {
                     var10000 = var72;
                     var10001 = false;
                     break label634;
                  }
               }

               try {
                  this.h.add((Object)null);
                  if (this.i == null) {
                     var3 = new ArrayList();
                     this.i = var3;
                  }
               } catch (Throwable var75) {
                  var10000 = var75;
                  var10001 = false;
                  break label634;
               }

               try {
                  this.i.add(var5);
               } catch (Throwable var73) {
                  var10000 = var73;
                  var10001 = false;
                  break label634;
               }

               ++var5;
            }
         }

         label603:
         try {
            return;
         } catch (Throwable var71) {
            var10000 = var71;
            var10001 = false;
            break label603;
         }
      }

      while(true) {
         Throwable var78 = var10000;

         try {
            throw var78;
         } catch (Throwable var70) {
            var10000 = var70;
            var10001 = false;
            continue;
         }
      }
   }

   public void a(int var1, boolean var2) {
      if (this.m == null && var1 != 0) {
         throw new IllegalStateException("No activity");
      } else if (var2 || var1 != this.l) {
         this.l = var1;
         if (this.e != null) {
            int var3 = this.d.size();

            for(var1 = 0; var1 < var3; ++var1) {
               this.e((b.d.a.d)this.d.get(var1));
            }

            var3 = this.e.size();

            for(var1 = 0; var1 < var3; ++var1) {
               b.d.a.d var4 = (b.d.a.d)this.e.valueAt(var1);
               if (var4 != null && (var4.l || var4.B) && !var4.N) {
                  this.e(var4);
               }
            }

            this.v();
            if (this.q) {
               b.d.a.h var5 = this.m;
               if (var5 != null && this.l == 4) {
                  ((b.d.a.e.b)var5).e.f();
                  this.q = false;
               }
            }
         }

      }
   }

   public void a(Configuration var1) {
      for(int var2 = 0; var2 < this.d.size(); ++var2) {
         b.d.a.d var3 = (b.d.a.d)this.d.get(var2);
         if (var3 != null) {
            var3.a(var1);
         }
      }

   }

   public void a(Parcelable param1, n param2) {
      // $FF: Couldn't be decompiled
   }

   public void a(Menu var1) {
      if (this.l >= 1) {
         for(int var2 = 0; var2 < this.d.size(); ++var2) {
            b.d.a.d var3 = (b.d.a.d)this.d.get(var2);
            if (var3 != null) {
               var3.a(var1);
            }
         }

      }
   }

   public final void a(b.b.c var1) {
      int var2 = this.l;
      if (var2 >= 1) {
         int var3 = Math.min(var2, 3);
         int var4 = this.d.size();

         for(var2 = 0; var2 < var4; ++var2) {
            b.d.a.d var5 = (b.d.a.d)this.d.get(var2);
            if (var5.a < var3) {
               this.a(var5, var3, var5.h(), var5.i(), false);
               if (var5.I != null && !var5.A && var5.N) {
                  var1.add(var5);
               }
            }
         }

      }
   }

   public void a(b.d.a.a var1, boolean var2, boolean var3, boolean var4) {
      if (var2) {
         var1.b(var4);
      } else {
         var1.c();
      }

      ArrayList var5 = new ArrayList(1);
      ArrayList var6 = new ArrayList(1);
      var5.add(var1);
      var6.add(var2);
      if (var3) {
         b.d.a.v.a(this, var5, var6, 0, 1, true);
      }

      if (var4) {
         this.a(this.l, true);
      }

      SparseArray var10 = this.e;
      if (var10 != null) {
         int var7 = var10.size();

         for(int var8 = 0; var8 < var7; ++var8) {
            b.d.a.d var11 = (b.d.a.d)this.e.valueAt(var8);
            if (var11 != null && var11.I != null && var11.N && var1.b(var11.y)) {
               float var9 = var11.P;
               if (var9 > 0.0F) {
                  var11.I.setAlpha(var9);
               }

               if (var4) {
                  var11.P = 0.0F;
               } else {
                  var11.P = -1.0F;
                  var11.N = false;
               }
            }
         }
      }

   }

   public void a(b.d.a.d param1) {
      // $FF: Couldn't be decompiled
   }

   public void a(b.d.a.d var1, int var2, int var3, int var4, boolean var5) {
      boolean var6 = var1.k;
      byte var7 = 1;
      boolean var8 = true;
      int var9;
      if (!var6 || var1.B) {
         var9 = var2;
         var2 = var2;
         if (var9 > 1) {
            var2 = 1;
         }
      }

      var9 = var2;
      int var10;
      if (var1.l) {
         var10 = var1.a;
         var9 = var2;
         if (var2 > var10) {
            if (var10 == 0 && var1.o()) {
               var9 = 1;
            } else {
               var9 = var1.a;
            }
         }
      }

      if (var1.K && var1.a < 3 && var9 > 2) {
         var2 = 2;
      } else {
         var2 = var9;
      }

      StringBuilder var32;
      label325: {
         var10 = var1.a;
         ViewGroup var11;
         View var12;
         View var18;
         ViewGroup var19;
         if (var10 <= var2) {
            label328: {
               if (var1.m && !var1.n) {
                  return;
               }

               if (var1.d() != null || var1.e() != null) {
                  var1.a((View)null);
                  var1.a((Animator)null);
                  this.a(var1, var1.k(), 0, 0, true);
               }

               label246: {
                  label312: {
                     var9 = var1.a;
                     if (var9 != 0) {
                        var3 = var2;
                        if (var9 != 1) {
                           var4 = var2;
                           if (var9 != 2) {
                              var3 = var2;
                              if (var9 != 3) {
                                 var9 = var2;
                                 break label328;
                              }
                              break label246;
                           }
                           break label312;
                        }
                     } else {
                        var3 = var2;
                        if (var2 > 0) {
                           Bundle var22 = var1.b;
                           var3 = var2;
                           b.d.a.d var24;
                           if (var22 != null) {
                              var22.setClassLoader(this.m.b.getClassLoader());
                              var1.c = var1.b.getSparseParcelableArray("android:view_state");
                              var3 = var1.b.getInt("android:target_state", -1);
                              if (var3 == -1) {
                                 var24 = null;
                              } else {
                                 var24 = (b.d.a.d)this.e.get(var3);
                                 if (var24 == null) {
                                    StringBuilder var16 = new StringBuilder();
                                    var16.append("Fragment no longer exists for key ");
                                    var16.append("android:target_state");
                                    var16.append(": index ");
                                    var16.append(var3);
                                    this.a((RuntimeException)(new IllegalStateException(var16.toString())));
                                    throw null;
                                 }
                              }

                              var1.h = var24;
                              if (var1.h != null) {
                                 var1.j = var1.b.getInt("android:target_req_state", 0);
                              }

                              Boolean var26 = var1.d;
                              if (var26 != null) {
                                 var1.L = var26;
                                 var1.d = null;
                              } else {
                                 var1.L = var1.b.getBoolean("android:user_visible_hint", true);
                              }

                              var3 = var2;
                              if (!var1.L) {
                                 var1.K = true;
                                 var3 = var2;
                                 if (var2 > 2) {
                                    var3 = 2;
                                 }
                              }
                           }

                           b.d.a.h var28 = this.m;
                           var1.s = var28;
                           b.d.a.d var20 = this.o;
                           var1.w = var20;
                           b.d.a.j var30;
                           if (var20 != null) {
                              var30 = var20.t;
                           } else {
                              var30 = var28.d;
                           }

                           var1.r = var30;
                           var24 = var1.h;
                           if (var24 != null) {
                              Object var23 = this.e.get(var24.e);
                              var24 = var1.h;
                              if (var23 != var24) {
                                 var32 = new StringBuilder();
                                 var32.append("Fragment ");
                                 var32.append(var1);
                                 var32.append(" declared target fragment ");
                                 var32.append(var1.h);
                                 var32.append(" that does not belong to this FragmentManager!");
                                 throw new IllegalStateException(var32.toString());
                              }

                              if (var24.a < 1) {
                                 this.a(var24, 1, 0, 0, true);
                              }
                           }

                           this.b(var1, this.m.b, false);
                           var1.G = false;
                           var1.onAttach(this.m.b);
                           if (!var1.G) {
                              throw new c0(c.a.b.a.a.a("Fragment ", var1, " did not call through to super.onAttach()"));
                           }

                           var24 = var1.w;
                           if (var24 == null) {
                              ((b.d.a.e.b)this.m).e.c();
                           } else {
                              var24.onAttachFragment(var1);
                           }

                           this.a(var1, this.m.b, false);
                           if (!var1.R) {
                              this.c(var1, var1.b, false);
                              var1.b(var1.b);
                              this.b(var1, var1.b, false);
                           } else {
                              var1.e(var1.b);
                              var1.a = 1;
                           }

                           var1.D = false;
                        }
                     }

                     if (var1.m && !var1.p) {
                        var1.a(var1.c(var1.b), (ViewGroup)null, var1.b);
                        var18 = var1.I;
                        if (var18 != null) {
                           var1.J = var18;
                           var18.setSaveFromParentEnabled(false);
                           if (var1.A) {
                              var1.I.setVisibility(8);
                           }

                           var1.onViewCreated(var1.I, var1.b);
                           this.a(var1, var1.I, var1.b, false);
                        } else {
                           var1.J = null;
                        }
                     }

                     var4 = var3;
                     if (var3 > 1) {
                        if (!var1.m) {
                           var2 = var1.y;
                           if (var2 != 0) {
                              if (var2 == -1) {
                                 this.a((RuntimeException)(new IllegalArgumentException(c.a.b.a.a.a("Cannot create fragment ", var1, " for a container view with no id"))));
                                 throw null;
                              }

                              var19 = (ViewGroup)this.n.a(var2);
                              var11 = var19;
                              if (var19 == null) {
                                 if (!var1.o) {
                                    String var31;
                                    try {
                                       var31 = var1.getResources().getResourceName(var1.y);
                                    } catch (NotFoundException var15) {
                                       var31 = "unknown";
                                    }

                                    StringBuilder var25 = c.a.b.a.a.b("No view found for id 0x");
                                    var25.append(Integer.toHexString(var1.y));
                                    var25.append(" (");
                                    var25.append(var31);
                                    var25.append(") for fragment ");
                                    var25.append(var1);
                                    this.a((RuntimeException)(new IllegalArgumentException(var25.toString())));
                                    throw null;
                                 }

                                 var11 = var19;
                              }
                           } else {
                              var11 = null;
                           }

                           var1.H = var11;
                           var1.a(var1.c(var1.b), var11, var1.b);
                           var12 = var1.I;
                           if (var12 == null) {
                              var1.J = null;
                           } else {
                              var1.J = var12;
                              var12.setSaveFromParentEnabled(false);
                              if (var11 != null) {
                                 var11.addView(var1.I);
                              }

                              if (var1.A) {
                                 var1.I.setVisibility(8);
                              }

                              var1.onViewCreated(var1.I, var1.b);
                              this.a(var1, var1.I, var1.b, false);
                              if (var1.I.getVisibility() == 0 && var1.H != null) {
                                 var5 = var8;
                              } else {
                                 var5 = false;
                              }

                              var1.N = var5;
                           }
                        }

                        var1.a(var1.b);
                        this.a(var1, var1.b, false);
                        if (var1.I != null) {
                           var1.f(var1.b);
                        }

                        var1.b = null;
                        var4 = var3;
                     }
                  }

                  var3 = var4;
                  if (var4 > 2) {
                     var1.y();
                     this.f(var1, false);
                     var3 = var4;
                  }
               }

               var9 = var3;
               if (var3 > 3) {
                  var1.x();
                  this.e(var1, false);
                  var1.b = null;
                  var1.c = null;
                  var9 = var3;
               }
            }
         } else {
            var9 = var2;
            if (var10 > var2) {
               label323: {
                  if (var10 != 1) {
                     if (var10 != 2) {
                        if (var10 != 3) {
                           if (var10 != 4) {
                              var9 = var2;
                              break label323;
                           }

                           if (var2 < 4) {
                              var1.w();
                              this.d(var1, false);
                           }
                        }

                        if (var2 < 3) {
                           var1.z();
                           this.g(var1, false);
                        }
                     }

                     if (var2 < 2) {
                        if (var1.I != null && ((b.d.a.e.b)this.m).e.isFinishing() ^ true && var1.c == null) {
                           this.h(var1);
                        }

                        var1.t();
                        this.h(var1, false);
                        var12 = var1.I;
                        if (var12 != null) {
                           var11 = var1.H;
                           if (var11 != null) {
                              var11.endViewTransition(var12);
                              var1.I.clearAnimation();
                              b.d.a.j.d var17;
                              if (this.l > 0 && !this.t && var1.I.getVisibility() == 0 && var1.P >= 0.0F) {
                                 var17 = this.a(var1, var3, false, var4);
                              } else {
                                 var17 = null;
                              }

                              var1.P = 0.0F;
                              if (var17 != null) {
                                 View var13 = var1.I;
                                 var19 = var1.H;
                                 var19.startViewTransition(var13);
                                 var1.b(var2);
                                 Animation var14 = var17.a;
                                 if (var14 != null) {
                                    b.d.a.j.f var27 = new b.d.a.j.f(var14, var19, var13);
                                    var1.a(var1.I);
                                    var27.setAnimationListener(new b.d.a.k(this, a((Animation)var27), var19, var1));
                                    a(var13, var17);
                                    var1.I.startAnimation(var27);
                                 } else {
                                    Animator var29 = var17.b;
                                    var1.a(var29);
                                    var29.addListener(new l(this, var19, var13, var1));
                                    var29.setTarget(var1.I);
                                    a(var1.I, var17);
                                    var29.start();
                                 }
                              }

                              var1.H.removeView(var1.I);
                           }
                        }

                        var1.H = null;
                        var1.I = null;
                        var1.U = null;
                        var1.V.b((Object)null);
                        var1.J = null;
                        var1.n = false;
                     }
                  }

                  var9 = var2;
                  if (var2 < 1) {
                     if (this.t) {
                        if (var1.d() != null) {
                           var18 = var1.d();
                           var1.a((View)null);
                           var18.clearAnimation();
                        } else if (var1.e() != null) {
                           Animator var21 = var1.e();
                           var1.a((Animator)null);
                           var21.cancel();
                        }
                     }

                     if (var1.d() != null || var1.e() != null) {
                        var1.b(var2);
                        var2 = var7;
                        break label325;
                     }

                     if (!var1.D) {
                        var1.s();
                        this.b(var1, false);
                     } else {
                        var1.a = 0;
                     }

                     var1.u();
                     this.c(var1, false);
                     var9 = var2;
                     if (!var5) {
                        if (!var1.D) {
                           var3 = var1.e;
                           if (var3 < 0) {
                              var9 = var2;
                           } else {
                              this.e.put(var3, (Object)null);
                              var1.l();
                              var9 = var2;
                           }
                        } else {
                           var1.s = null;
                           var1.w = null;
                           var1.r = null;
                           var9 = var2;
                        }
                     }
                  }
               }
            }
         }

         var2 = var9;
      }

      if (var1.a != var2) {
         var32 = new StringBuilder();
         var32.append("moveToState: Fragment state for ");
         var32.append(var1);
         var32.append(" not updated inline; ");
         var32.append("expected state ");
         var32.append(var2);
         var32.append(" found ");
         var32.append(var1.a);
         Log.w("FragmentManager", var32.toString());
         var1.a = var2;
      }

   }

   public void a(b.d.a.d var1, Context var2, boolean var3) {
      b.d.a.d var4 = this.o;
      if (var4 != null) {
         b.d.a.i var8 = var4.getFragmentManager();
         if (var8 instanceof b.d.a.j) {
            ((b.d.a.j)var8).a(var1, var2, true);
         }
      }

      Iterator var5 = this.k.iterator();

      b.d.a.j.g var7;
      do {
         if (!var5.hasNext()) {
            return;
         }

         var7 = (b.d.a.j.g)var5.next();
      } while(var3 && !var7.b);

      b.d.a.i.b var6 = var7.a;
      throw null;
   }

   public void a(b.d.a.d var1, Bundle var2, boolean var3) {
      b.d.a.d var4 = this.o;
      if (var4 != null) {
         b.d.a.i var8 = var4.getFragmentManager();
         if (var8 instanceof b.d.a.j) {
            ((b.d.a.j)var8).a(var1, var2, true);
         }
      }

      Iterator var7 = this.k.iterator();

      b.d.a.j.g var5;
      do {
         if (!var7.hasNext()) {
            return;
         }

         var5 = (b.d.a.j.g)var7.next();
      } while(var3 && !var5.b);

      b.d.a.i.b var6 = var5.a;
      throw null;
   }

   public void a(b.d.a.d var1, View var2, Bundle var3, boolean var4) {
      b.d.a.d var5 = this.o;
      if (var5 != null) {
         b.d.a.i var9 = var5.getFragmentManager();
         if (var9 instanceof b.d.a.j) {
            ((b.d.a.j)var9).a(var1, var2, var3, true);
         }
      }

      Iterator var6 = this.k.iterator();

      b.d.a.j.g var8;
      do {
         if (!var6.hasNext()) {
            return;
         }

         var8 = (b.d.a.j.g)var6.next();
      } while(var4 && !var8.b);

      b.d.a.i.b var7 = var8.a;
      throw null;
   }

   public void a(b.d.a.d param1, boolean param2) {
      // $FF: Couldn't be decompiled
   }

   public void a(b.d.a.j.i var1, boolean var2) {
      if (!var2) {
         this.f();
      }

      synchronized(this){}

      Throwable var10000;
      boolean var10001;
      label407: {
         label400: {
            try {
               if (!this.t && this.m != null) {
                  break label400;
               }
            } catch (Throwable var45) {
               var10000 = var45;
               var10001 = false;
               break label407;
            }

            if (var2) {
               try {
                  return;
               } catch (Throwable var43) {
                  var10000 = var43;
                  var10001 = false;
                  break label407;
               }
            } else {
               try {
                  IllegalStateException var46 = new IllegalStateException("Activity has been destroyed");
                  throw var46;
               } catch (Throwable var44) {
                  var10000 = var44;
                  var10001 = false;
                  break label407;
               }
            }
         }

         try {
            if (this.a == null) {
               ArrayList var3 = new ArrayList();
               this.a = var3;
            }
         } catch (Throwable var42) {
            var10000 = var42;
            var10001 = false;
            break label407;
         }

         label384:
         try {
            this.a.add(var1);
            this.u();
            return;
         } catch (Throwable var41) {
            var10000 = var41;
            var10001 = false;
            break label384;
         }
      }

      while(true) {
         Throwable var47 = var10000;

         try {
            throw var47;
         } catch (Throwable var40) {
            var10000 = var40;
            var10001 = false;
            continue;
         }
      }
   }

   public final void a(RuntimeException var1) {
      Log.e("FragmentManager", var1.getMessage());
      Log.e("FragmentManager", "Activity state:");
      PrintWriter var2 = new PrintWriter(new b.c.d.a("FragmentManager"));
      b.d.a.h var3 = this.m;
      if (var3 != null) {
         try {
            ((b.d.a.e.b)var3).e.dump("  ", (FileDescriptor)null, var2, new String[0]);
         } catch (Exception var5) {
            Log.e("FragmentManager", "Failed dumping state", var5);
         }
      } else {
         try {
            this.a("  ", (FileDescriptor)null, var2, new String[0]);
         } catch (Exception var4) {
            Log.e("FragmentManager", "Failed dumping state", var4);
         }
      }

      throw var1;
   }

   public void a(String var1, FileDescriptor var2, PrintWriter var3, String[] var4) {
      String var5 = c.a.b.a.a.a(var1, "    ");
      SparseArray var6 = this.e;
      byte var7 = 0;
      int var8;
      int var9;
      if (var6 != null) {
         var8 = var6.size();
         if (var8 > 0) {
            var3.print(var1);
            var3.print("Active Fragments in ");
            var3.print(Integer.toHexString(System.identityHashCode(this)));
            var3.println(":");

            for(var9 = 0; var9 < var8; ++var9) {
               b.d.a.d var57 = (b.d.a.d)this.e.valueAt(var9);
               var3.print(var1);
               var3.print("  #");
               var3.print(var9);
               var3.print(": ");
               var3.println(var57);
               if (var57 != null) {
                  var57.dump(var5, var2, var3, var4);
               }
            }
         }
      }

      var8 = this.d.size();
      b.d.a.d var53;
      if (var8 > 0) {
         var3.print(var1);
         var3.println("Added Fragments:");

         for(var9 = 0; var9 < var8; ++var9) {
            var53 = (b.d.a.d)this.d.get(var9);
            var3.print(var1);
            var3.print("  #");
            var3.print(var9);
            var3.print(": ");
            var3.println(var53.toString());
         }
      }

      ArrayList var54 = this.g;
      if (var54 != null) {
         var8 = var54.size();
         if (var8 > 0) {
            var3.print(var1);
            var3.println("Fragments Created Menus:");

            for(var9 = 0; var9 < var8; ++var9) {
               var53 = (b.d.a.d)this.g.get(var9);
               var3.print(var1);
               var3.print("  #");
               var3.print(var9);
               var3.print(": ");
               var3.println(var53.toString());
            }
         }
      }

      var54 = this.f;
      b.d.a.a var55;
      if (var54 != null) {
         var8 = var54.size();
         if (var8 > 0) {
            var3.print(var1);
            var3.println("Back Stack:");

            for(var9 = 0; var9 < var8; ++var9) {
               var55 = (b.d.a.a)this.f.get(var9);
               var3.print(var1);
               var3.print("  #");
               var3.print(var9);
               var3.print(": ");
               var3.println(var55.toString());
               var55.a(var5, var3, true);
            }
         }
      }

      synchronized(this){}

      label1028: {
         Throwable var10000;
         boolean var10001;
         label1029: {
            label1030: {
               try {
                  if (this.h == null) {
                     break label1030;
                  }

                  var8 = this.h.size();
               } catch (Throwable var51) {
                  var10000 = var51;
                  var10001 = false;
                  break label1029;
               }

               if (var8 > 0) {
                  try {
                     var3.print(var1);
                     var3.println("Back Stack Indices:");
                  } catch (Throwable var50) {
                     var10000 = var50;
                     var10001 = false;
                     break label1029;
                  }

                  for(var9 = 0; var9 < var8; ++var9) {
                     try {
                        var55 = (b.d.a.a)this.h.get(var9);
                        var3.print(var1);
                        var3.print("  #");
                        var3.print(var9);
                        var3.print(": ");
                        var3.println(var55);
                     } catch (Throwable var49) {
                        var10000 = var49;
                        var10001 = false;
                        break label1029;
                     }
                  }
               }
            }

            try {
               if (this.i != null && this.i.size() > 0) {
                  var3.print(var1);
                  var3.print("mAvailBackStackIndices: ");
                  var3.println(Arrays.toString(this.i.toArray()));
               }
            } catch (Throwable var48) {
               var10000 = var48;
               var10001 = false;
               break label1029;
            }

            label971:
            try {
               break label1028;
            } catch (Throwable var47) {
               var10000 = var47;
               var10001 = false;
               break label971;
            }
         }

         while(true) {
            Throwable var52 = var10000;

            try {
               throw var52;
            } catch (Throwable var46) {
               var10000 = var46;
               var10001 = false;
               continue;
            }
         }
      }

      var54 = this.a;
      if (var54 != null) {
         var8 = var54.size();
         if (var8 > 0) {
            var3.print(var1);
            var3.println("Pending Actions:");

            for(var9 = var7; var9 < var8; ++var9) {
               b.d.a.j.i var56 = (b.d.a.j.i)this.a.get(var9);
               var3.print(var1);
               var3.print("  #");
               var3.print(var9);
               var3.print(": ");
               var3.println(var56);
            }
         }
      }

      var3.print(var1);
      var3.println("FragmentManager misc state:");
      var3.print(var1);
      var3.print("  mHost=");
      var3.println(this.m);
      var3.print(var1);
      var3.print("  mContainer=");
      var3.println(this.n);
      if (this.o != null) {
         var3.print(var1);
         var3.print("  mParent=");
         var3.println(this.o);
      }

      var3.print(var1);
      var3.print("  mCurState=");
      var3.print(this.l);
      var3.print(" mStateSaved=");
      var3.print(this.r);
      var3.print(" mStopped=");
      var3.print(this.s);
      var3.print(" mDestroyed=");
      var3.println(this.t);
      if (this.q) {
         var3.print(var1);
         var3.print("  mNeedMenuInvalidate=");
         var3.println(this.q);
      }

      if (this.u != null) {
         var3.print(var1);
         var3.print("  mNoTransactionsBecause=");
         var3.println(this.u);
      }

   }

   public final void a(ArrayList var1, ArrayList var2) {
      ArrayList var3 = this.B;
      int var4;
      if (var3 == null) {
         var4 = 0;
      } else {
         var4 = var3.size();
      }

      byte var5 = 0;
      int var6 = var4;

      int var10;
      for(var4 = var5; var4 < var6; var6 = var10) {
         int var8;
         label55: {
            b.d.a.j.k var9 = (b.d.a.j.k)this.B.get(var4);
            b.d.a.a var7;
            if (var1 != null && !var9.a) {
               var10 = var1.indexOf(var9.b);
               if (var10 != -1 && (Boolean)var2.get(var10)) {
                  var7 = var9.b;
                  var7.a.a(var7, var9.a, false, false);
                  var8 = var4;
                  var10 = var6;
                  break label55;
               }
            }

            boolean var11;
            if (var9.c == 0) {
               var11 = true;
            } else {
               var11 = false;
            }

            if (!var11) {
               var8 = var4;
               var10 = var6;
               if (var1 == null) {
                  break label55;
               }

               var8 = var4;
               var10 = var6;
               if (!var9.b.a(var1, 0, var1.size())) {
                  break label55;
               }
            }

            this.B.remove(var4);
            var8 = var4 - 1;
            var10 = var6 - 1;
            if (var1 != null && !var9.a) {
               var4 = var1.indexOf(var9.b);
               if (var4 != -1 && (Boolean)var2.get(var4)) {
                  var7 = var9.b;
                  var7.a.a(var7, var9.a, false, false);
                  break label55;
               }
            }

            var9.a();
         }

         var4 = var8 + 1;
      }

   }

   public final void a(ArrayList var1, ArrayList var2, int var3, int var4) {
      boolean var5 = ((b.d.a.a)var1.get(var3)).s;
      ArrayList var6 = this.y;
      if (var6 == null) {
         this.y = new ArrayList();
      } else {
         var6.clear();
      }

      this.y.addAll(this.d);
      b.d.a.d var20 = this.p;
      int var7 = var3;

      boolean var8;
      int var11;
      int var13;
      boolean var29;
      for(var8 = false; var7 < var4; var8 = var29) {
         b.d.a.a var9 = (b.d.a.a)var1.get(var7);
         if (!(Boolean)var2.get(var7)) {
            ArrayList var26 = this.y;

            for(var11 = 0; var11 < var9.b.size(); ++var11) {
               b.d.a.a.a var12 = (b.d.a.a.a)var9.b.get(var11);
               var13 = var12.a;
               if (var13 != 1) {
                  label308: {
                     b.d.a.d var30;
                     if (var13 == 2) {
                        var30 = var12.b;
                        var13 = var30.y;
                        int var15 = var26.size();
                        --var15;

                        boolean var16;
                        for(var16 = false; var15 >= 0; --var15) {
                           b.d.a.d var17 = (b.d.a.d)var26.get(var15);
                           if (var17.y == var13) {
                              if (var17 == var30) {
                                 var16 = true;
                              } else {
                                 if (var17 == var20) {
                                    var9.b.add(var11, new b.d.a.a.a(9, var17));
                                    ++var11;
                                    var20 = null;
                                 }

                                 b.d.a.a.a var18 = new b.d.a.a.a(3, var17);
                                 var18.c = var12.c;
                                 var18.e = var12.e;
                                 var18.d = var12.d;
                                 var18.f = var12.f;
                                 var9.b.add(var11, var18);
                                 var26.remove(var17);
                                 ++var11;
                              }
                           }
                        }

                        if (var16) {
                           var9.b.remove(var11);
                           --var11;
                        } else {
                           var12.a = 1;
                           var26.add(var30);
                        }
                        continue;
                     }

                     if (var13 != 3 && var13 != 6) {
                        if (var13 == 7) {
                           break label308;
                        }

                        if (var13 != 8) {
                           var13 = var11;
                           var30 = var20;
                        } else {
                           var9.b.add(var11, new b.d.a.a.a(9, var20));
                           var13 = var11 + 1;
                           var30 = var12.b;
                        }
                     } else {
                        var26.remove(var12.b);
                        b.d.a.d var28 = var12.b;
                        var13 = var11;
                        var30 = var20;
                        if (var28 == var20) {
                           var9.b.add(var11, new b.d.a.a.a(9, var28));
                           var13 = var11 + 1;
                           var30 = null;
                        }
                     }

                     var11 = var13;
                     var20 = var30;
                     continue;
                  }
               }

               var26.add(var12.b);
            }
         } else {
            ArrayList var14 = this.y;

            for(var11 = 0; var11 < var9.b.size(); ++var11) {
               b.d.a.a.a var10;
               label268: {
                  var10 = (b.d.a.a.a)var9.b.get(var11);
                  var13 = var10.a;
                  if (var13 != 1) {
                     if (var13 == 3) {
                        break label268;
                     }

                     switch(var13) {
                     case 6:
                        break label268;
                     case 7:
                        break;
                     case 8:
                        var20 = null;
                        continue;
                     case 9:
                        var20 = var10.b;
                     default:
                        continue;
                     }
                  }

                  var14.remove(var10.b);
                  continue;
               }

               var14.add(var10.b);
            }
         }

         if (!var8 && !var9.i) {
            var29 = false;
         } else {
            var29 = true;
         }

         ++var7;
      }

      this.y.clear();
      if (!var5) {
         b.d.a.v.a(this, var1, var2, var3, var4, false);
      }

      boolean var19;
      for(var11 = var3; var11 < var4; ++var11) {
         b.d.a.a var21 = (b.d.a.a)var1.get(var11);
         if ((Boolean)var2.get(var11)) {
            var21.a(-1);
            if (var11 == var4 - 1) {
               var19 = true;
            } else {
               var19 = false;
            }

            var21.b(var19);
         } else {
            var21.a(1);
            var21.c();
         }
      }

      if (var5) {
         b.b.c var22 = new b.b.c();
         this.a(var22);
         var13 = var4 - 1;

         for(var11 = var4; var13 >= var3; --var13) {
            b.d.a.a var27 = (b.d.a.a)var1.get(var13);
            var19 = (Boolean)var2.get(var13);
            var7 = 0;

            boolean var23;
            while(true) {
               if (var7 >= var27.b.size()) {
                  var23 = false;
                  break;
               }

               if (b.d.a.a.b((b.d.a.a.a)var27.b.get(var7))) {
                  var23 = true;
                  break;
               }

               ++var7;
            }

            if (var23 && !var27.a(var1, var13 + 1, var4)) {
               var23 = true;
            } else {
               var23 = false;
            }

            if (var23) {
               if (this.B == null) {
                  this.B = new ArrayList();
               }

               b.d.a.j.k var24 = new b.d.a.j.k(var27, var19);
               this.B.add(var24);

               for(var7 = 0; var7 < var27.b.size(); ++var7) {
                  b.d.a.a.a var32 = (b.d.a.a.a)var27.b.get(var7);
                  if (b.d.a.a.b(var32)) {
                     var32.b.a((b.d.a.d.f)var24);
                  }
               }

               if (var19) {
                  var27.c();
               } else {
                  var27.b(false);
               }

               --var11;
               if (var13 != var11) {
                  var1.remove(var13);
                  var1.add(var11, var27);
               }

               this.a(var22);
            }
         }

         var7 = var22.c;

         for(var13 = 0; var13 < var7; ++var13) {
            b.d.a.d var25 = (b.d.a.d)var22.b[var13];
            if (!var25.k) {
               View var33 = var25.getView();
               var25.P = var33.getAlpha();
               var33.setAlpha(0.0F);
            }
         }

         var13 = var11;
      } else {
         var13 = var4;
      }

      byte var31 = 0;
      var11 = var3;
      if (var13 != var3) {
         var11 = var3;
         if (var5) {
            b.d.a.v.a(this, var1, var2, var3, var13, true);
            this.a(this.l, true);
            var11 = var3;
         }
      }

      for(; var11 < var4; ++var11) {
         b.d.a.a var34 = (b.d.a.a)var1.get(var11);
         if ((Boolean)var2.get(var11)) {
            var3 = var34.l;
            if (var3 >= 0) {
               this.c(var3);
               var34.l = -1;
            }
         }

         var6 = var34.t;
         if (var6 != null) {
            var13 = var6.size();

            for(var3 = 0; var3 < var13; ++var3) {
               ((Runnable)var34.t.get(var3)).run();
            }

            var34.t = null;
         }
      }

      if (var8 && this.j != null) {
         for(var3 = var31; var3 < this.j.size(); ++var3) {
            ((b.d.a.i.c)this.j.get(var3)).a();
         }
      }

   }

   public void a(boolean var1) {
      for(int var2 = this.d.size() - 1; var2 >= 0; --var2) {
         b.d.a.d var3 = (b.d.a.d)this.d.get(var2);
         if (var3 != null) {
            var3.a(var1);
         }
      }

   }

   public boolean a(Menu var1, MenuInflater var2) {
      int var3 = this.l;
      byte var4 = 0;
      if (var3 < 1) {
         return false;
      } else {
         ArrayList var5 = null;
         var3 = 0;

         boolean var6;
         boolean var9;
         for(var6 = false; var3 < this.d.size(); var6 = var9) {
            b.d.a.d var7 = (b.d.a.d)this.d.get(var3);
            ArrayList var8 = var5;
            var9 = var6;
            if (var7 != null) {
               var8 = var5;
               var9 = var6;
               if (var7.a(var1, var2)) {
                  var8 = var5;
                  if (var5 == null) {
                     var8 = new ArrayList();
                  }

                  var8.add(var7);
                  var9 = true;
               }
            }

            ++var3;
            var5 = var8;
         }

         if (this.g != null) {
            for(var3 = var4; var3 < this.g.size(); ++var3) {
               b.d.a.d var10 = (b.d.a.d)this.g.get(var3);
               if (var5 == null || !var5.contains(var10)) {
                  var10.onDestroyOptionsMenu();
               }
            }
         }

         this.g = var5;
         return var6;
      }
   }

   public boolean a(MenuItem var1) {
      if (this.l < 1) {
         return false;
      } else {
         for(int var2 = 0; var2 < this.d.size(); ++var2) {
            b.d.a.d var3 = (b.d.a.d)this.d.get(var2);
            if (var3 != null && var3.a(var1)) {
               return true;
            }
         }

         return false;
      }
   }

   public boolean a(ArrayList var1, ArrayList var2, String var3, int var4, int var5) {
      ArrayList var6 = this.f;
      if (var6 == null) {
         return false;
      } else {
         if (var3 == null && var4 < 0 && (var5 & 1) == 0) {
            var4 = var6.size() - 1;
            if (var4 < 0) {
               return false;
            }

            var1.add(this.f.remove(var4));
            var2.add(true);
         } else {
            int var7;
            if (var3 == null && var4 < 0) {
               var7 = -1;
            } else {
               int var8;
               b.d.a.a var9;
               for(var8 = this.f.size() - 1; var8 >= 0; --var8) {
                  var9 = (b.d.a.a)this.f.get(var8);
                  if (var3 != null && var3.equals(var9.j) || var4 >= 0 && var4 == var9.l) {
                     break;
                  }
               }

               if (var8 < 0) {
                  return false;
               }

               var7 = var8;
               if ((var5 & 1) != 0) {
                  label69:
                  while(true) {
                     do {
                        var5 = var8 - 1;
                        var7 = var5;
                        if (var5 < 0) {
                           break label69;
                        }

                        var9 = (b.d.a.a)this.f.get(var5);
                        if (var3 == null) {
                           break;
                        }

                        var8 = var5;
                     } while(var3.equals(var9.j));

                     var7 = var5;
                     if (var4 < 0) {
                        break;
                     }

                     var7 = var5;
                     if (var4 != var9.l) {
                        break;
                     }

                     var8 = var5;
                  }
               }
            }

            if (var7 == this.f.size() - 1) {
               return false;
            }

            for(var4 = this.f.size() - 1; var4 > var7; --var4) {
               var1.add(this.f.remove(var4));
               var2.add(true);
            }
         }

         return true;
      }
   }

   public b.d.a.d b(int var1) {
      int var2;
      b.d.a.d var3;
      for(var2 = this.d.size() - 1; var2 >= 0; --var2) {
         var3 = (b.d.a.d)this.d.get(var2);
         if (var3 != null && var3.x == var1) {
            return var3;
         }
      }

      SparseArray var4 = this.e;
      if (var4 != null) {
         for(var2 = var4.size() - 1; var2 >= 0; --var2) {
            var3 = (b.d.a.d)this.e.valueAt(var2);
            if (var3 != null && var3.x == var1) {
               return var3;
            }
         }
      }

      return null;
   }

   public b.d.a.d b(String var1) {
      SparseArray var2 = this.e;
      if (var2 != null && var1 != null) {
         for(int var3 = var2.size() - 1; var3 >= 0; --var3) {
            b.d.a.d var4 = (b.d.a.d)this.e.valueAt(var3);
            if (var4 != null) {
               var4 = var4.a(var1);
               if (var4 != null) {
                  return var4;
               }
            }
         }
      }

      return null;
   }

   public List b() {
      // $FF: Couldn't be decompiled
   }

   public void b(b.d.a.d param1) {
      // $FF: Couldn't be decompiled
   }

   public void b(b.d.a.d var1, Context var2, boolean var3) {
      b.d.a.d var4 = this.o;
      if (var4 != null) {
         b.d.a.i var8 = var4.getFragmentManager();
         if (var8 instanceof b.d.a.j) {
            ((b.d.a.j)var8).b(var1, var2, true);
         }
      }

      Iterator var5 = this.k.iterator();

      b.d.a.j.g var7;
      do {
         if (!var5.hasNext()) {
            return;
         }

         var7 = (b.d.a.j.g)var5.next();
      } while(var3 && !var7.b);

      b.d.a.i.b var6 = var7.a;
      throw null;
   }

   public void b(b.d.a.d var1, Bundle var2, boolean var3) {
      b.d.a.d var4 = this.o;
      if (var4 != null) {
         b.d.a.i var8 = var4.getFragmentManager();
         if (var8 instanceof b.d.a.j) {
            ((b.d.a.j)var8).b(var1, var2, true);
         }
      }

      Iterator var7 = this.k.iterator();

      b.d.a.j.g var5;
      do {
         if (!var7.hasNext()) {
            return;
         }

         var5 = (b.d.a.j.g)var7.next();
      } while(var3 && !var5.b);

      b.d.a.i.b var6 = var5.a;
      throw null;
   }

   public void b(b.d.a.d var1, boolean var2) {
      b.d.a.d var3 = this.o;
      if (var3 != null) {
         b.d.a.i var6 = var3.getFragmentManager();
         if (var6 instanceof b.d.a.j) {
            ((b.d.a.j)var6).b(var1, true);
         }
      }

      Iterator var4 = this.k.iterator();

      b.d.a.j.g var7;
      do {
         if (!var4.hasNext()) {
            return;
         }

         var7 = (b.d.a.j.g)var4.next();
      } while(var2 && !var7.b);

      b.d.a.i.b var5 = var7.a;
      throw null;
   }

   public void b(boolean var1) {
      for(int var2 = this.d.size() - 1; var2 >= 0; --var2) {
         b.d.a.d var3 = (b.d.a.d)this.d.get(var2);
         if (var3 != null) {
            var3.b(var1);
         }
      }

   }

   public boolean b(Menu var1) {
      int var2 = this.l;
      int var3 = 0;
      if (var2 < 1) {
         return false;
      } else {
         boolean var4;
         boolean var6;
         for(var4 = false; var3 < this.d.size(); var4 = var6) {
            b.d.a.d var5 = (b.d.a.d)this.d.get(var3);
            var6 = var4;
            if (var5 != null) {
               var6 = var4;
               if (var5.b(var1)) {
                  var6 = true;
               }
            }

            ++var3;
         }

         return var4;
      }
   }

   public boolean b(MenuItem var1) {
      if (this.l < 1) {
         return false;
      } else {
         for(int var2 = 0; var2 < this.d.size(); ++var2) {
            b.d.a.d var3 = (b.d.a.d)this.d.get(var2);
            if (var3 != null && var3.b(var1)) {
               return true;
            }
         }

         return false;
      }
   }

   public final boolean b(ArrayList var1, ArrayList var2) {
      synchronized(this){}

      Throwable var10000;
      boolean var10001;
      label515: {
         ArrayList var3;
         try {
            var3 = this.a;
         } catch (Throwable var62) {
            var10000 = var62;
            var10001 = false;
            break label515;
         }

         int var4;
         label507: {
            var4 = 0;
            if (var3 != null) {
               try {
                  if (this.a.size() != 0) {
                     break label507;
                  }
               } catch (Throwable var61) {
                  var10000 = var61;
                  var10001 = false;
                  break label515;
               }
            }

            try {
               return false;
            } catch (Throwable var60) {
               var10000 = var60;
               var10001 = false;
               break label515;
            }
         }

         int var5;
         try {
            var5 = this.a.size();
         } catch (Throwable var59) {
            var10000 = var59;
            var10001 = false;
            break label515;
         }

         boolean var6;
         for(var6 = false; var4 < var5; ++var4) {
            try {
               var6 |= ((b.d.a.j.i)this.a.get(var4)).a(var1, var2);
            } catch (Throwable var58) {
               var10000 = var58;
               var10001 = false;
               break label515;
            }
         }

         label486:
         try {
            this.a.clear();
            this.m.c.removeCallbacks(this.D);
            return var6;
         } catch (Throwable var57) {
            var10000 = var57;
            var10001 = false;
            break label486;
         }
      }

      while(true) {
         Throwable var63 = var10000;

         try {
            throw var63;
         } catch (Throwable var56) {
            var10000 = var56;
            var10001 = false;
            continue;
         }
      }
   }

   public void c(int var1) {
      synchronized(this){}

      Throwable var10000;
      boolean var10001;
      label122: {
         try {
            this.h.set(var1, (Object)null);
            if (this.i == null) {
               ArrayList var2 = new ArrayList();
               this.i = var2;
            }
         } catch (Throwable var14) {
            var10000 = var14;
            var10001 = false;
            break label122;
         }

         label119:
         try {
            this.i.add(var1);
            return;
         } catch (Throwable var13) {
            var10000 = var13;
            var10001 = false;
            break label119;
         }
      }

      while(true) {
         Throwable var15 = var10000;

         try {
            throw var15;
         } catch (Throwable var12) {
            var10000 = var12;
            var10001 = false;
            continue;
         }
      }
   }

   public void c(b.d.a.d var1) {
      if (!var1.A) {
         var1.A = true;
         var1.O ^= true;
      }

   }

   public void c(b.d.a.d var1, Bundle var2, boolean var3) {
      b.d.a.d var4 = this.o;
      if (var4 != null) {
         b.d.a.i var8 = var4.getFragmentManager();
         if (var8 instanceof b.d.a.j) {
            ((b.d.a.j)var8).c(var1, var2, true);
         }
      }

      Iterator var7 = this.k.iterator();

      b.d.a.j.g var5;
      do {
         if (!var7.hasNext()) {
            return;
         }

         var5 = (b.d.a.j.g)var7.next();
      } while(var3 && !var5.b);

      b.d.a.i.b var6 = var5.a;
      throw null;
   }

   public void c(b.d.a.d var1, boolean var2) {
      b.d.a.d var3 = this.o;
      if (var3 != null) {
         b.d.a.i var6 = var3.getFragmentManager();
         if (var6 instanceof b.d.a.j) {
            ((b.d.a.j)var6).c(var1, true);
         }
      }

      Iterator var4 = this.k.iterator();

      b.d.a.j.g var7;
      do {
         if (!var4.hasNext()) {
            return;
         }

         var7 = (b.d.a.j.g)var4.next();
      } while(var2 && !var7.b);

      b.d.a.i.b var5 = var7.a;
      throw null;
   }

   public final void c(ArrayList var1, ArrayList var2) {
      if (var1 != null && !var1.isEmpty()) {
         if (var2 != null && var1.size() == var2.size()) {
            this.a(var1, var2);
            int var3 = var1.size();
            int var4 = 0;

            int var5;
            int var7;
            for(var5 = 0; var4 < var3; var5 = var7) {
               int var6 = var4;
               var7 = var5;
               if (!((b.d.a.a)var1.get(var4)).s) {
                  if (var5 != var4) {
                     this.a(var1, var2, var5, var4);
                  }

                  var5 = var4 + 1;
                  var7 = var5;
                  if ((Boolean)var2.get(var4)) {
                     while(true) {
                        var7 = var5;
                        if (var5 >= var3) {
                           break;
                        }

                        var7 = var5;
                        if (!(Boolean)var2.get(var5)) {
                           break;
                        }

                        var7 = var5;
                        if (((b.d.a.a)var1.get(var5)).s) {
                           break;
                        }

                        ++var5;
                     }
                  }

                  this.a(var1, var2, var4, var7);
                  var6 = var7 - 1;
               }

               var4 = var6 + 1;
            }

            if (var5 != var3) {
               this.a(var1, var2, var5, var3);
            }

         } else {
            throw new IllegalStateException("Internal error with the back stack records");
         }
      }
   }

   public final void c(boolean var1) {
      if (!this.b) {
         if (this.m != null) {
            if (Looper.myLooper() == this.m.c.getLooper()) {
               if (!var1) {
                  this.f();
               }

               if (this.w == null) {
                  this.w = new ArrayList();
                  this.x = new ArrayList();
               }

               this.b = true;

               try {
                  this.a((ArrayList)null, (ArrayList)null);
               } finally {
                  this.b = false;
               }

            } else {
               throw new IllegalStateException("Must be called from main thread of fragment host");
            }
         } else {
            throw new IllegalStateException("Fragment host has been destroyed");
         }
      } else {
         throw new IllegalStateException("FragmentManager is already executing transactions");
      }
   }

   public boolean c() {
      boolean var1;
      if (!this.r && !this.s) {
         var1 = false;
      } else {
         var1 = true;
      }

      return var1;
   }

   public void d(b.d.a.d var1) {
      if (var1.e < 0) {
         int var2 = this.c++;
         var1.a(var2, this.o);
         if (this.e == null) {
            this.e = new SparseArray();
         }

         this.e.put(var1.e, var1);
      }
   }

   public void d(b.d.a.d var1, Bundle var2, boolean var3) {
      b.d.a.d var4 = this.o;
      if (var4 != null) {
         b.d.a.i var8 = var4.getFragmentManager();
         if (var8 instanceof b.d.a.j) {
            ((b.d.a.j)var8).d(var1, var2, true);
         }
      }

      Iterator var7 = this.k.iterator();

      b.d.a.j.g var5;
      do {
         if (!var7.hasNext()) {
            return;
         }

         var5 = (b.d.a.j.g)var7.next();
      } while(var3 && !var5.b);

      b.d.a.i.b var6 = var5.a;
      throw null;
   }

   public void d(b.d.a.d var1, boolean var2) {
      b.d.a.d var3 = this.o;
      if (var3 != null) {
         b.d.a.i var6 = var3.getFragmentManager();
         if (var6 instanceof b.d.a.j) {
            ((b.d.a.j)var6).d(var1, true);
         }
      }

      Iterator var4 = this.k.iterator();

      b.d.a.j.g var7;
      do {
         if (!var4.hasNext()) {
            return;
         }

         var7 = (b.d.a.j.g)var4.next();
      } while(var2 && !var7.b);

      b.d.a.i.b var5 = var7.a;
      throw null;
   }

   public boolean d() {
      this.f();
      this.p();
      boolean var1 = true;
      this.c(true);
      b.d.a.d var2 = this.p;
      if (var2 != null) {
         b.d.a.i var5 = var2.r();
         if (var5 != null && var5.d()) {
            return var1;
         }
      }

      var1 = this.a(this.w, this.x, (String)null, -1, 0);
      if (var1) {
         this.b = true;

         try {
            this.c(this.w, this.x);
         } finally {
            this.g();
         }
      }

      this.o();
      this.e();
      return var1;
   }

   public final void e() {
      SparseArray var1 = this.e;
      if (var1 != null) {
         for(int var2 = var1.size() - 1; var2 >= 0; --var2) {
            if (this.e.valueAt(var2) == null) {
               var1 = this.e;
               var1.delete(var1.keyAt(var2));
            }
         }
      }

   }

   public void e(b.d.a.d var1) {
      if (var1 != null) {
         int var2 = this.l;
         int var3 = var2;
         if (var1.l) {
            if (var1.o()) {
               var3 = Math.min(var2, 1);
            } else {
               var3 = Math.min(var2, 0);
            }
         }

         this.a(var1, var3, var1.i(), var1.j(), false);
         View var4 = var1.I;
         ViewGroup var5;
         View var6;
         if (var4 != null) {
            var5 = var1.H;
            var6 = null;
            b.d.a.d var7 = var6;
            if (var5 != null) {
               if (var4 == null) {
                  var7 = var6;
               } else {
                  var3 = this.d.indexOf(var1);

                  while(true) {
                     var2 = var3 - 1;
                     var7 = var6;
                     if (var2 < 0) {
                        break;
                     }

                     var7 = (b.d.a.d)this.d.get(var2);
                     var3 = var2;
                     if (var7.H == var5) {
                        var3 = var2;
                        if (var7.I != null) {
                           break;
                        }
                     }
                  }
               }
            }

            if (var7 != null) {
               var6 = var7.I;
               ViewGroup var12 = var1.H;
               var2 = var12.indexOfChild(var6);
               var3 = var12.indexOfChild(var1.I);
               if (var3 < var2) {
                  var12.removeViewAt(var3);
                  var12.addView(var1.I, var2);
               }
            }

            if (var1.N && var1.H != null) {
               float var8 = var1.P;
               if (var8 > 0.0F) {
                  var1.I.setAlpha(var8);
               }

               var1.P = 0.0F;
               var1.N = false;
               b.d.a.j.d var10 = this.a(var1, var1.i(), true, var1.j());
               if (var10 != null) {
                  a(var1.I, var10);
                  Animation var13 = var10.a;
                  if (var13 != null) {
                     var1.I.startAnimation(var13);
                  } else {
                     var10.b.setTarget(var1.I);
                     var10.b.start();
                  }
               }
            }
         }

         if (var1.O) {
            if (var1.I != null) {
               label116: {
                  b.d.a.j.d var14 = this.a(var1, var1.i(), var1.A ^ true, var1.j());
                  if (var14 != null) {
                     Animator var11 = var14.b;
                     if (var11 != null) {
                        var11.setTarget(var1.I);
                        if (var1.A) {
                           if (var1.n()) {
                              var1.c(false);
                           } else {
                              var5 = var1.H;
                              var6 = var1.I;
                              var5.startViewTransition(var6);
                              var14.b.addListener(new m(this, var5, var6, var1));
                           }
                        } else {
                           var1.I.setVisibility(0);
                        }

                        a(var1.I, var14);
                        var14.b.start();
                        break label116;
                     }
                  }

                  if (var14 != null) {
                     a(var1.I, var14);
                     var1.I.startAnimation(var14.a);
                     var14.a.start();
                  }

                  byte var9;
                  if (var1.A && !var1.n()) {
                     var9 = 8;
                  } else {
                     var9 = 0;
                  }

                  var1.I.setVisibility(var9);
                  if (var1.n()) {
                     var1.c(false);
                  }
               }
            }

            if (var1.k && var1.E && var1.F) {
               this.q = true;
            }

            var1.O = false;
            var1.onHiddenChanged(var1.A);
         }

      }
   }

   public void e(b.d.a.d var1, boolean var2) {
      b.d.a.d var3 = this.o;
      if (var3 != null) {
         b.d.a.i var6 = var3.getFragmentManager();
         if (var6 instanceof b.d.a.j) {
            ((b.d.a.j)var6).e(var1, true);
         }
      }

      Iterator var7 = this.k.iterator();

      b.d.a.j.g var4;
      do {
         if (!var7.hasNext()) {
            return;
         }

         var4 = (b.d.a.j.g)var7.next();
      } while(var2 && !var4.b);

      b.d.a.i.b var5 = var4.a;
      throw null;
   }

   public final void f() {
      if (!this.c()) {
         if (this.u != null) {
            StringBuilder var1 = c.a.b.a.a.b("Can not perform this action inside of ");
            var1.append(this.u);
            throw new IllegalStateException(var1.toString());
         }
      } else {
         throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
      }
   }

   public void f(b.d.a.d var1) {
      if (var1.K) {
         if (this.b) {
            this.v = true;
            return;
         }

         var1.K = false;
         this.a(var1, this.l, 0, 0, false);
      }

   }

   public void f(b.d.a.d var1, boolean var2) {
      b.d.a.d var3 = this.o;
      if (var3 != null) {
         b.d.a.i var6 = var3.getFragmentManager();
         if (var6 instanceof b.d.a.j) {
            ((b.d.a.j)var6).f(var1, true);
         }
      }

      Iterator var7 = this.k.iterator();

      b.d.a.j.g var4;
      do {
         if (!var7.hasNext()) {
            return;
         }

         var4 = (b.d.a.j.g)var7.next();
      } while(var2 && !var4.b);

      b.d.a.i.b var5 = var4.a;
      throw null;
   }

   public final void g() {
      this.b = false;
      this.x.clear();
      this.w.clear();
   }

   public void g(b.d.a.d param1) {
      // $FF: Couldn't be decompiled
   }

   public void g(b.d.a.d var1, boolean var2) {
      b.d.a.d var3 = this.o;
      if (var3 != null) {
         b.d.a.i var6 = var3.getFragmentManager();
         if (var6 instanceof b.d.a.j) {
            ((b.d.a.j)var6).g(var1, true);
         }
      }

      Iterator var4 = this.k.iterator();

      b.d.a.j.g var7;
      do {
         if (!var4.hasNext()) {
            return;
         }

         var7 = (b.d.a.j.g)var4.next();
      } while(var2 && !var7.b);

      b.d.a.i.b var5 = var7.a;
      throw null;
   }

   public void h() {
      this.r = false;
      this.s = false;
      this.a(2);
   }

   public void h(b.d.a.d var1) {
      if (var1.J != null) {
         SparseArray var2 = this.A;
         if (var2 == null) {
            this.A = new SparseArray();
         } else {
            var2.clear();
         }

         var1.J.saveHierarchyState(this.A);
         if (this.A.size() > 0) {
            var1.c = this.A;
            this.A = null;
         }

      }
   }

   public void h(b.d.a.d var1, boolean var2) {
      b.d.a.d var3 = this.o;
      if (var3 != null) {
         b.d.a.i var6 = var3.getFragmentManager();
         if (var6 instanceof b.d.a.j) {
            ((b.d.a.j)var6).h(var1, true);
         }
      }

      Iterator var7 = this.k.iterator();

      b.d.a.j.g var4;
      do {
         if (!var7.hasNext()) {
            return;
         }

         var4 = (b.d.a.j.g)var7.next();
      } while(var2 && !var4.b);

      b.d.a.i.b var5 = var4.a;
      throw null;
   }

   public void i() {
      this.r = false;
      this.s = false;
      this.a(1);
   }

   public void i(b.d.a.d var1) {
      if (var1 == null || this.e.get(var1.e) == var1 && (var1.s == null || var1.getFragmentManager() == this)) {
         this.p = var1;
      } else {
         StringBuilder var2 = new StringBuilder();
         var2.append("Fragment ");
         var2.append(var1);
         var2.append(" is not an active fragment of FragmentManager ");
         var2.append(this);
         throw new IllegalArgumentException(var2.toString());
      }
   }

   public void j() {
      this.t = true;
      this.p();
      this.a(0);
      this.m = null;
      this.n = null;
      this.o = null;
   }

   public void j(b.d.a.d var1) {
      if (var1.A) {
         var1.A = false;
         var1.O ^= true;
      }

   }

   public void k() {
      for(int var1 = 0; var1 < this.d.size(); ++var1) {
         b.d.a.d var2 = (b.d.a.d)this.d.get(var1);
         if (var2 != null) {
            var2.v();
         }
      }

   }

   public void l() {
      this.a(3);
   }

   public void m() {
      this.r = false;
      this.s = false;
      this.a(4);
   }

   public void n() {
      this.r = false;
      this.s = false;
      this.a(3);
   }

   public void o() {
      if (this.v) {
         this.v = false;
         this.v();
      }

   }

   public View onCreateView(View var1, String var2, Context var3, AttributeSet var4) {
      if (!"fragment".equals(var2)) {
         return null;
      } else {
         var2 = var4.getAttributeValue((String)null, "class");
         TypedArray var5 = var3.obtainStyledAttributes(var4, b.d.a.j.h.a);
         int var6 = 0;
         String var7 = var2;
         if (var2 == null) {
            var7 = var5.getString(0);
         }

         int var8 = var5.getResourceId(1, -1);
         String var9 = var5.getString(2);
         var5.recycle();
         if (!b.d.a.d.a(this.m.b, var7)) {
            return null;
         } else {
            if (var1 != null) {
               var6 = var1.getId();
            }

            StringBuilder var14;
            if (var6 == -1 && var8 == -1 && var9 == null) {
               var14 = new StringBuilder();
               var14.append(var4.getPositionDescription());
               var14.append(": Must specify unique android:id, android:tag, or have a parent with an id for ");
               var14.append(var7);
               throw new IllegalArgumentException(var14.toString());
            } else {
               b.d.a.d var12;
               if (var8 != -1) {
                  var12 = this.b(var8);
               } else {
                  var12 = null;
               }

               b.d.a.d var11 = var12;
               if (var12 == null) {
                  var11 = var12;
                  if (var9 != null) {
                     var11 = this.a(var9);
                  }
               }

               var12 = var11;
               if (var11 == null) {
                  var12 = var11;
                  if (var6 != -1) {
                     var12 = this.b(var6);
                  }
               }

               if (var12 == null) {
                  var11 = this.n.a(var3, var7, (Bundle)null);
                  var11.m = true;
                  int var10;
                  if (var8 != 0) {
                     var10 = var8;
                  } else {
                     var10 = var6;
                  }

                  var11.x = var10;
                  var11.y = var6;
                  var11.z = var9;
                  var11.n = true;
                  var11.r = this;
                  b.d.a.h var15 = this.m;
                  var11.s = var15;
                  var11.onInflate(var15.b, var4, var11.b);
                  this.a(var11, true);
               } else {
                  if (var12.n) {
                     var14 = new StringBuilder();
                     var14.append(var4.getPositionDescription());
                     var14.append(": Duplicate id 0x");
                     var14.append(Integer.toHexString(var8));
                     var14.append(", tag ");
                     var14.append(var9);
                     var14.append(", or parent id 0x");
                     var14.append(Integer.toHexString(var6));
                     var14.append(" with another fragment for ");
                     var14.append(var7);
                     throw new IllegalArgumentException(var14.toString());
                  }

                  var12.n = true;
                  b.d.a.h var13 = this.m;
                  var12.s = var13;
                  if (!var12.D) {
                     var12.onInflate(var13.b, var4, var12.b);
                  }

                  var11 = var12;
               }

               if (this.l < 1 && var11.m) {
                  this.a(var11, 1, 0, 0, false);
               } else {
                  this.a(var11, this.l, 0, 0, false);
               }

               View var16 = var11.I;
               if (var16 != null) {
                  if (var8 != 0) {
                     var16.setId(var8);
                  }

                  if (var11.I.getTag() == null) {
                     var11.I.setTag(var9);
                  }

                  return var11.I;
               } else {
                  throw new IllegalStateException(c.a.b.a.a.a("Fragment ", var7, " did not create a view."));
               }
            }
         }
      }
   }

   public View onCreateView(String var1, Context var2, AttributeSet var3) {
      return this.onCreateView((View)null, var1, var2, var3);
   }

   public boolean p() {
      this.c(true);

      boolean var1;
      for(var1 = false; this.b(this.w, this.x); var1 = true) {
         this.b = true;

         try {
            this.c(this.w, this.x);
         } finally {
            this.g();
         }
      }

      if (this.v) {
         this.v = false;
         this.v();
      }

      this.e();
      return var1;
   }

   public Factory2 q() {
      return this;
   }

   public void r() {
      this.C = null;
      int var1 = 0;
      this.r = false;
      this.s = false;

      for(int var2 = this.d.size(); var1 < var2; ++var1) {
         b.d.a.d var3 = (b.d.a.d)this.d.get(var1);
         if (var3 != null) {
            var3.q();
         }
      }

   }

   public Parcelable s() {
      ArrayList var1 = this.B;
      byte var2 = 0;
      if (var1 != null) {
         while(!this.B.isEmpty()) {
            ((b.d.a.j.k)this.B.remove(0)).a();
         }
      }

      SparseArray var11 = this.e;
      int var3;
      int var4;
      if (var11 == null) {
         var3 = 0;
         var4 = 0;
      } else {
         var4 = var11.size();
         var3 = 0;
      }

      while(true) {
         View var5 = null;
         b.d.a.d var6;
         int var7;
         if (var3 >= var4) {
            this.p();
            this.r = true;
            this.C = null;
            var11 = this.e;
            if (var11 != null && var11.size() > 0) {
               var7 = this.e.size();
               p[] var8 = new p[var7];
               var3 = 0;

               b.d.a.d var14;
               StringBuilder var15;
               boolean var16;
               for(var16 = false; var3 < var7; ++var3) {
                  b.d.a.d var9 = (b.d.a.d)this.e.valueAt(var3);
                  if (var9 != null) {
                     if (var9.e < 0) {
                        var15 = new StringBuilder();
                        var15.append("Failure saving state: active ");
                        var15.append(var9);
                        var15.append(" has cleared index: ");
                        var15.append(var9.e);
                        this.a((RuntimeException)(new IllegalStateException(var15.toString())));
                        throw null;
                     }

                     p var10 = new p(var9);
                     var8[var3] = var10;
                     if (var9.a > 0 && var10.k == null) {
                        if (this.z == null) {
                           this.z = new Bundle();
                        }

                        var9.d(this.z);
                        this.d(var9, this.z, false);
                        Bundle var20;
                        if (!this.z.isEmpty()) {
                           var20 = this.z;
                           this.z = null;
                        } else {
                           var20 = null;
                        }

                        if (var9.I != null) {
                           this.h(var9);
                        }

                        Bundle var13 = var20;
                        if (var9.c != null) {
                           var13 = var20;
                           if (var20 == null) {
                              var13 = new Bundle();
                           }

                           var13.putSparseParcelableArray("android:view_state", var9.c);
                        }

                        var20 = var13;
                        if (!var9.L) {
                           var20 = var13;
                           if (var13 == null) {
                              var20 = new Bundle();
                           }

                           var20.putBoolean("android:user_visible_hint", var9.L);
                        }

                        var10.k = var20;
                        var14 = var9.h;
                        if (var14 != null) {
                           if (var14.e < 0) {
                              var15 = new StringBuilder();
                              var15.append("Failure saving state: ");
                              var15.append(var9);
                              var15.append(" has target not in fragment manager: ");
                              var15.append(var9.h);
                              this.a((RuntimeException)(new IllegalStateException(var15.toString())));
                              throw null;
                           }

                           if (var10.k == null) {
                              var10.k = new Bundle();
                           }

                           var13 = var10.k;
                           var6 = var9.h;
                           var4 = var6.e;
                           if (var4 < 0) {
                              this.a((RuntimeException)(new IllegalStateException(c.a.b.a.a.a("Fragment ", var6, " is not currently in the FragmentManager"))));
                              throw null;
                           }

                           var13.putInt("android:target_state", var4);
                           var4 = var9.j;
                           if (var4 != 0) {
                              var10.k.putInt("android:target_req_state", var4);
                           }
                        }
                     } else {
                        var10.k = var9.b;
                     }

                     var16 = true;
                  }
               }

               if (!var16) {
                  return null;
               } else {
                  var4 = this.d.size();
                  int[] var17;
                  if (var4 > 0) {
                     int[] var21 = new int[var4];
                     var3 = 0;

                     while(true) {
                        var17 = var21;
                        if (var3 >= var4) {
                           break;
                        }

                        var21[var3] = ((b.d.a.d)this.d.get(var3)).e;
                        if (var21[var3] < 0) {
                           var15 = c.a.b.a.a.b("Failure saving state: active ");
                           var15.append(this.d.get(var3));
                           var15.append(" has cleared index: ");
                           var15.append(var21[var3]);
                           this.a((RuntimeException)(new IllegalStateException(var15.toString())));
                           throw null;
                        }

                        ++var3;
                     }
                  } else {
                     var17 = null;
                  }

                  ArrayList var22 = this.f;
                  b.d.a.b[] var23 = var5;
                  if (var22 != null) {
                     var4 = var22.size();
                     var23 = var5;
                     if (var4 > 0) {
                        b.d.a.b[] var18 = new b.d.a.b[var4];
                        var3 = var2;

                        while(true) {
                           var23 = var18;
                           if (var3 >= var4) {
                              break;
                           }

                           var18[var3] = new b.d.a.b((b.d.a.a)this.f.get(var3));
                           ++var3;
                        }
                     }
                  }

                  o var19 = new o();
                  var19.a = var8;
                  var19.b = var17;
                  var19.c = var23;
                  var14 = this.p;
                  if (var14 != null) {
                     var19.d = var14.e;
                  }

                  var19.e = this.c;
                  this.t();
                  return var19;
               }
            } else {
               return null;
            }
         }

         var6 = (b.d.a.d)this.e.valueAt(var3);
         if (var6 != null) {
            if (var6.d() != null) {
               var7 = var6.k();
               var5 = var6.d();
               Animation var12 = var5.getAnimation();
               if (var12 != null) {
                  var12.cancel();
                  var5.clearAnimation();
               }

               var6.a((View)null);
               this.a(var6, var7, 0, 0, false);
            } else if (var6.e() != null) {
               var6.e().end();
            }
         }

         ++var3;
      }
   }

   public void t() {
      ArrayList var5;
      ArrayList var6;
      ArrayList var7;
      if (this.e != null) {
         ArrayList var1 = null;
         ArrayList var2 = var1;
         ArrayList var3 = var1;
         int var4 = 0;

         while(true) {
            var5 = var1;
            var6 = var2;
            var7 = var3;
            if (var4 >= this.e.size()) {
               break;
            }

            b.d.a.d var8 = (b.d.a.d)this.e.valueAt(var4);
            var5 = var1;
            ArrayList var9 = var2;
            var6 = var3;
            if (var8 != null) {
               var7 = var1;
               int var10;
               if (var8.C) {
                  var7 = var1;
                  if (var1 == null) {
                     var7 = new ArrayList();
                  }

                  var7.add(var8);
                  b.d.a.d var11 = var8.h;
                  if (var11 != null) {
                     var10 = var11.e;
                  } else {
                     var10 = -1;
                  }

                  var8.i = var10;
               }

               b.d.a.j var12 = var8.t;
               n var13;
               if (var12 != null) {
                  var12.t();
                  var13 = var8.t.C;
               } else {
                  var13 = var8.u;
               }

               var1 = var2;
               if (var2 == null) {
                  var1 = var2;
                  if (var13 != null) {
                     var2 = new ArrayList(this.e.size());
                     var10 = 0;

                     while(true) {
                        var1 = var2;
                        if (var10 >= var4) {
                           break;
                        }

                        var2.add((Object)null);
                        ++var10;
                     }
                  }
               }

               if (var1 != null) {
                  var1.add(var13);
               }

               var2 = var3;
               if (var3 == null) {
                  var2 = var3;
                  if (var8.v != null) {
                     var3 = new ArrayList(this.e.size());
                     var10 = 0;

                     while(true) {
                        var2 = var3;
                        if (var10 >= var4) {
                           break;
                        }

                        var3.add((Object)null);
                        ++var10;
                     }
                  }
               }

               var5 = var7;
               var9 = var1;
               var6 = var2;
               if (var2 != null) {
                  var2.add(var8.v);
                  var6 = var2;
                  var9 = var1;
                  var5 = var7;
               }
            }

            ++var4;
            var1 = var5;
            var2 = var9;
            var3 = var6;
         }
      } else {
         var5 = null;
         var7 = var5;
         var6 = var5;
      }

      if (var5 == null && var6 == null && var7 == null) {
         this.C = null;
      } else {
         this.C = new n(var5, var6, var7);
      }

   }

   public String toString() {
      StringBuilder var1 = new StringBuilder(128);
      var1.append("FragmentManager{");
      var1.append(Integer.toHexString(System.identityHashCode(this)));
      var1.append(" in ");
      b.d.a.d var2 = this.o;
      if (var2 != null) {
         b.c.b.b.a((Object)var2, (StringBuilder)var1);
      } else {
         b.c.b.b.a((Object)this.m, (StringBuilder)var1);
      }

      var1.append("}}");
      return var1.toString();
   }

   public void u() {
      synchronized(this){}

      Throwable var10000;
      boolean var10001;
      label586: {
         ArrayList var1;
         try {
            var1 = this.B;
         } catch (Throwable var60) {
            var10000 = var60;
            var10001 = false;
            break label586;
         }

         boolean var2;
         boolean var3;
         label576: {
            label575: {
               var2 = false;
               if (var1 != null) {
                  try {
                     if (!this.B.isEmpty()) {
                        break label575;
                     }
                  } catch (Throwable var59) {
                     var10000 = var59;
                     var10001 = false;
                     break label586;
                  }
               }

               var3 = false;
               break label576;
            }

            var3 = true;
         }

         boolean var4 = var2;

         label585: {
            try {
               if (this.a == null) {
                  break label585;
               }
            } catch (Throwable var58) {
               var10000 = var58;
               var10001 = false;
               break label586;
            }

            var4 = var2;

            try {
               if (this.a.size() != 1) {
                  break label585;
               }
            } catch (Throwable var57) {
               var10000 = var57;
               var10001 = false;
               break label586;
            }

            var4 = true;
         }

         if (var3 || var4) {
            try {
               this.m.c.removeCallbacks(this.D);
               this.m.c.post(this.D);
            } catch (Throwable var56) {
               var10000 = var56;
               var10001 = false;
               break label586;
            }
         }

         label549:
         try {
            return;
         } catch (Throwable var55) {
            var10000 = var55;
            var10001 = false;
            break label549;
         }
      }

      while(true) {
         Throwable var61 = var10000;

         try {
            throw var61;
         } catch (Throwable var54) {
            var10000 = var54;
            var10001 = false;
            continue;
         }
      }
   }

   public void v() {
      if (this.e != null) {
         for(int var1 = 0; var1 < this.e.size(); ++var1) {
            b.d.a.d var2 = (b.d.a.d)this.e.valueAt(var1);
            if (var2 != null) {
               this.f(var2);
            }
         }

      }
   }

   public static class b extends b.d.a.j.c {
      public View b;

      public b(View var1, AnimationListener var2) {
         super(var2);
         this.b = var1;
      }

      public void onAnimationEnd(Animation var1) {
         if (!b.c.e.c.c(this.b) && VERSION.SDK_INT < 24) {
            this.b.setLayerType(0, (Paint)null);
         } else {
            this.b.post(new Runnable() {
               public void run() {
                  b.this.b.setLayerType(0, (Paint)null);
               }
            });
         }

         AnimationListener var2 = super.a;
         if (var2 != null) {
            var2.onAnimationEnd(var1);
         }

      }
   }

   public static class c implements AnimationListener {
      public final AnimationListener a;

      public c(AnimationListener var1) {
         this.a = var1;
      }

      public void onAnimationRepeat(Animation var1) {
         AnimationListener var2 = this.a;
         if (var2 != null) {
            var2.onAnimationRepeat(var1);
         }

      }

      public void onAnimationStart(Animation var1) {
         AnimationListener var2 = this.a;
         if (var2 != null) {
            var2.onAnimationStart(var1);
         }

      }
   }

   public static class d {
      public final Animation a;
      public final Animator b;

      public d(Animator var1) {
         this.a = null;
         this.b = var1;
         if (var1 == null) {
            throw new IllegalStateException("Animator cannot be null");
         }
      }

      public d(Animation var1) {
         this.a = var1;
         this.b = null;
         if (var1 == null) {
            throw new IllegalStateException("Animation cannot be null");
         }
      }
   }

   public static class e extends AnimatorListenerAdapter {
      public View a;

      public e(View var1) {
         this.a = var1;
      }

      public void onAnimationEnd(Animator var1) {
         this.a.setLayerType(0, (Paint)null);
         var1.removeListener(this);
      }

      public void onAnimationStart(Animator var1) {
         this.a.setLayerType(2, (Paint)null);
      }
   }

   public static class f extends AnimationSet implements Runnable {
      public final ViewGroup a;
      public final View b;
      public boolean c;
      public boolean d;
      public boolean e = true;

      public f(Animation var1, ViewGroup var2, View var3) {
         super(false);
         this.a = var2;
         this.b = var3;
         this.addAnimation(var1);
         this.a.post(this);
      }

      public boolean getTransformation(long var1, Transformation var3) {
         this.e = true;
         if (this.c) {
            return this.d ^ true;
         } else {
            if (!super.getTransformation(var1, var3)) {
               this.c = true;
               b0.a(this.a, this);
            }

            return true;
         }
      }

      public boolean getTransformation(long var1, Transformation var3, float var4) {
         this.e = true;
         if (this.c) {
            return this.d ^ true;
         } else {
            if (!super.getTransformation(var1, var3, var4)) {
               this.c = true;
               b0.a(this.a, this);
            }

            return true;
         }
      }

      public void run() {
         if (!this.c && this.e) {
            this.e = false;
            this.a.post(this);
         } else {
            this.a.endViewTransition(this.b);
            this.d = true;
         }

      }
   }

   public static final class g {
      public final b.d.a.i.b a;
      public final boolean b;
   }

   public static class h {
      public static final int[] a = new int[]{16842755, 16842960, 16842961};
   }

   public interface i {
      boolean a(ArrayList var1, ArrayList var2);
   }

   public class j implements b.d.a.j.i {
      public final String a;
      public final int b;
      public final int c;

      public j(String var2, int var3, int var4) {
         this.a = var2;
         this.b = var3;
         this.c = var4;
      }

      public boolean a(ArrayList var1, ArrayList var2) {
         b.d.a.d var3 = j.this.p;
         if (var3 != null && this.b < 0 && this.a == null) {
            b.d.a.i var4 = var3.r();
            if (var4 != null && var4.d()) {
               return false;
            }
         }

         return j.this.a(var1, var2, this.a, this.b, this.c);
      }
   }

   public static class k implements b.d.a.d.f {
      public final boolean a;
      public final b.d.a.a b;
      public int c;

      public k(b.d.a.a var1, boolean var2) {
         this.a = var2;
         this.b = var1;
      }

      public void a() {
         int var1 = this.c;
         int var2 = 0;
         boolean var6;
         if (var1 > 0) {
            var6 = true;
         } else {
            var6 = false;
         }

         b.d.a.j var3 = this.b.a;

         for(int var4 = var3.d.size(); var2 < var4; ++var2) {
            b.d.a.d var5 = (b.d.a.d)var3.d.get(var2);
            var5.a((b.d.a.d.f)null);
            if (var6 && var5.p()) {
               var5.startPostponedEnterTransition();
            }
         }

         b.d.a.a var7 = this.b;
         var7.a.a(var7, this.a, var6 ^ true, true);
      }
   }
}
