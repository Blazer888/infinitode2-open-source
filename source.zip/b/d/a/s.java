package b.d.a;

import android.view.View;
import java.util.ArrayList;

public final class s implements Runnable {
   // $FF: synthetic field
   public final Object a;
   // $FF: synthetic field
   public final a0 b;
   // $FF: synthetic field
   public final View c;
   // $FF: synthetic field
   public final d d;
   // $FF: synthetic field
   public final ArrayList e;
   // $FF: synthetic field
   public final ArrayList f;
   // $FF: synthetic field
   public final ArrayList g;
   // $FF: synthetic field
   public final Object h;

   public s(Object var1, a0 var2, View var3, d var4, ArrayList var5, ArrayList var6, ArrayList var7, Object var8) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
      this.f = var6;
      this.g = var7;
      this.h = var8;
   }

   public void run() {
      Object var1 = this.a;
      ArrayList var2;
      if (var1 != null) {
         this.b.a(var1, this.c);
         var2 = v.a(this.b, this.a, this.d, this.e, this.c);
         this.f.addAll(var2);
      }

      if (this.g != null) {
         if (this.h != null) {
            var2 = new ArrayList();
            var2.add(this.c);
            this.b.a(this.h, this.g, var2);
         }

         this.g.clear();
         this.g.add(this.c);
      }

   }
}
