package b.d.a;

import java.util.ArrayList;

public final class r implements Runnable {
   // $FF: synthetic field
   public final ArrayList a;

   public r(ArrayList var1) {
      this.a = var1;
   }

   public void run() {
      v.a(this.a, 4);
   }
}
