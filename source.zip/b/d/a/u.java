package b.d.a;

import android.graphics.Rect;
import android.view.View;
import java.util.ArrayList;

public final class u implements Runnable {
   // $FF: synthetic field
   public final a0 a;
   // $FF: synthetic field
   public final b.b.a b;
   // $FF: synthetic field
   public final Object c;
   // $FF: synthetic field
   public final v.a d;
   // $FF: synthetic field
   public final ArrayList e;
   // $FF: synthetic field
   public final View f;
   // $FF: synthetic field
   public final d g;
   // $FF: synthetic field
   public final d h;
   // $FF: synthetic field
   public final boolean i;
   // $FF: synthetic field
   public final ArrayList j;
   // $FF: synthetic field
   public final Object k;
   // $FF: synthetic field
   public final Rect l;

   public u(a0 var1, b.b.a var2, Object var3, v.a var4, ArrayList var5, View var6, d var7, d var8, boolean var9, ArrayList var10, Object var11, Rect var12) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
      this.f = var6;
      this.g = var7;
      this.h = var8;
      this.i = var9;
      this.j = var10;
      this.k = var11;
      this.l = var12;
   }

   public void run() {
      b.b.a var1 = v.a(this.a, this.b, this.c, this.d);
      if (var1 != null) {
         this.e.addAll(var1.values());
         this.e.add(this.f);
      }

      v.a(this.g, this.h, this.i, var1, false);
      Object var2 = this.c;
      if (var2 != null) {
         this.a.b(var2, this.j, this.e);
         View var3 = v.a(var1, this.d, this.k, this.i);
         if (var3 != null) {
            this.a.a(var3, this.l);
         }
      }

   }
}
