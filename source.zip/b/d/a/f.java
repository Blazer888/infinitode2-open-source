package b.d.a;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

public abstract class f {
   public abstract View a(int var1);

   public d a(Context var1, String var2, Bundle var3) {
      return d.instantiate(var1, var2, var3);
   }

   public abstract boolean a();
}
