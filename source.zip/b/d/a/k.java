package b.d.a;

import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;

public class k extends j.c {
   // $FF: synthetic field
   public final ViewGroup b;
   // $FF: synthetic field
   public final d c;
   // $FF: synthetic field
   public final j d;

   public k(j var1, AnimationListener var2, ViewGroup var3, d var4) {
      super(var2);
      this.d = var1;
      this.b = var3;
      this.c = var4;
   }

   public void onAnimationEnd(Animation var1) {
      AnimationListener var2 = super.a;
      if (var2 != null) {
         var2.onAnimationEnd(var1);
      }

      this.b.post(new Runnable() {
         public void run() {
            if (k.this.c.d() != null) {
               k.this.c.a((View)null);
               k var1 = k.this;
               j var2 = var1.d;
               d var3 = var1.c;
               var2.a(var3, var3.k(), 0, 0, false);
            }

         }
      });
   }
}
