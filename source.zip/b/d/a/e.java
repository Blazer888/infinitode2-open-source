package b.d.a;

import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Iterator;

public class e extends b.c.b.c implements b.f.v, b.c.b.a.b, b.c.b.a.c {
   public final Handler b = new Handler() {
      public void handleMessage(Message var1) {
         if (var1.what != 2) {
            super.handleMessage(var1);
         } else {
            e.this.d();
            e.this.c.a();
         }

      }
   };
   public final g c = new g(new e.b());
   public b.f.u d;
   public boolean e;
   public boolean f;
   public boolean g = true;
   public boolean h;
   public boolean i;
   public boolean j;
   public int k;
   public b.b.g l;

   public static boolean a(i var0, b.f.e.b var1) {
      Iterator var6 = var0.b().iterator();
      boolean var2 = false;

      while(var6.hasNext()) {
         d var3 = (d)var6.next();
         if (var3 != null) {
            boolean var4;
            if (((b.f.i)var3.getLifecycle()).b.compareTo(b.f.e.b.d) >= 0) {
               var4 = true;
            } else {
               var4 = false;
            }

            boolean var5 = var2;
            if (var4) {
               var3.S.a(var1);
               var5 = true;
            }

            i var7 = var3.r();
            var2 = var5;
            if (var7 != null) {
               var2 = var5 | a(var7, var1);
            }
         }
      }

      return var2;
   }

   public static void b(int var0) {
      if ((var0 & -65536) != 0) {
         throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
      }
   }

   public final int a(d var1) {
      if (this.l.c() >= 65534) {
         IllegalStateException var4 = new IllegalStateException("Too many pending Fragment activity results.");
         throw var4;
      } else {
         while(true) {
            b.b.g var2 = this.l;
            int var3 = this.k;
            if (var2.a) {
               var2.b();
            }

            if (b.b.d.a(var2.b, var2.d, var3) < 0) {
               var3 = this.k;
               this.l.a(var3, var1.f);
               this.k = (this.k + 1) % '\ufffe';
               return var3;
            }

            this.k = (this.k + 1) % '\ufffe';
         }
      }
   }

   public final View a(View var1, String var2, Context var3, AttributeSet var4) {
      return this.c.a.d.onCreateView(var1, var2, var3, var4);
   }

   public i a() {
      return this.c.b();
   }

   public final void a(int var1) {
      if (!this.h && var1 != -1) {
         b(var1);
      }

   }

   public void a(d var1, Intent var2, int var3, Bundle var4) {
      this.j = true;
      Throwable var10000;
      boolean var10001;
      if (var3 == -1) {
         label55: {
            try {
               var3 = VERSION.SDK_INT;
               this.startActivityForResult(var2, -1, var4);
            } catch (Throwable var11) {
               var10000 = var11;
               var10001 = false;
               break label55;
            }

            this.j = false;
            return;
         }
      } else {
         label58: {
            try {
               b(var3);
               int var5 = this.a(var1);
               int var6 = VERSION.SDK_INT;
               this.startActivityForResult(var2, (var5 + 1 << 16) + (var3 & '\uffff'), var4);
            } catch (Throwable var12) {
               var10000 = var12;
               var10001 = false;
               break label58;
            }

            this.j = false;
            return;
         }
      }

      Throwable var13 = var10000;
      this.j = false;
      throw var13;
   }

   public void a(d var1, IntentSender var2, int var3, Intent var4, int var5, int var6, int var7, Bundle var8) {
      this.i = true;
      int var9;
      Throwable var10000;
      boolean var10001;
      if (var3 == -1) {
         label55: {
            try {
               var9 = VERSION.SDK_INT;
               this.startIntentSenderForResult(var2, var3, var4, var5, var6, var7, var8);
            } catch (Throwable var15) {
               var10000 = var15;
               var10001 = false;
               break label55;
            }

            this.i = false;
            return;
         }
      } else {
         label58: {
            try {
               b(var3);
               var9 = this.a(var1);
               int var10 = VERSION.SDK_INT;
               this.startIntentSenderForResult(var2, (var9 + 1 << 16) + (var3 & '\uffff'), var4, var5, var6, var7, var8);
            } catch (Throwable var16) {
               var10000 = var16;
               var10001 = false;
               break label58;
            }

            this.i = false;
            return;
         }
      }

      Throwable var17 = var10000;
      this.i = false;
      throw var17;
   }

   public void a(d var1, String[] var2, int var3) {
      if (var3 == -1) {
         b.c.b.a.a(this, var2, var3);
      } else {
         b(var3);

         try {
            this.h = true;
            b.c.b.a.a(this, var2, (this.a(var1) + 1 << 16) + (var3 & '\uffff'));
         } finally {
            this.h = false;
         }

      }
   }

   public boolean a(View var1, Menu var2) {
      return super.onPreparePanel(0, var1, var2);
   }

   @Deprecated
   public b.g.a.a b() {
      return b.g.a.a.a(this);
   }

   public void c() {
   }

   public void d() {
      this.c.a.d.m();
   }

   public void dump(String var1, FileDescriptor var2, PrintWriter var3, String[] var4) {
      super.dump(var1, var2, var3, var4);
      var3.print(var1);
      var3.print("Local FragmentActivity ");
      var3.print(Integer.toHexString(System.identityHashCode(this)));
      var3.println(" State:");
      StringBuilder var5 = new StringBuilder();
      var5.append(var1);
      var5.append("  ");
      String var6 = var5.toString();
      var3.print(var6);
      var3.print("mCreated=");
      var3.print(this.e);
      var3.print(" mResumed=");
      var3.print(this.f);
      var3.print(" mStopped=");
      var3.print(this.g);
      if (this.getApplication() != null) {
         ((b.g.a.b)b.g.a.a.a(this)).b.a(var6, var2, var3, var4);
      }

      this.c.b().a(var1, var2, var3, var4);
   }

   public Object e() {
      return null;
   }

   @Deprecated
   public void f() {
      this.invalidateOptionsMenu();
   }

   public b.f.e getLifecycle() {
      return super.a;
   }

   public b.f.u getViewModelStore() {
      if (this.getApplication() != null) {
         if (this.d == null) {
            e.c var1 = (e.c)this.getLastNonConfigurationInstance();
            if (var1 != null) {
               this.d = var1.a;
            }

            if (this.d == null) {
               this.d = new b.f.u();
            }
         }

         return this.d;
      } else {
         throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
      }
   }

   public void onActivityResult(int var1, int var2, Intent var3) {
      this.c.c();
      int var4 = var1 >> 16;
      if (var4 != 0) {
         --var4;
         String var5 = (String)this.l.a(var4);
         this.l.c(var4);
         if (var5 == null) {
            Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
         } else {
            d var6 = this.c.a.d.b(var5);
            if (var6 == null) {
               StringBuilder var7 = new StringBuilder();
               var7.append("Activity result no fragment exists for who: ");
               var7.append(var5);
               Log.w("FragmentActivity", var7.toString());
            } else {
               var6.onActivityResult(var1 & '\uffff', var2, var3);
            }

         }
      } else {
         super.onActivityResult(var1, var2, var3);
      }
   }

   public void onBackPressed() {
      i var1 = this.c.b();
      boolean var2 = var1.c();
      if (!var2 || VERSION.SDK_INT > 25) {
         if (var2 || !var1.d()) {
            super.onBackPressed();
         }

      }
   }

   public void onConfigurationChanged(Configuration var1) {
      super.onConfigurationChanged(var1);
      this.c.c();
      this.c.a.d.a(var1);
   }

   public void onCreate(Bundle var1) {
      h var2 = this.c.a;
      j var3 = var2.d;
      if (var3.m == null) {
         var3.m = var2;
         var3.n = var2;
         n var9 = null;
         var3.o = null;
         super.onCreate(var1);
         e.c var10 = (e.c)this.getLastNonConfigurationInstance();
         if (var10 != null) {
            b.f.u var4 = var10.a;
            if (var4 != null && this.d == null) {
               this.d = var4;
            }
         }

         if (var1 != null) {
            Parcelable var12 = var1.getParcelable("android:support:fragments");
            g var5 = this.c;
            if (var10 != null) {
               var9 = var10.b;
            }

            var5.a.d.a(var12, var9);
            if (var1.containsKey("android:support:next_request_index")) {
               this.k = var1.getInt("android:support:next_request_index");
               int[] var11 = var1.getIntArray("android:support:request_indicies");
               String[] var8 = var1.getStringArray("android:support:request_fragment_who");
               if (var11 != null && var8 != null && var11.length == var8.length) {
                  this.l = new b.b.g(var11.length);

                  for(int var6 = 0; var6 < var11.length; ++var6) {
                     this.l.a(var11[var6], var8[var6]);
                  }
               } else {
                  Log.w("FragmentActivity", "Invalid requestCode mapping in savedInstanceState.");
               }
            }
         }

         if (this.l == null) {
            this.l = new b.b.g(10);
            this.k = 0;
         }

         this.c.a.d.i();
      } else {
         IllegalStateException var7 = new IllegalStateException("Already attached");
         throw var7;
      }
   }

   public boolean onCreatePanelMenu(int var1, Menu var2) {
      if (var1 == 0) {
         boolean var3 = super.onCreatePanelMenu(var1, var2);
         g var4 = this.c;
         MenuInflater var5 = this.getMenuInflater();
         return var3 | var4.a.d.a(var2, var5);
      } else {
         return super.onCreatePanelMenu(var1, var2);
      }
   }

   public View onCreateView(View var1, String var2, Context var3, AttributeSet var4) {
      View var5 = this.a(var1, var2, var3, var4);
      return var5 == null ? super.onCreateView(var1, var2, var3, var4) : var5;
   }

   public View onCreateView(String var1, Context var2, AttributeSet var3) {
      View var4 = this.a((View)null, var1, var2, var3);
      return var4 == null ? super.onCreateView(var1, var2, var3) : var4;
   }

   public void onDestroy() {
      super.onDestroy();
      if (this.d != null && !this.isChangingConfigurations()) {
         this.d.a();
      }

      this.c.a.d.j();
   }

   public void onLowMemory() {
      super.onLowMemory();
      this.c.a.d.k();
   }

   public boolean onMenuItemSelected(int var1, MenuItem var2) {
      if (super.onMenuItemSelected(var1, var2)) {
         return true;
      } else if (var1 != 0) {
         return var1 != 6 ? false : this.c.a.d.a(var2);
      } else {
         return this.c.a.d.b(var2);
      }
   }

   public void onMultiWindowModeChanged(boolean var1) {
      this.c.a.d.a(var1);
   }

   public void onNewIntent(Intent var1) {
      super.onNewIntent(var1);
      this.c.c();
   }

   public void onPanelClosed(int var1, Menu var2) {
      if (var1 == 0) {
         this.c.a.d.a(var2);
      }

      super.onPanelClosed(var1, var2);
   }

   public void onPause() {
      super.onPause();
      this.f = false;
      if (this.b.hasMessages(2)) {
         this.b.removeMessages(2);
         this.d();
      }

      this.c.a.d.l();
   }

   public void onPictureInPictureModeChanged(boolean var1) {
      this.c.a.d.b(var1);
   }

   public void onPostResume() {
      super.onPostResume();
      this.b.removeMessages(2);
      this.d();
      this.c.a();
   }

   public boolean onPreparePanel(int var1, View var2, Menu var3) {
      return var1 == 0 && var3 != null ? this.a(var2, var3) | this.c.a.d.b(var3) : super.onPreparePanel(var1, var2, var3);
   }

   public void onRequestPermissionsResult(int var1, String[] var2, int[] var3) {
      this.c.c();
      int var4 = var1 >> 16 & '\uffff';
      if (var4 != 0) {
         --var4;
         String var5 = (String)this.l.a(var4);
         this.l.c(var4);
         if (var5 == null) {
            Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
            return;
         }

         d var6 = this.c.a.d.b(var5);
         if (var6 == null) {
            StringBuilder var7 = new StringBuilder();
            var7.append("Activity result no fragment exists for who: ");
            var7.append(var5);
            Log.w("FragmentActivity", var7.toString());
         } else {
            var6.onRequestPermissionsResult(var1 & '\uffff', var2, var3);
         }
      }

   }

   public void onResume() {
      super.onResume();
      this.b.sendEmptyMessage(2);
      this.f = true;
      this.c.a();
   }

   public final Object onRetainNonConfigurationInstance() {
      Object var1 = this.e();
      j var2 = this.c.a.d;
      b.d.a.j.a(var2.C);
      n var4 = var2.C;
      if (var4 == null && this.d == null && var1 == null) {
         return null;
      } else {
         e.c var3 = new e.c();
         var3.a = this.d;
         var3.b = var4;
         return var3;
      }
   }

   public void onSaveInstanceState(Bundle var1) {
      super.onSaveInstanceState(var1);

      while(a(this.a(), b.f.e.b.c)) {
      }

      Parcelable var2 = this.c.a.d.s();
      if (var2 != null) {
         var1.putParcelable("android:support:fragments", var2);
      }

      if (this.l.c() > 0) {
         var1.putInt("android:support:next_request_index", this.k);
         int[] var3 = new int[this.l.c()];
         String[] var5 = new String[this.l.c()];

         for(int var4 = 0; var4 < this.l.c(); ++var4) {
            var3[var4] = this.l.b(var4);
            var5[var4] = (String)this.l.d(var4);
         }

         var1.putIntArray("android:support:request_indicies", var3);
         var1.putStringArray("android:support:request_fragment_who", var5);
      }

   }

   public void onStart() {
      super.onStart();
      this.g = false;
      if (!this.e) {
         this.e = true;
         this.c.a.d.h();
      }

      this.c.c();
      this.c.a();
      this.c.a.d.n();
   }

   public void onStateNotSaved() {
      this.c.c();
   }

   public void onStop() {
      super.onStop();
      this.g = true;

      while(a(this.a(), b.f.e.b.c)) {
      }

      j var1 = this.c.a.d;
      var1.s = true;
      var1.a(2);
   }

   public void startActivityForResult(Intent var1, int var2) {
      if (!this.j && var2 != -1) {
         b(var2);
      }

      super.startActivityForResult(var1, var2);
   }

   public void startActivityForResult(Intent var1, int var2, Bundle var3) {
      if (!this.j && var2 != -1) {
         b(var2);
      }

      super.startActivityForResult(var1, var2, var3);
   }

   public void startIntentSenderForResult(IntentSender var1, int var2, Intent var3, int var4, int var5, int var6) {
      if (!this.i && var2 != -1) {
         b(var2);
      }

      super.startIntentSenderForResult(var1, var2, var3, var4, var5, var6);
   }

   public void startIntentSenderForResult(IntentSender var1, int var2, Intent var3, int var4, int var5, int var6, Bundle var7) {
      if (!this.i && var2 != -1) {
         b(var2);
      }

      super.startIntentSenderForResult(var1, var2, var3, var4, var5, var6, var7);
   }

   public class b extends h {
      public b() {
         super(e.this);
      }

      public View a(int var1) {
         return e.this.findViewById(var1);
      }

      public boolean a() {
         Window var1 = e.this.getWindow();
         boolean var2;
         if (var1 != null && var1.peekDecorView() != null) {
            var2 = true;
         } else {
            var2 = false;
         }

         return var2;
      }
   }

   public static final class c {
      public b.f.u a;
      public n b;
   }
}
