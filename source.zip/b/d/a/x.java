package b.d.a;

import android.view.View;
import java.util.ArrayList;

public class x implements Runnable {
   // $FF: synthetic field
   public final int a;
   // $FF: synthetic field
   public final ArrayList b;
   // $FF: synthetic field
   public final ArrayList c;
   // $FF: synthetic field
   public final ArrayList d;
   // $FF: synthetic field
   public final ArrayList e;

   public x(a0 var1, int var2, ArrayList var3, ArrayList var4, ArrayList var5, ArrayList var6) {
      this.a = var2;
      this.b = var3;
      this.c = var4;
      this.d = var5;
      this.e = var6;
   }

   public void run() {
      for(int var1 = 0; var1 < this.a; ++var1) {
         b.c.e.c.a((View)this.b.get(var1), (String)this.c.get(var1));
         b.c.e.c.a((View)this.d.get(var1), (String)this.e.get(var1));
      }

   }
}
