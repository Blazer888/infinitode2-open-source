package b.d.a;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public final class p implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public Object createFromParcel(Parcel var1) {
         return new p(var1);
      }

      public Object[] newArray(int var1) {
         return new p[var1];
      }
   };
   public final String a;
   public final int b;
   public final boolean c;
   public final int d;
   public final int e;
   public final String f;
   public final boolean g;
   public final boolean h;
   public final Bundle i;
   public final boolean j;
   public Bundle k;
   public d l;

   public p(Parcel var1) {
      this.a = var1.readString();
      this.b = var1.readInt();
      int var2 = var1.readInt();
      boolean var3 = true;
      boolean var4;
      if (var2 != 0) {
         var4 = true;
      } else {
         var4 = false;
      }

      this.c = var4;
      this.d = var1.readInt();
      this.e = var1.readInt();
      this.f = var1.readString();
      if (var1.readInt() != 0) {
         var4 = true;
      } else {
         var4 = false;
      }

      this.g = var4;
      if (var1.readInt() != 0) {
         var4 = true;
      } else {
         var4 = false;
      }

      this.h = var4;
      this.i = var1.readBundle();
      if (var1.readInt() != 0) {
         var4 = var3;
      } else {
         var4 = false;
      }

      this.j = var4;
      this.k = var1.readBundle();
   }

   public p(d var1) {
      this.a = var1.getClass().getName();
      this.b = var1.e;
      this.c = var1.m;
      this.d = var1.x;
      this.e = var1.y;
      this.f = var1.z;
      this.g = var1.C;
      this.h = var1.B;
      this.i = var1.g;
      this.j = var1.A;
   }

   public int describeContents() {
      return 0;
   }

   public void writeToParcel(Parcel var1, int var2) {
      var1.writeString(this.a);
      var1.writeInt(this.b);
      var1.writeInt(this.c);
      var1.writeInt(this.d);
      var1.writeInt(this.e);
      var1.writeString(this.f);
      var1.writeInt(this.g);
      var1.writeInt(this.h);
      var1.writeBundle(this.i);
      var1.writeInt(this.j);
      var1.writeBundle(this.k);
   }
}
