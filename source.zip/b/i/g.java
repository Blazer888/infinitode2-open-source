package b.i;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.database.Cursor;
import android.os.CancellationSignal;
import android.os.Looper;
import android.os.Build.VERSION;
import android.util.Log;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public abstract class g {
   @Deprecated
   public volatile b.j.a.b a;
   public Executor b;
   public b.j.a.c c;
   public final e d;
   public boolean e;
   public boolean f;
   @Deprecated
   public List g;
   public final ReentrantReadWriteLock h = new ReentrantReadWriteLock();
   public final ThreadLocal i = new ThreadLocal();

   public g() {
      new ConcurrentHashMap();
      this.d = this.d();
   }

   public Cursor a(b.j.a.e var1) {
      return this.a(var1, (CancellationSignal)null);
   }

   public Cursor a(b.j.a.e var1, CancellationSignal var2) {
      this.a();
      this.b();
      if (var2 != null) {
         int var3 = VERSION.SDK_INT;
         b.j.a.g.a var4 = (b.j.a.g.a)this.c.getWritableDatabase();
         return var4.a.rawQueryWithFactory(new b.j.a.g.b(var4, var1), var1.a(), b.j.a.g.a.b, (String)null, var2);
      } else {
         return ((b.j.a.g.a)this.c.getWritableDatabase()).a(var1);
      }
   }

   public abstract b.j.a.c a(b.i.a var1);

   public b.j.a.f a(String var1) {
      this.a();
      this.b();
      return new b.j.a.g.f(((b.j.a.g.a)this.c.getWritableDatabase()).a.compileStatement(var1));
   }

   public void a() {
      if (!this.e) {
         boolean var1;
         if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            var1 = true;
         } else {
            var1 = false;
         }

         if (var1) {
            throw new IllegalStateException("Cannot access database on the main thread since it may potentially lock the UI for a long period of time.");
         }
      }
   }

   public void a(b.j.a.b var1) {
      this.d.a(var1);
   }

   public void b() {
      if (!this.i() && this.i.get() != null) {
         throw new IllegalStateException("Cannot access database on a different coroutine context inherited from a suspending transaction.");
      }
   }

   public void b(b.i.a var1) {
      this.c = this.a(var1);
      b.j.a.c var2 = this.c;
      if (var2 instanceof j) {
         ((j)var2).f = var1;
      }

      int var3 = VERSION.SDK_INT;
      boolean var4;
      if (var1.g == g.c.c) {
         var4 = true;
      } else {
         var4 = false;
      }

      this.c.setWriteAheadLoggingEnabled(var4);
      this.g = var1.e;
      this.b = var1.h;
      new m(var1.i);
      this.e = var1.f;
      this.f = var4;
      if (var1.j) {
         e var5 = this.d;
         new f(var1.b, var1.c, var5, var5.d.h());
      }

   }

   @Deprecated
   public void c() {
      this.a();
      b.j.a.b var1 = this.c.getWritableDatabase();
      this.d.b(var1);
      ((b.j.a.g.a)var1).a.beginTransaction();
   }

   public abstract e d();

   @Deprecated
   public void e() {
      ((b.j.a.g.a)this.c.getWritableDatabase()).a.endTransaction();
      if (!this.i()) {
         e var1 = this.d;
         if (var1.e.compareAndSet(false, true)) {
            var1.d.h().execute(var1.j);
         }
      }

   }

   public Lock f() {
      return this.h.readLock();
   }

   public b.j.a.c g() {
      return this.c;
   }

   public Executor h() {
      return this.b;
   }

   public boolean i() {
      return ((b.j.a.g.a)this.c.getWritableDatabase()).a.inTransaction();
   }

   public boolean j() {
      b.j.a.b var1 = this.a;
      boolean var2;
      if (var1 != null && ((b.j.a.g.a)var1).a.isOpen()) {
         var2 = true;
      } else {
         var2 = false;
      }

      return var2;
   }

   @Deprecated
   public void k() {
      ((b.j.a.g.a)this.c.getWritableDatabase()).a.setTransactionSuccessful();
   }

   public static class a {
      public final Class a;
      public final String b;
      public final Context c;
      public ArrayList d;
      public Executor e;
      public Executor f;
      public b.j.a.c.c g;
      public boolean h;
      public g.c i;
      public boolean j;
      public boolean k;
      public boolean l;
      public final g.d m;
      public Set n;
      public Set o;
      public String p;
      public File q;

      public a(Context var1, Class var2, String var3) {
         this.c = var1;
         this.a = var2;
         this.b = var3;
         this.i = g.c.a;
         this.k = true;
         this.m = new g.d();
      }

      public g.a a(b.i.n.a... var1) {
         if (this.o == null) {
            this.o = new HashSet();
         }

         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            b.i.n.a var4 = var1[var3];
            this.o.add(var4.a);
            this.o.add(var4.b);
         }

         this.m.a(var1);
         return this;
      }
   }

   public abstract static class b {
      public void a() {
      }

      public void a(b.j.a.b var1) {
      }

      public void b() {
      }
   }

   public static enum c {
      a,
      b,
      c;

      @SuppressLint({"NewApi"})
      public g.c a(Context var1) {
         if (this != a) {
            return this;
         } else {
            int var2 = VERSION.SDK_INT;
            ActivityManager var4 = (ActivityManager)var1.getSystemService("activity");
            if (var4 != null) {
               boolean var3;
               if (VERSION.SDK_INT >= 19) {
                  var3 = var4.isLowRamDevice();
               } else {
                  var3 = false;
               }

               if (!var3) {
                  return c;
               }
            }

            return b;
         }
      }
   }

   public static class d {
      public HashMap a = new HashMap();

      public List a(int var1, int var2) {
         if (var1 == var2) {
            return Collections.emptyList();
         } else {
            boolean var3;
            if (var2 > var1) {
               var3 = true;
            } else {
               var3 = false;
            }

            ArrayList var4 = new ArrayList();

            ArrayList var11;
            while(true) {
               if (var3) {
                  if (var1 >= var2) {
                     break;
                  }
               } else if (var1 <= var2) {
                  break;
               }

               TreeMap var5 = (TreeMap)this.a.get(var1);
               Object var6 = null;
               if (var5 == null) {
                  var11 = (ArrayList)var6;
                  return var11;
               }

               Object var7;
               if (var3) {
                  var7 = var5.descendingKeySet();
               } else {
                  var7 = var5.keySet();
               }

               Iterator var10 = ((Set)var7).iterator();

               boolean var9;
               while(true) {
                  if (!var10.hasNext()) {
                     var9 = false;
                     break;
                  }

                  int var8;
                  label60: {
                     label59: {
                        var8 = (Integer)var10.next();
                        if (var3) {
                           if (var8 <= var2 && var8 > var1) {
                              break label59;
                           }
                        } else if (var8 >= var2 && var8 < var1) {
                           break label59;
                        }

                        var9 = false;
                        break label60;
                     }

                     var9 = true;
                  }

                  if (var9) {
                     var4.add(var5.get(var8));
                     var9 = true;
                     var1 = var8;
                     break;
                  }
               }

               if (!var9) {
                  var11 = (ArrayList)var6;
                  return var11;
               }
            }

            var11 = var4;
            return var11;
         }
      }

      public void a(b.i.n.a... var1) {
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            b.i.n.a var4 = var1[var3];
            int var5 = var4.a;
            int var6 = var4.b;
            TreeMap var7 = (TreeMap)this.a.get(var5);
            TreeMap var8 = var7;
            if (var7 == null) {
               var8 = new TreeMap();
               this.a.put(var5, var8);
            }

            b.i.n.a var9 = (b.i.n.a)var8.get(var6);
            if (var9 != null) {
               StringBuilder var10 = new StringBuilder();
               var10.append("Overriding migration ");
               var10.append(var9);
               var10.append(" with ");
               var10.append(var4);
               Log.w("ROOM", var10.toString());
            }

            var8.put(var6, var4);
         }

      }
   }
}
