package b.i;

import java.util.ArrayDeque;
import java.util.concurrent.Executor;

public class m implements Executor {
   public final Executor a;
   public final ArrayDeque b = new ArrayDeque();
   public Runnable c;

   public m(Executor var1) {
      this.a = var1;
   }

   public void a() {
      synchronized(this){}

      Throwable var10000;
      label75: {
         Runnable var1;
         boolean var10001;
         try {
            var1 = (Runnable)this.b.poll();
            this.c = var1;
         } catch (Throwable var7) {
            var10000 = var7;
            var10001 = false;
            break label75;
         }

         if (var1 == null) {
            return;
         }

         label66:
         try {
            this.a.execute(this.c);
            return;
         } catch (Throwable var6) {
            var10000 = var6;
            var10001 = false;
            break label66;
         }
      }

      Throwable var8 = var10000;
      throw var8;
   }

   public void execute(final Runnable var1) {
      synchronized(this){}

      try {
         ArrayDeque var2 = this.b;
         Runnable var3 = new Runnable() {
            public void run() {
               try {
                  var1.run();
               } finally {
                  m.this.a();
               }

            }
         };
         var2.offer(var3);
         if (this.c == null) {
            this.a();
         }
      } finally {
         ;
      }

   }
}
