package b.i.o;

import android.database.AbstractWindowedCursor;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.os.CancellationSignal;
import android.os.Build.VERSION;
import b.i.g;
import b.j.a.e;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class b {
   public static int a(File var0) {
      Object var1;
      FileChannel var10;
      try {
         var1 = ByteBuffer.allocate(4);
         FileInputStream var2 = new FileInputStream(var0);
         var10 = var2.getChannel();
      } finally {
         ;
      }

      try {
         var10.tryLock(60L, 4L, true);
         var10.position(60L);
         if (var10.read((ByteBuffer)var1) != 4) {
            var1 = new IOException("Bad database header, unable to read 4 bytes at offset 60");
            throw var1;
         }

         ((ByteBuffer)var1).rewind();
         int var3 = ((ByteBuffer)var1).getInt();
      } finally {
         if (var10 != null) {
            var10.close();
         }

         throw var1;
      }

   }

   public static Cursor a(g var0, e var1, boolean var2, CancellationSignal var3) {
      Cursor var97 = var0.a(var1, var3);
      if (var2 && var97 instanceof AbstractWindowedCursor) {
         AbstractWindowedCursor var96 = (AbstractWindowedCursor)var97;
         int var4 = var96.getCount();
         int var5;
         if (var96.hasWindow()) {
            var5 = var96.getWindow().getNumRows();
         } else {
            var5 = var4;
         }

         if (VERSION.SDK_INT < 23 || var5 < var4) {
            MatrixCursor var101;
            label937: {
               Throwable var10000;
               label936: {
                  boolean var10001;
                  try {
                     var101 = new MatrixCursor(var96.getColumnNames(), var96.getCount());
                  } catch (Throwable var94) {
                     var10000 = var94;
                     var10001 = false;
                     break label936;
                  }

                  label935:
                  while(true) {
                     Object[] var98;
                     try {
                        if (!var96.moveToNext()) {
                           break label937;
                        }

                        var98 = new Object[var96.getColumnCount()];
                     } catch (Throwable var92) {
                        var10000 = var92;
                        var10001 = false;
                        break;
                     }

                     var5 = 0;

                     while(true) {
                        label952: {
                           try {
                              if (var5 < var96.getColumnCount()) {
                                 var4 = var96.getType(var5);
                                 break label952;
                              }
                           } catch (Throwable var95) {
                              var10000 = var95;
                              var10001 = false;
                              break label935;
                           }

                           try {
                              var101.addRow(var98);
                              break;
                           } catch (Throwable var93) {
                              var10000 = var93;
                              var10001 = false;
                              break label935;
                           }
                        }

                        if (var4 != 0) {
                           if (var4 != 1) {
                              if (var4 != 2) {
                                 if (var4 != 3) {
                                    if (var4 != 4) {
                                       try {
                                          IllegalStateException var99 = new IllegalStateException();
                                          throw var99;
                                       } catch (Throwable var87) {
                                          var10000 = var87;
                                          var10001 = false;
                                          break label935;
                                       }
                                    }

                                    try {
                                       var98[var5] = var96.getBlob(var5);
                                    } catch (Throwable var91) {
                                       var10000 = var91;
                                       var10001 = false;
                                       break label935;
                                    }
                                 } else {
                                    try {
                                       var98[var5] = var96.getString(var5);
                                    } catch (Throwable var90) {
                                       var10000 = var90;
                                       var10001 = false;
                                       break label935;
                                    }
                                 }
                              } else {
                                 try {
                                    var98[var5] = var96.getDouble(var5);
                                 } catch (Throwable var89) {
                                    var10000 = var89;
                                    var10001 = false;
                                    break label935;
                                 }
                              }
                           } else {
                              try {
                                 var98[var5] = var96.getLong(var5);
                              } catch (Throwable var88) {
                                 var10000 = var88;
                                 var10001 = false;
                                 break label935;
                              }
                           }
                        } else {
                           var98[var5] = null;
                        }

                        ++var5;
                     }
                  }
               }

               Throwable var100 = var10000;
               var96.close();
               throw var100;
            }

            var96.close();
            return var101;
         }
      }

      return var97;
   }
}
