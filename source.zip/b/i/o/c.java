package b.i.o;

import android.database.Cursor;
import android.os.Build.VERSION;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class c {
   public final String a;
   public final Map b;
   public final Set c;
   public final Set d;

   public c(String var1, Map var2, Set var3, Set var4) {
      this.a = var1;
      this.b = Collections.unmodifiableMap(var2);
      this.c = Collections.unmodifiableSet(var3);
      Set var5;
      if (var4 == null) {
         var5 = null;
      } else {
         var5 = Collections.unmodifiableSet(var4);
      }

      this.d = var5;
   }

   public static b.i.o.c.d a(b.j.a.b var0, String var1, boolean var2) {
      String var3 = c.a.b.a.a.a("PRAGMA index_xinfo(`", var1, "`)");
      Cursor var38 = ((b.j.a.g.a)var0).a(var3);

      Throwable var10000;
      label346: {
         int var4;
         int var5;
         int var6;
         boolean var10001;
         try {
            var4 = var38.getColumnIndex("seqno");
            var5 = var38.getColumnIndex("cid");
            var6 = var38.getColumnIndex("name");
         } catch (Throwable var37) {
            var10000 = var37;
            var10001 = false;
            break label346;
         }

         if (var4 == -1 || var5 == -1 || var6 == -1) {
            var38.close();
            return null;
         }

         TreeMap var7;
         try {
            var7 = new TreeMap();
         } catch (Throwable var35) {
            var10000 = var35;
            var10001 = false;
            break label346;
         }

         label330:
         while(true) {
            while(true) {
               try {
                  if (!var38.moveToNext()) {
                     break label330;
                  }

                  if (var38.getInt(var5) < 0) {
                     continue;
                  }
               } catch (Throwable var36) {
                  var10000 = var36;
                  var10001 = false;
                  break label346;
               }

               try {
                  var7.put(var38.getInt(var4), var38.getString(var6));
               } catch (Throwable var34) {
                  var10000 = var34;
                  var10001 = false;
                  break label346;
               }
            }
         }

         b.i.o.c.d var40;
         try {
            ArrayList var41 = new ArrayList(var7.size());
            var41.addAll(var7.values());
            var40 = new b.i.o.c.d(var1, var2, var41);
         } catch (Throwable var33) {
            var10000 = var33;
            var10001 = false;
            break label346;
         }

         var38.close();
         return var40;
      }

      Throwable var39 = var10000;
      var38.close();
      throw var39;
   }

   public static b.i.o.c a(b.j.a.b var0, String var1) {
      String var2 = c.a.b.a.a.a("PRAGMA table_info(`", var1, "`)");
      b.j.a.g.a var3 = (b.j.a.g.a)var0;
      Cursor var259 = var3.a(var2);
      HashMap var4 = new HashMap();

      int var5;
      int var6;
      int var7;
      int var8;
      int var9;
      String var10;
      boolean var12;
      int var13;
      Throwable var10000;
      boolean var10001;
      label2712: {
         label2716: {
            try {
               var5 = var259.getColumnCount();
            } catch (Throwable var258) {
               var10000 = var258;
               var10001 = false;
               break label2716;
            }

            if (var5 <= 0) {
               break label2712;
            }

            try {
               var5 = var259.getColumnIndex("name");
               var6 = var259.getColumnIndex("type");
               var7 = var259.getColumnIndex("notnull");
               var8 = var259.getColumnIndex("pk");
               var9 = var259.getColumnIndex("dflt_value");
            } catch (Throwable var257) {
               var10000 = var257;
               var10001 = false;
               break label2716;
            }

            while(true) {
               String var11;
               label2702: {
                  label2701: {
                     try {
                        if (!var259.moveToNext()) {
                           break label2712;
                        }

                        var10 = var259.getString(var5);
                        var11 = var259.getString(var6);
                        if (var259.getInt(var7) != 0) {
                           break label2701;
                        }
                     } catch (Throwable var256) {
                        var10000 = var256;
                        var10001 = false;
                        break;
                     }

                     var12 = false;
                     break label2702;
                  }

                  var12 = true;
               }

               try {
                  var13 = var259.getInt(var8);
                  String var14 = var259.getString(var9);
                  b.i.o.c.a var265 = new b.i.o.c.a(var10, var11, var12, var13, var14, 2);
                  var4.put(var10, var265);
               } catch (Throwable var255) {
                  var10000 = var255;
                  var10001 = false;
                  break;
               }
            }
         }

         Throwable var262 = var10000;
         var259.close();
         throw var262;
      }

      var259.close();
      HashSet var270 = new HashSet();
      StringBuilder var260 = new StringBuilder();
      var260.append("PRAGMA foreign_key_list(`");
      var260.append(var1);
      var260.append("`)");
      Cursor var266 = var3.a(var260.toString());

      Throwable var263;
      label2718: {
         List var261;
         int var15;
         try {
            var7 = var266.getColumnIndex("id");
            var6 = var266.getColumnIndex("seq");
            var15 = var266.getColumnIndex("table");
            var13 = var266.getColumnIndex("on_delete");
            var8 = var266.getColumnIndex("on_update");
            var261 = a(var266);
            var5 = var266.getCount();
         } catch (Throwable var254) {
            var10000 = var254;
            var10001 = false;
            break label2718;
         }

         var9 = 0;

         label2683:
         while(true) {
            if (var9 >= var5) {
               var266.close();
               var260 = new StringBuilder();
               var260.append("PRAGMA index_list(`");
               var260.append(var1);
               var260.append("`)");
               Cursor var272 = var3.a(var260.toString());

               label2736: {
                  try {
                     var6 = var272.getColumnIndex("name");
                     var7 = var272.getColumnIndex("origin");
                     var5 = var272.getColumnIndex("unique");
                  } catch (Throwable var249) {
                     var10000 = var249;
                     var10001 = false;
                     break label2736;
                  }

                  HashSet var264;
                  HashSet var267;
                  label2737: {
                     var264 = null;
                     if (var6 != -1 && var7 != -1 && var5 != -1) {
                        try {
                           var267 = new HashSet();
                        } catch (Throwable var246) {
                           var10000 = var246;
                           var10001 = false;
                           break label2736;
                        }

                        label2651:
                        while(true) {
                           while(true) {
                              try {
                                 if (!var272.moveToNext()) {
                                    break label2737;
                                 }

                                 if (!"c".equals(var272.getString(var7))) {
                                    continue;
                                 }
                              } catch (Throwable var247) {
                                 var10000 = var247;
                                 var10001 = false;
                                 break label2736;
                              }

                              label2646: {
                                 label2645: {
                                    try {
                                       var10 = var272.getString(var6);
                                       if (var272.getInt(var5) == 1) {
                                          break label2645;
                                       }
                                    } catch (Throwable var248) {
                                       var10000 = var248;
                                       var10001 = false;
                                       break label2736;
                                    }

                                    var12 = false;
                                    break label2646;
                                 }

                                 var12 = true;
                              }

                              b.i.o.c.d var269;
                              try {
                                 var269 = a(var3, var10, var12);
                              } catch (Throwable var244) {
                                 var10000 = var244;
                                 var10001 = false;
                                 break label2736;
                              }

                              if (var269 == null) {
                                 break label2651;
                              }

                              try {
                                 var267.add(var269);
                              } catch (Throwable var245) {
                                 var10000 = var245;
                                 var10001 = false;
                                 break label2736;
                              }
                           }
                        }
                     }

                     var272.close();
                     return new b.i.o.c(var1, var4, var270, var264);
                  }

                  var272.close();
                  var264 = var267;
                  return new b.i.o.c(var1, var4, var270, var264);
               }

               var263 = var10000;
               var272.close();
               throw var263;
            }

            label2724: {
               try {
                  var266.moveToPosition(var9);
                  if (var266.getInt(var6) != 0) {
                     break label2724;
                  }
               } catch (Throwable var253) {
                  var10000 = var253;
                  var10001 = false;
                  break;
               }

               ArrayList var268;
               ArrayList var271;
               int var16;
               Iterator var17;
               try {
                  var16 = var266.getInt(var7);
                  var271 = new ArrayList();
                  var268 = new ArrayList();
                  var17 = var261.iterator();
               } catch (Throwable var251) {
                  var10000 = var251;
                  var10001 = false;
                  break;
               }

               while(true) {
                  try {
                     if (!var17.hasNext()) {
                        break;
                     }

                     b.i.o.c.c var18 = (b.i.o.c.c)var17.next();
                     if (var18.a == var16) {
                        var271.add(var18.c);
                        var268.add(var18.d);
                     }
                  } catch (Throwable var252) {
                     var10000 = var252;
                     var10001 = false;
                     break label2683;
                  }
               }

               try {
                  b.i.o.c.b var273 = new b.i.o.c.b(var266.getString(var15), var266.getString(var13), var266.getString(var8), var271, var268);
                  var270.add(var273);
               } catch (Throwable var250) {
                  var10000 = var250;
                  var10001 = false;
                  break;
               }
            }

            ++var9;
         }
      }

      var263 = var10000;
      var266.close();
      throw var263;
   }

   public static List a(Cursor var0) {
      int var1 = var0.getColumnIndex("id");
      int var2 = var0.getColumnIndex("seq");
      int var3 = var0.getColumnIndex("from");
      int var4 = var0.getColumnIndex("to");
      int var5 = var0.getCount();
      ArrayList var6 = new ArrayList();

      for(int var7 = 0; var7 < var5; ++var7) {
         var0.moveToPosition(var7);
         var6.add(new b.i.o.c.c(var0.getInt(var1), var0.getInt(var2), var0.getString(var3), var0.getString(var4)));
      }

      Collections.sort(var6);
      return var6;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && b.i.o.c.class == var1.getClass()) {
         b.i.o.c var3 = (b.i.o.c)var1;
         String var2 = this.a;
         if (var2 != null) {
            if (!var2.equals(var3.a)) {
               return false;
            }
         } else if (var3.a != null) {
            return false;
         }

         label46: {
            Map var5 = this.b;
            if (var5 != null) {
               if (var5.equals(var3.b)) {
                  break label46;
               }
            } else if (var3.b == null) {
               break label46;
            }

            return false;
         }

         Set var6;
         label39: {
            var6 = this.c;
            if (var6 != null) {
               if (var6.equals(var3.c)) {
                  break label39;
               }
            } else if (var3.c == null) {
               break label39;
            }

            return false;
         }

         var6 = this.d;
         if (var6 != null) {
            Set var4 = var3.d;
            if (var4 != null) {
               return var6.equals(var4);
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public int hashCode() {
      String var1 = this.a;
      int var2 = 0;
      int var3;
      if (var1 != null) {
         var3 = var1.hashCode();
      } else {
         var3 = 0;
      }

      Map var5 = this.b;
      int var4;
      if (var5 != null) {
         var4 = var5.hashCode();
      } else {
         var4 = 0;
      }

      Set var6 = this.c;
      if (var6 != null) {
         var2 = var6.hashCode();
      }

      return (var3 * 31 + var4) * 31 + var2;
   }

   public String toString() {
      StringBuilder var1 = c.a.b.a.a.b("TableInfo{name='");
      c.a.b.a.a.a(var1, this.a, '\'', ", columns=");
      var1.append(this.b);
      var1.append(", foreignKeys=");
      var1.append(this.c);
      var1.append(", indices=");
      var1.append(this.d);
      var1.append('}');
      return var1.toString();
   }

   public static class a {
      public final String a;
      public final String b;
      public final int c;
      public final boolean d;
      public final int e;
      public final String f;
      public final int g;

      public a(String var1, String var2, boolean var3, int var4, String var5, int var6) {
         this.a = var1;
         this.b = var2;
         this.d = var3;
         this.e = var4;
         byte var7 = 5;
         if (var2 != null) {
            var1 = var2.toUpperCase(Locale.US);
            if (var1.contains("INT")) {
               var7 = 3;
            } else if (!var1.contains("CHAR") && !var1.contains("CLOB") && !var1.contains("TEXT")) {
               if (!var1.contains("BLOB")) {
                  if (!var1.contains("REAL") && !var1.contains("FLOA") && !var1.contains("DOUB")) {
                     var7 = 1;
                  } else {
                     var7 = 4;
                  }
               }
            } else {
               var7 = 2;
            }
         }

         this.c = var7;
         this.f = var5;
         this.g = var6;
      }

      public boolean equals(Object var1) {
         boolean var2 = true;
         if (this == var1) {
            return true;
         } else if (var1 != null && b.i.o.c.a.class == var1.getClass()) {
            b.i.o.c.a var6 = (b.i.o.c.a)var1;
            if (VERSION.SDK_INT >= 20) {
               if (this.e != var6.e) {
                  return false;
               }
            } else {
               boolean var3;
               if (this.e > 0) {
                  var3 = true;
               } else {
                  var3 = false;
               }

               boolean var4;
               if (var6.e > 0) {
                  var4 = true;
               } else {
                  var4 = false;
               }

               if (var3 != var4) {
                  return false;
               }
            }

            if (!this.a.equals(var6.a)) {
               return false;
            } else if (this.d != var6.d) {
               return false;
            } else {
               String var5;
               if (this.g == 1 && var6.g == 2) {
                  var5 = this.f;
                  if (var5 != null && !var5.equals(var6.f)) {
                     return false;
                  }
               }

               if (this.g == 2 && var6.g == 1) {
                  var5 = var6.f;
                  if (var5 != null && !var5.equals(this.f)) {
                     return false;
                  }
               }

               int var7 = this.g;
               if (var7 != 0 && var7 == var6.g) {
                  var5 = this.f;
                  if (var5 != null) {
                     if (!var5.equals(var6.f)) {
                        return false;
                     }
                  } else if (var6.f != null) {
                     return false;
                  }
               }

               if (this.c != var6.c) {
                  var2 = false;
               }

               return var2;
            }
         } else {
            return false;
         }
      }

      public int hashCode() {
         int var1 = this.a.hashCode();
         int var2 = this.c;
         short var3;
         if (this.d) {
            var3 = 1231;
         } else {
            var3 = 1237;
         }

         return ((var1 * 31 + var2) * 31 + var3) * 31 + this.e;
      }

      public String toString() {
         StringBuilder var1 = c.a.b.a.a.b("Column{name='");
         c.a.b.a.a.a(var1, this.a, '\'', ", type='");
         c.a.b.a.a.a(var1, this.b, '\'', ", affinity='");
         var1.append(this.c);
         var1.append('\'');
         var1.append(", notNull=");
         var1.append(this.d);
         var1.append(", primaryKeyPosition=");
         var1.append(this.e);
         var1.append(", defaultValue='");
         var1.append(this.f);
         var1.append('\'');
         var1.append('}');
         return var1.toString();
      }
   }

   public static class b {
      public final String a;
      public final String b;
      public final String c;
      public final List d;
      public final List e;

      public b(String var1, String var2, String var3, List var4, List var5) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = Collections.unmodifiableList(var4);
         this.e = Collections.unmodifiableList(var5);
      }

      public boolean equals(Object var1) {
         if (this == var1) {
            return true;
         } else if (var1 != null && b.i.o.c.b.class == var1.getClass()) {
            b.i.o.c.b var2 = (b.i.o.c.b)var1;
            if (!this.a.equals(var2.a)) {
               return false;
            } else if (!this.b.equals(var2.b)) {
               return false;
            } else if (!this.c.equals(var2.c)) {
               return false;
            } else {
               return !this.d.equals(var2.d) ? false : this.e.equals(var2.e);
            }
         } else {
            return false;
         }
      }

      public int hashCode() {
         int var1 = this.a.hashCode();
         int var2 = this.b.hashCode();
         int var3 = this.c.hashCode();
         int var4 = this.d.hashCode();
         return this.e.hashCode() + (var4 + (var3 + (var2 + var1 * 31) * 31) * 31) * 31;
      }

      public String toString() {
         StringBuilder var1 = c.a.b.a.a.b("ForeignKey{referenceTable='");
         c.a.b.a.a.a(var1, this.a, '\'', ", onDelete='");
         c.a.b.a.a.a(var1, this.b, '\'', ", onUpdate='");
         c.a.b.a.a.a(var1, this.c, '\'', ", columnNames=");
         var1.append(this.d);
         var1.append(", referenceColumnNames=");
         var1.append(this.e);
         var1.append('}');
         return var1.toString();
      }
   }

   public static class c implements Comparable {
      public final int a;
      public final int b;
      public final String c;
      public final String d;

      public c(int var1, int var2, String var3, String var4) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
      }

      public int compareTo(Object var1) {
         b.i.o.c.c var4 = (b.i.o.c.c)var1;
         int var2 = this.a - var4.a;
         int var3 = var2;
         if (var2 == 0) {
            var3 = this.b - var4.b;
         }

         return var3;
      }
   }

   public static class d {
      public final String a;
      public final boolean b;
      public final List c;

      public d(String var1, boolean var2, List var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }

      public boolean equals(Object var1) {
         if (this == var1) {
            return true;
         } else if (var1 != null && b.i.o.c.d.class == var1.getClass()) {
            b.i.o.c.d var2 = (b.i.o.c.d)var1;
            if (this.b != var2.b) {
               return false;
            } else if (!this.c.equals(var2.c)) {
               return false;
            } else {
               return this.a.startsWith("index_") ? var2.a.startsWith("index_") : this.a.equals(var2.a);
            }
         } else {
            return false;
         }
      }

      public int hashCode() {
         int var1;
         if (this.a.startsWith("index_")) {
            var1 = "index_".hashCode();
         } else {
            var1 = this.a.hashCode();
         }

         byte var2 = this.b;
         return this.c.hashCode() + (var1 * 31 + var2) * 31;
      }

      public String toString() {
         StringBuilder var1 = c.a.b.a.a.b("Index{name='");
         c.a.b.a.a.a(var1, this.a, '\'', ", unique=");
         var1.append(this.b);
         var1.append(", columns=");
         var1.append(this.c);
         var1.append('}');
         return var1.toString();
      }
   }
}
