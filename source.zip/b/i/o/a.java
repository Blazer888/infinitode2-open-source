package b.i.o;

import java.io.File;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class a {
   public static final Map e = new HashMap();
   public final File a;
   public final Lock b;
   public final boolean c;
   public FileChannel d;

   public a(String var1, File var2, boolean var3) {
      this.a = new File(var2, c.a.b.a.a.a(var1, ".lck"));
      this.b = a(this.a.getAbsolutePath());
      this.c = var3;
   }

   public static Lock a(String var0) {
      Map var1 = e;
      synchronized(var1){}

      Throwable var10000;
      boolean var10001;
      label176: {
         Lock var2;
         try {
            var2 = (Lock)e.get(var0);
         } catch (Throwable var23) {
            var10000 = var23;
            var10001 = false;
            break label176;
         }

         Object var3 = var2;
         if (var2 == null) {
            try {
               var3 = new ReentrantLock();
               e.put(var0, var3);
            } catch (Throwable var22) {
               var10000 = var22;
               var10001 = false;
               break label176;
            }
         }

         label165:
         try {
            return (Lock)var3;
         } catch (Throwable var21) {
            var10000 = var21;
            var10001 = false;
            break label165;
         }
      }

      while(true) {
         Throwable var24 = var10000;

         try {
            throw var24;
         } catch (Throwable var20) {
            var10000 = var20;
            var10001 = false;
            continue;
         }
      }
   }

   public void a() {
      FileChannel var1 = this.d;
      if (var1 != null) {
         try {
            var1.close();
         } catch (IOException var2) {
         }
      }

      this.b.unlock();
   }
}
