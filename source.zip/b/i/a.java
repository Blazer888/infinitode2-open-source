package b.i;

import android.content.Context;
import java.io.File;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;

public class a {
   public final b.j.a.c.c a;
   public final Context b;
   public final String c;
   public final g.d d;
   public final List e;
   public final boolean f;
   public final g.c g;
   public final Executor h;
   public final Executor i;
   public final boolean j;
   public final boolean k;
   public final boolean l;
   public final Set m;

   public a(Context var1, String var2, b.j.a.c.c var3, g.d var4, List var5, boolean var6, g.c var7, Executor var8, Executor var9, boolean var10, boolean var11, boolean var12, Set var13, String var14, File var15) {
      this.a = var3;
      this.b = var1;
      this.c = var2;
      this.d = var4;
      this.e = var5;
      this.f = var6;
      this.g = var7;
      this.h = var8;
      this.i = var9;
      this.j = var10;
      this.k = var11;
      this.l = var12;
      this.m = var13;
   }

   public boolean a(int var1, int var2) {
      boolean var3 = true;
      boolean var6;
      if (var1 > var2) {
         var6 = true;
      } else {
         var6 = false;
      }

      if (var6 && this.l) {
         return false;
      } else {
         boolean var5;
         if (this.k) {
            Set var4 = this.m;
            var5 = var3;
            if (var4 == null) {
               return var5;
            }

            if (!var4.contains(var1)) {
               var5 = var3;
               return var5;
            }
         }

         var5 = false;
         return var5;
      }
   }
}
