package b.i;

public abstract class b extends l {
   public b(g var1) {
      super(var1);
   }

   public abstract void a(b.j.a.f var1, Object var2);

   public final void a(Object var1) {
      b.j.a.f var2 = this.a();
      boolean var4 = false;

      try {
         var4 = true;
         this.a(var2, var1);
         ((b.j.a.g.f)var2).b.executeInsert();
         var4 = false;
      } finally {
         if (var4) {
            this.a(var2);
         }
      }

      if (var2 == super.c) {
         super.a.set(false);
      }

   }
}
