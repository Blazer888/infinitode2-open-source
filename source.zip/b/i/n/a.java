package b.i.n;

import b.j.a.b;

public abstract class a {
   public final int a;
   public final int b;

   public a(int var1, int var2) {
      this.a = var1;
      this.b = var2;
   }

   public abstract void a(b var1);
}
