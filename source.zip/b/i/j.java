package b.i;

import android.content.Context;
import android.os.Build.VERSION;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;

public class j implements b.j.a.c {
   public final Context a;
   public final String b;
   public final File c;
   public final int d;
   public final b.j.a.c e;
   public b.i.a f;
   public boolean g;

   public j(Context var1, String var2, File var3, int var4, b.j.a.c var5) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
   }

   public final void a() {
      // $FF: Couldn't be decompiled
   }

   public final void a(File var1) {
      Object var2;
      File var41;
      if (this.b != null) {
         var2 = Channels.newChannel(this.a.getAssets().open(this.b));
      } else {
         var41 = this.c;
         if (var41 == null) {
            IllegalStateException var40 = new IllegalStateException("copyFromAssetPath and copyFromFile == null!");
            throw var40;
         }

         var2 = (new FileInputStream(var41)).getChannel();
      }

      File var3 = File.createTempFile("room-copy-helper", ".tmp", this.a.getCacheDir());
      var3.deleteOnExit();
      FileChannel var4 = (new FileOutputStream(var3)).getChannel();

      label414: {
         Throwable var10000;
         label413: {
            boolean var10001;
            label420: {
               try {
                  if (VERSION.SDK_INT > 23) {
                     var4.transferFrom((ReadableByteChannel)var2, 0L, Long.MAX_VALUE);
                     break label420;
                  }
               } catch (Throwable var38) {
                  var10000 = var38;
                  var10001 = false;
                  break label413;
               }

               InputStream var5;
               OutputStream var6;
               byte[] var7;
               try {
                  var5 = Channels.newInputStream((ReadableByteChannel)var2);
                  var6 = Channels.newOutputStream(var4);
                  var7 = new byte[4096];
               } catch (Throwable var37) {
                  var10000 = var37;
                  var10001 = false;
                  break label413;
               }

               while(true) {
                  int var8;
                  try {
                     var8 = var5.read(var7);
                  } catch (Throwable var35) {
                     var10000 = var35;
                     var10001 = false;
                     break label413;
                  }

                  if (var8 <= 0) {
                     break;
                  }

                  try {
                     var6.write(var7, 0, var8);
                  } catch (Throwable var36) {
                     var10000 = var36;
                     var10001 = false;
                     break label413;
                  }
               }
            }

            label395:
            try {
               var4.force(false);
               break label414;
            } catch (Throwable var34) {
               var10000 = var34;
               var10001 = false;
               break label395;
            }
         }

         Throwable var39 = var10000;
         ((ReadableByteChannel)var2).close();
         var4.close();
         throw var39;
      }

      ((ReadableByteChannel)var2).close();
      var4.close();
      var41 = var1.getParentFile();
      StringBuilder var42;
      if (var41 != null && !var41.exists() && !var41.mkdirs()) {
         var42 = c.a.b.a.a.b("Failed to create directories for ");
         var42.append(var1.getAbsolutePath());
         throw new IOException(var42.toString());
      } else if (!var3.renameTo(var1)) {
         var42 = c.a.b.a.a.b("Failed to move intermediate file (");
         var42.append(var3.getAbsolutePath());
         var42.append(") to destination (");
         var42.append(var1.getAbsolutePath());
         var42.append(").");
         throw new IOException(var42.toString());
      }
   }

   public void close() {
      synchronized(this){}

      try {
         this.e.close();
         this.g = false;
      } finally {
         ;
      }

   }

   public String getDatabaseName() {
      return this.e.getDatabaseName();
   }

   public b.j.a.b getWritableDatabase() {
      synchronized(this){}

      b.j.a.b var1;
      try {
         if (!this.g) {
            this.a();
            this.g = true;
         }

         var1 = this.e.getWritableDatabase();
      } finally {
         ;
      }

      return var1;
   }

   public void setWriteAheadLoggingEnabled(boolean var1) {
      this.e.setWriteAheadLoggingEnabled(var1);
   }
}
