package b.i;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.util.Log;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;

public class e {
   public static final String[] k = new String[]{"UPDATE", "DELETE", "INSERT"};
   public final HashMap a;
   public final String[] b;
   public Map c;
   public final g d;
   public AtomicBoolean e;
   public volatile boolean f;
   public volatile b.j.a.f g;
   public e.b h;
   @SuppressLint({"RestrictedApi"})
   public final b.a.a.b.b i;
   public Runnable j;

   public e(g var1, Map var2, Map var3, String... var4) {
      int var5 = 0;
      this.e = new AtomicBoolean(false);
      this.f = false;
      this.i = new b.a.a.b.b();
      this.j = new Runnable() {
         public final Set a() {
            HashSet var1 = new HashSet();
            Cursor var2 = e.this.d.a((b.j.a.e)(new b.j.a.a("SELECT * FROM room_table_modification_log WHERE invalidated = 1;")));

            while(true) {
               boolean var4 = false;

               try {
                  var4 = true;
                  if (!var2.moveToNext()) {
                     var4 = false;
                     break;
                  }

                  var1.add(var2.getInt(0));
                  var4 = false;
               } finally {
                  if (var4) {
                     var2.close();
                  }
               }
            }

            var2.close();
            if (!var1.isEmpty()) {
               ((b.j.a.g.f)e.this.g).a();
            }

            return var1;
         }

         public void run() {
            // $FF: Couldn't be decompiled
         }
      };
      this.d = var1;
      this.h = new e.b(var4.length);
      this.a = new HashMap();
      this.c = var3;
      Collections.newSetFromMap(new IdentityHashMap());
      int var6 = var4.length;

      for(this.b = new String[var6]; var5 < var6; ++var5) {
         String var10 = var4[var5].toLowerCase(Locale.US);
         this.a.put(var10, var5);
         String var7 = (String)var2.get(var4[var5]);
         if (var7 != null) {
            this.b[var5] = var7.toLowerCase(Locale.US);
         } else {
            this.b[var5] = var10;
         }
      }

      Iterator var8 = var2.entrySet().iterator();

      while(var8.hasNext()) {
         Entry var11 = (Entry)var8.next();
         String var9 = ((String)var11.getValue()).toLowerCase(Locale.US);
         if (this.a.containsKey(var9)) {
            String var13 = ((String)var11.getKey()).toLowerCase(Locale.US);
            HashMap var12 = this.a;
            var12.put(var13, var12.get(var9));
         }
      }

   }

   @SuppressLint({"RestrictedApi"})
   public void a(e.c param1) {
      // $FF: Couldn't be decompiled
   }

   public void a(b.j.a.b var1) {
      synchronized(this){}

      Throwable var10000;
      boolean var10001;
      label197: {
         try {
            if (this.f) {
               Log.e("ROOM", "Invalidation tracker is initialized twice :/.");
               return;
            }
         } catch (Throwable var22) {
            var10000 = var22;
            var10001 = false;
            break label197;
         }

         try {
            ((b.j.a.g.a)var1).a.execSQL("PRAGMA temp_store = MEMORY;");
            ((b.j.a.g.a)var1).a.execSQL("PRAGMA recursive_triggers='ON';");
            ((b.j.a.g.a)var1).a.execSQL("CREATE TEMP TABLE room_table_modification_log(table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)");
            this.b(var1);
         } catch (Throwable var21) {
            var10000 = var21;
            var10001 = false;
            break label197;
         }

         b.j.a.g.a var2 = (b.j.a.g.a)var1;

         label183:
         try {
            b.j.a.g.f var24 = new b.j.a.g.f(var2.a.compileStatement("UPDATE room_table_modification_log SET invalidated = 0 WHERE invalidated = 1 "));
            this.g = var24;
            this.f = true;
            return;
         } catch (Throwable var20) {
            var10000 = var20;
            var10001 = false;
            break label183;
         }
      }

      while(true) {
         Throwable var23 = var10000;

         try {
            throw var23;
         } catch (Throwable var19) {
            var10000 = var19;
            var10001 = false;
            continue;
         }
      }
   }

   public final void a(b.j.a.b var1, int var2) {
      String var3 = c.a.b.a.a.a("INSERT OR IGNORE INTO room_table_modification_log VALUES(", var2, ", 0)");
      b.j.a.g.a var9 = (b.j.a.g.a)var1;
      var9.a.execSQL(var3);
      var3 = this.b[var2];
      StringBuilder var4 = new StringBuilder();
      String[] var5 = k;
      int var6 = var5.length;

      for(int var7 = 0; var7 < var6; ++var7) {
         String var8 = var5[var7];
         var4.setLength(0);
         var4.append("CREATE TEMP TRIGGER IF NOT EXISTS ");
         var4.append("`");
         var4.append("room_table_modification_trigger_");
         var4.append(var3);
         var4.append("_");
         var4.append(var8);
         var4.append("`");
         var4.append(" AFTER ");
         var4.append(var8);
         var4.append(" ON `");
         var4.append(var3);
         var4.append("` BEGIN UPDATE ");
         var4.append("room_table_modification_log");
         var4.append(" SET ");
         var4.append("invalidated");
         var4.append(" = 1");
         var4.append(" WHERE ");
         var4.append("table_id");
         var4.append(" = ");
         var4.append(var2);
         var4.append(" AND ");
         var4.append("invalidated");
         var4.append(" = 0");
         var4.append("; END");
         var8 = var4.toString();
         var9.a.execSQL(var8);
      }

   }

   public void a(String... var1) {
      b.a.a.b.b var23 = this.i;
      synchronized(var23){}

      Throwable var10000;
      boolean var10001;
      label200: {
         Iterator var2;
         try {
            var2 = this.i.iterator();
         } catch (Throwable var21) {
            var10000 = var21;
            var10001 = false;
            break label200;
         }

         while(true) {
            try {
               if (var2.hasNext()) {
                  ((e.c)((Entry)var2.next()).getKey()).a();
                  continue;
               }
            } catch (Throwable var22) {
               var10000 = var22;
               var10001 = false;
               break;
            }

            try {
               return;
            } catch (Throwable var20) {
               var10000 = var20;
               var10001 = false;
               break;
            }
         }
      }

      while(true) {
         Throwable var24 = var10000;

         try {
            throw var24;
         } catch (Throwable var19) {
            var10000 = var19;
            var10001 = false;
            continue;
         }
      }
   }

   public boolean a() {
      if (!this.d.j()) {
         return false;
      } else {
         if (!this.f) {
            this.d.g().getWritableDatabase();
         }

         if (!this.f) {
            Log.e("ROOM", "database is not initialized even though it is open");
            return false;
         } else {
            return true;
         }
      }
   }

   public void b() {
      if (this.d.j()) {
         this.b(this.d.g().getWritableDatabase());
      }
   }

   @SuppressLint({"RestrictedApi"})
   public void b(e.c param1) {
      // $FF: Couldn't be decompiled
   }

   public void b(b.j.a.b var1) {
      b.j.a.g.a var2 = (b.j.a.g.a)var1;
      if (!var2.a.inTransaction()) {
         while(true) {
            Object var128;
            label796: {
               IllegalStateException var131;
               label795: {
                  SQLiteException var10000;
                  label801: {
                     boolean var10001;
                     Lock var127;
                     try {
                        var127 = this.d.f();
                        var127.lock();
                     } catch (IllegalStateException var125) {
                        var131 = var125;
                        var10001 = false;
                        break label795;
                     } catch (SQLiteException var126) {
                        var10000 = var126;
                        var10001 = false;
                        break label801;
                     }

                     Throwable var132;
                     label802: {
                        int[] var3;
                        try {
                           var3 = this.h.a();
                        } catch (Throwable var124) {
                           var132 = var124;
                           var10001 = false;
                           break label802;
                        }

                        if (var3 == null) {
                           try {
                              var127.unlock();
                              return;
                           } catch (IllegalStateException var115) {
                              var131 = var115;
                              var10001 = false;
                              break label795;
                           } catch (SQLiteException var116) {
                              var10000 = var116;
                              var10001 = false;
                              break label801;
                           }
                        }

                        int var4;
                        try {
                           var4 = var3.length;
                           var2.a.beginTransaction();
                        } catch (Throwable var123) {
                           var132 = var123;
                           var10001 = false;
                           break label802;
                        }

                        int var5 = 0;

                        while(true) {
                           if (var5 < var4) {
                              label775: {
                                 int var6 = var3[var5];
                                 if (var6 != 1) {
                                    if (var6 == 2) {
                                       try {
                                          this.b(var2, var5);
                                       } catch (Throwable var121) {
                                          var132 = var121;
                                          var10001 = false;
                                          break label775;
                                       }
                                    }
                                 } else {
                                    try {
                                       this.a(var2, var5);
                                    } catch (Throwable var120) {
                                       var132 = var120;
                                       var10001 = false;
                                       break label775;
                                    }
                                 }

                                 ++var5;
                                 continue;
                              }
                           } else {
                              label777:
                              try {
                                 var2.a.setTransactionSuccessful();
                                 break;
                              } catch (Throwable var122) {
                                 var132 = var122;
                                 var10001 = false;
                                 break label777;
                              }
                           }

                           Throwable var130 = var132;

                           try {
                              var2.a.endTransaction();
                              throw var130;
                           } catch (Throwable var112) {
                              var132 = var112;
                              var10001 = false;
                              break label802;
                           }
                        }

                        try {
                           var2.a.endTransaction();
                           this.h.b();
                        } catch (Throwable var119) {
                           var132 = var119;
                           var10001 = false;
                           break label802;
                        }

                        try {
                           var127.unlock();
                           continue;
                        } catch (IllegalStateException var117) {
                           var131 = var117;
                           var10001 = false;
                           break label795;
                        } catch (SQLiteException var118) {
                           var10000 = var118;
                           var10001 = false;
                           break label801;
                        }
                     }

                     Throwable var129 = var132;

                     try {
                        var127.unlock();
                        throw var129;
                     } catch (IllegalStateException var113) {
                        var131 = var113;
                        var10001 = false;
                        break label795;
                     } catch (SQLiteException var114) {
                        var10000 = var114;
                        var10001 = false;
                     }
                  }

                  var128 = var10000;
                  break label796;
               }

               var128 = var131;
            }

            Log.e("ROOM", "Cannot run invalidation tracker. Is the db closed?", (Throwable)var128);
            return;
         }
      }
   }

   public final void b(b.j.a.b var1, int var2) {
      String var3 = this.b[var2];
      StringBuilder var4 = new StringBuilder();
      String[] var5 = k;
      int var6 = var5.length;

      for(var2 = 0; var2 < var6; ++var2) {
         String var7 = var5[var2];
         var4.setLength(0);
         var4.append("DROP TRIGGER IF EXISTS ");
         var4.append("`");
         var4.append("room_table_modification_trigger_");
         var4.append(var3);
         var4.append("_");
         var4.append(var7);
         var4.append("`");
         var7 = var4.toString();
         ((b.j.a.g.a)var1).a.execSQL(var7);
      }

   }

   public static class b {
      public final long[] a;
      public final boolean[] b;
      public final int[] c;
      public boolean d;
      public boolean e;

      public b(int var1) {
         this.a = new long[var1];
         this.b = new boolean[var1];
         this.c = new int[var1];
         Arrays.fill(this.a, 0L);
         Arrays.fill(this.b, false);
      }

      public boolean a(int... var1) {
         synchronized(this){}

         Throwable var10000;
         boolean var10001;
         label320: {
            int var2;
            try {
               var2 = var1.length;
            } catch (Throwable var37) {
               var10000 = var37;
               var10001 = false;
               break label320;
            }

            int var3 = 0;

            boolean var4;
            for(var4 = false; var3 < var2; ++var3) {
               int var5 = var1[var3];

               int var6;
               try {
                  var6 = this.a[var5]++;
               } catch (Throwable var36) {
                  var10000 = var36;
                  var10001 = false;
                  break label320;
               }

               if (var6 == 0L) {
                  try {
                     this.d = true;
                  } catch (Throwable var35) {
                     var10000 = var35;
                     var10001 = false;
                     break label320;
                  }

                  var4 = true;
               }
            }

            label299:
            try {
               return var4;
            } catch (Throwable var34) {
               var10000 = var34;
               var10001 = false;
               break label299;
            }
         }

         while(true) {
            Throwable var38 = var10000;

            try {
               throw var38;
            } catch (Throwable var33) {
               var10000 = var33;
               var10001 = false;
               continue;
            }
         }
      }

      public int[] a() {
         synchronized(this){}

         Throwable var10000;
         boolean var10001;
         label925: {
            label928: {
               try {
                  if (this.d && !this.e) {
                     break label928;
                  }
               } catch (Throwable var95) {
                  var10000 = var95;
                  var10001 = false;
                  break label925;
               }

               try {
                  return null;
               } catch (Throwable var94) {
                  var10000 = var94;
                  var10001 = false;
                  break label925;
               }
            }

            int var1;
            try {
               var1 = this.a.length;
            } catch (Throwable var93) {
               var10000 = var93;
               var10001 = false;
               break label925;
            }

            int var2 = 0;

            while(true) {
               byte var3 = 1;
               int[] var5;
               if (var2 >= var1) {
                  try {
                     this.e = true;
                     this.d = false;
                     var5 = this.c;
                     return var5;
                  } catch (Throwable var88) {
                     var10000 = var88;
                     var10001 = false;
                     break;
                  }
               }

               boolean var4;
               label893: {
                  label892: {
                     try {
                        if (this.a[var2] > 0L) {
                           break label892;
                        }
                     } catch (Throwable var91) {
                        var10000 = var91;
                        var10001 = false;
                        break;
                     }

                     var4 = false;
                     break label893;
                  }

                  var4 = true;
               }

               label902: {
                  label927: {
                     try {
                        if (var4 == this.b[var2]) {
                           break label927;
                        }

                        var5 = this.c;
                     } catch (Throwable var92) {
                        var10000 = var92;
                        var10001 = false;
                        break;
                     }

                     if (!var4) {
                        var3 = 2;
                     }

                     var5[var2] = var3;
                     break label902;
                  }

                  try {
                     this.c[var2] = 0;
                  } catch (Throwable var90) {
                     var10000 = var90;
                     var10001 = false;
                     break;
                  }
               }

               try {
                  this.b[var2] = var4;
               } catch (Throwable var89) {
                  var10000 = var89;
                  var10001 = false;
                  break;
               }

               ++var2;
            }
         }

         while(true) {
            Throwable var96 = var10000;

            try {
               throw var96;
            } catch (Throwable var87) {
               var10000 = var87;
               var10001 = false;
               continue;
            }
         }
      }

      public void b() {
         // $FF: Couldn't be decompiled
      }

      public boolean b(int... var1) {
         synchronized(this){}

         Throwable var10000;
         boolean var10001;
         label320: {
            int var2;
            try {
               var2 = var1.length;
            } catch (Throwable var37) {
               var10000 = var37;
               var10001 = false;
               break label320;
            }

            int var3 = 0;

            boolean var4;
            for(var4 = false; var3 < var2; ++var3) {
               int var5 = var1[var3];

               int var6;
               try {
                  var6 = this.a[var5]--;
               } catch (Throwable var36) {
                  var10000 = var36;
                  var10001 = false;
                  break label320;
               }

               if (var6 == 1L) {
                  try {
                     this.d = true;
                  } catch (Throwable var35) {
                     var10000 = var35;
                     var10001 = false;
                     break label320;
                  }

                  var4 = true;
               }
            }

            label299:
            try {
               return var4;
            } catch (Throwable var34) {
               var10000 = var34;
               var10001 = false;
               break label299;
            }
         }

         while(true) {
            Throwable var38 = var10000;

            try {
               throw var38;
            } catch (Throwable var33) {
               var10000 = var33;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public abstract static class c {
      public final String[] a;

      public c(String[] var1) {
         this.a = (String[])Arrays.copyOf(var1, var1.length);
      }

      public abstract void a(Set var1);

      public boolean a() {
         return false;
      }
   }

   public static class d {
      public final int[] a;
      public final String[] b;
      public final e.c c;
      public final Set d;

      public d(e.c var1, int[] var2, String[] var3) {
         this.c = var1;
         this.a = var2;
         this.b = var3;
         if (var2.length == 1) {
            HashSet var4 = new HashSet();
            var4.add(this.b[0]);
            this.d = Collections.unmodifiableSet(var4);
         } else {
            this.d = null;
         }

      }
   }
}
