package b.i;

import java.util.concurrent.atomic.AtomicBoolean;

public abstract class l {
   public final AtomicBoolean a = new AtomicBoolean(false);
   public final g b;
   public volatile b.j.a.f c;

   public l(g var1) {
      this.b = var1;
   }

   public b.j.a.f a() {
      this.b.a();
      b.j.a.f var1;
      if (this.a.compareAndSet(false, true)) {
         if (this.c == null) {
            this.c = this.b();
         }

         var1 = this.c;
      } else {
         var1 = this.b();
      }

      return var1;
   }

   public void a(b.j.a.f var1) {
      if (var1 == this.c) {
         this.a.set(false);
      }

   }

   public final b.j.a.f b() {
      String var1 = this.c();
      return this.b.a(var1);
   }

   public abstract String c();
}
