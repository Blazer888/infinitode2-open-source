package b.i;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import androidx.room.MultiInstanceInvalidationService;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

public class f {
   public final Context a;
   public final String b;
   public int c;
   public final e d;
   public final e.c e;
   public d f;
   public final Executor g;
   public final c h = new c.a() {
      public void a(final String[] var1) {
         f.this.g.execute(new Runnable() {
            public void run() {
               f.this.d.a(var1);
            }
         });
      }
   };
   public final AtomicBoolean i = new AtomicBoolean(false);
   public final ServiceConnection j = new ServiceConnection() {
      public void onServiceConnected(ComponentName var1, IBinder var2) {
         f.this.f = d.a.a(var2);
         f var3 = f.this;
         var3.g.execute(var3.k);
      }

      public void onServiceDisconnected(ComponentName var1) {
         f var2 = f.this;
         var2.g.execute(var2.l);
         f.this.f = null;
      }
   };
   public final Runnable k = new Runnable() {
      public void run() {
         // $FF: Couldn't be decompiled
      }
   };
   public final Runnable l = new Runnable() {
      public void run() {
         f var1 = f.this;
         var1.d.b(var1.e);
      }
   };

   public f(Context var1, String var2, e var3, Executor var4) {
      Runnable var10001 = new Runnable() {
         public void run() {
            f var1 = f.this;
            var1.d.b(var1.e);

            label24: {
               RemoteException var10000;
               label28: {
                  boolean var10001;
                  d var4;
                  try {
                     var4 = f.this.f;
                  } catch (RemoteException var3) {
                     var10000 = var3;
                     var10001 = false;
                     break label28;
                  }

                  if (var4 == null) {
                     break label24;
                  }

                  try {
                     var4.a(f.this.h, f.this.c);
                     break label24;
                  } catch (RemoteException var2) {
                     var10000 = var2;
                     var10001 = false;
                  }
               }

               RemoteException var5 = var10000;
               Log.w("ROOM", "Cannot unregister multi-instance invalidation callback", var5);
            }

            var1 = f.this;
            var1.a.unbindService(var1.j);
         }
      };
      this.a = var1.getApplicationContext();
      this.b = var2;
      this.d = var3;
      this.g = var4;
      this.e = new e.c(var3.b) {
         public void a(Set var1) {
            if (!f.this.i.get()) {
               RemoteException var10000;
               label30: {
                  boolean var10001;
                  d var2;
                  try {
                     var2 = f.this.f;
                  } catch (RemoteException var4) {
                     var10000 = var4;
                     var10001 = false;
                     break label30;
                  }

                  if (var2 == null) {
                     return;
                  }

                  try {
                     var2.a(f.this.c, (String[])var1.toArray(new String[0]));
                     return;
                  } catch (RemoteException var3) {
                     var10000 = var3;
                     var10001 = false;
                  }
               }

               RemoteException var5 = var10000;
               Log.w("ROOM", "Cannot broadcast invalidation", var5);
            }
         }

         public boolean a() {
            return true;
         }
      };
      Intent var5 = new Intent(this.a, MultiInstanceInvalidationService.class);
      this.a.bindService(var5, this.j, 1);
   }
}
