package b.i;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public interface d extends IInterface {
   int a(c var1, String var2);

   void a(int var1, String[] var2);

   void a(c var1, int var2);

   public abstract static class a extends Binder implements d {
      public a() {
         this.attachInterface(this, "androidx.room.IMultiInstanceInvalidationService");
      }

      public static d a(IBinder var0) {
         if (var0 == null) {
            return null;
         } else {
            IInterface var1 = var0.queryLocalInterface("androidx.room.IMultiInstanceInvalidationService");
            return (d)(var1 != null && var1 instanceof d ? (d)var1 : new d.a.a(var0));
         }
      }

      public IBinder asBinder() {
         return this;
      }

      public boolean onTransact(int var1, Parcel var2, Parcel var3, int var4) {
         c var5;
         if (var1 != 1) {
            if (var1 != 2) {
               if (var1 != 3) {
                  if (var1 != 1598968902) {
                     return super.onTransact(var1, var2, var3, var4);
                  } else {
                     var3.writeString("androidx.room.IMultiInstanceInvalidationService");
                     return true;
                  }
               } else {
                  var2.enforceInterface("androidx.room.IMultiInstanceInvalidationService");
                  var1 = var2.readInt();
                  String[] var7 = var2.createStringArray();
                  ((<undefinedtype>)this).a(var1, var7);
                  return true;
               }
            } else {
               var2.enforceInterface("androidx.room.IMultiInstanceInvalidationService");
               var5 = c.a.a(var2.readStrongBinder());
               var1 = var2.readInt();
               ((<undefinedtype>)this).a(var5, var1);
               var3.writeNoException();
               return true;
            }
         } else {
            var2.enforceInterface("androidx.room.IMultiInstanceInvalidationService");
            var5 = c.a.a(var2.readStrongBinder());
            String var6 = var2.readString();
            var1 = ((<undefinedtype>)this).a(var5, var6);
            var3.writeNoException();
            var3.writeInt(var1);
            return true;
         }
      }

      public static class a implements d {
         public IBinder a;

         public a(IBinder var1) {
            this.a = var1;
         }

         public int a(c var1, String var2) {
            Parcel var3 = Parcel.obtain();
            Parcel var4 = Parcel.obtain();

            int var5;
            label124: {
               Throwable var10000;
               label128: {
                  boolean var10001;
                  try {
                     var3.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
                  } catch (Throwable var17) {
                     var10000 = var17;
                     var10001 = false;
                     break label128;
                  }

                  IBinder var18;
                  if (var1 != null) {
                     try {
                        var18 = var1.asBinder();
                     } catch (Throwable var16) {
                        var10000 = var16;
                        var10001 = false;
                        break label128;
                     }
                  } else {
                     var18 = null;
                  }

                  label115:
                  try {
                     var3.writeStrongBinder(var18);
                     var3.writeString(var2);
                     this.a.transact(1, var3, var4, 0);
                     var4.readException();
                     var5 = var4.readInt();
                     break label124;
                  } catch (Throwable var15) {
                     var10000 = var15;
                     var10001 = false;
                     break label115;
                  }
               }

               Throwable var19 = var10000;
               var4.recycle();
               var3.recycle();
               throw var19;
            }

            var4.recycle();
            var3.recycle();
            return var5;
         }

         public void a(int var1, String[] var2) {
            Parcel var3 = Parcel.obtain();

            try {
               var3.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
               var3.writeInt(var1);
               var3.writeStringArray(var2);
               this.a.transact(3, var3, (Parcel)null, 1);
            } finally {
               var3.recycle();
            }

         }

         public void a(c var1, int var2) {
            Parcel var3 = Parcel.obtain();
            Parcel var4 = Parcel.obtain();

            label124: {
               Throwable var10000;
               label128: {
                  boolean var10001;
                  try {
                     var3.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
                  } catch (Throwable var16) {
                     var10000 = var16;
                     var10001 = false;
                     break label128;
                  }

                  IBinder var17;
                  if (var1 != null) {
                     try {
                        var17 = var1.asBinder();
                     } catch (Throwable var15) {
                        var10000 = var15;
                        var10001 = false;
                        break label128;
                     }
                  } else {
                     var17 = null;
                  }

                  label115:
                  try {
                     var3.writeStrongBinder(var17);
                     var3.writeInt(var2);
                     this.a.transact(2, var3, var4, 0);
                     var4.readException();
                     break label124;
                  } catch (Throwable var14) {
                     var10000 = var14;
                     var10001 = false;
                     break label115;
                  }
               }

               Throwable var18 = var10000;
               var4.recycle();
               var3.recycle();
               throw var18;
            }

            var4.recycle();
            var3.recycle();
         }

         public IBinder asBinder() {
            return this.a;
         }
      }
   }
}
