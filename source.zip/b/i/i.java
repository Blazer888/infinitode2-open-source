package b.i;

import java.util.Iterator;
import java.util.TreeMap;
import java.util.Map.Entry;

public class i implements b.j.a.e, b.j.a.d {
   public static final TreeMap i = new TreeMap();
   public volatile String a;
   public final long[] b;
   public final double[] c;
   public final String[] d;
   public final byte[][] e;
   public final int[] f;
   public final int g;
   public int h;

   public i(int var1) {
      this.g = var1++;
      this.f = new int[var1];
      this.b = new long[var1];
      this.c = new double[var1];
      this.d = new String[var1];
      this.e = new byte[var1][];
   }

   public static i a(String var0, int var1) {
      TreeMap var2 = i;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label173: {
         Entry var3;
         try {
            var3 = i.ceilingEntry(var1);
         } catch (Throwable var23) {
            var10000 = var23;
            var10001 = false;
            break label173;
         }

         if (var3 != null) {
            label166:
            try {
               i.remove(var3.getKey());
               i var26 = (i)var3.getValue();
               var26.a = var0;
               var26.h = var1;
               return var26;
            } catch (Throwable var21) {
               var10000 = var21;
               var10001 = false;
               break label166;
            }
         } else {
            label169: {
               try {
                  ;
               } catch (Throwable var22) {
                  var10000 = var22;
                  var10001 = false;
                  break label169;
               }

               i var25 = new i(var1);
               var25.a = var0;
               var25.h = var1;
               return var25;
            }
         }
      }

      while(true) {
         Throwable var24 = var10000;

         try {
            throw var24;
         } catch (Throwable var20) {
            var10000 = var20;
            var10001 = false;
            continue;
         }
      }
   }

   public String a() {
      return this.a;
   }

   public void a(int var1, double var2) {
      this.f[var1] = 3;
      this.c[var1] = var2;
   }

   public void a(int var1, long var2) {
      this.f[var1] = 2;
      this.b[var1] = var2;
   }

   public void a(int var1, String var2) {
      this.f[var1] = 4;
      this.d[var1] = var2;
   }

   public void a(int var1, byte[] var2) {
      this.f[var1] = 5;
      this.e[var1] = var2;
   }

   public void a(b.j.a.d var1) {
      for(int var2 = 1; var2 <= this.h; ++var2) {
         int var3 = this.f[var2];
         if (var3 != 1) {
            if (var3 != 2) {
               if (var3 != 3) {
                  if (var3 != 4) {
                     if (var3 == 5) {
                        var1.a(var2, this.e[var2]);
                     }
                  } else {
                     var1.a(var2, this.d[var2]);
                  }
               } else {
                  var1.a(var2, this.c[var2]);
               }
            } else {
               var1.a(var2, this.b[var2]);
            }
         } else {
            var1.b(var2);
         }
      }

   }

   public void b() {
      TreeMap var1 = i;
      synchronized(var1){}

      Throwable var10000;
      boolean var10001;
      label209: {
         label208: {
            int var2;
            Iterator var3;
            try {
               i.put(this.g, this);
               if (i.size() <= 15) {
                  break label208;
               }

               var2 = i.size() - 10;
               var3 = i.descendingKeySet().iterator();
            } catch (Throwable var23) {
               var10000 = var23;
               var10001 = false;
               break label209;
            }

            for(; var2 > 0; --var2) {
               try {
                  var3.next();
                  var3.remove();
               } catch (Throwable var22) {
                  var10000 = var22;
                  var10001 = false;
                  break label209;
               }
            }
         }

         label197:
         try {
            return;
         } catch (Throwable var21) {
            var10000 = var21;
            var10001 = false;
            break label197;
         }
      }

      while(true) {
         Throwable var24 = var10000;

         try {
            throw var24;
         } catch (Throwable var20) {
            var10000 = var20;
            var10001 = false;
            continue;
         }
      }
   }

   public void b(int var1) {
      this.f[var1] = 1;
   }

   public void close() {
   }
}
