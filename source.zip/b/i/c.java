package b.i;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public interface c extends IInterface {
   void a(String[] var1);

   public abstract static class a extends Binder implements c {
      public a() {
         this.attachInterface(this, "androidx.room.IMultiInstanceInvalidationCallback");
      }

      public static c a(IBinder var0) {
         if (var0 == null) {
            return null;
         } else {
            IInterface var1 = var0.queryLocalInterface("androidx.room.IMultiInstanceInvalidationCallback");
            return (c)(var1 != null && var1 instanceof c ? (c)var1 : new c.a.a(var0));
         }
      }

      public IBinder asBinder() {
         return this;
      }

      public boolean onTransact(int var1, Parcel var2, Parcel var3, int var4) {
         if (var1 != 1) {
            if (var1 != 1598968902) {
               return super.onTransact(var1, var2, var3, var4);
            } else {
               var3.writeString("androidx.room.IMultiInstanceInvalidationCallback");
               return true;
            }
         } else {
            var2.enforceInterface("androidx.room.IMultiInstanceInvalidationCallback");
            String[] var5 = var2.createStringArray();
            ((<undefinedtype>)this).a(var5);
            return true;
         }
      }

      public static class a implements c {
         public IBinder a;

         public a(IBinder var1) {
            this.a = var1;
         }

         public void a(String[] var1) {
            Parcel var2 = Parcel.obtain();

            try {
               var2.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationCallback");
               var2.writeStringArray(var1);
               this.a.transact(1, var2, (Parcel)null, 1);
            } finally {
               var2.recycle();
            }

         }

         public IBinder asBinder() {
            return this.a;
         }
      }
   }
}
