package b.i;

import java.io.File;

public class k implements b.j.a.c.c {
   public final String a;
   public final File b;
   public final b.j.a.c.c c;

   public k(String var1, File var2, b.j.a.c.c var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public b.j.a.c a(b.j.a.c.b var1) {
      return new j(var1.a, this.a, this.b, var1.c.a, this.c.a(var1));
   }
}
