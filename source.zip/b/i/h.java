package b.i;

import android.database.Cursor;
import androidx.work.impl.WorkDatabase_Impl;
import java.util.Iterator;
import java.util.List;

public class h extends b.j.a.c.a {
   public b.i.a b;
   public final h.a c;
   public final String d;
   public final String e;

   public h(b.i.a var1, h.a var2, String var3, String var4) {
      super(var2.a);
      this.b = var1;
      this.c = var2;
      this.d = var3;
      this.e = var4;
   }

   public void a(b.j.a.b var1) {
      super.a(var1);
   }

   public void a(b.j.a.b var1, int var2, int var3) {
      b.i.a var4;
      boolean var5;
      StringBuilder var6;
      label39: {
         var4 = this.b;
         if (var4 != null) {
            List var7 = var4.d.a(var2, var3);
            if (var7 != null) {
               this.c.d(var1);
               Iterator var8 = var7.iterator();

               while(var8.hasNext()) {
                  ((b.i.n.a)var8.next()).a(var1);
               }

               h.b var9 = this.c.e(var1);
               if (!var9.a) {
                  var6 = c.a.b.a.a.b("Migration didn't properly handle: ");
                  var6.append(var9.b);
                  throw new IllegalStateException(var6.toString());
               }

               this.c.c(var1);
               this.e(var1);
               var5 = true;
               break label39;
            }
         }

         var5 = false;
      }

      if (!var5) {
         var4 = this.b;
         if (var4 == null || var4.a(var2, var3)) {
            var6 = new StringBuilder();
            var6.append("A migration from ");
            var6.append(var2);
            var6.append(" to ");
            var6.append(var3);
            var6.append(" was required but not found. Please provide the necessary Migration path via RoomDatabase.Builder.addMigration(Migration ...) or allow for destructive migrations via one of the RoomDatabase.Builder.fallbackToDestructiveMigration* methods.");
            throw new IllegalStateException(var6.toString());
         }

         this.c.b(var1);
         this.c.a(var1);
      }

   }

   public void c(b.j.a.b var1) {
      Cursor var2 = ((b.j.a.g.a)var1).a("SELECT count(*) FROM sqlite_master WHERE name != 'android_metadata'");

      byte var4;
      int var5;
      boolean var17;
      label146: {
         label145: {
            Throwable var10000;
            label150: {
               boolean var3;
               boolean var10001;
               try {
                  var3 = var2.moveToFirst();
               } catch (Throwable var12) {
                  var10000 = var12;
                  var10001 = false;
                  break label150;
               }

               var4 = 0;
               if (!var3) {
                  break label145;
               }

               try {
                  var5 = var2.getInt(0);
               } catch (Throwable var11) {
                  var10000 = var11;
                  var10001 = false;
                  break label150;
               }

               if (var5 == 0) {
                  var17 = true;
                  break label146;
               }
               break label145;
            }

            Throwable var13 = var10000;
            var2.close();
            throw var13;
         }

         var17 = false;
      }

      var2.close();
      this.c.a(var1);
      if (!var17) {
         h.b var16 = this.c.e(var1);
         if (!var16.a) {
            StringBuilder var15 = c.a.b.a.a.b("Pre-packaged database has an invalid schema: ");
            var15.append(var16.b);
            throw new IllegalStateException(var15.toString());
         }
      }

      this.e(var1);
      <undefinedtype> var14 = (<undefinedtype>)this.c;
      if (WorkDatabase_Impl.b(var14.b) != null) {
         int var6 = var14.b.g.size();

         for(var5 = var4; var5 < var6; ++var5) {
            ((g.b)var14.b.g.get(var5)).a();
         }
      }

   }

   public void d(b.j.a.b var1) {
      super.d(var1);
      b.j.a.g.a var2 = (b.j.a.g.a)var1;
      Cursor var3 = var2.a("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name='room_master_table'");

      byte var5;
      int var6;
      boolean var28;
      label285: {
         label284: {
            Throwable var10000;
            label289: {
               boolean var4;
               boolean var10001;
               try {
                  var4 = var3.moveToFirst();
               } catch (Throwable var21) {
                  var10000 = var21;
                  var10001 = false;
                  break label289;
               }

               var5 = 0;
               if (!var4) {
                  break label284;
               }

               try {
                  var6 = var3.getInt(0);
               } catch (Throwable var20) {
                  var10000 = var20;
                  var10001 = false;
                  break label289;
               }

               if (var6 != 0) {
                  var28 = true;
                  break label285;
               }
               break label284;
            }

            Throwable var22 = var10000;
            var3.close();
            throw var22;
         }

         var28 = false;
      }

      var3.close();
      if (var28) {
         Cursor var7 = var2.a((b.j.a.e)(new b.j.a.a("SELECT identity_hash FROM room_master_table WHERE id = 42 LIMIT 1")));
         boolean var12 = false;

         String var25;
         label268: {
            try {
               var12 = true;
               if (var7.moveToFirst()) {
                  var25 = var7.getString(0);
                  var12 = false;
                  break label268;
               }

               var12 = false;
            } finally {
               if (var12) {
                  var7.close();
               }
            }

            var25 = null;
         }

         var7.close();
         if (!this.d.equals(var25) && !this.e.equals(var25)) {
            throw new IllegalStateException("Room cannot verify the data integrity. Looks like you've changed schema but forgot to update the version number. You can simply fix this by increasing the version number.");
         }
      } else {
         h.b var26 = this.c.e(var1);
         if (!var26.a) {
            StringBuilder var23 = c.a.b.a.a.b("Pre-packaged database has an invalid schema: ");
            var23.append(var26.b);
            throw new IllegalStateException(var23.toString());
         }

         this.c.c(var1);
         this.e(var1);
      }

      <undefinedtype> var27 = (<undefinedtype>)this.c;
      WorkDatabase_Impl.a(var27.b, var1);
      var2.a.execSQL("PRAGMA foreign_keys = ON");
      var27.b.a(var1);
      List var24 = var27.b.g;
      if (var24 != null) {
         int var8 = var24.size();

         for(var6 = var5; var6 < var8; ++var6) {
            ((g.b)var27.b.g.get(var6)).a(var1);
         }
      }

      this.b = null;
   }

   public final void e(b.j.a.b var1) {
      ((b.j.a.g.a)var1).a.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
      String var2 = c.a.b.a.a.a("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '", this.d, "')");
      ((b.j.a.g.a)var1).a.execSQL(var2);
   }

   public abstract static class a {
      public final int a;

      public a(int var1) {
         this.a = var1;
      }

      public abstract void a(b.j.a.b var1);

      public abstract void b(b.j.a.b var1);

      public abstract void c(b.j.a.b var1);

      public abstract void d(b.j.a.b var1);

      public abstract h.b e(b.j.a.b var1);
   }

   public static class b {
      public final boolean a;
      public final String b;

      public b(boolean var1, String var2) {
         this.a = var1;
         this.b = var2;
      }
   }
}
