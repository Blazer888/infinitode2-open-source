package b.f;

@Deprecated
public interface j extends h {
   i getLifecycle();
}
