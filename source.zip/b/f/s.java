package b.f;

public abstract class s {
   public void a() {
   }
}
