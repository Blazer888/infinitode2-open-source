package b.f;

public interface c {
   void a(h var1, e.a var2, boolean var3, m var4);
}
