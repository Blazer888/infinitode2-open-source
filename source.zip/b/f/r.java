package b.f;

import android.os.Handler;

public class r {
   public final i a;
   public final Handler b;
   public r.a c;

   public r(h var1) {
      this.a = new i(var1);
      this.b = new Handler();
   }

   public void a() {
      this.a(e.a.ON_START);
   }

   public final void a(e.a var1) {
      r.a var2 = this.c;
      if (var2 != null) {
         var2.run();
      }

      this.c = new r.a(this.a, var1);
      this.b.postAtFrontOfQueue(this.c);
   }

   public void b() {
      this.a(e.a.ON_CREATE);
   }

   public void c() {
      this.a(e.a.ON_STOP);
      this.a(e.a.ON_DESTROY);
   }

   public void d() {
      this.a(e.a.ON_START);
   }

   public static class a implements Runnable {
      public final i a;
      public final e.a b;
      public boolean c = false;

      public a(i var1, e.a var2) {
         this.a = var1;
         this.b = var2;
      }

      public void run() {
         if (!this.c) {
            this.a.a(this.b);
            this.c = true;
         }

      }
   }
}
