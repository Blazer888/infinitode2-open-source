package b.f;

import java.util.HashMap;
import java.util.Iterator;

public class u {
   public final HashMap a = new HashMap();

   public final void a() {
      Iterator var1 = this.a.values().iterator();

      while(var1.hasNext()) {
         ((s)var1.next()).a();
      }

      this.a.clear();
   }
}
