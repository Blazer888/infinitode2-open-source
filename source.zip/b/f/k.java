package b.f;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class k extends Service implements h {
   public final r a = new r(this);

   public e getLifecycle() {
      return this.a.a;
   }

   public IBinder onBind(Intent var1) {
      this.a.a();
      return null;
   }

   public void onCreate() {
      this.a.b();
      super.onCreate();
   }

   public void onDestroy() {
      this.a.c();
      super.onDestroy();
   }

   public void onStart(Intent var1, int var2) {
      this.a.d();
      super.onStart(var1, var2);
   }

   public int onStartCommand(Intent var1, int var2, int var3) {
      return super.onStartCommand(var1, var2, var3);
   }
}
