package b.f;

public interface t {
}
