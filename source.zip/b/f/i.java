package b.f;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Map.Entry;

public class i extends e {
   public b.a.a.b.a a = new b.a.a.b.a();
   public e.b b;
   public final WeakReference c;
   public int d = 0;
   public boolean e = false;
   public boolean f = false;
   public ArrayList g = new ArrayList();

   public i(h var1) {
      this.c = new WeakReference(var1);
      this.b = e.b.b;
   }

   public static e.b a(e.b var0, e.b var1) {
      e.b var2 = var0;
      if (var1 != null) {
         var2 = var0;
         if (var1.compareTo(var0) < 0) {
            var2 = var1;
         }
      }

      return var2;
   }

   public static e.a b(e.b var0) {
      int var1 = var0.ordinal();
      if (var1 != 0 && var1 != 1) {
         if (var1 != 2) {
            if (var1 != 3) {
               if (var1 != 4) {
                  StringBuilder var2 = new StringBuilder();
                  var2.append("Unexpected state value ");
                  var2.append(var0);
                  throw new IllegalArgumentException(var2.toString());
               } else {
                  throw new IllegalArgumentException();
               }
            } else {
               return e.a.ON_RESUME;
            }
         } else {
            return e.a.ON_START;
         }
      } else {
         return e.a.ON_CREATE;
      }
   }

   public static e.b b(e.a var0) {
      int var1 = var0.ordinal();
      if (var1 != 0) {
         if (var1 == 1) {
            return e.b.d;
         }

         if (var1 == 2) {
            return e.b.e;
         }

         if (var1 == 3) {
            return e.b.d;
         }

         if (var1 != 4) {
            if (var1 == 5) {
               return e.b.a;
            }

            StringBuilder var2 = new StringBuilder();
            var2.append("Unexpected event value ");
            var2.append(var0);
            throw new IllegalArgumentException(var2.toString());
         }
      }

      return e.b.c;
   }

   public final e.b a(g var1) {
      b.a.a.b.a var2 = this.a;
      boolean var3 = var2.e.containsKey(var1);
      e.b var4 = null;
      b.a.a.b.b.c var5;
      if (var3) {
         var5 = ((b.a.a.b.b.c)var2.e.get(var1)).d;
      } else {
         var5 = null;
      }

      e.b var6;
      if (var5 != null) {
         var6 = ((i.a)var5.getValue()).a;
      } else {
         var6 = null;
      }

      if (!this.g.isEmpty()) {
         ArrayList var7 = this.g;
         var4 = (e.b)var7.get(var7.size() - 1);
      }

      return a(a(this.b, var6), var4);
   }

   public final void a() {
      ArrayList var1 = this.g;
      var1.remove(var1.size() - 1);
   }

   public void a(e.a var1) {
      this.a(b(var1));
   }

   public final void a(e.b var1) {
      if (this.b != var1) {
         this.b = var1;
         if (!this.e && this.d == 0) {
            this.e = true;
            this.b();
            this.e = false;
         } else {
            this.f = true;
         }
      }
   }

   public final void b() {
      h var1 = (h)this.c.get();
      if (var1 == null) {
         IllegalStateException var16 = new IllegalStateException("LifecycleOwner of this LifecycleRegistry is alreadygarbage collected. It is too late to change lifecycle state.");
         throw var16;
      } else {
         while(true) {
            b.a.a.b.b.c var13;
            do {
               do {
                  do {
                     b.a.a.b.a var2;
                     boolean var4;
                     e.b var9;
                     label125: {
                        var2 = this.a;
                        if (var2.d != 0) {
                           var9 = ((i.a)var2.a.getValue()).a;
                           e.b var3 = ((i.a)this.a.b.getValue()).a;
                           if (var9 != var3 || this.b != var3) {
                              var4 = false;
                              break label125;
                           }
                        }

                        var4 = true;
                     }

                     if (var4) {
                        this.f = false;
                        return;
                     }

                     this.f = false;
                     if (this.b.compareTo(((i.a)this.a.a.getValue()).a) < 0) {
                        var2 = this.a;
                        b.a.a.b.b.b var10 = new b.a.a.b.b.b(var2.b, var2.a);
                        var2.c.put(var10, false);

                        while(var10.hasNext() && !this.f) {
                           Entry var5 = (Entry)var10.next();
                           i.a var6 = (i.a)var5.getValue();

                           while(var6.a.compareTo(this.b) > 0 && !this.f && this.a.contains(var5.getKey())) {
                              var9 = var6.a;
                              int var14 = var9.ordinal();
                              if (var14 == 0) {
                                 throw new IllegalArgumentException();
                              }

                              if (var14 == 1) {
                                 throw new IllegalArgumentException();
                              }

                              e.a var11;
                              if (var14 != 2) {
                                 if (var14 != 3) {
                                    if (var14 != 4) {
                                       StringBuilder var8 = new StringBuilder();
                                       var8.append("Unexpected state value ");
                                       var8.append(var9);
                                       throw new IllegalArgumentException(var8.toString());
                                    }

                                    var11 = e.a.ON_PAUSE;
                                 } else {
                                    var11 = e.a.ON_STOP;
                                 }
                              } else {
                                 var11 = e.a.ON_DESTROY;
                              }

                              e.b var7 = b(var11);
                              this.g.add(var7);
                              var6.a(var1, var11);
                              this.a();
                           }
                        }
                     }

                     var13 = this.a.b;
                  } while(this.f);
               } while(var13 == null);
            } while(this.b.compareTo(((i.a)var13.getValue()).a) <= 0);

            b.a.a.b.b.d var18 = this.a.a();

            while(var18.hasNext() && !this.f) {
               Entry var12 = (Entry)var18.next();
               i.a var15 = (i.a)var12.getValue();

               while(var15.a.compareTo(this.b) < 0 && !this.f && this.a.contains(var12.getKey())) {
                  e.b var17 = var15.a;
                  this.g.add(var17);
                  var15.a(var1, b(var15.a));
                  this.a();
               }
            }
         }
      }
   }

   public static class a {
      public e.b a;
      public f b;

      public a(g var1, e.b var2) {
         this.b = l.a((Object)var1);
         this.a = var2;
      }

      public void a(h var1, e.a var2) {
         e.b var3 = i.b(var2);
         this.a = i.a(this.a, var3);
         this.b.a(var1, var2);
         this.a = var3;
      }
   }
}
