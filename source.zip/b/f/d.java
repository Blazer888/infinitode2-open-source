package b.f;

@Deprecated
public interface d extends f {
}
