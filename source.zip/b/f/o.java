package b.f;

public interface o {
}
