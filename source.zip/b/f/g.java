package b.f;

public interface g {
}
