package b.f;

public interface v {
   u getViewModelStore();
}
