package b.f;

import androidx.lifecycle.LiveData;

public class n extends LiveData {
   public void a(Object var1) {
      super.a(var1);
   }

   public void b(Object var1) {
      super.b(var1);
   }
}
