package b.f;

import java.util.concurrent.atomic.AtomicReference;

public abstract class e {
   public e() {
      new AtomicReference();
   }

   public static enum a {
      ON_ANY,
      ON_CREATE,
      ON_DESTROY,
      ON_PAUSE,
      ON_RESUME,
      ON_START,
      ON_STOP;
   }

   public static enum b {
      a,
      b,
      c,
      d,
      e;
   }
}
