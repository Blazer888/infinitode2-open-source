package b.f;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class a {
   public static b.f.a c = new b.f.a();
   public final Map a = new HashMap();
   public final Map b = new HashMap();

   public final b.f.a.a a(Class var1, Method[] var2) {
      Class var3 = var1.getSuperclass();
      HashMap var4 = new HashMap();
      if (var3 != null) {
         b.f.a.a var14 = this.b(var3);
         if (var14 != null) {
            var4.putAll(var14.b);
         }
      }

      Class[] var15 = var1.getInterfaces();
      int var5 = var15.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         Iterator var7 = this.b(var15[var6]).b.entrySet().iterator();

         while(var7.hasNext()) {
            Entry var8 = (Entry)var7.next();
            this.a(var4, (b.f.a.b)var8.getKey(), (e.a)var8.getValue(), var1);
         }
      }

      if (var2 == null) {
         try {
            var2 = var1.getDeclaredMethods();
         } catch (NoClassDefFoundError var11) {
            IllegalArgumentException var12 = new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", var11);
            throw var12;
         }
      }

      int var9 = var2.length;
      var5 = 0;

      boolean var10;
      for(var10 = false; var5 < var9; ++var5) {
         Method var17 = var2[var5];
         p var18 = (p)var17.getAnnotation(p.class);
         if (var18 != null) {
            var15 = var17.getParameterTypes();
            byte var16;
            if (var15.length > 0) {
               if (!var15[0].isAssignableFrom(h.class)) {
                  throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
               }

               var16 = 1;
            } else {
               var16 = 0;
            }

            e.a var19 = var18.value();
            if (var15.length > 1) {
               if (!var15[1].isAssignableFrom(e.a.class)) {
                  throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
               }

               if (var19 != e.a.ON_ANY) {
                  throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
               }

               var16 = 2;
            }

            if (var15.length > 2) {
               throw new IllegalArgumentException("cannot have more than 2 params");
            }

            this.a(var4, new b.f.a.b(var16, var17), var19, var1);
            var10 = true;
         }
      }

      b.f.a.a var13 = new b.f.a.a(var4);
      this.a.put(var1, var13);
      this.b.put(var1, var10);
      return var13;
   }

   public final void a(Map var1, b.f.a.b var2, e.a var3, Class var4) {
      e.a var5 = (e.a)var1.get(var2);
      if (var5 != null && var3 != var5) {
         Method var6 = var2.b;
         StringBuilder var7 = c.a.b.a.a.b("Method ");
         var7.append(var6.getName());
         var7.append(" in ");
         var7.append(var4.getName());
         var7.append(" already declared with different @OnLifecycleEvent value: previous value ");
         var7.append(var5);
         var7.append(", new value ");
         var7.append(var3);
         throw new IllegalArgumentException(var7.toString());
      } else {
         if (var5 == null) {
            var1.put(var2, var3);
         }

      }
   }

   public final Method[] a(Class var1) {
      try {
         Method[] var3 = var1.getDeclaredMethods();
         return var3;
      } catch (NoClassDefFoundError var2) {
         throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", var2);
      }
   }

   public b.f.a.a b(Class var1) {
      b.f.a.a var2 = (b.f.a.a)this.a.get(var1);
      return var2 != null ? var2 : this.a(var1, (Method[])null);
   }

   public static class a {
      public final Map a;
      public final Map b;

      public a(Map var1) {
         this.b = var1;
         this.a = new HashMap();

         Entry var3;
         Object var6;
         for(Iterator var2 = var1.entrySet().iterator(); var2.hasNext(); ((List)var6).add(var3.getKey())) {
            var3 = (Entry)var2.next();
            e.a var4 = (e.a)var3.getValue();
            List var5 = (List)this.a.get(var4);
            var6 = var5;
            if (var5 == null) {
               var6 = new ArrayList();
               this.a.put(var4, var6);
            }
         }

      }

      public static void a(List var0, h var1, e.a var2, Object var3) {
         if (var0 != null) {
            for(int var4 = var0.size() - 1; var4 >= 0; --var4) {
               ((b.f.a.b)var0.get(var4)).a(var1, var2, var3);
            }
         }

      }
   }

   public static class b {
      public final int a;
      public final Method b;

      public b(int var1, Method var2) {
         this.a = var1;
         this.b = var2;
         this.b.setAccessible(true);
      }

      public void a(h var1, e.a var2, Object var3) {
         InvocationTargetException var15;
         label49: {
            IllegalAccessException var10000;
            label48: {
               int var4;
               boolean var10001;
               try {
                  var4 = this.a;
               } catch (InvocationTargetException var11) {
                  var15 = var11;
                  var10001 = false;
                  break label49;
               } catch (IllegalAccessException var12) {
                  var10000 = var12;
                  var10001 = false;
                  break label48;
               }

               if (var4 != 0) {
                  if (var4 != 1) {
                     if (var4 != 2) {
                        return;
                     }

                     try {
                        this.b.invoke(var3, var1, var2);
                        return;
                     } catch (InvocationTargetException var5) {
                        var15 = var5;
                        var10001 = false;
                        break label49;
                     } catch (IllegalAccessException var6) {
                        var10000 = var6;
                        var10001 = false;
                     }
                  } else {
                     try {
                        this.b.invoke(var3, var1);
                        return;
                     } catch (InvocationTargetException var7) {
                        var15 = var7;
                        var10001 = false;
                        break label49;
                     } catch (IllegalAccessException var8) {
                        var10000 = var8;
                        var10001 = false;
                     }
                  }
               } else {
                  try {
                     this.b.invoke(var3);
                     return;
                  } catch (InvocationTargetException var9) {
                     var15 = var9;
                     var10001 = false;
                     break label49;
                  } catch (IllegalAccessException var10) {
                     var10000 = var10;
                     var10001 = false;
                  }
               }
            }

            IllegalAccessException var13 = var10000;
            throw new RuntimeException(var13);
         }

         InvocationTargetException var14 = var15;
         throw new RuntimeException("Failed to call observer method", var14.getCause());
      }

      public boolean equals(Object var1) {
         boolean var2 = true;
         if (this == var1) {
            return true;
         } else if (var1 != null && b.f.a.b.class == var1.getClass()) {
            b.f.a.b var3 = (b.f.a.b)var1;
            if (this.a != var3.a || !this.b.getName().equals(var3.b.getName())) {
               var2 = false;
            }

            return var2;
         } else {
            return false;
         }
      }

      public int hashCode() {
         int var1 = this.a;
         return this.b.getName().hashCode() + var1 * 31;
      }
   }
}
