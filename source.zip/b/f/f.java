package b.f;

public interface f extends g {
   void a(h var1, e.a var2);
}
