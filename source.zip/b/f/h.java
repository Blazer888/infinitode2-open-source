package b.f;

public interface h {
   e getLifecycle();
}
