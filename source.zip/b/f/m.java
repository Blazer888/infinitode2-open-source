package b.f;

import java.util.HashMap;

public class m {
   public m() {
      new HashMap();
   }
}
