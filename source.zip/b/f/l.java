package b.f;

import androidx.lifecycle.CompositeGeneratedAdaptersObserver;
import androidx.lifecycle.FullLifecycleObserverAdapter;
import androidx.lifecycle.ReflectiveGenericLifecycleObserver;
import androidx.lifecycle.SingleGeneratedAdapterObserver;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class l {
   public static Map a = new HashMap();
   public static Map b = new HashMap();

   public static int a(Class var0) {
      Integer var1 = (Integer)a.get(var0);
      if (var1 != null) {
         return var1;
      } else {
         String var27 = var0.getCanonicalName();
         byte var2 = 1;
         byte var30;
         if (var27 == null) {
            var30 = var2;
         } else {
            label180: {
               Class[] var4 = null;
               byte var5 = 0;

               Constructor var29;
               label164: {
                  Constructor var34;
                  label163: {
                     label162: {
                        NoSuchMethodException var10000;
                        label173: {
                           String var6;
                           boolean var10001;
                           Package var28;
                           try {
                              var28 = var0.getPackage();
                              var6 = var0.getCanonicalName();
                           } catch (ClassNotFoundException var24) {
                              var10001 = false;
                              break label162;
                           } catch (NoSuchMethodException var25) {
                              var10000 = var25;
                              var10001 = false;
                              break label173;
                           }

                           if (var28 != null) {
                              try {
                                 var27 = var28.getName();
                              } catch (ClassNotFoundException var22) {
                                 var10001 = false;
                                 break label162;
                              } catch (NoSuchMethodException var23) {
                                 var10000 = var23;
                                 var10001 = false;
                                 break label173;
                              }
                           } else {
                              var27 = "";
                           }

                           label184: {
                              label150:
                              try {
                                 if (!var27.isEmpty()) {
                                    break label150;
                                 }
                                 break label184;
                              } catch (ClassNotFoundException var20) {
                                 var10001 = false;
                                 break label162;
                              } catch (NoSuchMethodException var21) {
                                 var10000 = var21;
                                 var10001 = false;
                                 break label173;
                              }

                              try {
                                 var6 = var6.substring(var27.length() + 1);
                              } catch (ClassNotFoundException var18) {
                                 var10001 = false;
                                 break label162;
                              } catch (NoSuchMethodException var19) {
                                 var10000 = var19;
                                 var10001 = false;
                                 break label173;
                              }
                           }

                           label143: {
                              label142: {
                                 try {
                                    var6 = a(var6);
                                    if (!var27.isEmpty()) {
                                       break label142;
                                    }
                                 } catch (ClassNotFoundException var16) {
                                    var10001 = false;
                                    break label162;
                                 } catch (NoSuchMethodException var17) {
                                    var10000 = var17;
                                    var10001 = false;
                                    break label173;
                                 }

                                 var27 = var6;
                                 break label143;
                              }

                              try {
                                 StringBuilder var7 = new StringBuilder();
                                 var7.append(var27);
                                 var7.append(".");
                                 var7.append(var6);
                                 var27 = var7.toString();
                              } catch (ClassNotFoundException var14) {
                                 var10001 = false;
                                 break label162;
                              } catch (NoSuchMethodException var15) {
                                 var10000 = var15;
                                 var10001 = false;
                                 break label173;
                              }
                           }

                           try {
                              var34 = Class.forName(var27).getDeclaredConstructor(var0);
                           } catch (ClassNotFoundException var12) {
                              var10001 = false;
                              break label162;
                           } catch (NoSuchMethodException var13) {
                              var10000 = var13;
                              var10001 = false;
                              break label173;
                           }

                           var29 = var34;

                           try {
                              if (var34.isAccessible()) {
                                 break label164;
                              }

                              var34.setAccessible(true);
                              break label163;
                           } catch (ClassNotFoundException var10) {
                              var10001 = false;
                              break label162;
                           } catch (NoSuchMethodException var11) {
                              var10000 = var11;
                              var10001 = false;
                           }
                        }

                        NoSuchMethodException var26 = var10000;
                        throw new RuntimeException(var26);
                     }

                     var29 = null;
                     break label164;
                  }

                  var29 = var34;
               }

               if (var29 != null) {
                  b.put(var0, Collections.singletonList(var29));
               } else {
                  a var31 = b.f.a.c;
                  Boolean var36 = (Boolean)var31.b.get(var0);
                  int var3;
                  boolean var8;
                  int var9;
                  if (var36 != null) {
                     var8 = var36;
                  } else {
                     Method[] var37 = var31.a(var0);
                     var9 = var37.length;
                     var3 = 0;

                     while(true) {
                        if (var3 >= var9) {
                           var31.b.put(var0, false);
                           var8 = false;
                           break;
                        }

                        if ((p)var37[var3].getAnnotation(p.class) != null) {
                           var31.a(var0, var37);
                           var8 = true;
                           break;
                        }

                        ++var3;
                     }
                  }

                  if (var8) {
                     var30 = var2;
                     break label180;
                  }

                  Class var32 = var0.getSuperclass();
                  ArrayList var38 = var4;
                  if (b(var32)) {
                     if (a(var32) == 1) {
                        var30 = var2;
                        break label180;
                     }

                     var38 = new ArrayList((Collection)b.get(var32));
                  }

                  var4 = var0.getInterfaces();
                  var9 = var4.length;

                  ArrayList var33;
                  for(var3 = var5; var3 < var9; var38 = var33) {
                     Class var35 = var4[var3];
                     if (!b(var35)) {
                        var33 = var38;
                     } else {
                        if (a(var35) == 1) {
                           var30 = var2;
                           break label180;
                        }

                        var33 = var38;
                        if (var38 == null) {
                           var33 = new ArrayList();
                        }

                        var33.addAll((Collection)b.get(var35));
                     }

                     ++var3;
                  }

                  var30 = var2;
                  if (var38 == null) {
                     break label180;
                  }

                  b.put(var0, var38);
               }

               var30 = 2;
            }
         }

         a.put(var0, Integer.valueOf(var30));
         return var30;
      }
   }

   public static c a(Constructor var0, Object var1) {
      try {
         c var5 = (c)var0.newInstance(var1);
         return var5;
      } catch (IllegalAccessException var2) {
         throw new RuntimeException(var2);
      } catch (InstantiationException var3) {
         throw new RuntimeException(var3);
      } catch (InvocationTargetException var4) {
         throw new RuntimeException(var4);
      }
   }

   public static f a(Object var0) {
      boolean var1 = var0 instanceof f;
      boolean var2 = var0 instanceof b;
      if (var1 && var2) {
         return new FullLifecycleObserverAdapter((b)var0, (f)var0);
      } else if (var2) {
         return new FullLifecycleObserverAdapter((b)var0, (f)null);
      } else if (var1) {
         return (f)var0;
      } else {
         Class var3 = var0.getClass();
         if (a(var3) != 2) {
            return new ReflectiveGenericLifecycleObserver(var0);
         } else {
            List var4 = (List)b.get(var3);
            int var5 = var4.size();
            int var6 = 0;
            if (var5 == 1) {
               return new SingleGeneratedAdapterObserver(a((Constructor)var4.get(0), var0));
            } else {
               c[] var7;
               for(var7 = new c[var4.size()]; var6 < var4.size(); ++var6) {
                  var7[var6] = a((Constructor)var4.get(var6), var0);
               }

               return new CompositeGeneratedAdaptersObserver(var7);
            }
         }
      }
   }

   public static String a(String var0) {
      StringBuilder var1 = new StringBuilder();
      var1.append(var0.replace(".", "_"));
      var1.append("_LifecycleAdapter");
      return var1.toString();
   }

   public static boolean b(Class var0) {
      boolean var1;
      if (var0 != null && g.class.isAssignableFrom(var0)) {
         var1 = true;
      } else {
         var1 = false;
      }

      return var1;
   }
}
