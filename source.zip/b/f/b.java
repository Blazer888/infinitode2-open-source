package b.f;

public interface b extends g {
   void a(h var1);

   void b(h var1);

   void c(h var1);

   void d(h var1);

   void e(h var1);

   void f(h var1);
}
