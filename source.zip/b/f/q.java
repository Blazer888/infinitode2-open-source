package b.f;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;

public class q extends Fragment {
   public static void a(Activity var0) {
      FragmentManager var1 = var0.getFragmentManager();
      if (var1.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
         var1.beginTransaction().add(new q(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
         var1.executePendingTransactions();
      }

   }

   public final void a(e.a var1) {
      Activity var2 = this.getActivity();
      if (var2 instanceof j) {
         ((j)var2).getLifecycle().a(var1);
      } else {
         if (var2 instanceof h) {
            e var3 = ((h)var2).getLifecycle();
            if (var3 instanceof i) {
               ((i)var3).a(var1);
            }
         }

      }
   }

   public void onActivityCreated(Bundle var1) {
      super.onActivityCreated(var1);
      this.a(e.a.ON_CREATE);
   }

   public void onDestroy() {
      super.onDestroy();
      this.a(e.a.ON_DESTROY);
   }

   public void onPause() {
      super.onPause();
      this.a(e.a.ON_PAUSE);
   }

   public void onResume() {
      super.onResume();
      this.a(e.a.ON_RESUME);
   }

   public void onStart() {
      super.onStart();
      this.a(e.a.ON_START);
   }

   public void onStop() {
      super.onStop();
      this.a(e.a.ON_STOP);
   }
}
