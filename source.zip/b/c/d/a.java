package b.c.d;

import android.util.Log;
import java.io.Writer;

public class a extends Writer {
   public final String a;
   public StringBuilder b = new StringBuilder(128);

   public a(String var1) {
      this.a = var1;
   }

   public final void a() {
      if (this.b.length() > 0) {
         Log.d(this.a, this.b.toString());
         StringBuilder var1 = this.b;
         var1.delete(0, var1.length());
      }

   }

   public void close() {
      this.a();
   }

   public void flush() {
      this.a();
   }

   public void write(char[] var1, int var2, int var3) {
      for(int var4 = 0; var4 < var3; ++var4) {
         char var5 = var1[var2 + var4];
         if (var5 == '\n') {
            this.a();
         } else {
            this.b.append(var5);
         }
      }

   }
}
