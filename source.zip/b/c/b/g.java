package b.c.b;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Notification.BigTextStyle;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Build.VERSION;
import android.util.SparseArray;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Iterator;

public class g {
   public String A;
   public Bundle B;
   public int C = 0;
   public int D = 0;
   public Notification E;
   public RemoteViews F;
   public RemoteViews G;
   public RemoteViews H;
   public String I;
   public int J = 0;
   public String K;
   public long L;
   public int M = 0;
   public Notification N = new Notification();
   @Deprecated
   public ArrayList O;
   public Context a;
   public ArrayList b = new ArrayList();
   public ArrayList c = new ArrayList();
   public CharSequence d;
   public CharSequence e;
   public PendingIntent f;
   public PendingIntent g;
   public RemoteViews h;
   public Bitmap i;
   public CharSequence j;
   public int k;
   public int l;
   public boolean m = true;
   public boolean n;
   public h o;
   public CharSequence p;
   public CharSequence[] q;
   public int r;
   public int s;
   public boolean t;
   public String u;
   public boolean v;
   public String w;
   public boolean x = false;
   public boolean y;
   public boolean z;

   public g(Context var1, String var2) {
      this.a = var1;
      this.I = var2;
      this.N.when = System.currentTimeMillis();
      this.N.audioStreamType = -1;
      this.l = 0;
      this.O = new ArrayList();
   }

   public static CharSequence a(CharSequence var0) {
      if (var0 == null) {
         return var0;
      } else {
         CharSequence var1 = var0;
         if (var0.length() > 5120) {
            var1 = var0.subSequence(0, 5120);
         }

         return var1;
      }
   }

   public Notification a() {
      i var1 = new i(this);
      h var2 = var1.b.o;
      int var4;
      if (var2 != null) {
         f var3 = (f)var2;
         var4 = VERSION.SDK_INT;
         BigTextStyle var5 = (new BigTextStyle(var1.a)).setBigContentTitle(var3.b).bigText(var3.e);
         if (var3.d) {
            var5.setSummaryText(var3.c);
         }
      }

      var4 = VERSION.SDK_INT;
      Notification var11;
      if (var4 >= 26) {
         var11 = var1.a.build();
      } else {
         Notification var9;
         if (var4 >= 24) {
            var9 = var1.a.build();
            var11 = var9;
            if (var1.g != 0) {
               if (var9.getGroup() != null && (var9.flags & 512) != 0 && var1.g == 2) {
                  var1.a(var9);
               }

               var11 = var9;
               if (var9.getGroup() != null) {
                  var11 = var9;
                  if ((var9.flags & 512) == 0) {
                     var11 = var9;
                     if (var1.g == 1) {
                        var1.a(var9);
                        var11 = var9;
                     }
                  }
               }
            }
         } else {
            RemoteViews var13;
            if (var4 >= 21) {
               var1.a.setExtras(var1.f);
               var9 = var1.a.build();
               var13 = var1.c;
               if (var13 != null) {
                  var9.contentView = var13;
               }

               var13 = var1.d;
               if (var13 != null) {
                  var9.bigContentView = var13;
               }

               var13 = var1.h;
               if (var13 != null) {
                  var9.headsUpContentView = var13;
               }

               var11 = var9;
               if (var1.g != 0) {
                  if (var9.getGroup() != null && (var9.flags & 512) != 0 && var1.g == 2) {
                     var1.a(var9);
                  }

                  var11 = var9;
                  if (var9.getGroup() != null) {
                     var11 = var9;
                     if ((var9.flags & 512) == 0) {
                        var11 = var9;
                        if (var1.g == 1) {
                           var1.a(var9);
                           var11 = var9;
                        }
                     }
                  }
               }
            } else if (var4 >= 20) {
               var1.a.setExtras(var1.f);
               var9 = var1.a.build();
               var13 = var1.c;
               if (var13 != null) {
                  var9.contentView = var13;
               }

               var13 = var1.d;
               if (var13 != null) {
                  var9.bigContentView = var13;
               }

               var11 = var9;
               if (var1.g != 0) {
                  if (var9.getGroup() != null && (var9.flags & 512) != 0 && var1.g == 2) {
                     var1.a(var9);
                  }

                  var11 = var9;
                  if (var9.getGroup() != null) {
                     var11 = var9;
                     if ((var9.flags & 512) == 0) {
                        var11 = var9;
                        if (var1.g == 1) {
                           var1.a(var9);
                           var11 = var9;
                        }
                     }
                  }
               }
            } else {
               RemoteViews var6;
               SparseArray var14;
               if (var4 >= 19) {
                  var14 = b.c.b.j.a(var1.e);
                  if (var14 != null) {
                     var1.f.putSparseParcelableArray("android.support.actionExtras", var14);
                  }

                  var1.a.setExtras(var1.f);
                  var9 = var1.a.build();
                  var13 = var1.c;
                  if (var13 != null) {
                     var9.contentView = var13;
                  }

                  var6 = var1.d;
                  var11 = var9;
                  if (var6 != null) {
                     var9.bigContentView = var6;
                     var11 = var9;
                  }
               } else {
                  var9 = var1.a.build();
                  Bundle var15 = b.c.b.b.a(var9);
                  Bundle var7 = new Bundle(var1.f);
                  Iterator var8 = var1.f.keySet().iterator();

                  while(var8.hasNext()) {
                     String var12 = (String)var8.next();
                     if (var15.containsKey(var12)) {
                        var7.remove(var12);
                     }
                  }

                  var15.putAll(var7);
                  var14 = b.c.b.j.a(var1.e);
                  if (var14 != null) {
                     b.c.b.b.a(var9).putSparseParcelableArray("android.support.actionExtras", var14);
                  }

                  var13 = var1.c;
                  if (var13 != null) {
                     var9.contentView = var13;
                  }

                  var6 = var1.d;
                  var11 = var9;
                  if (var6 != null) {
                     var9.bigContentView = var6;
                     var11 = var9;
                  }
               }
            }
         }
      }

      RemoteViews var10 = var1.b.F;
      if (var10 != null) {
         var11.contentView = var10;
      }

      if (VERSION.SDK_INT >= 21 && var2 != null) {
         var1.b.o.a();
      }

      var4 = VERSION.SDK_INT;
      if (var2 != null) {
         b.c.b.b.a(var11);
      }

      return var11;
   }

   public g a(h var1) {
      if (this.o != var1) {
         this.o = var1;
         h var2 = this.o;
         if (var2 != null && var2.a != this) {
            var2.a = this;
            g var3 = var2.a;
            if (var3 != null) {
               var3.a(var2);
            }
         }
      }

      return this;
   }

   public g a(boolean var1) {
      Notification var2;
      if (var1) {
         var2 = this.N;
         var2.flags |= 16;
      } else {
         var2 = this.N;
         var2.flags &= -17;
      }

      return this;
   }
}
