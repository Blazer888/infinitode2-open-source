package b.c.b;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.os.Build.VERSION;

public class a extends b.c.c.a {
   public static void a(final Activity var0, final String[] var1, final int var2) {
      if (VERSION.SDK_INT >= 23) {
         if (var0 instanceof a.c) {
            ((a.c)var0).a(var2);
         }

         var0.requestPermissions(var1, var2);
      } else if (var0 instanceof a.b) {
         (new Handler(Looper.getMainLooper())).post(new Runnable() {
            public void run() {
               int[] var1x = new int[var1.length];
               PackageManager var2x = var0.getPackageManager();
               String var3 = var0.getPackageName();
               int var4 = var1.length;

               for(int var5 = 0; var5 < var4; ++var5) {
                  var1x[var5] = var2x.checkPermission(var1[var5], var3);
               }

               ((a.b)var0).onRequestPermissionsResult(var2, var1, var1x);
            }
         });
      }

   }

   public interface b {
      void onRequestPermissionsResult(int var1, String[] var2, int[] var3);
   }

   public interface c {
      void a(int var1);
   }
}
