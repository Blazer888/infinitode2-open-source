package b.c.b;

public abstract class m {
}
