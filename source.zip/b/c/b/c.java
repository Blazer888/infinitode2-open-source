package b.c.b;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;
import android.os.Build.VERSION;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.KeyEvent.DispatcherState;
import b.f.q;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class c extends Activity implements b.f.h, b.c.e.a.a {
   public b.f.i a;

   public c() {
      int[] var1 = b.b.d.a;
      Object[] var2 = b.b.d.b;
      this.a = new b.f.i(this);
   }

   public boolean a(KeyEvent var1) {
      return super.dispatchKeyEvent(var1);
   }

   public boolean dispatchKeyEvent(KeyEvent var1) {
      View var2 = this.getWindow().getDecorView();
      boolean var3 = true;
      if (var2 != null && b.c.e.c.b(var2, var1)) {
         return true;
      } else {
         boolean var4 = false;
         boolean var5;
         if (VERSION.SDK_INT >= 28) {
            var5 = this.a(var1);
         } else {
            DispatcherState var11 = null;
            this.onUserInteraction();
            Window var6 = this.getWindow();
            if (var6.hasFeature(8)) {
               ActionBar var7 = this.getActionBar();
               if (var1.getKeyCode() == 82 && var7 != null) {
                  if (!b.c.e.a.a) {
                     try {
                        b.c.e.a.b = var7.getClass().getMethod("onMenuKeyEvent", KeyEvent.class);
                     } catch (NoSuchMethodException var10) {
                     }

                     b.c.e.a.a = true;
                  }

                  Method var8 = b.c.e.a.b;
                  var5 = var4;
                  if (var8 != null) {
                     try {
                        var5 = (Boolean)var8.invoke(var7, var1);
                     } catch (InvocationTargetException | IllegalAccessException var9) {
                        var5 = var4;
                     }
                  }

                  if (var5) {
                     var5 = var3;
                     return var5;
                  }
               }
            }

            if (var6.superDispatchKeyEvent(var1)) {
               var5 = var3;
            } else {
               View var12 = var6.getDecorView();
               if (b.c.e.c.a(var12, var1)) {
                  var5 = var3;
               } else {
                  if (var12 != null) {
                     var11 = var12.getKeyDispatcherState();
                  }

                  var5 = var1.dispatch(this, var11, this);
               }
            }
         }

         return var5;
      }
   }

   public boolean dispatchKeyShortcutEvent(KeyEvent var1) {
      View var2 = this.getWindow().getDecorView();
      return var2 != null && b.c.e.c.b(var2, var1) ? true : super.dispatchKeyShortcutEvent(var1);
   }

   @SuppressLint({"RestrictedApi"})
   public void onCreate(Bundle var1) {
      super.onCreate(var1);
      q.a((Activity)this);
   }

   public void onSaveInstanceState(Bundle var1) {
      this.a.a(b.f.e.b.c);
      super.onSaveInstanceState(var1);
   }
}
