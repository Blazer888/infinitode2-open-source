package b.c.b;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.app.Notification.Builder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build.VERSION;
import android.text.TextUtils;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class i implements d {
   public final Builder a;
   public final g b;
   public RemoteViews c;
   public RemoteViews d;
   public final List e = new ArrayList();
   public final Bundle f = new Bundle();
   public int g;
   public RemoteViews h;

   public i(g var1) {
      this.b = var1;
      if (VERSION.SDK_INT >= 26) {
         this.a = new Builder(var1.a, var1.I);
      } else {
         this.a = new Builder(var1.a);
      }

      Notification var2 = var1.N;
      Builder var3 = this.a.setWhen(var2.when).setSmallIcon(var2.icon, var2.iconLevel).setContent(var2.contentView).setTicker(var2.tickerText, var1.h).setVibrate(var2.vibrate).setLights(var2.ledARGB, var2.ledOnMS, var2.ledOffMS);
      boolean var4;
      if ((var2.flags & 2) != 0) {
         var4 = true;
      } else {
         var4 = false;
      }

      var3 = var3.setOngoing(var4);
      if ((var2.flags & 8) != 0) {
         var4 = true;
      } else {
         var4 = false;
      }

      var3 = var3.setOnlyAlertOnce(var4);
      if ((var2.flags & 16) != 0) {
         var4 = true;
      } else {
         var4 = false;
      }

      Builder var5 = var3.setAutoCancel(var4).setDefaults(var2.defaults).setContentTitle(var1.d).setContentText(var1.e).setContentInfo(var1.j).setContentIntent(var1.f).setDeleteIntent(var2.deleteIntent);
      PendingIntent var15 = var1.g;
      if ((var2.flags & 128) != 0) {
         var4 = true;
      } else {
         var4 = false;
      }

      var5.setFullScreenIntent(var15, var4).setLargeIcon(var1.i).setNumber(var1.k).setProgress(var1.r, var1.s, var1.t);
      if (VERSION.SDK_INT < 21) {
         this.a.setSound(var2.sound, var2.audioStreamType);
      }

      int var6 = VERSION.SDK_INT;
      this.a.setSubText(var1.p).setUsesChronometer(var1.n).setPriority(var1.l);
      Iterator var7 = var1.b.iterator();

      while(true) {
         Bundle var17;
         while(var7.hasNext()) {
            e var8 = (e)var7.next();
            if (VERSION.SDK_INT >= 20) {
               android.app.Notification.Action.Builder var18 = new android.app.Notification.Action.Builder(var8.g, var8.h, var8.i);
               l[] var16 = var8.b;
               if (var16 != null) {
                  RemoteInput[] var9 = new RemoteInput[var16.length];
                  if (var16.length > 0) {
                     l var11 = var16[0];
                     android.app.RemoteInput.Builder var12 = new android.app.RemoteInput.Builder;
                     throw null;
                  }

                  int var10 = var9.length;

                  for(var6 = 0; var6 < var10; ++var6) {
                     var18.addRemoteInput(var9[var6]);
                  }
               }

               var17 = var8.a;
               if (var17 != null) {
                  var17 = new Bundle(var17);
               } else {
                  var17 = new Bundle();
               }

               var17.putBoolean("android.support.allowGeneratedReplies", var8.d);
               if (VERSION.SDK_INT >= 24) {
                  var18.setAllowGeneratedReplies(var8.d);
               }

               var17.putInt("android.support.action.semanticAction", var8.f);
               if (VERSION.SDK_INT >= 28) {
                  var18.setSemanticAction(var8.f);
               }

               var17.putBoolean("android.support.action.showsUserInterface", var8.e);
               var18.addExtras(var17);
               this.a.addAction(var18.build());
            } else {
               this.e.add(j.a(this.a, var8));
            }
         }

         var17 = var1.B;
         if (var17 != null) {
            this.f.putAll(var17);
         }

         if (VERSION.SDK_INT < 20) {
            if (var1.x) {
               this.f.putBoolean("android.support.localOnly", true);
            }

            String var20 = var1.u;
            if (var20 != null) {
               this.f.putString("android.support.groupKey", var20);
               if (var1.v) {
                  this.f.putBoolean("android.support.isGroupSummary", true);
               } else {
                  this.f.putBoolean("android.support.useSideChannel", true);
               }
            }

            var20 = var1.w;
            if (var20 != null) {
               this.f.putString("android.support.sortKey", var20);
            }
         }

         this.c = var1.F;
         this.d = var1.G;
         if (VERSION.SDK_INT >= 19) {
            this.a.setShowWhen(var1.m);
            if (VERSION.SDK_INT < 21) {
               ArrayList var21 = var1.O;
               if (var21 != null && !var21.isEmpty()) {
                  Bundle var19 = this.f;
                  var21 = var1.O;
                  var19.putStringArray("android.people", (String[])var21.toArray(new String[var21.size()]));
               }
            }
         }

         if (VERSION.SDK_INT >= 20) {
            this.a.setLocalOnly(var1.x).setGroup(var1.u).setGroupSummary(var1.v).setSortKey(var1.w);
            this.g = var1.M;
         }

         if (VERSION.SDK_INT >= 21) {
            this.a.setCategory(var1.A).setColor(var1.C).setVisibility(var1.D).setPublicVersion(var1.E).setSound(var2.sound, var2.audioAttributes);
            Iterator var22 = var1.O.iterator();

            while(var22.hasNext()) {
               String var13 = (String)var22.next();
               this.a.addPerson(var13);
            }

            this.h = var1.H;
            if (var1.c.size() > 0) {
               if (var1.B == null) {
                  var1.B = new Bundle();
               }

               Bundle var14 = var1.B.getBundle("android.car.EXTENSIONS");
               var17 = var14;
               if (var14 == null) {
                  var17 = new Bundle();
               }

               var14 = new Bundle();

               for(var6 = 0; var6 < var1.c.size(); ++var6) {
                  var14.putBundle(Integer.toString(var6), j.a((e)var1.c.get(var6)));
               }

               var17.putBundle("invisible_actions", var14);
               if (var1.B == null) {
                  var1.B = new Bundle();
               }

               var1.B.putBundle("android.car.EXTENSIONS", var17);
               this.f.putBundle("android.car.EXTENSIONS", var17);
            }
         }

         if (VERSION.SDK_INT >= 24) {
            this.a.setExtras(var1.B).setRemoteInputHistory(var1.q);
            RemoteViews var23 = var1.F;
            if (var23 != null) {
               this.a.setCustomContentView(var23);
            }

            var23 = var1.G;
            if (var23 != null) {
               this.a.setCustomBigContentView(var23);
            }

            var23 = var1.H;
            if (var23 != null) {
               this.a.setCustomHeadsUpContentView(var23);
            }
         }

         if (VERSION.SDK_INT >= 26) {
            this.a.setBadgeIconType(var1.J).setShortcutId(var1.K).setTimeoutAfter(var1.L).setGroupAlertBehavior(var1.M);
            if (var1.z) {
               this.a.setColorized(var1.y);
            }

            if (!TextUtils.isEmpty(var1.I)) {
               this.a.setSound((Uri)null).setDefaults(0).setLights(0, 0, 0).setVibrate((long[])null);
            }
         }

         return;
      }
   }

   public final void a(Notification var1) {
      var1.sound = null;
      var1.vibrate = null;
      var1.defaults &= -2;
      var1.defaults &= -3;
   }
}
