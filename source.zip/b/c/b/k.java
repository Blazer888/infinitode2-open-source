package b.c.b;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ResolveInfo;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.os.Handler.Callback;
import android.provider.Settings.Secure;
import android.util.Log;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public final class k {
   public static final Object c = new Object();
   public static String d;
   public static Set e = new HashSet();
   public static final Object f = new Object();
   public static k.c g;
   public final Context a;
   public final NotificationManager b;

   public k(Context var1) {
      this.a = var1;
      this.b = (NotificationManager)this.a.getSystemService("notification");
   }

   public static Set a(Context var0) {
      Throwable var10000;
      boolean var10001;
      label390: {
         String var1 = Secure.getString(var0.getContentResolver(), "enabled_notification_listeners");
         Object var49 = c;
         synchronized(var49){}
         if (var1 != null) {
            label389: {
               String[] var2;
               HashSet var3;
               int var4;
               try {
                  if (var1.equals(d)) {
                     break label389;
                  }

                  var2 = var1.split(":", -1);
                  var3 = new HashSet(var2.length);
                  var4 = var2.length;
               } catch (Throwable var48) {
                  var10000 = var48;
                  var10001 = false;
                  break label390;
               }

               int var5 = 0;

               while(true) {
                  if (var5 >= var4) {
                     try {
                        e = var3;
                        d = var1;
                        break;
                     } catch (Throwable var45) {
                        var10000 = var45;
                        var10001 = false;
                        break label390;
                     }
                  }

                  ComponentName var6;
                  try {
                     var6 = ComponentName.unflattenFromString(var2[var5]);
                  } catch (Throwable var47) {
                     var10000 = var47;
                     var10001 = false;
                     break label390;
                  }

                  if (var6 != null) {
                     try {
                        var3.add(var6.getPackageName());
                     } catch (Throwable var46) {
                        var10000 = var46;
                        var10001 = false;
                        break label390;
                     }
                  }

                  ++var5;
               }
            }
         }

         label364:
         try {
            Set var51 = e;
            return var51;
         } catch (Throwable var44) {
            var10000 = var44;
            var10001 = false;
            break label364;
         }
      }

      while(true) {
         Throwable var50 = var10000;

         try {
            throw var50;
         } catch (Throwable var43) {
            var10000 = var43;
            var10001 = false;
            continue;
         }
      }
   }

   public final void a(k.d var1) {
      Object var2 = f;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label122: {
         try {
            if (g == null) {
               k.c var3 = new k.c(this.a.getApplicationContext());
               g = var3;
            }
         } catch (Throwable var15) {
            var10000 = var15;
            var10001 = false;
            break label122;
         }

         label119:
         try {
            g.c.obtainMessage(0, var1).sendToTarget();
            return;
         } catch (Throwable var14) {
            var10000 = var14;
            var10001 = false;
            break label119;
         }
      }

      while(true) {
         Throwable var16 = var10000;

         try {
            throw var16;
         } catch (Throwable var13) {
            var10000 = var13;
            var10001 = false;
            continue;
         }
      }
   }

   public static class a implements k.d {
      public final String a;
      public final int b;
      public final String c;
      public final Notification d;

      public a(String var1, int var2, String var3, Notification var4) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
      }

      public String toString() {
         StringBuilder var1 = new StringBuilder("NotifyTask[");
         var1.append("packageName:");
         var1.append(this.a);
         var1.append(", id:");
         var1.append(this.b);
         var1.append(", tag:");
         return c.a.b.a.a.a(var1, this.c, "]");
      }
   }

   public static class b {
      public final ComponentName a;
      public final IBinder b;

      public b(ComponentName var1, IBinder var2) {
         this.a = var1;
         this.b = var2;
      }
   }

   public static class c implements Callback, ServiceConnection {
      public final Context a;
      public final HandlerThread b;
      public final Handler c;
      public final Map d = new HashMap();
      public Set e = new HashSet();

      public c(Context var1) {
         this.a = var1;
         this.b = new HandlerThread("NotificationManagerCompat");
         this.b.start();
         this.c = new Handler(this.b.getLooper(), this);
      }

      public final void a(k.c.a var1) {
         if (var1.b) {
            this.a.unbindService(this);
            var1.b = false;
         }

         var1.c = null;
      }

      public final void b(k.c.a var1) {
         StringBuilder var2;
         if (Log.isLoggable("NotifManCompat", 3)) {
            var2 = c.a.b.a.a.b("Processing component ");
            var2.append(var1.a);
            var2.append(", ");
            var2.append(var1.d.size());
            var2.append(" queued tasks");
            Log.d("NotifManCompat", var2.toString());
         }

         if (!var1.d.isEmpty()) {
            boolean var3;
            if (var1.b) {
               var3 = true;
            } else {
               Intent var10 = (new Intent("android.support.BIND_NOTIFICATION_SIDE_CHANNEL")).setComponent(var1.a);
               var1.b = this.a.bindService(var10, this, 33);
               if (var1.b) {
                  var1.e = 0;
               } else {
                  var2 = c.a.b.a.a.b("Unable to bind to listener ");
                  var2.append(var1.a);
                  Log.w("NotifManCompat", var2.toString());
                  this.a.unbindService(this);
               }

               var3 = var1.b;
            }

            if (var3 && var1.c != null) {
               while(true) {
                  k.d var4 = (k.d)var1.d.peek();
                  if (var4 == null) {
                     break;
                  }

                  try {
                     if (Log.isLoggable("NotifManCompat", 3)) {
                        var2 = new StringBuilder();
                        var2.append("Sending task ");
                        var2.append(var4);
                        Log.d("NotifManCompat", var2.toString());
                     }

                     a.a.a.a.a var11 = var1.c;
                     k.a var5 = (k.a)var4;
                     String var12 = var5.a;
                     int var6 = var5.b;
                     String var7 = var5.c;
                     Notification var13 = var5.d;
                     ((a.a.a.a.a.a.a)var11).a(var12, var6, var7, var13);
                     var1.d.remove();
                  } catch (DeadObjectException var8) {
                     if (Log.isLoggable("NotifManCompat", 3)) {
                        var2 = c.a.b.a.a.b("Remote service has died: ");
                        var2.append(var1.a);
                        Log.d("NotifManCompat", var2.toString());
                     }
                     break;
                  } catch (RemoteException var9) {
                     var2 = c.a.b.a.a.b("RemoteException communicating with ");
                     var2.append(var1.a);
                     Log.w("NotifManCompat", var2.toString(), var9);
                     break;
                  }
               }

               if (!var1.d.isEmpty()) {
                  this.c(var1);
               }

            } else {
               this.c(var1);
            }
         }
      }

      public final void c(k.c.a var1) {
         if (!this.c.hasMessages(3, var1.a)) {
            ++var1.e;
            int var2 = var1.e;
            StringBuilder var3;
            if (var2 > 6) {
               var3 = c.a.b.a.a.b("Giving up on delivering ");
               var3.append(var1.d.size());
               var3.append(" tasks to ");
               var3.append(var1.a);
               var3.append(" after ");
               var3.append(var1.e);
               var3.append(" retries");
               Log.w("NotifManCompat", var3.toString());
               var1.d.clear();
            } else {
               var2 = (1 << var2 - 1) * 1000;
               if (Log.isLoggable("NotifManCompat", 3)) {
                  var3 = new StringBuilder();
                  var3.append("Scheduling retry for ");
                  var3.append(var2);
                  var3.append(" ms");
                  Log.d("NotifManCompat", var3.toString());
               }

               Message var4 = this.c.obtainMessage(3, var1.a);
               this.c.sendMessageDelayed(var4, (long)var2);
            }
         }
      }

      public boolean handleMessage(Message var1) {
         int var2 = var1.what;
         if (var2 != 0) {
            if (var2 != 1) {
               ComponentName var11;
               k.c.a var12;
               if (var2 != 2) {
                  if (var2 != 3) {
                     return false;
                  } else {
                     var11 = (ComponentName)var1.obj;
                     var12 = (k.c.a)this.d.get(var11);
                     if (var12 != null) {
                        this.b(var12);
                     }

                     return true;
                  }
               } else {
                  var11 = (ComponentName)var1.obj;
                  var12 = (k.c.a)this.d.get(var11);
                  if (var12 != null) {
                     this.a(var12);
                  }

                  return true;
               }
            } else {
               k.b var9 = (k.b)var1.obj;
               ComponentName var14 = var9.a;
               IBinder var10 = var9.b;
               k.c.a var15 = (k.c.a)this.d.get(var14);
               if (var15 != null) {
                  var15.c = a.a.a.a.a.a.a(var10);
                  var15.e = 0;
                  this.b(var15);
               }

               return true;
            }
         } else {
            k.d var8 = (k.d)var1.obj;
            Set var4 = k.a(this.a);
            if (!var4.equals(this.e)) {
               this.e = var4;
               List var5 = this.a.getPackageManager().queryIntentServices((new Intent()).setAction("android.support.BIND_NOTIFICATION_SIDE_CHANNEL"), 0);
               HashSet var3 = new HashSet();
               Iterator var6 = var5.iterator();

               while(var6.hasNext()) {
                  ResolveInfo var7 = (ResolveInfo)var6.next();
                  if (var4.contains(var7.serviceInfo.packageName)) {
                     ComponentName var19 = new ComponentName(var7.serviceInfo.packageName, var7.serviceInfo.name);
                     if (var7.serviceInfo.permission != null) {
                        StringBuilder var22 = new StringBuilder();
                        var22.append("Permission present on component ");
                        var22.append(var19);
                        var22.append(", not adding listener record.");
                        Log.w("NotifManCompat", var22.toString());
                     } else {
                        var3.add(var19);
                     }
                  }
               }

               var6 = var3.iterator();

               while(var6.hasNext()) {
                  ComponentName var16 = (ComponentName)var6.next();
                  if (!this.d.containsKey(var16)) {
                     if (Log.isLoggable("NotifManCompat", 3)) {
                        StringBuilder var20 = new StringBuilder();
                        var20.append("Adding listener record for ");
                        var20.append(var16);
                        Log.d("NotifManCompat", var20.toString());
                     }

                     this.d.put(var16, new k.c.a(var16));
                  }
               }

               var6 = this.d.entrySet().iterator();

               while(var6.hasNext()) {
                  Entry var21 = (Entry)var6.next();
                  if (!var3.contains(var21.getKey())) {
                     if (Log.isLoggable("NotifManCompat", 3)) {
                        StringBuilder var17 = c.a.b.a.a.b("Removing listener record for ");
                        var17.append(var21.getKey());
                        Log.d("NotifManCompat", var17.toString());
                     }

                     this.a((k.c.a)var21.getValue());
                     var6.remove();
                  }
               }
            }

            Iterator var13 = this.d.values().iterator();

            while(var13.hasNext()) {
               k.c.a var18 = (k.c.a)var13.next();
               var18.d.add(var8);
               this.b(var18);
            }

            return true;
         }
      }

      public void onServiceConnected(ComponentName var1, IBinder var2) {
         if (Log.isLoggable("NotifManCompat", 3)) {
            StringBuilder var3 = new StringBuilder();
            var3.append("Connected to service ");
            var3.append(var1);
            Log.d("NotifManCompat", var3.toString());
         }

         this.c.obtainMessage(1, new k.b(var1, var2)).sendToTarget();
      }

      public void onServiceDisconnected(ComponentName var1) {
         if (Log.isLoggable("NotifManCompat", 3)) {
            StringBuilder var2 = new StringBuilder();
            var2.append("Disconnected from service ");
            var2.append(var1);
            Log.d("NotifManCompat", var2.toString());
         }

         this.c.obtainMessage(2, var1).sendToTarget();
      }

      public static class a {
         public final ComponentName a;
         public boolean b = false;
         public a.a.a.a.a c;
         public ArrayDeque d = new ArrayDeque();
         public int e = 0;

         public a(ComponentName var1) {
            this.a = var1;
         }
      }
   }

   public interface d {
   }
}
