package b.c.b;

public interface d {
}
