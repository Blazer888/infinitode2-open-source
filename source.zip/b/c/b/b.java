package b.c.b;

import android.annotation.TargetApi;
import android.app.AppOpsManager;
import android.app.Notification;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Process;
import android.os.StrictMode;
import android.os.Build.VERSION;
import android.os.Parcelable.Creator;
import android.os.StrictMode.ThreadPolicy;
import android.os.StrictMode.ThreadPolicy.Builder;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory2;
import b.l.s;
import c.c.b.a.d.o.p;
import c.c.b.a.d.o.u0;
import c.c.b.a.i.a.a6;
import c.c.b.a.i.a.j6;
import c.c.b.a.i.a.l3;
import c.c.b.a.i.a.y5;
import c.c.b.a.i.a.y6;
import c.c.b.a.i.g.h1;
import c.c.b.a.i.g.i2;
import c.c.b.a.i.j.a4;
import c.c.b.a.i.j.b2;
import c.c.b.a.i.j.e2;
import c.c.b.a.i.j.e4;
import c.c.b.a.i.j.g2;
import c.c.b.a.i.j.h4;
import c.c.b.a.i.j.i5;
import c.c.b.a.i.j.k1;
import c.c.b.a.i.j.k5;
import c.c.b.a.i.j.k6;
import c.c.b.a.i.j.q6;
import c.c.b.a.i.j.t2;
import c.c.b.a.i.j.u2;
import c.c.b.a.i.j.v5;
import c.c.b.a.i.j.x3;
import c.c.b.a.j.b.ca;
import c.c.b.a.j.b.z3;
import c.c.b.a.l.c0;
import c.c.b.a.l.d0;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.dynamite.DynamiteModule;
import java.io.File;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Map.Entry;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public final class b {
   public static Field a;
   public static boolean b;
   public static Boolean c;
   public static Boolean d;
   public static Boolean e;
   public static Context f;
   public static Boolean g;
   public static ca h;

   public static int a(int var0, byte[] var1, int var2, int var3, e4 var4, t2 var5) {
      a4 var7 = (a4)var4;
      var2 = a(var1, var2, var5);
      var7.f(var5.a);

      while(var2 < var3) {
         int var6 = a(var1, var2, var5);
         if (var0 != var5.a) {
            break;
         }

         var2 = a(var1, var6, var5);
         var7.f(var5.a);
      }

      return var2;
   }

   public static int a(int var0, byte[] var1, int var2, int var3, k6 var4, t2 var5) {
      if (var0 >>> 3 == 0) {
         h4 var10 = h4.c();
         throw var10;
      } else {
         int var6 = var0 & 7;
         if (var6 == 0) {
            var2 = b(var1, var2, var5);
            var4.a(var0, var5.b);
            return var2;
         } else if (var6 == 1) {
            var4.a(var0, b(var1, var2));
            return var2 + 8;
         } else if (var6 == 2) {
            var2 = a(var1, var2, var5);
            var3 = var5.a;
            if (var3 >= 0) {
               if (var3 <= var1.length - var2) {
                  if (var3 == 0) {
                     var4.a(var0, u2.b);
                  } else {
                     var4.a(var0, u2.a(var1, var2, var3));
                  }

                  return var2 + var3;
               } else {
                  throw h4.a();
               }
            } else {
               throw h4.b();
            }
         } else if (var6 != 3) {
            if (var6 == 5) {
               var4.a(var0, a(var1, var2));
               return var2 + 4;
            } else {
               throw h4.c();
            }
         } else {
            k6 var7 = k6.b();
            int var8 = var0 & -8 | 4;
            var6 = 0;

            int var9;
            while(true) {
               var9 = var6;
               var6 = var2;
               if (var2 >= var3) {
                  break;
               }

               var9 = a(var1, var2, var5);
               var6 = var5.a;
               var2 = var6;
               if (var6 == var8) {
                  var6 = var9;
                  var9 = var2;
                  break;
               }

               var2 = a(var6, var1, var9, var3, var7, var5);
            }

            if (var6 <= var3 && var9 == var8) {
               var4.a(var0, var7);
               return var6;
            } else {
               throw h4.e();
            }
         }
      }
   }

   public static int a(int var0, byte[] var1, int var2, int var3, t2 var4) {
      if (var0 >>> 3 == 0) {
         h4 var8 = h4.c();
         throw var8;
      } else {
         int var5 = var0 & 7;
         if (var5 == 0) {
            return b(var1, var2, var4);
         } else if (var5 == 1) {
            return var2 + 8;
         } else if (var5 == 2) {
            return a(var1, var2, var4) + var4.a;
         } else if (var5 != 3) {
            if (var5 == 5) {
               return var2 + 4;
            } else {
               throw h4.c();
            }
         } else {
            int var6 = var0 & -8 | 4;
            var0 = 0;

            int var7;
            while(true) {
               var5 = var0;
               var7 = var2;
               if (var2 >= var3) {
                  break;
               }

               var2 = a(var1, var2, var4);
               var0 = var4.a;
               var5 = var0;
               var7 = var2;
               if (var0 == var6) {
                  break;
               }

               var2 = a(var0, var1, var2, var3, var4);
            }

            if (var7 <= var3 && var5 == var6) {
               return var7;
            } else {
               throw h4.e();
            }
         }
      }
   }

   public static int a(int var0, byte[] var1, int var2, t2 var3) {
      var0 &= 127;
      int var4 = var2 + 1;
      byte var7 = var1[var2];
      if (var7 >= 0) {
         var3.a = var0 | var7 << 7;
         return var4;
      } else {
         var2 = var0 | (var7 & 127) << 7;
         var0 = var4 + 1;
         byte var8 = var1[var4];
         if (var8 >= 0) {
            var3.a = var2 | var8 << 14;
            return var0;
         } else {
            var4 = var2 | (var8 & 127) << 14;
            var2 = var0 + 1;
            byte var6 = var1[var0];
            if (var6 >= 0) {
               var3.a = var4 | var6 << 21;
               return var2;
            } else {
               var4 |= (var6 & 127) << 21;
               var0 = var2 + 1;
               byte var5 = var1[var2];
               if (var5 >= 0) {
                  var3.a = var4 | var5 << 28;
                  return var0;
               } else {
                  while(true) {
                     var2 = var0 + 1;
                     if (var1[var0] >= 0) {
                        var3.a = var4 | (var5 & 127) << 28;
                        return var2;
                     }

                     var0 = var2;
                  }
               }
            }
         }
      }
   }

   public static int a(Context var0, String var1) {
      int var2 = Process.myPid();
      int var3 = Process.myUid();
      String var4 = var0.getPackageName();
      int var5 = var0.checkPermission(var1, var2, var3);
      byte var7 = -1;
      byte var8;
      if (var5 == -1) {
         var8 = var7;
      } else {
         if (VERSION.SDK_INT >= 23) {
            var1 = AppOpsManager.permissionToOp(var1);
         } else {
            var1 = null;
         }

         if (var1 != null) {
            String var6 = var4;
            if (var4 == null) {
               String[] var9 = var0.getPackageManager().getPackagesForUid(var3);
               var8 = var7;
               if (var9 == null) {
                  return var8;
               }

               if (var9.length <= 0) {
                  var8 = var7;
                  return var8;
               }

               var6 = var9[0];
            }

            if (VERSION.SDK_INT >= 23) {
               var3 = ((AppOpsManager)var0.getSystemService(AppOpsManager.class)).noteProxyOpNoThrow(var1, var6);
            } else {
               var3 = 1;
            }

            if (var3 != 0) {
               var8 = -2;
               return var8;
            }
         }

         var8 = 0;
      }

      return var8;
   }

   public static int a(Cursor var0, String var1) {
      int var2 = var0.getColumnIndex(var1);
      if (var2 >= 0) {
         return var2;
      } else {
         StringBuilder var3 = new StringBuilder();
         var3.append("`");
         var3.append(var1);
         var3.append("`");
         return var0.getColumnIndexOrThrow(var3.toString());
      }
   }

   public static int a(Parcel var0) {
      return l(var0, 20293);
   }

   public static int a(s var0) {
      int var1 = var0.ordinal();
      if (var1 != 0) {
         byte var2 = 1;
         if (var1 != 1) {
            var2 = 2;
            if (var1 != 2) {
               var2 = 3;
               if (var1 != 3) {
                  var2 = 4;
                  if (var1 != 4) {
                     if (var1 == 5) {
                        return 5;
                     }

                     StringBuilder var3 = new StringBuilder();
                     var3.append("Could not convert ");
                     var3.append(var0);
                     var3.append(" to int");
                     throw new IllegalArgumentException(var3.toString());
                  }
               }
            }
         }

         return var2;
      } else {
         return 0;
      }
   }

   public static int a(c.c.a.a var0) {
      int var1 = l3.b[var0.ordinal()];
      if (var1 != 2) {
         if (var1 != 3) {
            return var1 != 4 ? 0 : 3;
         } else {
            return 2;
         }
      } else {
         return 1;
      }
   }

   public static int a(v5 var0, int var1, byte[] var2, int var3, int var4, e4 var5, t2 var6) {
      var3 = a(var0, var2, var3, var4, var6);
      var5.add(var6.c);

      while(var3 < var4) {
         int var7 = a(var2, var3, var6);
         if (var1 != var6.a) {
            break;
         }

         var3 = a(var0, var2, var7, var4, var6);
         var5.add(var6.c);
      }

      return var3;
   }

   public static int a(v5 var0, byte[] var1, int var2, int var3, int var4, t2 var5) {
      k5 var7 = (k5)var0;
      Object var6 = var7.a();
      var2 = var7.a(var6, var1, var2, var3, var4, var5);
      var7.c(var6);
      var5.c = var6;
      return var2;
   }

   public static int a(v5 var0, byte[] var1, int var2, int var3, t2 var4) {
      int var5 = var2 + 1;
      byte var6 = var1[var2];
      var2 = var5;
      int var7 = var6;
      if (var6 < 0) {
         var2 = a(var6, var1, var5, var4);
         var7 = var4.a;
      }

      if (var7 >= 0 && var7 <= var3 - var2) {
         Object var8 = var0.a();
         var3 = var7 + var2;
         var0.a(var8, var1, var2, var3, var4);
         var0.c(var8);
         var4.c = var8;
         return var3;
      } else {
         throw h4.a();
      }
   }

   public static int a(byte[] var0, int var1) {
      byte var2 = var0[var1];
      byte var3 = var0[var1 + 1];
      byte var4 = var0[var1 + 2];
      return (var0[var1 + 3] & 255) << 24 | var2 & 255 | (var3 & 255) << 8 | (var4 & 255) << 16;
   }

   public static int a(byte[] var0, int var1, e4 var2, t2 var3) {
      a4 var6 = (a4)var2;
      var1 = a(var0, var1, var3);
      int var4 = var3.a + var1;

      while(var1 < var4) {
         var1 = a(var0, var1, var3);
         var6.f(var3.a);
      }

      if (var1 == var4) {
         return var1;
      } else {
         h4 var5 = h4.a();
         throw var5;
      }
   }

   public static int a(byte[] var0, int var1, t2 var2) {
      int var3 = var1 + 1;
      byte var4 = var0[var1];
      if (var4 >= 0) {
         var2.a = var4;
         return var3;
      } else {
         return a(var4, var0, var3, var2);
      }
   }

   public static Bundle a(Notification var0) {
      return VERSION.SDK_INT >= 19 ? var0.extras : j.a(var0);
   }

   public static Parcelable a(Parcel var0, int var1, Creator var2) {
      int var3 = j(var0, var1);
      var1 = var0.dataPosition();
      if (var3 == 0) {
         return null;
      } else {
         Parcelable var4 = (Parcelable)var2.createFromParcel(var0);
         var0.setDataPosition(var1 + var3);
         return var4;
      }
   }

   public static b.l.d a(byte[] param0) {
      // $FF: Couldn't be decompiled
   }

   public static c.c.a.d.a a(y6 var0, boolean var1) {
      List var2 = var0.e;
      HashSet var3;
      if (var2 != null) {
         var3 = new HashSet(var2);
      } else {
         var3 = null;
      }

      Date var4 = new Date(var0.b);
      int var5 = var0.d;
      c.c.a.b var6;
      if (var5 != 1) {
         if (var5 != 2) {
            var6 = c.c.a.b.a;
         } else {
            var6 = c.c.a.b.c;
         }
      } else {
         var6 = c.c.a.b.b;
      }

      return new c.c.a.d.a(var4, var6, var3, var1, var0.k);
   }

   public static c.c.b.a.d.m.b a(Status var0) {
      boolean var1;
      if (var0.d != null) {
         var1 = true;
      } else {
         var1 = false;
      }

      return (c.c.b.a.d.m.b)(var1 ? new c.c.b.a.d.m.j(var0) : new c.c.b.a.d.m.b(var0));
   }

   public static c.c.b.a.d.m.f a(c.c.b.a.d.m.k var0, c.c.b.a.d.m.e var1) {
      b((Object)var0, (Object)"Result must not be null");
      c.c.b.a.d.m.h var2 = new c.c.b.a.d.m.h(var1);
      var2.a(var0);
      return new c.c.b.a.d.m.n.k(var2);
   }

   public static b2 a(b2 var0) {
      if (!(var0 instanceof g2) && !(var0 instanceof e2)) {
         return (b2)(var0 instanceof Serializable ? new e2(var0) : new g2(var0));
      } else {
         return var0;
      }
   }

   public static c.c.d.f.d a(String var0, String var1) {
      c.c.d.k.a var2 = new c.c.d.k.a(var0, var1);
      c.c.d.f.d.b var3 = c.c.d.f.d.a(c.c.d.k.e.class);
      var3.d = 1;
      var3.a((c.c.d.f.h)(new c.c.d.f.c(var2)));
      return var3.a();
   }

   public static Object a(Context var0, String var1, y5 var2) {
      Exception var10000;
      label32: {
         DynamiteModule var8;
         boolean var10001;
         try {
            var8 = DynamiteModule.a(var0, DynamiteModule.i, "com.google.android.gms.ads.dynamite");
         } catch (Exception var6) {
            Exception var10 = var6;

            try {
               a6 var7 = new a6(var10);
               throw var7;
            } catch (Exception var3) {
               var10000 = var3;
               var10001 = false;
               break label32;
            }
         }

         IBinder var9;
         try {
            var9 = var8.a(var1);
         } catch (Exception var5) {
            var10000 = var5;
            var10001 = false;
            break label32;
         }

         c.c.b.a.i.a.e2 var12 = (c.c.b.a.i.a.e2)var2;

         try {
            return var12.a(var9);
         } catch (Exception var4) {
            var10000 = var4;
            var10001 = false;
         }
      }

      Exception var11 = var10000;
      throw new a6(var11);
   }

   public static Object a(Bundle var0, String var1, Class var2, Object var3) {
      Object var4 = var0.get(var1);
      if (var4 == null) {
         return var3;
      } else if (var2.isAssignableFrom(var4.getClass())) {
         return var4;
      } else {
         throw new IllegalStateException(String.format("Invalid conditional user property field type. '%s' expected [%s] but was [%s]", var1, var2.getCanonicalName(), var4.getClass().getCanonicalName()));
      }
   }

   public static Object a(j6 var0) {
      ThreadPolicy var1 = StrictMode.getThreadPolicy();

      Object var5;
      try {
         Builder var2 = new Builder(var1);
         StrictMode.setThreadPolicy(var2.permitDiskReads().permitDiskWrites().build());
         var5 = var0.get();
      } finally {
         StrictMode.setThreadPolicy(var1);
      }

      return var5;
   }

   public static Object a(k1 var0) {
      Object var1;
      Object var8;
      try {
         var1 = var0.a();
      } catch (SecurityException var7) {
         long var2 = Binder.clearCallingIdentity();

         try {
            var8 = var0.a();
            return var8;
         } finally {
            Binder.restoreCallingIdentity(var2);
         }
      }

      var8 = var1;
      return var8;
   }

   public static Object a(c.c.b.a.l.g var0) {
      c("Must not be called on the main application thread");
      b((Object)var0, (Object)"Task must not be null");
      if (var0.c()) {
         return b(var0);
      } else {
         c.c.b.a.l.j var1 = new c.c.b.a.l.j((d0)null);
         var0.a((Executor)c.c.b.a.l.i.b, (c.c.b.a.l.e)var1);
         var0.a((Executor)c.c.b.a.l.i.b, (c.c.b.a.l.d)var1);
         var0.a((Executor)c.c.b.a.l.i.b, (c.c.b.a.l.b)var1);
         var1.a.await();
         return b(var0);
      }
   }

   public static Object a(c.c.b.a.l.g var0, long var1, TimeUnit var3) {
      c("Must not be called on the main application thread");
      b((Object)var0, (Object)"Task must not be null");
      b((Object)var3, (Object)"TimeUnit must not be null");
      if (var0.c()) {
         return b(var0);
      } else {
         c.c.b.a.l.j var4 = new c.c.b.a.l.j((d0)null);
         var0.a((Executor)c.c.b.a.l.i.b, (c.c.b.a.l.e)var4);
         var0.a((Executor)c.c.b.a.l.i.b, (c.c.b.a.l.d)var4);
         var0.a((Executor)c.c.b.a.l.i.b, (c.c.b.a.l.b)var4);
         if (var4.a.await(var1, var3)) {
            return b(var0);
         } else {
            throw new TimeoutException("Timed out waiting for Task");
         }
      }
   }

   public static Object a(Object var0) {
      if (var0 != null) {
         return var0;
      } else {
         throw new NullPointerException("null reference");
      }
   }

   public static Object a(Object var0, Object var1) {
      if (var0 != null) {
         return var0;
      } else {
         throw new NullPointerException(String.valueOf(var1));
      }
   }

   public static String a(int var0) {
      switch(var0) {
      case -1:
         return "SUCCESS_CACHE";
      case 0:
         return "SUCCESS";
      case 1:
      case 9:
      case 11:
      case 12:
      default:
         StringBuilder var1 = new StringBuilder(32);
         var1.append("unknown status code: ");
         var1.append(var0);
         return var1.toString();
      case 2:
         return "SERVICE_VERSION_UPDATE_REQUIRED";
      case 3:
         return "SERVICE_DISABLED";
      case 4:
         return "SIGN_IN_REQUIRED";
      case 5:
         return "INVALID_ACCOUNT";
      case 6:
         return "RESOLUTION_REQUIRED";
      case 7:
         return "NETWORK_ERROR";
      case 8:
         return "INTERNAL_ERROR";
      case 10:
         return "DEVELOPER_ERROR";
      case 13:
         return "ERROR";
      case 14:
         return "INTERRUPTED";
      case 15:
         return "TIMEOUT";
      case 16:
         return "CANCELED";
      case 17:
         return "API_NOT_CONNECTED";
      case 18:
         return "DEAD_CLIENT";
      }
   }

   public static String a(c.c.b.a.i.g.i var0) {
      StringBuilder var1 = new StringBuilder(var0.size());

      for(int var2 = 0; var2 < var0.size(); ++var2) {
         byte var3 = var0.b(var2);
         if (var3 != 34) {
            if (var3 != 39) {
               if (var3 != 92) {
                  switch(var3) {
                  case 7:
                     var1.append("\\a");
                     break;
                  case 8:
                     var1.append("\\b");
                     break;
                  case 9:
                     var1.append("\\t");
                     break;
                  case 10:
                     var1.append("\\n");
                     break;
                  case 11:
                     var1.append("\\v");
                     break;
                  case 12:
                     var1.append("\\f");
                     break;
                  case 13:
                     var1.append("\\r");
                     break;
                  default:
                     if (var3 >= 32 && var3 <= 126) {
                        var1.append((char)var3);
                     } else {
                        var1.append('\\');
                        var1.append((char)((var3 >>> 6 & 3) + 48));
                        var1.append((char)((var3 >>> 3 & 7) + 48));
                        var1.append((char)((var3 & 7) + 48));
                     }
                  }
               } else {
                  var1.append("\\\\");
               }
            } else {
               var1.append("\\'");
            }
         } else {
            var1.append("\\\"");
         }
      }

      return var1.toString();
   }

   public static String a(u2 var0) {
      StringBuilder var1 = new StringBuilder(var0.a());

      for(int var2 = 0; var2 < var0.a(); ++var2) {
         byte var3 = var0.a(var2);
         if (var3 != 34) {
            if (var3 != 39) {
               if (var3 != 92) {
                  switch(var3) {
                  case 7:
                     var1.append("\\a");
                     break;
                  case 8:
                     var1.append("\\b");
                     break;
                  case 9:
                     var1.append("\\t");
                     break;
                  case 10:
                     var1.append("\\n");
                     break;
                  case 11:
                     var1.append("\\v");
                     break;
                  case 12:
                     var1.append("\\f");
                     break;
                  case 13:
                     var1.append("\\r");
                     break;
                  default:
                     if (var3 >= 32 && var3 <= 126) {
                        var1.append((char)var3);
                     } else {
                        var1.append('\\');
                        var1.append((char)((var3 >>> 6 & 3) + 48));
                        var1.append((char)((var3 >>> 3 & 7) + 48));
                        var1.append((char)((var3 & 7) + 48));
                     }
                  }
               } else {
                  var1.append("\\\\");
               }
            } else {
               var1.append("\\'");
            }
         } else {
            var1.append("\\\"");
         }
      }

      return var1.toString();
   }

   public static String a(String var0, Object var1) {
      if (!TextUtils.isEmpty(var0)) {
         return var0;
      } else {
         throw new IllegalArgumentException(String.valueOf(var1));
      }
   }

   public static String a(String var0, String[] var1, String[] var2) {
      a((Object)var1);
      a((Object)var2);
      int var3 = Math.min(var1.length, var2.length);

      for(int var4 = 0; var4 < var3; ++var4) {
         String var5 = var1[var4];
         boolean var6;
         if (var0 == null && var5 == null) {
            var6 = true;
         } else if (var0 == null) {
            var6 = false;
         } else {
            var6 = var0.equals(var5);
         }

         if (var6) {
            return var2[var4];
         }
      }

      return null;
   }

   public static Set a(SQLiteDatabase var0, String var1) {
      HashSet var2 = new HashSet();
      Cursor var5 = var0.rawQuery(c.a.b.a.a.a(c.a.b.a.a.b(var1, 22), "SELECT * FROM ", var1, " LIMIT 0"), (String[])null);

      try {
         Collections.addAll(var2, var5.getColumnNames());
      } finally {
         var5.close();
      }

      return var2;
   }

   // $FF: synthetic method
   public static void a(byte var0, byte var1, byte var2, byte var3, char[] var4, int var5) {
      if (!b(var1) && var1 + 112 + (var0 << 28) >> 30 == 0 && !b(var2) && !b(var3)) {
         int var6 = (var0 & 7) << 18 | (var1 & 63) << 12 | (var2 & 63) << 6 | var3 & 63;
         var4[var5] = (char)((char)((var6 >>> 10) + 'ퟀ'));
         var4[var5 + 1] = (char)((char)((var6 & 1023) + '\udc00'));
      } else {
         throw h4.f();
      }
   }

   // $FF: synthetic method
   public static void a(byte var0, byte var1, byte var2, char[] var3, int var4) {
      if (!b(var1) && (var0 != -32 || var1 >= -96) && (var0 != -19 || var1 < -96) && !b(var2)) {
         var3[var4] = (char)((char)((var0 & 15) << 12 | (var1 & 63) << 6 | var2 & 63));
      } else {
         throw h4.f();
      }
   }

   // $FF: synthetic method
   public static void a(byte var0, byte var1, char[] var2, int var3) {
      if (var0 >= -62 && !b(var1)) {
         var2[var3] = (char)((char)((var0 & 31) << 6 | var1 & 63));
      } else {
         throw h4.f();
      }
   }

   public static void a(Bundle var0, Object var1) {
      if (var1 instanceof Double) {
         var0.putDouble("value", (Double)var1);
      } else if (var1 instanceof Long) {
         var0.putLong("value", (Long)var1);
      } else {
         var0.putString("value", var1.toString());
      }
   }

   public static void a(Handler var0, String var1) {
      if (Looper.myLooper() != var0.getLooper()) {
         throw new IllegalStateException(var1);
      }
   }

   public static void a(Parcel var0, int var1, int var2) {
      d(var0, var1, 4);
      var0.writeInt(var2);
   }

   public static void a(Parcel var0, int var1, long var2) {
      d(var0, var1, 8);
      var0.writeLong(var2);
   }

   public static void a(Parcel var0, int var1, Bundle var2, boolean var3) {
      if (var2 == null) {
         if (var3) {
            d(var0, var1, 0);
         }

      } else {
         var1 = l(var0, var1);
         var0.writeBundle(var2);
         m(var0, var1);
      }
   }

   public static void a(Parcel var0, int var1, IBinder var2, boolean var3) {
      if (var2 == null) {
         if (var3) {
            d(var0, var1, 0);
         }

      } else {
         var1 = l(var0, var1);
         var0.writeStrongBinder(var2);
         m(var0, var1);
      }
   }

   public static void a(Parcel var0, int var1, Parcelable var2, int var3, boolean var4) {
      if (var2 == null) {
         if (var4) {
            d(var0, var1, 0);
         }

      } else {
         var1 = l(var0, var1);
         var2.writeToParcel(var0, var3);
         m(var0, var1);
      }
   }

   public static void a(Parcel var0, int var1, String var2, boolean var3) {
      if (var2 == null) {
         if (var3) {
            d(var0, var1, 0);
         }

      } else {
         var1 = l(var0, var1);
         var0.writeString(var2);
         m(var0, var1);
      }
   }

   public static void a(Parcel var0, int var1, List var2, boolean var3) {
      if (var2 == null) {
         if (var3) {
            d(var0, var1, 0);
         }

      } else {
         var1 = l(var0, var1);
         var0.writeStringList(var2);
         m(var0, var1);
      }
   }

   public static void a(Parcel var0, int var1, boolean var2) {
      d(var0, var1, 4);
      var0.writeInt(var2);
   }

   public static void a(Parcel var0, int var1, Parcelable[] var2, int var3, boolean var4) {
      if (var2 == null) {
         if (var4) {
            d(var0, var1, 0);
         }

      } else {
         int var5 = l(var0, var1);
         int var6 = var2.length;
         var0.writeInt(var6);

         for(var1 = 0; var1 < var6; ++var1) {
            Parcelable var7 = var2[var1];
            if (var7 == null) {
               var0.writeInt(0);
            } else {
               a(var0, var7, var3);
            }
         }

         m(var0, var5);
      }
   }

   public static void a(Parcel var0, Parcelable var1, int var2) {
      int var3 = var0.dataPosition();
      var0.writeInt(1);
      int var4 = var0.dataPosition();
      var1.writeToParcel(var0, var2);
      var2 = var0.dataPosition();
      var0.setDataPosition(var3);
      var0.writeInt(var2 - var4);
      var0.setDataPosition(var2);
   }

   public static void a(LayoutInflater var0, Factory2 var1) {
      if (!b) {
         try {
            a = LayoutInflater.class.getDeclaredField("mFactory2");
            a.setAccessible(true);
         } catch (NoSuchFieldException var5) {
            StringBuilder var3 = c.a.b.a.a.b("forceSetFactory2 Could not find field 'mFactory2' on class ");
            var3.append(LayoutInflater.class.getName());
            var3.append("; inflation may have unexpected results.");
            Log.e("LayoutInflaterCompatHC", var3.toString(), var5);
         }

         b = true;
      }

      Field var2 = a;
      if (var2 != null) {
         try {
            var2.set(var0, var1);
         } catch (IllegalAccessException var4) {
            StringBuilder var6 = new StringBuilder();
            var6.append("forceSetFactory2 could not set the Factory2 on LayoutInflater ");
            var6.append(var0);
            var6.append("; inflation may have unexpected results.");
            Log.e("LayoutInflaterCompatHC", var6.toString(), var4);
         }
      }

   }

   public static void a(h1 var0, StringBuilder var1, int var2) {
      HashMap var3 = new HashMap();
      HashMap var4 = new HashMap();
      TreeSet var5 = new TreeSet();
      Method[] var6 = var0.getClass().getDeclaredMethods();
      int var7 = var6.length;
      byte var8 = 0;

      int var9;
      Method var10;
      for(var9 = 0; var9 < var7; ++var9) {
         var10 = var6[var9];
         var4.put(var10.getName(), var10);
         if (var10.getParameterTypes().length == 0) {
            var3.put(var10.getName(), var10);
            if (var10.getName().startsWith("get")) {
               var5.add(var10.getName());
            }
         }
      }

      Iterator var17 = var5.iterator();

      while(true) {
         while(var17.hasNext()) {
            String var18 = (String)var17.next();
            String var11 = var18.replaceFirst("get", "");
            boolean var12 = var11.endsWith("List");
            boolean var13 = true;
            String var14;
            String var16;
            Method var21;
            if (var12 && !var11.endsWith("OrBuilderList") && !var11.equals("List")) {
               var14 = String.valueOf(var11.substring(0, 1).toLowerCase());
               var16 = String.valueOf(var11.substring(1, var11.length() - 4));
               if (var16.length() != 0) {
                  var16 = var14.concat(var16);
               } else {
                  var16 = new String(var14);
               }

               var21 = (Method)var3.get(var18);
               if (var21 != null && var21.getReturnType().equals(List.class)) {
                  a(var1, var2, i(var16), c.c.b.a.i.g.d0.a(var21, var0));
                  continue;
               }
            }

            if (var11.endsWith("Map") && !var11.equals("Map")) {
               var16 = String.valueOf(var11.substring(0, 1).toLowerCase());
               var14 = String.valueOf(var11.substring(1, var11.length() - 3));
               if (var14.length() != 0) {
                  var16 = var16.concat(var14);
               } else {
                  var16 = new String(var16);
               }

               var10 = (Method)var3.get(var18);
               if (var10 != null && var10.getReturnType().equals(Map.class) && !var10.isAnnotationPresent(Deprecated.class) && Modifier.isPublic(var10.getModifiers())) {
                  a(var1, var2, i(var16), c.c.b.a.i.g.d0.a(var10, var0));
                  continue;
               }
            }

            if (var11.length() != 0) {
               var16 = "set".concat(var11);
            } else {
               var16 = new String("set");
            }

            if ((Method)var4.get(var16) != null) {
               if (var11.endsWith("Bytes")) {
                  var16 = String.valueOf(var11.substring(0, var11.length() - 5));
                  if (var16.length() != 0) {
                     var16 = "get".concat(var16);
                  } else {
                     var16 = new String("get");
                  }

                  if (var3.containsKey(var16)) {
                     continue;
                  }
               }

               var16 = String.valueOf(var11.substring(0, 1).toLowerCase());
               var18 = String.valueOf(var11.substring(1));
               if (var18.length() != 0) {
                  var16 = var16.concat(var18);
               } else {
                  var16 = new String(var16);
               }

               if (var11.length() != 0) {
                  var18 = "get".concat(var11);
               } else {
                  var18 = new String("get");
               }

               var21 = (Method)var3.get(var18);
               if (var11.length() != 0) {
                  var18 = "has".concat(var11);
               } else {
                  var18 = new String("has");
               }

               var10 = (Method)var3.get(var18);
               if (var21 != null) {
                  Object var19 = c.c.b.a.i.g.d0.a(var21, var0);
                  if (var10 == null) {
                     label153: {
                        label152: {
                           if (var19 instanceof Boolean) {
                              if (!(Boolean)var19) {
                                 break label152;
                              }
                           } else if (var19 instanceof Integer) {
                              if ((Integer)var19 == 0) {
                                 break label152;
                              }
                           } else if (var19 instanceof Float) {
                              if ((Float)var19 == 0.0F) {
                                 break label152;
                              }
                           } else if (var19 instanceof Double) {
                              if ((Double)var19 == 0.0D) {
                                 break label152;
                              }
                           } else {
                              if (var19 instanceof String) {
                                 var12 = var19.equals("");
                                 break label153;
                              }

                              if (var19 instanceof c.c.b.a.i.g.i) {
                                 var12 = var19.equals(c.c.b.a.i.g.i.b);
                                 break label153;
                              }

                              if (var19 instanceof h1) {
                                 if (var19 == ((h1)var19).b()) {
                                    break label152;
                                 }
                              } else if (var19 instanceof Enum && ((Enum)var19).ordinal() == 0) {
                                 break label152;
                              }
                           }

                           var12 = false;
                           break label153;
                        }

                        var12 = true;
                     }

                     if (!var12) {
                        var12 = var13;
                     } else {
                        var12 = false;
                     }
                  } else {
                     var12 = (Boolean)c.c.b.a.i.g.d0.a(var10, var0);
                  }

                  if (var12) {
                     a(var1, var2, i(var16), var19);
                  }
               }
            }
         }

         if (var0 instanceof c.c.b.a.i.g.d0.c) {
            Iterator var20 = ((c.c.b.a.i.g.d0.c)var0).zzrw.b();
            if (var20.hasNext()) {
               ((Entry)var20.next()).getKey();
               throw new NoSuchMethodError();
            }
         }

         i2 var15 = ((c.c.b.a.i.g.d0)var0).zzrq;
         if (var15 != null) {
            for(var9 = var8; var9 < var15.a; ++var9) {
               a(var1, var2, String.valueOf(var15.b[var9] >>> 3), var15.c[var9]);
            }
         }

         return;
      }
   }

   public static void a(i5 var0, StringBuilder var1, int var2) {
      HashMap var3 = new HashMap();
      HashMap var4 = new HashMap();
      TreeSet var5 = new TreeSet();
      Method[] var6 = var0.getClass().getDeclaredMethods();
      int var7 = var6.length;
      byte var8 = 0;

      int var9;
      Method var10;
      for(var9 = 0; var9 < var7; ++var9) {
         var10 = var6[var9];
         var4.put(var10.getName(), var10);
         if (var10.getParameterTypes().length == 0) {
            var3.put(var10.getName(), var10);
            if (var10.getName().startsWith("get")) {
               var5.add(var10.getName());
            }
         }
      }

      Iterator var18 = var5.iterator();

      while(true) {
         while(var18.hasNext()) {
            String var19 = (String)var18.next();
            String var11 = var19.replaceFirst("get", "");
            boolean var12 = var11.endsWith("List");
            boolean var13 = true;
            String var14;
            String var17;
            Method var22;
            if (var12 && !var11.endsWith("OrBuilderList") && !var11.equals("List")) {
               var14 = String.valueOf(var11.substring(0, 1).toLowerCase());
               var17 = String.valueOf(var11.substring(1, var11.length() - 4));
               if (var17.length() != 0) {
                  var17 = var14.concat(var17);
               } else {
                  var17 = new String(var14);
               }

               var22 = (Method)var3.get(var19);
               if (var22 != null && var22.getReturnType().equals(List.class)) {
                  b(var1, var2, d(var17), x3.a(var22, var0));
                  continue;
               }
            }

            if (var11.endsWith("Map") && !var11.equals("Map")) {
               var17 = String.valueOf(var11.substring(0, 1).toLowerCase());
               var14 = String.valueOf(var11.substring(1, var11.length() - 3));
               if (var14.length() != 0) {
                  var17 = var17.concat(var14);
               } else {
                  var17 = new String(var17);
               }

               var10 = (Method)var3.get(var19);
               if (var10 != null && var10.getReturnType().equals(Map.class) && !var10.isAnnotationPresent(Deprecated.class) && Modifier.isPublic(var10.getModifiers())) {
                  b(var1, var2, d(var17), x3.a(var10, var0));
                  continue;
               }
            }

            if (var11.length() != 0) {
               var17 = "set".concat(var11);
            } else {
               var17 = new String("set");
            }

            if ((Method)var4.get(var17) != null) {
               if (var11.endsWith("Bytes")) {
                  var17 = String.valueOf(var11.substring(0, var11.length() - 5));
                  if (var17.length() != 0) {
                     var17 = "get".concat(var17);
                  } else {
                     var17 = new String("get");
                  }

                  if (var3.containsKey(var17)) {
                     continue;
                  }
               }

               var17 = String.valueOf(var11.substring(0, 1).toLowerCase());
               var19 = String.valueOf(var11.substring(1));
               if (var19.length() != 0) {
                  var17 = var17.concat(var19);
               } else {
                  var17 = new String(var17);
               }

               if (var11.length() != 0) {
                  var19 = "get".concat(var11);
               } else {
                  var19 = new String("get");
               }

               var22 = (Method)var3.get(var19);
               if (var11.length() != 0) {
                  var19 = "has".concat(var11);
               } else {
                  var19 = new String("has");
               }

               var10 = (Method)var3.get(var19);
               if (var22 != null) {
                  Object var20 = x3.a(var22, var0);
                  if (var10 == null) {
                     label153: {
                        label152: {
                           if (var20 instanceof Boolean) {
                              if (!(Boolean)var20) {
                                 break label152;
                              }
                           } else if (var20 instanceof Integer) {
                              if ((Integer)var20 == 0) {
                                 break label152;
                              }
                           } else if (var20 instanceof Float) {
                              if ((Float)var20 == 0.0F) {
                                 break label152;
                              }
                           } else if (var20 instanceof Double) {
                              if ((Double)var20 == 0.0D) {
                                 break label152;
                              }
                           } else {
                              if (var20 instanceof String) {
                                 var12 = var20.equals("");
                                 break label153;
                              }

                              if (var20 instanceof u2) {
                                 var12 = var20.equals(u2.b);
                                 break label153;
                              }

                              if (var20 instanceof i5) {
                                 if (var20 == ((i5)var20).a()) {
                                    break label152;
                                 }
                              } else if (var20 instanceof Enum && ((Enum)var20).ordinal() == 0) {
                                 break label152;
                              }
                           }

                           var12 = false;
                           break label153;
                        }

                        var12 = true;
                     }

                     if (!var12) {
                        var12 = var13;
                     } else {
                        var12 = false;
                     }
                  } else {
                     var12 = (Boolean)x3.a(var10, var0);
                  }

                  if (var12) {
                     b(var1, var2, d(var17), var20);
                  }
               }
            }
         }

         if (var0 instanceof x3.d) {
            Iterator var21 = ((x3.d)var0).zzc.b();
            if (var21.hasNext()) {
               x3.c var16 = (x3.c)((Entry)var21.next()).getKey();
               throw new NoSuchMethodError();
            }
         }

         k6 var15 = ((x3)var0).zzb;
         if (var15 != null) {
            for(var9 = var8; var9 < var15.a; ++var9) {
               b(var1, var2, String.valueOf(var15.b[var9] >>> 3), var15.c[var9]);
            }
         }

         return;
      }
   }

   public static void a(z3 var0, SQLiteDatabase var1) {
      if (var0 != null) {
         File var2 = new File(var1.getPath());
         if (!var2.setReadable(false, false)) {
            var0.i.a("Failed to turn off database read permission");
         }

         if (!var2.setWritable(false, false)) {
            var0.i.a("Failed to turn off database write permission");
         }

         if (!var2.setReadable(true, true)) {
            var0.i.a("Failed to turn on database read permission for owner");
         }

         if (!var2.setWritable(true, true)) {
            var0.i.a("Failed to turn on database write permission for owner");
         }

      } else {
         throw new IllegalArgumentException("Monitor must not be null");
      }
   }

   public static void a(z3 param0, SQLiteDatabase param1, String param2, String param3, String param4, String[] param5) {
      // $FF: Couldn't be decompiled
   }

   public static void a(Object var0, StringBuilder var1) {
      if (var0 == null) {
         var1.append("null");
      } else {
         String var2 = var0.getClass().getSimpleName();
         String var3 = var2;
         if (var2.length() <= 0) {
            var2 = var0.getClass().getName();
            int var4 = var2.lastIndexOf(46);
            var3 = var2;
            if (var4 > 0) {
               var3 = var2.substring(var4 + 1);
            }
         }

         var1.append(var3);
         var1.append('{');
         var1.append(Integer.toHexString(System.identityHashCode(var0)));
      }

   }

   public static void a(String var0) {
      boolean var1;
      if (Looper.getMainLooper() == Looper.myLooper()) {
         var1 = true;
      } else {
         var1 = false;
      }

      if (!var1) {
         throw new IllegalStateException(var0);
      }
   }

   public static void a(String var0, Throwable var1) {
      if (e(6)) {
         Log.e("Ads", var0, var1);
      }

   }

   public static final void a(StringBuilder var0, int var1, String var2, Object var3) {
      Iterator var8;
      if (var3 instanceof List) {
         var8 = ((List)var3).iterator();

         while(var8.hasNext()) {
            a(var0, var1, var2, var8.next());
         }

      } else if (var3 instanceof Map) {
         var8 = ((Map)var3).entrySet().iterator();

         while(var8.hasNext()) {
            a((StringBuilder)var0, var1, (String)var2, (Object)((Entry)var8.next()));
         }

      } else {
         var0.append('\n');
         byte var4 = 0;
         byte var5 = 0;

         int var6;
         for(var6 = 0; var6 < var1; ++var6) {
            var0.append(' ');
         }

         var0.append(var2);
         if (var3 instanceof String) {
            var0.append(": \"");
            var0.append(a(c.c.b.a.i.g.i.a((String)var3)));
            var0.append('"');
         } else if (var3 instanceof c.c.b.a.i.g.i) {
            var0.append(": \"");
            var0.append(a((c.c.b.a.i.g.i)var3));
            var0.append('"');
         } else if (var3 instanceof c.c.b.a.i.g.d0) {
            var0.append(" {");
            a((h1)((c.c.b.a.i.g.d0)var3), (StringBuilder)var0, var1 + 2);
            var0.append("\n");

            for(var6 = var5; var6 < var1; ++var6) {
               var0.append(' ');
            }

            var0.append("}");
         } else if (!(var3 instanceof Entry)) {
            var0.append(": ");
            var0.append(var3.toString());
         } else {
            var0.append(" {");
            Entry var7 = (Entry)var3;
            var6 = var1 + 2;
            a(var0, var6, "key", var7.getKey());
            a(var0, var6, "value", var7.getValue());
            var0.append("\n");

            for(var6 = var4; var6 < var1; ++var6) {
               var0.append(' ');
            }

            var0.append("}");
         }
      }
   }

   public static void a(boolean var0) {
      if (!var0) {
         throw new IllegalArgumentException();
      }
   }

   public static void a(boolean var0, Object var1) {
      if (!var0) {
         throw new IllegalArgumentException(String.valueOf(var1));
      }
   }

   public static void a(boolean var0, String var1, Object... var2) {
      if (!var0) {
         throw new IllegalStateException(String.format(var1, var2));
      }
   }

   public static boolean a() {
      return VERSION.SDK_INT >= 17;
   }

   // $FF: synthetic method
   public static boolean a(byte var0) {
      boolean var1;
      if (var0 >= 0) {
         var1 = true;
      } else {
         var1 = false;
      }

      return var1;
   }

   public static boolean a(Context param0) {
      // $FF: Couldn't be decompiled
   }

   public static boolean a(Context var0, int var1) {
      if (!c.c.b.a.d.s.c.b(var0).a(var1, "com.google.android.gms")) {
         return false;
      } else {
         PackageManager var2 = var0.getPackageManager();

         PackageInfo var4;
         try {
            var4 = var2.getPackageInfo("com.google.android.gms", 64);
         } catch (NameNotFoundException var3) {
            if (Log.isLoggable("UidVerifier", 3)) {
               Log.d("UidVerifier", "Package manager can't find google play services package, defaulting to false");
            }

            return false;
         }

         return c.c.b.a.d.j.a(var0).a(var4);
      }
   }

   public static boolean[] a(Parcel var0, int var1) {
      int var2 = j(var0, var1);
      var1 = var0.dataPosition();
      if (var2 == 0) {
         return null;
      } else {
         boolean[] var3 = var0.createBooleanArray();
         var0.setDataPosition(var1 + var2);
         return var3;
      }
   }

   public static int b(Parcel var0) {
      int var1 = var0.readInt();
      int var2 = j(var0, var1);
      int var3 = var0.dataPosition();
      if (('\uffff' & var1) != 20293) {
         String var4 = String.valueOf(Integer.toHexString(var1));
         if (var4.length() != 0) {
            var4 = "Expected object header. Got 0x".concat(var4);
         } else {
            var4 = new String("Expected object header. Got 0x");
         }

         throw new c.c.b.a.d.o.v.b(var4, var0);
      } else {
         var2 += var3;
         if (var2 >= var3 && var2 <= var0.dataSize()) {
            return var2;
         } else {
            throw new c.c.b.a.d.o.v.b(c.a.b.a.a.a(54, "Size read is invalid start=", var3, " end=", var2), var0);
         }
      }
   }

   public static int b(byte[] var0, int var1, t2 var2) {
      int var3 = var1 + 1;
      long var4 = (long)var0[var1];
      if (var4 >= 0L) {
         var2.b = var4;
         return var3;
      } else {
         var1 = var3 + 1;
         byte var6 = var0[var3];
         var4 = var4 & 127L | (long)(var6 & 127) << 7;

         for(var3 = 7; var6 < 0; ++var1) {
            var6 = var0[var1];
            var3 += 7;
            var4 |= (long)(var6 & 127) << var3;
         }

         var2.b = var4;
         return var1;
      }
   }

   public static long b(byte[] var0, int var1) {
      long var2 = (long)var0[var1];
      long var4 = (long)var0[var1 + 1];
      long var6 = (long)var0[var1 + 2];
      long var8 = (long)var0[var1 + 3];
      long var10 = (long)var0[var1 + 4];
      long var12 = (long)var0[var1 + 5];
      long var14 = (long)var0[var1 + 6];
      return ((long)var0[var1 + 7] & 255L) << 56 | var2 & 255L | (var4 & 255L) << 8 | (var6 & 255L) << 16 | (var8 & 255L) << 24 | (var10 & 255L) << 32 | (var12 & 255L) << 40 | (var14 & 255L) << 48;
   }

   public static Bundle b(Parcel var0, int var1) {
      var1 = j(var0, var1);
      int var2 = var0.dataPosition();
      if (var1 == 0) {
         return null;
      } else {
         Bundle var3 = var0.readBundle();
         var0.setDataPosition(var2 + var1);
         return var3;
      }
   }

   public static b.l.a b(int var0) {
      if (var0 != 0) {
         if (var0 == 1) {
            return b.l.a.b;
         } else {
            throw new IllegalArgumentException(c.a.b.a.a.a("Could not convert ", var0, " to BackoffPolicy"));
         }
      } else {
         return b.l.a.a;
      }
   }

   public static c.c.b.a.l.g b(Object var0) {
      c0 var1 = new c0();
      var1.a(var0);
      return var1;
   }

   public static Object b(c.c.b.a.l.g var0) {
      if (var0.d()) {
         return var0.b();
      } else if (((c0)var0).d) {
         throw new CancellationException("Task is already canceled");
      } else {
         throw new ExecutionException(var0.a());
      }
   }

   public static Object b(Object var0, Object var1) {
      if (var0 != null) {
         return var0;
      } else {
         throw new NullPointerException(String.valueOf(var1));
      }
   }

   public static String b(String var0) {
      if (!TextUtils.isEmpty(var0)) {
         return var0;
      } else {
         throw new IllegalArgumentException("Given String is empty or null");
      }
   }

   public static String b(byte[] var0) {
      return var0 == null ? null : Base64.encodeToString(var0, 11);
   }

   public static void b(Parcel var0, int var1, int var2) {
      var1 = j(var0, var1);
      if (var1 != var2) {
         String var3 = Integer.toHexString(var1);
         StringBuilder var4 = new StringBuilder(c.a.b.a.a.b(var3, 46));
         var4.append("Expected size ");
         var4.append(var2);
         var4.append(" got ");
         var4.append(var1);
         throw new c.c.b.a.d.o.v.b(c.a.b.a.a.a(var4, " (0x", var3, ")"), var0);
      }
   }

   public static void b(Parcel var0, int var1, List var2, boolean var3) {
      if (var2 == null) {
         if (var3) {
            d(var0, var1, 0);
         }

      } else {
         int var4 = l(var0, var1);
         int var5 = var2.size();
         var0.writeInt(var5);

         for(var1 = 0; var1 < var5; ++var1) {
            Parcelable var6 = (Parcelable)var2.get(var1);
            if (var6 == null) {
               var0.writeInt(0);
            } else {
               a((Parcel)var0, (Parcelable)var6, 0);
            }
         }

         m(var0, var4);
      }
   }

   public static void b(String var0, Throwable var1) {
      if (e(5)) {
         Log.w("Ads", var0, var1);
      }

   }

   public static final void b(StringBuilder var0, int var1, String var2, Object var3) {
      Iterator var8;
      if (var3 instanceof List) {
         var8 = ((List)var3).iterator();

         while(var8.hasNext()) {
            b(var0, var1, var2, var8.next());
         }

      } else if (var3 instanceof Map) {
         var8 = ((Map)var3).entrySet().iterator();

         while(var8.hasNext()) {
            b(var0, var1, var2, (Entry)var8.next());
         }

      } else {
         var0.append('\n');
         byte var4 = 0;
         byte var5 = 0;

         int var6;
         for(var6 = 0; var6 < var1; ++var6) {
            var0.append(' ');
         }

         var0.append(var2);
         if (var3 instanceof String) {
            var0.append(": \"");
            var0.append(a(u2.a((String)var3)));
            var0.append('"');
         } else if (var3 instanceof u2) {
            var0.append(": \"");
            var0.append(a((u2)var3));
            var0.append('"');
         } else if (var3 instanceof x3) {
            var0.append(" {");
            a((i5)((x3)var3), (StringBuilder)var0, var1 + 2);
            var0.append("\n");

            for(var6 = var5; var6 < var1; ++var6) {
               var0.append(' ');
            }

            var0.append("}");
         } else if (!(var3 instanceof Entry)) {
            var0.append(": ");
            var0.append(var3.toString());
         } else {
            var0.append(" {");
            Entry var7 = (Entry)var3;
            var6 = var1 + 2;
            b(var0, var6, "key", var7.getKey());
            b(var0, var6, "value", var7.getValue());
            var0.append("\n");

            for(var6 = var4; var6 < var1; ++var6) {
               var0.append(' ');
            }

            var0.append("}");
         }
      }
   }

   public static void b(boolean var0) {
      if (!var0) {
         throw new IllegalStateException();
      }
   }

   public static void b(boolean var0, Object var1) {
      if (!var0) {
         throw new IllegalStateException(String.valueOf(var1));
      }
   }

   public static boolean b() {
      return VERSION.SDK_INT >= 21;
   }

   public static boolean b(byte var0) {
      return var0 > -65;
   }

   @TargetApi(20)
   public static boolean b(Context var0) {
      if (c == null) {
         int var1 = VERSION.SDK_INT;
         boolean var2 = true;
         boolean var3;
         if (var1 >= 20) {
            var3 = true;
         } else {
            var3 = false;
         }

         if (!var3 || !var0.getPackageManager().hasSystemFeature("android.hardware.type.watch")) {
            var2 = false;
         }

         c = var2;
      }

      return c;
   }

   public static Object[] b(Parcel var0, int var1, Creator var2) {
      int var3 = j(var0, var1);
      var1 = var0.dataPosition();
      if (var3 == 0) {
         return null;
      } else {
         Object[] var4 = var0.createTypedArray(var2);
         var0.setDataPosition(var1 + var3);
         return var4;
      }
   }

   public static double c(byte[] var0, int var1) {
      return Double.longBitsToDouble(b(var0, var1));
   }

   public static int c(byte[] var0, int var1, t2 var2) {
      int var3 = a(var0, var1, var2);
      var1 = var2.a;
      if (var1 >= 0) {
         if (var1 == 0) {
            var2.c = "";
            return var3;
         } else {
            var2.c = new String(var0, var3, var1, c.c.b.a.i.j.z3.a);
            return var3 + var1;
         }
      } else {
         throw h4.b();
      }
   }

   public static b.l.m c(int var0) {
      if (var0 != 0) {
         if (var0 != 1) {
            if (var0 != 2) {
               if (var0 != 3) {
                  if (var0 == 4) {
                     return b.l.m.e;
                  } else {
                     throw new IllegalArgumentException(c.a.b.a.a.a("Could not convert ", var0, " to NetworkType"));
                  }
               } else {
                  return b.l.m.d;
               }
            } else {
               return b.l.m.c;
            }
         } else {
            return b.l.m.b;
         }
      } else {
         return b.l.m.a;
      }
   }

   public static p c(Object var0) {
      return new p(var0, (u0)null);
   }

   public static String c(Parcel var0, int var1) {
      var1 = j(var0, var1);
      int var2 = var0.dataPosition();
      if (var1 == 0) {
         return null;
      } else {
         String var3 = var0.readString();
         var0.setDataPosition(var2 + var1);
         return var3;
      }
   }

   public static ArrayList c(Parcel var0, int var1, Creator var2) {
      var1 = j(var0, var1);
      int var3 = var0.dataPosition();
      if (var1 == 0) {
         return null;
      } else {
         ArrayList var4 = var0.createTypedArrayList(var2);
         var0.setDataPosition(var3 + var1);
         return var4;
      }
   }

   public static void c(Parcel var0, int var1, int var2) {
      if (var1 != var2) {
         String var3 = Integer.toHexString(var1);
         StringBuilder var4 = new StringBuilder(c.a.b.a.a.b(var3, 46));
         var4.append("Expected size ");
         var4.append(var2);
         var4.append(" got ");
         var4.append(var1);
         throw new c.c.b.a.d.o.v.b(c.a.b.a.a.a(var4, " (0x", var3, ")"), var0);
      }
   }

   public static void c(String var0) {
      boolean var1;
      if (Looper.getMainLooper() == Looper.myLooper()) {
         var1 = true;
      } else {
         var1 = false;
      }

      if (var1) {
         throw new IllegalStateException(var0);
      }
   }

   public static void c(String var0, Throwable var1) {
      if (e(5)) {
         if (var1 != null) {
            b(h(var0), var1);
            return;
         }

         g(h(var0));
      }

   }

   public static boolean c() {
      return VERSION.SDK_INT >= 26;
   }

   @TargetApi(26)
   public static boolean c(Context var0) {
      if (b(var0)) {
         boolean var1;
         if (VERSION.SDK_INT >= 24) {
            var1 = true;
         } else {
            var1 = false;
         }

         if (!var1) {
            return true;
         }

         if (d == null) {
            boolean var2;
            if (b() && var0.getPackageManager().hasSystemFeature("cn.google")) {
               var2 = true;
            } else {
               var2 = false;
            }

            d = var2;
         }

         if (d && !c()) {
            return true;
         }
      }

      return false;
   }

   public static boolean c(Object var0, Object var1) {
      return var0 == var1 || var0 != null && var0.equals(var1);
   }

   public static float d(byte[] var0, int var1) {
      return Float.intBitsToFloat(a(var0, var1));
   }

   public static int d(byte[] var0, int var1, t2 var2) {
      var1 = a(var0, var1, var2);
      int var3 = var2.a;
      if (var3 >= 0) {
         if (var3 == 0) {
            var2.c = "";
            return var1;
         } else {
            var2.c = q6.a.b(var0, var1, var3);
            return var1 + var3;
         }
      } else {
         throw h4.b();
      }
   }

   public static s d(int var0) {
      if (var0 != 0) {
         if (var0 != 1) {
            if (var0 != 2) {
               if (var0 != 3) {
                  if (var0 != 4) {
                     if (var0 == 5) {
                        return s.f;
                     } else {
                        throw new IllegalArgumentException(c.a.b.a.a.a("Could not convert ", var0, " to State"));
                     }
                  } else {
                     return s.e;
                  }
               } else {
                  return s.d;
               }
            } else {
               return s.c;
            }
         } else {
            return s.b;
         }
      } else {
         return s.a;
      }
   }

   public static final String d(String var0) {
      StringBuilder var1 = new StringBuilder();

      for(int var2 = 0; var2 < var0.length(); ++var2) {
         char var3 = var0.charAt(var2);
         if (Character.isUpperCase(var3)) {
            var1.append("_");
         }

         var1.append(Character.toLowerCase(var3));
      }

      return var1.toString();
   }

   public static ArrayList d(Parcel var0, int var1) {
      int var2 = j(var0, var1);
      var1 = var0.dataPosition();
      if (var2 == 0) {
         return null;
      } else {
         ArrayList var3 = var0.createStringArrayList();
         var0.setDataPosition(var1 + var2);
         return var3;
      }
   }

   public static void d(Parcel var0, int var1, int var2) {
      if (var2 >= 65535) {
         var0.writeInt(var1 | -65536);
         var0.writeInt(var2);
      } else {
         var0.writeInt(var1 | var2 << 16);
      }
   }

   public static int e(byte[] var0, int var1, t2 var2) {
      var1 = a(var0, var1, var2);
      int var3 = var2.a;
      if (var3 >= 0) {
         if (var3 <= var0.length - var1) {
            if (var3 == 0) {
               var2.c = u2.b;
               return var1;
            } else {
               var2.c = u2.a(var0, var1, var3);
               return var1 + var3;
            }
         } else {
            throw h4.a();
         }
      } else {
         throw h4.b();
      }
   }

   public static void e(Parcel var0, int var1) {
      if (var0.dataPosition() != var1) {
         StringBuilder var2 = new StringBuilder(37);
         var2.append("Overread allowed size end=");
         var2.append(var1);
         throw new c.c.b.a.d.o.v.b(var2.toString(), var0);
      }
   }

   public static void e(String var0) {
      if (e(3)) {
         Log.d("Ads", var0);
      }

   }

   public static boolean e(int var0) {
      return var0 >= 5 || Log.isLoggable("Ads", var0);
   }

   public static void f(String var0) {
      if (e(6)) {
         Log.e("Ads", var0);
      }

   }

   public static boolean f(Parcel var0, int var1) {
      b(var0, var1, 4);
      return var0.readInt() != 0;
   }

   public static IBinder g(Parcel var0, int var1) {
      int var2 = j(var0, var1);
      var1 = var0.dataPosition();
      if (var2 == 0) {
         return null;
      } else {
         IBinder var3 = var0.readStrongBinder();
         var0.setDataPosition(var1 + var2);
         return var3;
      }
   }

   public static void g(String var0) {
      if (e(5)) {
         Log.w("Ads", var0);
      }

   }

   public static int h(Parcel var0, int var1) {
      b(var0, var1, 4);
      return var0.readInt();
   }

   public static String h(String var0) {
      StackTraceElement[] var1 = Thread.currentThread().getStackTrace();
      String var2 = var0;
      if (var1.length >= 4) {
         int var3 = var1[3].getLineNumber();
         StringBuilder var4 = new StringBuilder(c.a.b.a.a.b(var0, 13));
         var4.append(var0);
         var4.append(" @");
         var4.append(var3);
         var2 = var4.toString();
      }

      return var2;
   }

   public static long i(Parcel var0, int var1) {
      b(var0, var1, 8);
      return var0.readLong();
   }

   public static final String i(String var0) {
      StringBuilder var1 = new StringBuilder();

      for(int var2 = 0; var2 < var0.length(); ++var2) {
         char var3 = var0.charAt(var2);
         if (Character.isUpperCase(var3)) {
            var1.append("_");
         }

         var1.append(Character.toLowerCase(var3));
      }

      return var1.toString();
   }

   public static int j(Parcel var0, int var1) {
      return (var1 & -65536) != -65536 ? var1 >> 16 & '\uffff' : var0.readInt();
   }

   public static void k(Parcel var0, int var1) {
      var1 = j(var0, var1);
      var0.setDataPosition(var0.dataPosition() + var1);
   }

   public static int l(Parcel var0, int var1) {
      var0.writeInt(var1 | -65536);
      var0.writeInt(0);
      return var0.dataPosition();
   }

   public static void m(Parcel var0, int var1) {
      int var2 = var0.dataPosition();
      var0.setDataPosition(var1 - 4);
      var0.writeInt(var2 - var1);
      var0.setDataPosition(var2);
   }
}
