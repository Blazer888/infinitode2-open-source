package b.c.b;

import android.app.PendingIntent;
import android.os.Bundle;

public class e {
   public final Bundle a;
   public final l[] b;
   public final l[] c;
   public boolean d;
   public boolean e;
   public final int f;
   public int g;
   public CharSequence h;
   public PendingIntent i;

   public e(int var1, CharSequence var2, PendingIntent var3) {
      Bundle var4 = new Bundle();
      super();
      this.e = true;
      this.g = var1;
      this.h = b.c.b.g.a(var2);
      this.i = var3;
      this.a = var4;
      this.b = null;
      this.c = null;
      this.d = true;
      this.f = 0;
      this.e = true;
   }
}
