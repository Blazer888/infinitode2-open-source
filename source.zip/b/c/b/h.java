package b.c.b;

import android.widget.RemoteViews;

public abstract class h {
   public g a;
   public CharSequence b;
   public CharSequence c;
   public boolean d = false;

   public RemoteViews a() {
      return null;
   }
}
