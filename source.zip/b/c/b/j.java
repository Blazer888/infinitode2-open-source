package b.c.b;

import android.app.Notification;
import android.app.Notification.Builder;
import android.os.Bundle;
import android.util.SparseArray;
import java.lang.reflect.Field;
import java.util.List;

public class j {
   public static final Object a = new Object();
   public static Field b;
   public static boolean c;

   public static Bundle a(Builder var0, e var1) {
      var0.addAction(var1.g, var1.h, var1.i);
      Bundle var3 = new Bundle(var1.a);
      l[] var2 = var1.b;
      if (var2 != null) {
         var3.putParcelableArray("android.support.remoteInputs", a(var2));
      }

      var2 = var1.c;
      if (var2 != null) {
         var3.putParcelableArray("android.support.dataRemoteInputs", a(var2));
      }

      var3.putBoolean("android.support.allowGeneratedReplies", var1.d);
      return var3;
   }

   public static Bundle a(Notification param0) {
      // $FF: Couldn't be decompiled
   }

   public static Bundle a(e var0) {
      Bundle var1 = new Bundle();
      var1.putInt("icon", var0.g);
      var1.putCharSequence("title", var0.h);
      var1.putParcelable("actionIntent", var0.i);
      Bundle var2 = var0.a;
      if (var2 != null) {
         var2 = new Bundle(var2);
      } else {
         var2 = new Bundle();
      }

      var2.putBoolean("android.support.allowGeneratedReplies", var0.d);
      var1.putBundle("extras", var2);
      var1.putParcelableArray("remoteInputs", a(var0.b));
      var1.putBoolean("showsUserInterface", var0.e);
      var1.putInt("semanticAction", var0.f);
      return var1;
   }

   public static SparseArray a(List var0) {
      int var1 = var0.size();
      SparseArray var2 = null;

      SparseArray var5;
      for(int var3 = 0; var3 < var1; var2 = var5) {
         Bundle var4 = (Bundle)var0.get(var3);
         var5 = var2;
         if (var4 != null) {
            var5 = var2;
            if (var2 == null) {
               var5 = new SparseArray();
            }

            var5.put(var3, var4);
         }

         ++var3;
      }

      return var2;
   }

   public static Bundle[] a(l[] var0) {
      if (var0 == null) {
         return null;
      } else {
         Bundle[] var1 = new Bundle[var0.length];
         if (var0.length <= 0) {
            return var1;
         } else {
            l var2 = var0[0];
            new Bundle();
            throw null;
         }
      }
   }
}
