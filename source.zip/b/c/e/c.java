package b.c.e;

import android.os.Build.VERSION;
import android.util.Log;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;

public class c {
   public static WeakHashMap a;

   static {
      new AtomicInteger(1);
      int var0 = b.c.a.accessibility_custom_action_0;
      var0 = b.c.a.accessibility_custom_action_1;
      var0 = b.c.a.accessibility_custom_action_2;
      var0 = b.c.a.accessibility_custom_action_3;
      var0 = b.c.a.accessibility_custom_action_4;
      var0 = b.c.a.accessibility_custom_action_5;
      var0 = b.c.a.accessibility_custom_action_6;
      var0 = b.c.a.accessibility_custom_action_7;
      var0 = b.c.a.accessibility_custom_action_8;
      var0 = b.c.a.accessibility_custom_action_9;
      var0 = b.c.a.accessibility_custom_action_10;
      var0 = b.c.a.accessibility_custom_action_11;
      var0 = b.c.a.accessibility_custom_action_12;
      var0 = b.c.a.accessibility_custom_action_13;
      var0 = b.c.a.accessibility_custom_action_14;
      var0 = b.c.a.accessibility_custom_action_15;
      var0 = b.c.a.accessibility_custom_action_16;
      var0 = b.c.a.accessibility_custom_action_17;
      var0 = b.c.a.accessibility_custom_action_18;
      var0 = b.c.a.accessibility_custom_action_19;
      var0 = b.c.a.accessibility_custom_action_20;
      var0 = b.c.a.accessibility_custom_action_21;
      var0 = b.c.a.accessibility_custom_action_22;
      var0 = b.c.a.accessibility_custom_action_23;
      var0 = b.c.a.accessibility_custom_action_24;
      var0 = b.c.a.accessibility_custom_action_25;
      var0 = b.c.a.accessibility_custom_action_26;
      var0 = b.c.a.accessibility_custom_action_27;
      var0 = b.c.a.accessibility_custom_action_28;
      var0 = b.c.a.accessibility_custom_action_29;
      var0 = b.c.a.accessibility_custom_action_30;
      var0 = b.c.a.accessibility_custom_action_31;
      new b.c.e.c.a();
   }

   public static String a(View var0) {
      if (VERSION.SDK_INT >= 21) {
         return var0.getTransitionName();
      } else {
         WeakHashMap var1 = a;
         return var1 == null ? null : (String)var1.get(var0);
      }
   }

   public static void a(View var0, int var1) {
      if (((AccessibilityManager)var0.getContext().getSystemService("accessibility")).isEnabled()) {
         b.c.e.b var2 = new b.c.e.b(b.c.a.tag_accessibility_pane_title, CharSequence.class, 8, 28);
         int var3 = VERSION.SDK_INT;
         int var4 = var2.c;
         boolean var5 = true;
         int var6 = 0;
         boolean var10;
         if (var3 >= var4) {
            var10 = true;
         } else {
            var10 = false;
         }

         Object var7;
         if (var10) {
            var7 = var0.getAccessibilityPaneTitle();
         } else {
            label68: {
               if (VERSION.SDK_INT >= 19) {
                  var10 = true;
               } else {
                  var10 = false;
               }

               if (var10) {
                  var7 = var0.getTag(var2.a);
                  if (var2.b.isInstance(var7)) {
                     break label68;
                  }
               }

               var7 = null;
            }
         }

         if ((CharSequence)var7 != null) {
            var10 = var5;
         } else {
            var10 = false;
         }

         if (VERSION.SDK_INT >= 19) {
            var6 = var0.getAccessibilityLiveRegion();
         }

         if (var6 == 0 && (!var10 || var0.getVisibility() != 0)) {
            if (var0.getParent() != null) {
               try {
                  var0.getParent().notifySubtreeAccessibilityStateChanged(var0, var0, var1);
               } catch (AbstractMethodError var8) {
                  StringBuilder var9 = new StringBuilder();
                  var9.append(var0.getParent().getClass().getSimpleName());
                  var9.append(" does not fully implement ViewParent");
                  Log.e("ViewCompat", var9.toString(), var8);
               }
            }
         } else {
            AccessibilityEvent var12 = AccessibilityEvent.obtain();
            short var11;
            if (var10) {
               var11 = 32;
            } else {
               var11 = 2048;
            }

            var12.setEventType(var11);
            var12.setContentChangeTypes(var1);
            var0.sendAccessibilityEventUnchecked(var12);
         }

      }
   }

   public static void a(View var0, String var1) {
      if (VERSION.SDK_INT >= 21) {
         var0.setTransitionName(var1);
      } else {
         if (a == null) {
            a = new WeakHashMap();
         }

         a.put(var0, var1);
      }

   }

   public static boolean a(View var0, KeyEvent var1) {
      return VERSION.SDK_INT >= 28 ? false : b.c.e.c.d.a(var0).a(var0, var1);
   }

   public static boolean b(View var0) {
      int var1 = VERSION.SDK_INT;
      return var0.hasOverlappingRendering();
   }

   public static boolean b(View var0, KeyEvent var1) {
      int var2 = VERSION.SDK_INT;
      boolean var3 = false;
      if (var2 >= 28) {
         return false;
      } else {
         b.c.e.c.d var4 = b.c.e.c.d.a(var0);
         WeakReference var7 = var4.c;
         if (var7 == null || var7.get() != var1) {
            var4.c = new WeakReference(var1);
            WeakReference var5 = null;
            SparseArray var6 = var4.a();
            var7 = var5;
            if (var1.getAction() == 1) {
               var2 = var6.indexOfKey(var1.getKeyCode());
               var7 = var5;
               if (var2 >= 0) {
                  var7 = (WeakReference)var6.valueAt(var2);
                  var6.removeAt(var2);
               }
            }

            var5 = var7;
            if (var7 == null) {
               var5 = (WeakReference)var6.get(var1.getKeyCode());
            }

            if (var5 != null) {
               var0 = (View)var5.get();
               if (var0 != null && c(var0)) {
                  var4.c(var0, var1);
               }

               var3 = true;
            }
         }

         return var3;
      }
   }

   public static boolean c(View var0) {
      if (VERSION.SDK_INT >= 19) {
         return var0.isAttachedToWindow();
      } else {
         boolean var1;
         if (var0.getWindowToken() != null) {
            var1 = true;
         } else {
            var1 = false;
         }

         return var1;
      }
   }

   public static class a implements OnGlobalLayoutListener, OnAttachStateChangeListener {
      public WeakHashMap a = new WeakHashMap();

      public void onGlobalLayout() {
         Iterator var1 = this.a.entrySet().iterator();

         while(var1.hasNext()) {
            Entry var2 = (Entry)var1.next();
            View var3 = (View)var2.getKey();
            boolean var4 = (Boolean)var2.getValue();
            boolean var5;
            if (var3.getVisibility() == 0) {
               var5 = true;
            } else {
               var5 = false;
            }

            if (var4 != var5) {
               if (var5) {
                  b.c.e.c.a(var3, 16);
               }

               this.a.put(var3, var5);
            }
         }

      }

      public void onViewAttachedToWindow(View var1) {
         var1.getViewTreeObserver().addOnGlobalLayoutListener(this);
      }

      public void onViewDetachedFromWindow(View var1) {
      }
   }

   public abstract static class b {
      public final int a;
      public final Class b;
      public final int c;

      public b(int var1, Class var2, int var3, int var4) {
         this.a = var1;
         this.b = var2;
         this.c = var4;
      }
   }

   public interface c {
      boolean a(View var1, KeyEvent var2);
   }

   public static class d {
      public static final ArrayList d = new ArrayList();
      public WeakHashMap a = null;
      public SparseArray b = null;
      public WeakReference c = null;

      public static b.c.e.c.d a(View var0) {
         b.c.e.c.d var1 = (b.c.e.c.d)var0.getTag(b.c.a.tag_unhandled_key_event_manager);
         b.c.e.c.d var2 = var1;
         if (var1 == null) {
            var2 = new b.c.e.c.d();
            var0.setTag(b.c.a.tag_unhandled_key_event_manager, var2);
         }

         return var2;
      }

      public final SparseArray a() {
         if (this.b == null) {
            this.b = new SparseArray();
         }

         return this.b;
      }

      public boolean a(View var1, KeyEvent var2) {
         if (var2.getAction() == 0) {
            this.b();
         }

         var1 = this.b(var1, var2);
         if (var2.getAction() == 0) {
            int var3 = var2.getKeyCode();
            if (var1 != null && !KeyEvent.isModifierKey(var3)) {
               if (this.b == null) {
                  this.b = new SparseArray();
               }

               this.b.put(var3, new WeakReference(var1));
            }
         }

         boolean var4;
         if (var1 != null) {
            var4 = true;
         } else {
            var4 = false;
         }

         return var4;
      }

      public final View b(View var1, KeyEvent var2) {
         WeakHashMap var3 = this.a;
         if (var3 != null && var3.containsKey(var1)) {
            if (var1 instanceof ViewGroup) {
               ViewGroup var6 = (ViewGroup)var1;

               for(int var4 = var6.getChildCount() - 1; var4 >= 0; --var4) {
                  View var5 = this.b(var6.getChildAt(var4), var2);
                  if (var5 != null) {
                     return var5;
                  }
               }
            }

            if (this.c(var1, var2)) {
               return var1;
            }
         }

         return null;
      }

      public final void b() {
         WeakHashMap var1 = this.a;
         if (var1 != null) {
            var1.clear();
         }

         if (!d.isEmpty()) {
            ArrayList var2 = d;
            synchronized(var2){}

            Throwable var10000;
            boolean var10001;
            label696: {
               try {
                  if (this.a == null) {
                     var1 = new WeakHashMap();
                     this.a = var1;
                  }
               } catch (Throwable var75) {
                  var10000 = var75;
                  var10001 = false;
                  break label696;
               }

               int var3;
               try {
                  var3 = d.size() - 1;
               } catch (Throwable var73) {
                  var10000 = var73;
                  var10001 = false;
                  break label696;
               }

               for(; var3 >= 0; --var3) {
                  View var76;
                  try {
                     var76 = (View)((WeakReference)d.get(var3)).get();
                  } catch (Throwable var72) {
                     var10000 = var72;
                     var10001 = false;
                     break label696;
                  }

                  if (var76 == null) {
                     try {
                        d.remove(var3);
                     } catch (Throwable var71) {
                        var10000 = var71;
                        var10001 = false;
                        break label696;
                     }
                  } else {
                     ViewParent var77;
                     try {
                        this.a.put(var76, Boolean.TRUE);
                        var77 = var76.getParent();
                     } catch (Throwable var70) {
                        var10000 = var70;
                        var10001 = false;
                        break label696;
                     }

                     while(true) {
                        try {
                           if (!(var77 instanceof View)) {
                              break;
                           }

                           this.a.put((View)var77, Boolean.TRUE);
                           var77 = var77.getParent();
                        } catch (Throwable var74) {
                           var10000 = var74;
                           var10001 = false;
                           break label696;
                        }
                     }
                  }
               }

               label665:
               try {
                  return;
               } catch (Throwable var69) {
                  var10000 = var69;
                  var10001 = false;
                  break label665;
               }
            }

            while(true) {
               Throwable var78 = var10000;

               try {
                  throw var78;
               } catch (Throwable var68) {
                  var10000 = var68;
                  var10001 = false;
                  continue;
               }
            }
         }
      }

      public final boolean c(View var1, KeyEvent var2) {
         ArrayList var3 = (ArrayList)var1.getTag(b.c.a.tag_unhandled_key_listeners);
         if (var3 != null) {
            for(int var4 = var3.size() - 1; var4 >= 0; --var4) {
               if (((b.c.e.c.c)var3.get(var4)).a(var1, var2)) {
                  return true;
               }
            }
         }

         return false;
      }
   }
}
