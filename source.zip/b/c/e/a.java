package b.c.e;

import android.view.KeyEvent;
import java.lang.reflect.Method;

public class a {
   public static boolean a;
   public static Method b;

   public interface a {
      boolean a(KeyEvent var1);
   }
}
