package b.c.c;

import android.content.Context;
import android.os.Build.VERSION;
import android.util.Log;
import java.io.File;

public class a {
   public static File a(Context var0) {
      return VERSION.SDK_INT >= 21 ? var0.getNoBackupFilesDir() : a(new File(var0.getApplicationInfo().dataDir, "no_backup"));
   }

   public static File a(File var0) {
      synchronized(a.class){}

      label103: {
         Throwable var10000;
         label107: {
            boolean var1;
            boolean var10001;
            try {
               if (var0.exists() || var0.mkdirs()) {
                  break label103;
               }

               var1 = var0.exists();
            } catch (Throwable var8) {
               var10000 = var8;
               var10001 = false;
               break label107;
            }

            if (var1) {
               return var0;
            }

            try {
               StringBuilder var2 = new StringBuilder();
               var2.append("Unable to create files subdir ");
               var2.append(var0.getPath());
               Log.w("ContextCompat", var2.toString());
            } catch (Throwable var7) {
               var10000 = var7;
               var10001 = false;
               break label107;
            }

            return null;
         }

         Throwable var9 = var10000;
         throw var9;
      }

      return var0;
   }
}
