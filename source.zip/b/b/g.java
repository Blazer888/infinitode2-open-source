package b.b;

public class g implements Cloneable {
   public static final Object e = new Object();
   public boolean a;
   public int[] b;
   public Object[] c;
   public int d;

   public g() {
      this(10);
   }

   public g(int var1) {
      this.a = false;
      if (var1 == 0) {
         this.b = b.b.d.a;
         this.c = b.b.d.b;
      } else {
         var1 = b.b.d.a(var1);
         this.b = new int[var1];
         this.c = new Object[var1];
      }

      this.d = 0;
   }

   public Object a(int var1) {
      var1 = b.b.d.a(this.b, this.d, var1);
      Object var3;
      if (var1 >= 0) {
         Object[] var2 = this.c;
         if (var2[var1] != e) {
            var3 = var2[var1];
            return var3;
         }
      }

      var3 = null;
      return var3;
   }

   public void a(int var1, Object var2) {
      int var3 = b.b.d.a(this.b, this.d, var1);
      if (var3 >= 0) {
         this.c[var3] = var2;
      } else {
         int var4 = ~var3;
         Object[] var5;
         if (var4 < this.d) {
            var5 = this.c;
            if (var5[var4] == e) {
               this.b[var4] = var1;
               var5[var4] = var2;
               return;
            }
         }

         var3 = var4;
         if (this.a) {
            var3 = var4;
            if (this.d >= this.b.length) {
               this.b();
               var3 = ~b.b.d.a(this.b, this.d, var1);
            }
         }

         var4 = this.d;
         int[] var9;
         if (var4 >= this.b.length) {
            var4 = b.b.d.a(var4 + 1);
            var9 = new int[var4];
            Object[] var6 = new Object[var4];
            int[] var7 = this.b;
            System.arraycopy(var7, 0, var9, 0, var7.length);
            Object[] var10 = this.c;
            System.arraycopy(var10, 0, var6, 0, var10.length);
            this.b = var9;
            this.c = var6;
         }

         int var8 = this.d;
         if (var8 - var3 != 0) {
            var9 = this.b;
            var4 = var3 + 1;
            System.arraycopy(var9, var3, var9, var4, var8 - var3);
            var5 = this.c;
            System.arraycopy(var5, var3, var5, var4, this.d - var3);
         }

         this.b[var3] = var1;
         this.c[var3] = var2;
         ++this.d;
      }

   }

   public int b(int var1) {
      if (this.a) {
         this.b();
      }

      return this.b[var1];
   }

   public final void b() {
      int var1 = this.d;
      int[] var2 = this.b;
      Object[] var3 = this.c;
      int var4 = 0;

      int var5;
      int var7;
      for(var5 = 0; var4 < var1; var5 = var7) {
         Object var6 = var3[var4];
         var7 = var5;
         if (var6 != e) {
            if (var4 != var5) {
               var2[var5] = var2[var4];
               var3[var5] = var6;
               var3[var4] = null;
            }

            var7 = var5 + 1;
         }

         ++var4;
      }

      this.a = false;
      this.d = var5;
   }

   public int c() {
      if (this.a) {
         this.b();
      }

      return this.d;
   }

   public void c(int var1) {
      var1 = b.b.d.a(this.b, this.d, var1);
      if (var1 >= 0) {
         Object[] var2 = this.c;
         Object var3 = var2[var1];
         Object var4 = e;
         if (var3 != var4) {
            var2[var1] = var4;
            this.a = true;
         }
      }

   }

   public Object clone() {
      try {
         g var1 = (g)super.clone();
         var1.b = (int[])this.b.clone();
         var1.c = (Object[])this.c.clone();
         return var1;
      } catch (CloneNotSupportedException var2) {
         throw new AssertionError(var2);
      }
   }

   public Object d(int var1) {
      if (this.a) {
         this.b();
      }

      return this.c[var1];
   }

   public String toString() {
      if (this.c() <= 0) {
         return "{}";
      } else {
         StringBuilder var1 = new StringBuilder(this.d * 28);
         var1.append('{');

         for(int var2 = 0; var2 < this.d; ++var2) {
            if (var2 > 0) {
               var1.append(", ");
            }

            var1.append(this.b(var2));
            var1.append('=');
            Object var3 = this.d(var2);
            if (var3 != this) {
               var1.append(var3);
            } else {
               var1.append("(this Map)");
            }
         }

         var1.append('}');
         return var1.toString();
      }
   }
}
