package b.b;

import java.util.Map;

public class b extends b.b.e {
   // $FF: synthetic field
   public final b.b.c d;

   public b(b.b.c var1) {
      this.d = var1;
   }

   public int a(Object var1) {
      return this.d.indexOf(var1);
   }

   public Object a(int var1, int var2) {
      return this.d.b[var1];
   }

   public Object a(int var1, Object var2) {
      throw new UnsupportedOperationException("not a map");
   }

   public void a() {
      this.d.clear();
   }

   public void a(int var1) {
      this.d.f(var1);
   }

   public void a(Object var1, Object var2) {
      this.d.add(var1);
   }

   public int b(Object var1) {
      return this.d.indexOf(var1);
   }

   public Map b() {
      throw new UnsupportedOperationException("not a map");
   }

   public int c() {
      return this.d.c;
   }
}
