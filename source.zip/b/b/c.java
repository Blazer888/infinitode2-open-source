package b.b;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

public final class c implements Collection, Set {
   public static final int[] e = new int[0];
   public static final Object[] f = new Object[0];
   public static Object[] g;
   public static int h;
   public static Object[] i;
   public static int j;
   public int[] a;
   public Object[] b;
   public int c;
   public e d;

   public c() {
      this.a = e;
      this.b = f;
      this.c = 0;
   }

   public static void a(int[] var0, Object[] var1, int var2) {
      Throwable var75;
      Throwable var10000;
      boolean var10001;
      if (var0.length == 8) {
         synchronized(c.class){}

         label811: {
            label838: {
               try {
                  if (j >= 10) {
                     break label838;
                  }

                  var1[0] = i;
               } catch (Throwable var71) {
                  var10000 = var71;
                  var10001 = false;
                  break label811;
               }

               var1[1] = var0;
               --var2;

               while(true) {
                  if (var2 < 2) {
                     try {
                        i = var1;
                        ++j;
                        break;
                     } catch (Throwable var70) {
                        var10000 = var70;
                        var10001 = false;
                        break label811;
                     }
                  }

                  var1[var2] = null;
                  --var2;
               }
            }

            label798:
            try {
               return;
            } catch (Throwable var69) {
               var10000 = var69;
               var10001 = false;
               break label798;
            }
         }

         while(true) {
            var75 = var10000;

            try {
               throw var75;
            } catch (Throwable var67) {
               var10000 = var67;
               var10001 = false;
               continue;
            }
         }
      } else if (var0.length == 4) {
         synchronized(c.class){}

         label829: {
            label839: {
               try {
                  if (h >= 10) {
                     break label839;
                  }

                  var1[0] = g;
               } catch (Throwable var74) {
                  var10000 = var74;
                  var10001 = false;
                  break label829;
               }

               var1[1] = var0;
               --var2;

               while(true) {
                  if (var2 < 2) {
                     try {
                        g = var1;
                        ++h;
                        break;
                     } catch (Throwable var73) {
                        var10000 = var73;
                        var10001 = false;
                        break label829;
                     }
                  }

                  var1[var2] = null;
                  --var2;
               }
            }

            label816:
            try {
               return;
            } catch (Throwable var72) {
               var10000 = var72;
               var10001 = false;
               break label816;
            }
         }

         while(true) {
            var75 = var10000;

            try {
               throw var75;
            } catch (Throwable var68) {
               var10000 = var68;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public final int a() {
      int var1 = this.c;
      if (var1 == 0) {
         return -1;
      } else {
         int var2 = b.b.d.a(this.a, var1, 0);
         if (var2 < 0) {
            return var2;
         } else if (this.b[var2] == null) {
            return var2;
         } else {
            int var3;
            for(var3 = var2 + 1; var3 < var1 && this.a[var3] == 0; ++var3) {
               if (this.b[var3] == null) {
                  return var3;
               }
            }

            for(var1 = var2 - 1; var1 >= 0 && this.a[var1] == 0; --var1) {
               if (this.b[var1] == null) {
                  return var1;
               }
            }

            return ~var3;
         }
      }
   }

   public final int a(Object var1, int var2) {
      int var3 = this.c;
      if (var3 == 0) {
         return -1;
      } else {
         int var4 = b.b.d.a(this.a, var3, var2);
         if (var4 < 0) {
            return var4;
         } else if (var1.equals(this.b[var4])) {
            return var4;
         } else {
            int var5;
            for(var5 = var4 + 1; var5 < var3 && this.a[var5] == var2; ++var5) {
               if (var1.equals(this.b[var5])) {
                  return var5;
               }
            }

            for(var3 = var4 - 1; var3 >= 0 && this.a[var3] == var2; --var3) {
               if (var1.equals(this.b[var3])) {
                  return var3;
               }
            }

            return ~var5;
         }
      }
   }

   public boolean add(Object var1) {
      int var2;
      int var3;
      if (var1 == null) {
         var2 = this.a();
         var3 = 0;
      } else {
         var3 = var1.hashCode();
         var2 = this.a(var1, var3);
      }

      if (var2 >= 0) {
         return false;
      } else {
         int var4 = ~var2;
         int var5 = this.c;
         int[] var6;
         if (var5 >= this.a.length) {
            var2 = 4;
            if (var5 >= 8) {
               var2 = (var5 >> 1) + var5;
            } else if (var5 >= 4) {
               var2 = 8;
            }

            var6 = this.a;
            Object[] var7 = this.b;
            this.b(var2);
            int[] var8 = this.a;
            if (var8.length > 0) {
               System.arraycopy(var6, 0, var8, 0, var6.length);
               System.arraycopy(var7, 0, this.b, 0, var7.length);
            }

            a(var6, var7, this.c);
         }

         var2 = this.c;
         if (var4 < var2) {
            var6 = this.a;
            var5 = var4 + 1;
            System.arraycopy(var6, var4, var6, var5, var2 - var4);
            Object[] var9 = this.b;
            System.arraycopy(var9, var4, var9, var5, this.c - var4);
         }

         this.a[var4] = var3;
         this.b[var4] = var1;
         ++this.c;
         return true;
      }
   }

   public boolean addAll(Collection var1) {
      int var2 = this.c;
      var2 += var1.size();
      int[] var3 = this.a;
      int var4 = var3.length;
      boolean var5 = false;
      if (var4 < var2) {
         Object[] var6 = this.b;
         this.b(var2);
         var2 = this.c;
         if (var2 > 0) {
            System.arraycopy(var3, 0, this.a, 0, var2);
            System.arraycopy(var6, 0, this.b, 0, this.c);
         }

         a(var3, var6, this.c);
      }

      for(Iterator var7 = var1.iterator(); var7.hasNext(); var5 |= this.add(var7.next())) {
      }

      return var5;
   }

   public final void b(int var1) {
      Throwable var75;
      Throwable var10000;
      boolean var10001;
      label758: {
         Object[] var2;
         if (var1 == 8) {
            synchronized(c.class){}

            label754: {
               try {
                  if (i == null) {
                     break label754;
                  }

                  var2 = i;
                  this.b = var2;
                  i = (Object[])var2[0];
                  this.a = (int[])var2[1];
               } catch (Throwable var72) {
                  var10000 = var72;
                  var10001 = false;
                  break label758;
               }

               var2[1] = null;
               var2[0] = null;

               try {
                  --j;
                  return;
               } catch (Throwable var69) {
                  var10000 = var69;
                  var10001 = false;
                  break label758;
               }
            }

            try {
               ;
            } catch (Throwable var71) {
               var10000 = var71;
               var10001 = false;
               break label758;
            }
         } else if (var1 == 4) {
            label757: {
               synchronized(c.class){}

               label743: {
                  label755: {
                     try {
                        if (g == null) {
                           break label755;
                        }

                        var2 = g;
                        this.b = var2;
                        g = (Object[])var2[0];
                        this.a = (int[])var2[1];
                     } catch (Throwable var74) {
                        var10000 = var74;
                        var10001 = false;
                        break label743;
                     }

                     var2[1] = null;
                     var2[0] = null;

                     try {
                        --h;
                        return;
                     } catch (Throwable var70) {
                        var10000 = var70;
                        var10001 = false;
                        break label743;
                     }
                  }

                  label736:
                  try {
                     break label757;
                  } catch (Throwable var73) {
                     var10000 = var73;
                     var10001 = false;
                     break label736;
                  }
               }

               while(true) {
                  var75 = var10000;

                  try {
                     throw var75;
                  } catch (Throwable var68) {
                     var10000 = var68;
                     var10001 = false;
                     continue;
                  }
               }
            }
         }

         this.a = new int[var1];
         this.b = new Object[var1];
         return;
      }

      while(true) {
         var75 = var10000;

         try {
            throw var75;
         } catch (Throwable var67) {
            var10000 = var67;
            var10001 = false;
            continue;
         }
      }
   }

   public void clear() {
      int var1 = this.c;
      if (var1 != 0) {
         a(this.a, this.b, var1);
         this.a = e;
         this.b = f;
         this.c = 0;
      }

   }

   public boolean contains(Object var1) {
      boolean var2;
      if (this.indexOf(var1) >= 0) {
         var2 = true;
      } else {
         var2 = false;
      }

      return var2;
   }

   public boolean containsAll(Collection var1) {
      Iterator var2 = var1.iterator();

      do {
         if (!var2.hasNext()) {
            return true;
         }
      } while(this.contains(var2.next()));

      return false;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else {
         if (var1 instanceof Set) {
            Set var5 = (Set)var1;
            if (this.c != var5.size()) {
               return false;
            }

            int var2 = 0;

            while(true) {
               boolean var3;
               try {
                  if (var2 >= this.c) {
                     return true;
                  }

                  var3 = var5.contains(this.b[var2]);
               } catch (ClassCastException | NullPointerException var4) {
                  break;
               }

               if (!var3) {
                  return false;
               }

               ++var2;
            }
         }

         return false;
      }
   }

   public Object f(int var1) {
      Object[] var2 = this.b;
      Object var3 = var2[var1];
      int var4 = this.c;
      if (var4 <= 1) {
         a(this.a, var2, var4);
         this.a = e;
         this.b = f;
         this.c = 0;
      } else {
         int[] var8 = this.a;
         int var5 = var8.length;
         int var6 = 8;
         if (var5 > 8 && var4 < var8.length / 3) {
            if (var4 > 8) {
               var6 = var4 + (var4 >> 1);
            }

            var8 = this.a;
            Object[] var7 = this.b;
            this.b(var6);
            --this.c;
            if (var1 > 0) {
               System.arraycopy(var8, 0, this.a, 0, var1);
               System.arraycopy(var7, 0, this.b, 0, var1);
            }

            var4 = this.c;
            if (var1 < var4) {
               var6 = var1 + 1;
               System.arraycopy(var8, var6, this.a, var1, var4 - var1);
               System.arraycopy(var7, var6, this.b, var1, this.c - var1);
            }
         } else {
            --this.c;
            var4 = this.c;
            if (var1 < var4) {
               var8 = this.a;
               var6 = var1 + 1;
               System.arraycopy(var8, var6, var8, var1, var4 - var1);
               var2 = this.b;
               System.arraycopy(var2, var6, var2, var1, this.c - var1);
            }

            this.b[this.c] = null;
         }
      }

      return var3;
   }

   public int hashCode() {
      int[] var1 = this.a;
      int var2 = this.c;
      int var3 = 0;

      int var4;
      for(var4 = 0; var3 < var2; ++var3) {
         var4 += var1[var3];
      }

      return var4;
   }

   public int indexOf(Object var1) {
      int var2;
      if (var1 == null) {
         var2 = this.a();
      } else {
         var2 = this.a(var1, var1.hashCode());
      }

      return var2;
   }

   public boolean isEmpty() {
      boolean var1;
      if (this.c <= 0) {
         var1 = true;
      } else {
         var1 = false;
      }

      return var1;
   }

   public Iterator iterator() {
      if (this.d == null) {
         this.d = new b(this);
      }

      e var1 = this.d;
      if (var1.b == null) {
         var1.b = var1.new c();
      }

      return var1.b.iterator();
   }

   public boolean remove(Object var1) {
      int var2 = this.indexOf(var1);
      if (var2 >= 0) {
         this.f(var2);
         return true;
      } else {
         return false;
      }
   }

   public boolean removeAll(Collection var1) {
      Iterator var3 = var1.iterator();

      boolean var2;
      for(var2 = false; var3.hasNext(); var2 |= this.remove(var3.next())) {
      }

      return var2;
   }

   public boolean retainAll(Collection var1) {
      int var2 = this.c - 1;

      boolean var3;
      for(var3 = false; var2 >= 0; --var2) {
         if (!var1.contains(this.b[var2])) {
            this.f(var2);
            var3 = true;
         }
      }

      return var3;
   }

   public int size() {
      return this.c;
   }

   public Object[] toArray() {
      int var1 = this.c;
      Object[] var2 = new Object[var1];
      System.arraycopy(this.b, 0, var2, 0, var1);
      return var2;
   }

   public Object[] toArray(Object[] var1) {
      Object[] var2 = var1;
      if (var1.length < this.c) {
         var2 = (Object[])Array.newInstance(var1.getClass().getComponentType(), this.c);
      }

      System.arraycopy(this.b, 0, var2, 0, this.c);
      int var3 = var2.length;
      int var4 = this.c;
      if (var3 > var4) {
         var2[var4] = null;
      }

      return var2;
   }

   public String toString() {
      if (this.isEmpty()) {
         return "{}";
      } else {
         StringBuilder var1 = new StringBuilder(this.c * 14);
         var1.append('{');

         for(int var2 = 0; var2 < this.c; ++var2) {
            if (var2 > 0) {
               var1.append(", ");
            }

            Object var3 = this.b[var2];
            if (var3 != this) {
               var1.append(var3);
            } else {
               var1.append("(this Set)");
            }
         }

         var1.append('}');
         return var1.toString();
      }
   }
}
