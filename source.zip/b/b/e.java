package b.b;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.Map.Entry;

public abstract class e {
   public b.b.e.b a;
   public b.b.e.c b;
   public b.b.e.e c;

   public static boolean a(Map var0, Collection var1) {
      int var2 = var0.size();
      Iterator var3 = var0.keySet().iterator();

      while(var3.hasNext()) {
         if (!var1.contains(var3.next())) {
            var3.remove();
         }
      }

      boolean var4;
      if (var2 != var0.size()) {
         var4 = true;
      } else {
         var4 = false;
      }

      return var4;
   }

   public static boolean a(Set var0, Object var1) {
      boolean var2 = true;
      if (var0 == var1) {
         return true;
      } else if (var1 instanceof Set) {
         Set var5 = (Set)var1;

         label27: {
            boolean var3;
            try {
               if (var0.size() != var5.size()) {
                  break label27;
               }

               var3 = var0.containsAll(var5);
            } catch (ClassCastException | NullPointerException var4) {
               return false;
            }

            if (var3) {
               return var2;
            }
         }

         var2 = false;
         return var2;
      } else {
         return false;
      }
   }

   public abstract int a(Object var1);

   public abstract Object a(int var1, int var2);

   public abstract Object a(int var1, Object var2);

   public abstract void a();

   public abstract void a(int var1);

   public abstract void a(Object var1, Object var2);

   public Object[] a(Object[] var1, int var2) {
      int var3 = this.c();
      Object[] var4 = var1;
      if (var1.length < var3) {
         var4 = (Object[])Array.newInstance(var1.getClass().getComponentType(), var3);
      }

      for(int var5 = 0; var5 < var3; ++var5) {
         var4[var5] = this.a(var5, var2);
      }

      if (var4.length > var3) {
         var4[var3] = null;
      }

      return var4;
   }

   public abstract int b(Object var1);

   public abstract Map b();

   public Object[] b(int var1) {
      int var2 = this.c();
      Object[] var3 = new Object[var2];

      for(int var4 = 0; var4 < var2; ++var4) {
         var3[var4] = this.a(var4, var1);
      }

      return var3;
   }

   public abstract int c();

   public final class a implements Iterator {
      public final int a;
      public int b;
      public int c;
      public boolean d = false;

      public a(int var2) {
         this.a = var2;
         this.b = e.this.c();
      }

      public boolean hasNext() {
         boolean var1;
         if (this.c < this.b) {
            var1 = true;
         } else {
            var1 = false;
         }

         return var1;
      }

      public Object next() {
         if (this.hasNext()) {
            Object var1 = e.this.a(this.c, this.a);
            ++this.c;
            this.d = true;
            return var1;
         } else {
            throw new NoSuchElementException();
         }
      }

      public void remove() {
         if (this.d) {
            --this.c;
            --this.b;
            this.d = false;
            e.this.a(this.c);
         } else {
            throw new IllegalStateException();
         }
      }
   }

   public final class b implements Set {
      public boolean add(Object var1) {
         Entry var2 = (Entry)var1;
         throw new UnsupportedOperationException();
      }

      public boolean addAll(Collection var1) {
         int var2 = e.this.c();
         Iterator var3 = var1.iterator();

         while(var3.hasNext()) {
            Entry var5 = (Entry)var3.next();
            e.this.a(var5.getKey(), var5.getValue());
         }

         boolean var4;
         if (var2 != e.this.c()) {
            var4 = true;
         } else {
            var4 = false;
         }

         return var4;
      }

      public void clear() {
         e.this.a();
      }

      public boolean contains(Object var1) {
         if (!(var1 instanceof Entry)) {
            return false;
         } else {
            Entry var3 = (Entry)var1;
            int var2 = e.this.a(var3.getKey());
            return var2 < 0 ? false : b.b.d.a(e.this.a(var2, 1), var3.getValue());
         }
      }

      public boolean containsAll(Collection var1) {
         Iterator var2 = var1.iterator();

         do {
            if (!var2.hasNext()) {
               return true;
            }
         } while(this.contains(var2.next()));

         return false;
      }

      public boolean equals(Object var1) {
         return b.b.e.a((Set)this, (Object)var1);
      }

      public int hashCode() {
         int var1 = e.this.c() - 1;

         int var2;
         for(var2 = 0; var1 >= 0; --var1) {
            Object var3 = e.this.a(var1, 0);
            Object var4 = e.this.a(var1, 1);
            int var5;
            if (var3 == null) {
               var5 = 0;
            } else {
               var5 = var3.hashCode();
            }

            int var6;
            if (var4 == null) {
               var6 = 0;
            } else {
               var6 = var4.hashCode();
            }

            var2 += var5 ^ var6;
         }

         return var2;
      }

      public boolean isEmpty() {
         boolean var1;
         if (e.this.c() == 0) {
            var1 = true;
         } else {
            var1 = false;
         }

         return var1;
      }

      public Iterator iterator() {
         return e.this.new d();
      }

      public boolean remove(Object var1) {
         throw new UnsupportedOperationException();
      }

      public boolean removeAll(Collection var1) {
         throw new UnsupportedOperationException();
      }

      public boolean retainAll(Collection var1) {
         throw new UnsupportedOperationException();
      }

      public int size() {
         return e.this.c();
      }

      public Object[] toArray() {
         throw new UnsupportedOperationException();
      }

      public Object[] toArray(Object[] var1) {
         throw new UnsupportedOperationException();
      }
   }

   public final class c implements Set {
      public boolean add(Object var1) {
         throw new UnsupportedOperationException();
      }

      public boolean addAll(Collection var1) {
         throw new UnsupportedOperationException();
      }

      public void clear() {
         e.this.a();
      }

      public boolean contains(Object var1) {
         boolean var2;
         if (e.this.a(var1) >= 0) {
            var2 = true;
         } else {
            var2 = false;
         }

         return var2;
      }

      public boolean containsAll(Collection var1) {
         Map var2 = e.this.b();
         Iterator var4 = var1.iterator();

         boolean var3;
         while(true) {
            if (var4.hasNext()) {
               if (var2.containsKey(var4.next())) {
                  continue;
               }

               var3 = false;
               break;
            }

            var3 = true;
            break;
         }

         return var3;
      }

      public boolean equals(Object var1) {
         return b.b.e.a((Set)this, (Object)var1);
      }

      public int hashCode() {
         int var1 = e.this.c() - 1;

         int var2;
         for(var2 = 0; var1 >= 0; --var1) {
            Object var3 = e.this.a(var1, 0);
            int var4;
            if (var3 == null) {
               var4 = 0;
            } else {
               var4 = var3.hashCode();
            }

            var2 += var4;
         }

         return var2;
      }

      public boolean isEmpty() {
         boolean var1;
         if (e.this.c() == 0) {
            var1 = true;
         } else {
            var1 = false;
         }

         return var1;
      }

      public Iterator iterator() {
         return e.this.new a(0);
      }

      public boolean remove(Object var1) {
         int var2 = e.this.a(var1);
         if (var2 >= 0) {
            e.this.a(var2);
            return true;
         } else {
            return false;
         }
      }

      public boolean removeAll(Collection var1) {
         Map var2 = e.this.b();
         int var3 = var2.size();
         Iterator var5 = var1.iterator();

         while(var5.hasNext()) {
            var2.remove(var5.next());
         }

         boolean var4;
         if (var3 != var2.size()) {
            var4 = true;
         } else {
            var4 = false;
         }

         return var4;
      }

      public boolean retainAll(Collection var1) {
         return b.b.e.a(e.this.b(), var1);
      }

      public int size() {
         return e.this.c();
      }

      public Object[] toArray() {
         return e.this.b(0);
      }

      public Object[] toArray(Object[] var1) {
         return e.this.a(var1, 0);
      }
   }

   public final class d implements Iterator, Entry {
      public int a = e.this.c() - 1;
      public int b = -1;
      public boolean c = false;

      public boolean equals(Object var1) {
         if (this.c) {
            boolean var2 = var1 instanceof Entry;
            boolean var3 = false;
            if (!var2) {
               return false;
            } else {
               Entry var4 = (Entry)var1;
               var2 = var3;
               if (b.b.d.a(var4.getKey(), e.this.a(this.b, 0))) {
                  var2 = var3;
                  if (b.b.d.a(var4.getValue(), e.this.a(this.b, 1))) {
                     var2 = true;
                  }
               }

               return var2;
            }
         } else {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
         }
      }

      public Object getKey() {
         if (this.c) {
            return e.this.a(this.b, 0);
         } else {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
         }
      }

      public Object getValue() {
         if (this.c) {
            return e.this.a(this.b, 1);
         } else {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
         }
      }

      public boolean hasNext() {
         boolean var1;
         if (this.b < this.a) {
            var1 = true;
         } else {
            var1 = false;
         }

         return var1;
      }

      public int hashCode() {
         if (this.c) {
            b.b.e var1 = e.this;
            int var2 = this.b;
            int var3 = 0;
            Object var4 = var1.a(var2, 0);
            Object var5 = e.this.a(this.b, 1);
            if (var4 == null) {
               var2 = 0;
            } else {
               var2 = var4.hashCode();
            }

            if (var5 != null) {
               var3 = var5.hashCode();
            }

            return var2 ^ var3;
         } else {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
         }
      }

      public Object next() {
         if (this.hasNext()) {
            ++this.b;
            this.c = true;
            return this;
         } else {
            throw new NoSuchElementException();
         }
      }

      public void remove() {
         if (this.c) {
            e.this.a(this.b);
            --this.b;
            --this.a;
            this.c = false;
         } else {
            throw new IllegalStateException();
         }
      }

      public Object setValue(Object var1) {
         if (this.c) {
            return e.this.a(this.b, var1);
         } else {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
         }
      }

      public String toString() {
         StringBuilder var1 = new StringBuilder();
         var1.append(this.getKey());
         var1.append("=");
         var1.append(this.getValue());
         return var1.toString();
      }
   }

   public final class e implements Collection {
      public boolean add(Object var1) {
         throw new UnsupportedOperationException();
      }

      public boolean addAll(Collection var1) {
         throw new UnsupportedOperationException();
      }

      public void clear() {
         e.this.a();
      }

      public boolean contains(Object var1) {
         boolean var2;
         if (e.this.b(var1) >= 0) {
            var2 = true;
         } else {
            var2 = false;
         }

         return var2;
      }

      public boolean containsAll(Collection var1) {
         Iterator var2 = var1.iterator();

         do {
            if (!var2.hasNext()) {
               return true;
            }
         } while(this.contains(var2.next()));

         return false;
      }

      public boolean isEmpty() {
         boolean var1;
         if (e.this.c() == 0) {
            var1 = true;
         } else {
            var1 = false;
         }

         return var1;
      }

      public Iterator iterator() {
         return e.this.new a(1);
      }

      public boolean remove(Object var1) {
         int var2 = e.this.b(var1);
         if (var2 >= 0) {
            e.this.a(var2);
            return true;
         } else {
            return false;
         }
      }

      public boolean removeAll(Collection var1) {
         int var2 = e.this.c();
         int var3 = 0;

         boolean var4;
         int var5;
         for(var4 = false; var3 < var2; var2 = var5) {
            var5 = var2;
            int var6 = var3;
            if (var1.contains(e.this.a(var3, 1))) {
               e.this.a(var3);
               var6 = var3 - 1;
               var5 = var2 - 1;
               var4 = true;
            }

            var3 = var6 + 1;
         }

         return var4;
      }

      public boolean retainAll(Collection var1) {
         int var2 = e.this.c();
         int var3 = 0;

         boolean var4;
         int var5;
         for(var4 = false; var3 < var2; var2 = var5) {
            var5 = var2;
            int var6 = var3;
            if (!var1.contains(e.this.a(var3, 1))) {
               e.this.a(var3);
               var6 = var3 - 1;
               var5 = var2 - 1;
               var4 = true;
            }

            var3 = var6 + 1;
         }

         return var4;
      }

      public int size() {
         return e.this.c();
      }

      public Object[] toArray() {
         return e.this.b(1);
      }

      public Object[] toArray(Object[] var1) {
         return e.this.a(var1, 1);
      }
   }
}
