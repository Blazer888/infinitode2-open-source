package b.b;

import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class a extends f implements Map {
   public e h;

   public a() {
   }

   public a(int var1) {
      super(var1);
   }

   public final e b() {
      if (this.h == null) {
         this.h = new e() {
            public int a(Object var1) {
               return a.this.a(var1);
            }

            public Object a(int var1, int var2) {
               return a.super.b[(var1 << 1) + var2];
            }

            public Object a(int var1, Object var2) {
               a var3 = a.this;
               var1 = (var1 << 1) + 1;
               Object[] var5 = var3.b;
               Object var4 = var5[var1];
               var5[var1] = var2;
               return var4;
            }

            public void a() {
               a.this.clear();
            }

            public void a(int var1) {
               a.this.c(var1);
            }

            public void a(Object var1, Object var2) {
               a.this.put(var1, var2);
            }

            public int b(Object var1) {
               return a.this.b(var1);
            }

            public Map b() {
               return a.this;
            }

            public int c() {
               return a.super.c;
            }
         };
      }

      return this.h;
   }

   public Set entrySet() {
      e var1 = this.b();
      if (var1.a == null) {
         var1.a = var1.new b();
      }

      return var1.a;
   }

   public Set keySet() {
      e var1 = this.b();
      if (var1.b == null) {
         var1.b = var1.new c();
      }

      return var1.b;
   }

   public void putAll(Map var1) {
      int var2 = super.c;
      int var3 = var1.size() + var2;
      var2 = super.c;
      int[] var4 = super.a;
      if (var4.length < var3) {
         Object[] var5 = super.b;
         this.a(var3);
         if (super.c > 0) {
            System.arraycopy(var4, 0, super.a, 0, var2);
            System.arraycopy(var5, 0, super.b, 0, var2 << 1);
         }

         b.b.f.a(var4, var5, var2);
      }

      if (super.c != var2) {
         ConcurrentModificationException var7 = new ConcurrentModificationException();
         throw var7;
      } else {
         Iterator var8 = var1.entrySet().iterator();

         while(var8.hasNext()) {
            Entry var6 = (Entry)var8.next();
            this.put(var6.getKey(), var6.getValue());
         }

      }
   }

   public Collection values() {
      e var1 = this.b();
      if (var1.c == null) {
         var1.c = var1.new e();
      }

      return var1.c;
   }
}
