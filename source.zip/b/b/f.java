package b.b;

import java.util.ConcurrentModificationException;
import java.util.Map;

public class f {
   public static Object[] d;
   public static int e;
   public static Object[] f;
   public static int g;
   public int[] a;
   public Object[] b;
   public int c;

   public f() {
      this.a = b.b.d.a;
      this.b = b.b.d.b;
      this.c = 0;
   }

   public f(int var1) {
      if (var1 == 0) {
         this.a = b.b.d.a;
         this.b = b.b.d.b;
      } else {
         this.a(var1);
      }

      this.c = 0;
   }

   public static void a(int[] var0, Object[] var1, int var2) {
      Throwable var75;
      Throwable var10000;
      boolean var10001;
      if (var0.length == 8) {
         synchronized(a.class){}

         label811: {
            label838: {
               try {
                  if (g >= 10) {
                     break label838;
                  }

                  var1[0] = f;
               } catch (Throwable var71) {
                  var10000 = var71;
                  var10001 = false;
                  break label811;
               }

               var1[1] = var0;
               var2 = (var2 << 1) - 1;

               while(true) {
                  if (var2 < 2) {
                     try {
                        f = var1;
                        ++g;
                        break;
                     } catch (Throwable var70) {
                        var10000 = var70;
                        var10001 = false;
                        break label811;
                     }
                  }

                  var1[var2] = null;
                  --var2;
               }
            }

            label798:
            try {
               return;
            } catch (Throwable var69) {
               var10000 = var69;
               var10001 = false;
               break label798;
            }
         }

         while(true) {
            var75 = var10000;

            try {
               throw var75;
            } catch (Throwable var68) {
               var10000 = var68;
               var10001 = false;
               continue;
            }
         }
      } else if (var0.length == 4) {
         synchronized(a.class){}

         label829: {
            label839: {
               try {
                  if (e >= 10) {
                     break label839;
                  }

                  var1[0] = d;
               } catch (Throwable var74) {
                  var10000 = var74;
                  var10001 = false;
                  break label829;
               }

               var1[1] = var0;
               var2 = (var2 << 1) - 1;

               while(true) {
                  if (var2 < 2) {
                     try {
                        d = var1;
                        ++e;
                        break;
                     } catch (Throwable var73) {
                        var10000 = var73;
                        var10001 = false;
                        break label829;
                     }
                  }

                  var1[var2] = null;
                  --var2;
               }
            }

            label816:
            try {
               return;
            } catch (Throwable var72) {
               var10000 = var72;
               var10001 = false;
               break label816;
            }
         }

         while(true) {
            var75 = var10000;

            try {
               throw var75;
            } catch (Throwable var67) {
               var10000 = var67;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public int a() {
      int var1 = this.c;
      if (var1 == 0) {
         return -1;
      } else {
         int[] var2 = this.a;

         int var3;
         try {
            var3 = b.b.d.a(var2, var1, 0);
         } catch (ArrayIndexOutOfBoundsException var5) {
            ConcurrentModificationException var6 = new ConcurrentModificationException();
            throw var6;
         }

         if (var3 < 0) {
            return var3;
         } else if (this.b[var3 << 1] == null) {
            return var3;
         } else {
            int var4;
            for(var4 = var3 + 1; var4 < var1 && this.a[var4] == 0; ++var4) {
               if (this.b[var4 << 1] == null) {
                  return var4;
               }
            }

            for(var1 = var3 - 1; var1 >= 0 && this.a[var1] == 0; --var1) {
               if (this.b[var1 << 1] == null) {
                  return var1;
               }
            }

            return ~var4;
         }
      }
   }

   public int a(Object var1) {
      int var2;
      if (var1 == null) {
         var2 = this.a();
      } else {
         var2 = this.a(var1, var1.hashCode());
      }

      return var2;
   }

   public int a(Object var1, int var2) {
      int var3 = this.c;
      if (var3 == 0) {
         return -1;
      } else {
         int[] var4 = this.a;

         int var5;
         try {
            var5 = b.b.d.a(var4, var3, var2);
         } catch (ArrayIndexOutOfBoundsException var7) {
            ConcurrentModificationException var8 = new ConcurrentModificationException();
            throw var8;
         }

         if (var5 < 0) {
            return var5;
         } else if (var1.equals(this.b[var5 << 1])) {
            return var5;
         } else {
            int var6;
            for(var6 = var5 + 1; var6 < var3 && this.a[var6] == var2; ++var6) {
               if (var1.equals(this.b[var6 << 1])) {
                  return var6;
               }
            }

            --var5;

            while(var5 >= 0 && this.a[var5] == var2) {
               if (var1.equals(this.b[var5 << 1])) {
                  return var5;
               }

               --var5;
            }

            return ~var6;
         }
      }
   }

   public final void a(int var1) {
      Throwable var75;
      Throwable var10000;
      boolean var10001;
      label758: {
         Object[] var2;
         if (var1 == 8) {
            synchronized(a.class){}

            label754: {
               try {
                  if (f == null) {
                     break label754;
                  }

                  var2 = f;
                  this.b = var2;
                  f = (Object[])var2[0];
                  this.a = (int[])var2[1];
               } catch (Throwable var72) {
                  var10000 = var72;
                  var10001 = false;
                  break label758;
               }

               var2[1] = null;
               var2[0] = null;

               try {
                  --g;
                  return;
               } catch (Throwable var69) {
                  var10000 = var69;
                  var10001 = false;
                  break label758;
               }
            }

            try {
               ;
            } catch (Throwable var71) {
               var10000 = var71;
               var10001 = false;
               break label758;
            }
         } else if (var1 == 4) {
            label757: {
               synchronized(a.class){}

               label743: {
                  label755: {
                     try {
                        if (d == null) {
                           break label755;
                        }

                        var2 = d;
                        this.b = var2;
                        d = (Object[])var2[0];
                        this.a = (int[])var2[1];
                     } catch (Throwable var74) {
                        var10000 = var74;
                        var10001 = false;
                        break label743;
                     }

                     var2[1] = null;
                     var2[0] = null;

                     try {
                        --e;
                        return;
                     } catch (Throwable var70) {
                        var10000 = var70;
                        var10001 = false;
                        break label743;
                     }
                  }

                  label736:
                  try {
                     break label757;
                  } catch (Throwable var73) {
                     var10000 = var73;
                     var10001 = false;
                     break label736;
                  }
               }

               while(true) {
                  var75 = var10000;

                  try {
                     throw var75;
                  } catch (Throwable var68) {
                     var10000 = var68;
                     var10001 = false;
                     continue;
                  }
               }
            }
         }

         this.a = new int[var1];
         this.b = new Object[var1 << 1];
         return;
      }

      while(true) {
         var75 = var10000;

         try {
            throw var75;
         } catch (Throwable var67) {
            var10000 = var67;
            var10001 = false;
            continue;
         }
      }
   }

   public int b(Object var1) {
      int var2 = this.c * 2;
      Object[] var3 = this.b;
      int var4;
      if (var1 == null) {
         for(var4 = 1; var4 < var2; var4 += 2) {
            if (var3[var4] == null) {
               return var4 >> 1;
            }
         }
      } else {
         for(var4 = 1; var4 < var2; var4 += 2) {
            if (var1.equals(var3[var4])) {
               return var4 >> 1;
            }
         }
      }

      return -1;
   }

   public Object b(int var1) {
      return this.b[var1 << 1];
   }

   public Object c(int var1) {
      Object[] var2 = this.b;
      int var3 = var1 << 1;
      Object var4 = var2[var3 + 1];
      int var5 = this.c;
      int var6;
      if (var5 <= 1) {
         a(this.a, var2, var5);
         this.a = b.b.d.a;
         this.b = b.b.d.b;
         var6 = 0;
      } else {
         int var7 = var5 - 1;
         int[] var11 = this.a;
         int var8 = var11.length;
         var6 = 8;
         if (var8 > 8 && var5 < var11.length / 3) {
            if (var5 > 8) {
               var6 = var5 + (var5 >> 1);
            }

            var11 = this.a;
            Object[] var9 = this.b;
            this.a(var6);
            if (var5 != this.c) {
               throw new ConcurrentModificationException();
            }

            if (var1 > 0) {
               System.arraycopy(var11, 0, this.a, 0, var1);
               System.arraycopy(var9, 0, this.b, 0, var3);
            }

            var6 = var7;
            if (var1 < var7) {
               var6 = var1 + 1;
               int[] var10 = this.a;
               var8 = var7 - var1;
               System.arraycopy(var11, var6, var10, var1, var8);
               System.arraycopy(var9, var6 << 1, this.b, var3, var8 << 1);
               var6 = var7;
            }
         } else {
            if (var1 < var7) {
               var11 = this.a;
               var8 = var1 + 1;
               var6 = var7 - var1;
               System.arraycopy(var11, var8, var11, var1, var6);
               var2 = this.b;
               System.arraycopy(var2, var8 << 1, var2, var3, var6 << 1);
            }

            var2 = this.b;
            var1 = var7 << 1;
            var2[var1] = null;
            var2[var1 + 1] = null;
            var6 = var7;
         }
      }

      if (var5 == this.c) {
         this.c = var6;
         return var4;
      } else {
         throw new ConcurrentModificationException();
      }
   }

   public void clear() {
      int var1 = this.c;
      if (var1 > 0) {
         int[] var2 = this.a;
         Object[] var3 = this.b;
         this.a = b.b.d.a;
         this.b = b.b.d.b;
         this.c = 0;
         a(var2, var3, var1);
      }

      if (this.c > 0) {
         throw new ConcurrentModificationException();
      }
   }

   public boolean containsKey(Object var1) {
      boolean var2;
      if (this.a(var1) >= 0) {
         var2 = true;
      } else {
         var2 = false;
      }

      return var2;
   }

   public boolean containsValue(Object var1) {
      boolean var2;
      if (this.b(var1) >= 0) {
         var2 = true;
      } else {
         var2 = false;
      }

      return var2;
   }

   public Object d(int var1) {
      return this.b[(var1 << 1) + 1];
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else {
         boolean var10001;
         int var3;
         Object var5;
         boolean var6;
         if (var1 instanceof f) {
            f var13 = (f)var1;
            if (this.c != var13.c) {
               return false;
            } else {
               var3 = 0;

               while(true) {
                  Object var14;
                  try {
                     if (var3 >= this.c) {
                        return true;
                     }

                     var14 = this.b(var3);
                     var1 = this.d(var3);
                     var5 = var13.get(var14);
                  } catch (ClassCastException | NullPointerException var9) {
                     var10001 = false;
                     break;
                  }

                  if (var1 == null) {
                     label67: {
                        if (var5 == null) {
                           try {
                              if (var13.containsKey(var14)) {
                                 break label67;
                              }
                           } catch (ClassCastException | NullPointerException var8) {
                              var10001 = false;
                              break;
                           }
                        }

                        return false;
                     }
                  } else {
                     try {
                        var6 = var1.equals(var5);
                     } catch (ClassCastException | NullPointerException var7) {
                        var10001 = false;
                        break;
                     }

                     if (!var6) {
                        return false;
                     }
                  }

                  ++var3;
               }

               return false;
            }
         } else {
            if (var1 instanceof Map) {
               Map var4 = (Map)var1;
               if (this.c != var4.size()) {
                  return false;
               }

               var3 = 0;

               while(true) {
                  Object var2;
                  try {
                     if (var3 >= this.c) {
                        return true;
                     }

                     var5 = this.b(var3);
                     var2 = this.d(var3);
                     var1 = var4.get(var5);
                  } catch (ClassCastException | NullPointerException var12) {
                     var10001 = false;
                     break;
                  }

                  if (var2 == null) {
                     label91: {
                        if (var1 == null) {
                           try {
                              if (var4.containsKey(var5)) {
                                 break label91;
                              }
                           } catch (ClassCastException | NullPointerException var11) {
                              var10001 = false;
                              break;
                           }
                        }

                        return false;
                     }
                  } else {
                     try {
                        var6 = var2.equals(var1);
                     } catch (ClassCastException | NullPointerException var10) {
                        var10001 = false;
                        break;
                     }

                     if (!var6) {
                        return false;
                     }
                  }

                  ++var3;
               }
            }

            return false;
         }
      }
   }

   public Object get(Object var1) {
      int var2 = this.a(var1);
      if (var2 >= 0) {
         var1 = this.b[(var2 << 1) + 1];
      } else {
         var1 = null;
      }

      return var1;
   }

   public int hashCode() {
      int[] var1 = this.a;
      Object[] var2 = this.b;
      int var3 = this.c;
      int var4 = 0;
      int var5 = 0;

      for(int var6 = 1; var4 < var3; var6 += 2) {
         Object var7 = var2[var6];
         int var8 = var1[var4];
         int var9;
         if (var7 == null) {
            var9 = 0;
         } else {
            var9 = var7.hashCode();
         }

         var5 += var9 ^ var8;
         ++var4;
      }

      return var5;
   }

   public boolean isEmpty() {
      boolean var1;
      if (this.c <= 0) {
         var1 = true;
      } else {
         var1 = false;
      }

      return var1;
   }

   public Object put(Object var1, Object var2) {
      int var3 = this.c;
      int var4;
      int var5;
      if (var1 == null) {
         var4 = this.a();
         var5 = 0;
      } else {
         var5 = var1.hashCode();
         var4 = this.a(var1, var5);
      }

      Object[] var10;
      if (var4 >= 0) {
         var4 = (var4 << 1) + 1;
         var10 = this.b;
         var1 = var10[var4];
         var10[var4] = var2;
         return var1;
      } else {
         int var7 = ~var4;
         int[] var6;
         if (var3 >= this.a.length) {
            var4 = 4;
            if (var3 >= 8) {
               var4 = (var3 >> 1) + var3;
            } else if (var3 >= 4) {
               var4 = 8;
            }

            var6 = this.a;
            Object[] var8 = this.b;
            this.a(var4);
            if (var3 != this.c) {
               throw new ConcurrentModificationException();
            }

            int[] var9 = this.a;
            if (var9.length > 0) {
               System.arraycopy(var6, 0, var9, 0, var6.length);
               System.arraycopy(var8, 0, this.b, 0, var8.length);
            }

            a(var6, var8, var3);
         }

         if (var7 < var3) {
            var6 = this.a;
            var4 = var7 + 1;
            System.arraycopy(var6, var7, var6, var4, var3 - var7);
            var10 = this.b;
            System.arraycopy(var10, var7 << 1, var10, var4 << 1, this.c - var7 << 1);
         }

         var4 = this.c;
         if (var3 == var4) {
            var6 = this.a;
            if (var7 < var6.length) {
               var6[var7] = var5;
               var10 = this.b;
               var5 = var7 << 1;
               var10[var5] = var1;
               var10[var5 + 1] = var2;
               this.c = var4 + 1;
               return null;
            }
         }

         throw new ConcurrentModificationException();
      }
   }

   public Object remove(Object var1) {
      int var2 = this.a(var1);
      return var2 >= 0 ? this.c(var2) : null;
   }

   public int size() {
      return this.c;
   }

   public String toString() {
      if (this.isEmpty()) {
         return "{}";
      } else {
         StringBuilder var1 = new StringBuilder(this.c * 28);
         var1.append('{');

         for(int var2 = 0; var2 < this.c; ++var2) {
            if (var2 > 0) {
               var1.append(", ");
            }

            Object var3 = this.b(var2);
            if (var3 != this) {
               var1.append(var3);
            } else {
               var1.append("(this Map)");
            }

            var1.append('=');
            var3 = this.d(var2);
            if (var3 != this) {
               var1.append(var3);
            } else {
               var1.append("(this Map)");
            }
         }

         var1.append('}');
         return var1.toString();
      }
   }
}
