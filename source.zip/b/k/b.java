package b.k;

import android.os.Parcel;
import android.util.SparseIntArray;

public class b extends a {
   public final SparseIntArray d;
   public final Parcel e;
   public final int f;
   public final int g;
   public final String h;
   public int i;
   public int j;
   public int k;

   public b(Parcel var1) {
      this(var1, var1.dataPosition(), var1.dataSize(), "", new b.b.a(), new b.b.a(), new b.b.a());
   }

   public b(Parcel var1, int var2, int var3, String var4, b.b.a var5, b.b.a var6, b.b.a var7) {
      super(var5, var6, var7);
      this.d = new SparseIntArray();
      this.i = -1;
      this.j = 0;
      this.k = -1;
      this.e = var1;
      this.f = var2;
      this.g = var3;
      this.j = this.f;
      this.h = var4;
   }

   public void a() {
      int var1 = this.i;
      if (var1 >= 0) {
         int var2 = this.d.get(var1);
         var1 = this.e.dataPosition();
         this.e.setDataPosition(var2);
         this.e.writeInt(var1 - var2);
         this.e.setDataPosition(var1);
      }

   }

   public boolean a(int var1) {
      while(true) {
         int var2 = this.j;
         int var3 = this.g;
         boolean var4 = true;
         if (var2 >= var3) {
            if (this.k != var1) {
               var4 = false;
            }

            return var4;
         }

         var3 = this.k;
         if (var3 == var1) {
            return true;
         }

         if (String.valueOf(var3).compareTo(String.valueOf(var1)) > 0) {
            return false;
         }

         this.e.setDataPosition(this.j);
         var3 = this.e.readInt();
         this.k = this.e.readInt();
         this.j += var3;
      }
   }

   public a b() {
      Parcel var1 = this.e;
      int var2 = var1.dataPosition();
      int var3 = this.j;
      int var4 = var3;
      if (var3 == this.f) {
         var4 = this.g;
      }

      return new b(var1, var2, var4, c.a.b.a.a.a(new StringBuilder(), this.h, "  "), super.a, super.b, super.c);
   }

   public void b(int var1) {
      this.a();
      this.i = var1;
      this.d.put(var1, this.e.dataPosition());
      this.e.writeInt(0);
      this.e.writeInt(var1);
   }

   public String c() {
      return this.e.readString();
   }
}
