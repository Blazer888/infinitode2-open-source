package b.k;

public interface c {
}
