package b.k;

import android.os.Parcelable;
import android.text.TextUtils;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public abstract class a {
   public final b.b.a a;
   public final b.b.a b;
   public final b.b.a c;

   public a(b.b.a var1, b.b.a var2, b.b.a var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public int a(int var1, int var2) {
      return !this.a(var2) ? var1 : ((b)this).e.readInt();
   }

   public Parcelable a(Parcelable var1, int var2) {
      return !this.a(var2) ? var1 : ((b)this).e.readParcelable(b.class.getClassLoader());
   }

   public CharSequence a(CharSequence var1, int var2) {
      if (!this.a(var2)) {
         return var1;
      } else {
         b var3 = (b)this;
         return (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(var3.e);
      }
   }

   public final Class a(Class var1) {
      Class var2 = (Class)this.c.get(var1.getName());
      Class var3 = var2;
      if (var2 == null) {
         var3 = Class.forName(String.format("%s.%sParcelizer", var1.getPackage().getName(), var1.getSimpleName()), false, var1.getClassLoader());
         this.c.put(var1.getName(), var3);
      }

      return var3;
   }

   public final Method a(String var1) {
      Method var2 = (Method)this.a.get(var1);
      Method var3 = var2;
      if (var2 == null) {
         System.currentTimeMillis();
         var3 = Class.forName(var1, true, a.class.getClassLoader()).getDeclaredMethod("read", a.class);
         this.a.put(var1, var3);
      }

      return var3;
   }

   public abstract void a();

   public void a(c var1) {
      if (var1 == null) {
         ((b)this).e.writeString((String)null);
      } else {
         Class var9;
         try {
            var9 = this.a(var1.getClass());
         } catch (ClassNotFoundException var4) {
            StringBuilder var2 = new StringBuilder();
            var2.append(var1.getClass().getSimpleName());
            var2.append(" does not have a Parcelizer");
            throw new RuntimeException(var2.toString(), var4);
         }

         String var10 = var9.getName();
         ((b)this).e.writeString(var10);
         a var11 = this.b();

         try {
            this.b(var1.getClass()).invoke((Object)null, var1, var11);
         } catch (IllegalAccessException var5) {
            throw new RuntimeException("VersionedParcel encountered IllegalAccessException", var5);
         } catch (InvocationTargetException var6) {
            if (var6.getCause() instanceof RuntimeException) {
               throw (RuntimeException)var6.getCause();
            }

            throw new RuntimeException("VersionedParcel encountered InvocationTargetException", var6);
         } catch (NoSuchMethodException var7) {
            throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", var7);
         } catch (ClassNotFoundException var8) {
            throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", var8);
         }

         var11.a();
      }
   }

   public abstract boolean a(int var1);

   public boolean a(boolean var1, int var2) {
      if (!this.a(var2)) {
         return var1;
      } else {
         if (((b)this).e.readInt() != 0) {
            var1 = true;
         } else {
            var1 = false;
         }

         return var1;
      }
   }

   public abstract a b();

   public final Method b(Class var1) {
      Method var2 = (Method)this.b.get(var1.getName());
      Method var3 = var2;
      if (var2 == null) {
         Class var4 = this.a(var1);
         System.currentTimeMillis();
         var3 = var4.getDeclaredMethod("write", var1, a.class);
         this.b.put(var1.getName(), var3);
      }

      return var3;
   }

   public abstract void b(int var1);

   public void b(int var1, int var2) {
      this.b(var2);
      ((b)this).e.writeInt(var1);
   }

   public void b(Parcelable var1, int var2) {
      this.b(var2);
      ((b)this).e.writeParcelable(var1, 0);
   }

   public abstract String c();

   public c d() {
      String var1 = ((b)this).e.readString();
      if (var1 == null) {
         return null;
      } else {
         a var2 = this.b();

         try {
            c var7 = (c)this.a(var1).invoke((Object)null, var2);
            return var7;
         } catch (IllegalAccessException var3) {
            throw new RuntimeException("VersionedParcel encountered IllegalAccessException", var3);
         } catch (InvocationTargetException var4) {
            if (var4.getCause() instanceof RuntimeException) {
               throw (RuntimeException)var4.getCause();
            } else {
               throw new RuntimeException("VersionedParcel encountered InvocationTargetException", var4);
            }
         } catch (NoSuchMethodException var5) {
            throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", var5);
         } catch (ClassNotFoundException var6) {
            throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", var6);
         }
      }
   }

   public void e() {
   }
}
