package b.h;

public class d {
   public long a;
   public long b;
}
