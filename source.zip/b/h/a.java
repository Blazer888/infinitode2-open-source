package b.h;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build.VERSION;
import android.util.Log;
import dalvik.system.DexFile;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

public final class a {
   public static final Set a = new HashSet();
   public static final boolean b;

   static {
      String var0 = System.getProperty("java.vm.version");
      boolean var1 = false;
      boolean var2 = var1;
      if (var0 != null) {
         Matcher var3 = Pattern.compile("(\\d+)\\.(\\d+)(\\.\\d+)?").matcher(var0);
         var2 = var1;
         if (var3.matches()) {
            label33: {
               int var4;
               int var5;
               try {
                  var4 = Integer.parseInt(var3.group(1));
                  var5 = Integer.parseInt(var3.group(2));
               } catch (NumberFormatException var6) {
                  var2 = var1;
                  break label33;
               }

               if (var4 <= 2) {
                  var2 = var1;
                  if (var4 != 2) {
                     break label33;
                  }

                  var2 = var1;
                  if (var5 < 1) {
                     break label33;
                  }
               }

               var2 = true;
            }
         }
      }

      StringBuilder var7 = c.a.b.a.a.b("VM with version ", var0);
      if (var2) {
         var0 = " has multidex support";
      } else {
         var0 = " does not have multidex support";
      }

      var7.append(var0);
      Log.i("MultiDex", var7.toString());
      b = var2;
   }

   public static Field a(Object var0, String var1) {
      Class var2 = var0.getClass();

      while(var2 != null) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            if (!var3.isAccessible()) {
               var3.setAccessible(true);
            }

            return var3;
         } catch (NoSuchFieldException var4) {
            var2 = var2.getSuperclass();
         }
      }

      StringBuilder var6 = c.a.b.a.a.b("Field ", var1, " not found in ");
      var6.append(var0.getClass());
      NoSuchFieldException var5 = new NoSuchFieldException(var6.toString());
      throw var5;
   }

   // $FF: synthetic method
   public static Method a(Object var0, String var1, Class[] var2) {
      Class var3 = var0.getClass();

      while(var3 != null) {
         try {
            Method var4 = var3.getDeclaredMethod(var1, var2);
            if (!var4.isAccessible()) {
               var4.setAccessible(true);
            }

            return var4;
         } catch (NoSuchMethodException var5) {
            var3 = var3.getSuperclass();
         }
      }

      StringBuilder var7 = c.a.b.a.a.b("Method ", var1, " with parameters ");
      var7.append(Arrays.asList(var2));
      var7.append(" not found in ");
      var7.append(var0.getClass());
      NoSuchMethodException var6 = new NoSuchMethodException(var7.toString());
      throw var6;
   }

   public static void a(Context var0) {
      File var6 = new File(var0.getFilesDir(), "secondary-dexes");
      if (var6.isDirectory()) {
         StringBuilder var1 = c.a.b.a.a.b("Clearing old secondary dex dir (");
         var1.append(var6.getPath());
         var1.append(").");
         Log.i("MultiDex", var1.toString());
         File[] var2 = var6.listFiles();
         if (var2 == null) {
            var1 = c.a.b.a.a.b("Failed to list secondary dex dir content (");
            var1.append(var6.getPath());
            var1.append(").");
            Log.w("MultiDex", var1.toString());
            return;
         }

         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            File var7 = var2[var4];
            StringBuilder var5 = c.a.b.a.a.b("Trying to delete old file ");
            var5.append(var7.getPath());
            var5.append(" of size ");
            var5.append(var7.length());
            Log.i("MultiDex", var5.toString());
            if (!var7.delete()) {
               var5 = c.a.b.a.a.b("Failed to delete old file ");
               var5.append(var7.getPath());
               Log.w("MultiDex", var5.toString());
            } else {
               var5 = c.a.b.a.a.b("Deleted old file ");
               var5.append(var7.getPath());
               Log.i("MultiDex", var5.toString());
            }
         }

         if (!var6.delete()) {
            var1 = c.a.b.a.a.b("Failed to delete secondary dex dir ");
            var1.append(var6.getPath());
            Log.w("MultiDex", var1.toString());
         } else {
            var1 = c.a.b.a.a.b("Deleted old secondary dex dir ");
            var1.append(var6.getPath());
            Log.i("MultiDex", var1.toString());
         }
      }

   }

   public static void a(Context param0, File param1, File param2, String param3, String param4, boolean param5) {
      // $FF: Couldn't be decompiled
   }

   public static void a(File var0) {
      var0.mkdir();
      if (!var0.isDirectory()) {
         File var1 = var0.getParentFile();
         StringBuilder var2;
         if (var1 == null) {
            var2 = c.a.b.a.a.b("Failed to create dir ");
            var2.append(var0.getPath());
            var2.append(". Parent file is null.");
            Log.e("MultiDex", var2.toString());
         } else {
            var2 = c.a.b.a.a.b("Failed to create dir ");
            var2.append(var0.getPath());
            var2.append(". parent file is a dir ");
            var2.append(var1.isDirectory());
            var2.append(", a file ");
            var2.append(var1.isFile());
            var2.append(", exists ");
            var2.append(var1.exists());
            var2.append(", readable ");
            var2.append(var1.canRead());
            var2.append(", writable ");
            var2.append(var1.canWrite());
            Log.e("MultiDex", var2.toString());
         }

         var2 = c.a.b.a.a.b("Failed to create directory ");
         var2.append(var0.getPath());
         throw new IOException(var2.toString());
      }
   }

   public static void a(ClassLoader var0, File var1, List var2) {
      if (!var2.isEmpty()) {
         if (VERSION.SDK_INT >= 19) {
            Object var3 = a(var0, "pathList").get(var0);
            ArrayList var4 = new ArrayList();
            ArrayList var12 = new ArrayList(var2);
            a(var3, "dexElements", (Object[])a(var3, "makeDexElements", new Class[]{ArrayList.class, File.class, ArrayList.class}).invoke(var3, var12, var1, var4));
            if (var4.size() > 0) {
               Iterator var13 = var4.iterator();

               while(var13.hasNext()) {
                  Log.w("MultiDex", "Exception in makeDexElement", (IOException)var13.next());
               }

               Field var15 = a(var3, "dexElementsSuppressedExceptions");
               IOException[] var19 = (IOException[])var15.get(var3);
               IOException[] var14;
               if (var19 == null) {
                  var14 = (IOException[])var4.toArray(new IOException[var4.size()]);
               } else {
                  var14 = new IOException[var4.size() + var19.length];
                  var4.toArray(var14);
                  System.arraycopy(var19, 0, var14, var4.size(), var19.length);
               }

               var15.set(var3, var14);
               IOException var17 = new IOException("I/O exception during makeDexElement");
               var17.initCause((Throwable)var4.get(0));
               throw var17;
            }
         } else {
            Object var18 = a(var0, "pathList").get(var0);
            b.h.a.a var5 = new b.h.a.a();
            Object[] var16 = new Object[var2.size()];

            for(int var6 = 0; var6 < var16.length; ++var6) {
               File var7 = (File)var2.get(var6);
               b.h.a.a.a var8 = var5.a;
               String var9 = var7.getPath();
               File var20 = var7.getParentFile();
               String var21 = var7.getName();
               StringBuilder var10 = new StringBuilder();
               var10.append(var21.substring(0, var21.length() - 4));
               var10.append(".dex");
               var16[var6] = var8.a(var7, DexFile.loadDex(var9, (new File(var20, var10.toString())).getPath(), 0));
            }

            try {
               a(var18, "dexElements", var16);
            } catch (NoSuchFieldException var11) {
               Log.w("MultiDex", "Failed find field 'dexElements' attempting 'pathElements'", var11);
               a(var18, "pathElements", var16);
            }
         }
      }

   }

   // $FF: synthetic method
   public static void a(Object var0, String var1, Object[] var2) {
      Field var5 = a(var0, var1);
      Object[] var3 = (Object[])var5.get(var0);
      Object[] var4 = (Object[])Array.newInstance(var3.getClass().getComponentType(), var3.length + var2.length);
      System.arraycopy(var3, 0, var4, 0, var3.length);
      System.arraycopy(var2, 0, var4, var3.length, var2.length);
      var5.set(var0, var4);
   }

   public static void b(Context var0) {
      Log.i("MultiDex", "Installing application");
      if (b) {
         Log.i("MultiDex", "VM has multidex support, MultiDex support library is disabled.");
      } else {
         int var1 = VERSION.SDK_INT;

         Exception var10000;
         label44: {
            ApplicationInfo var11;
            boolean var10001;
            label50: {
               RuntimeException var2;
               try {
                  try {
                     var11 = var0.getApplicationInfo();
                     break label50;
                  } catch (RuntimeException var8) {
                     var2 = var8;
                  }
               } catch (Exception var9) {
                  var10000 = var9;
                  var10001 = false;
                  break label44;
               }

               try {
                  Log.w("MultiDex", "Failure while trying to obtain ApplicationInfo from Context. Must be running in test mode. Skip patching.", var2);
               } catch (Exception var7) {
                  var10000 = var7;
                  var10001 = false;
                  break label44;
               }

               var11 = null;
            }

            if (var11 == null) {
               try {
                  Log.i("MultiDex", "No ApplicationInfo available, i.e. running on a test Context: MultiDex support library is disabled.");
                  return;
               } catch (Exception var5) {
                  var10000 = var5;
                  var10001 = false;
               }
            } else {
               label34: {
                  try {
                     File var3 = new File(var11.sourceDir);
                     File var4 = new File(var11.dataDir);
                     a(var0, var3, var4, "secondary-dexes", "", true);
                  } catch (Exception var6) {
                     var10000 = var6;
                     var10001 = false;
                     break label34;
                  }

                  Log.i("MultiDex", "install done");
                  return;
               }
            }
         }

         Exception var12 = var10000;
         Log.e("MultiDex", "MultiDex installation failure", var12);
         StringBuilder var10 = c.a.b.a.a.b("MultiDex installation failed (");
         var10.append(var12.getMessage());
         var10.append(").");
         throw new RuntimeException(var10.toString());
      }
   }

   public static final class a {
      public final b.h.a.a.a a;

      public a() {
         Class var1 = Class.forName("dalvik.system.DexPathList$Element");

         Object var2;
         try {
            var2 = new b.h.a.a.b(var1);
         } catch (NoSuchMethodException var4) {
            try {
               var2 = new b.h.a.a.c(var1);
            } catch (NoSuchMethodException var3) {
               var2 = new b.h.a.a.d(var1);
            }
         }

         this.a = (b.h.a.a.a)var2;
      }

      public interface a {
         Object a(File var1, DexFile var2);
      }

      public static class b implements b.h.a.a.a {
         public final Constructor a;

         public b(Class var1) {
            this.a = var1.getConstructor(File.class, ZipFile.class, DexFile.class);
            this.a.setAccessible(true);
         }

         public Object a(File var1, DexFile var2) {
            return this.a.newInstance(var1, new ZipFile(var1), var2);
         }
      }

      public static class c implements b.h.a.a.a {
         public final Constructor a;

         public c(Class var1) {
            this.a = var1.getConstructor(File.class, File.class, DexFile.class);
            this.a.setAccessible(true);
         }

         public Object a(File var1, DexFile var2) {
            return this.a.newInstance(var1, var1, var2);
         }
      }

      public static class d implements b.h.a.a.a {
         public final Constructor a;

         public d(Class var1) {
            this.a = var1.getConstructor(File.class, Boolean.TYPE, File.class, DexFile.class);
            this.a.setAccessible(true);
         }

         public Object a(File var1, DexFile var2) {
            return this.a.newInstance(var1, Boolean.FALSE, var1, var2);
         }
      }
   }

   public static final class b {
      public static b.h.d a(RandomAccessFile var0) {
         long var1 = var0.length() - 22L;
         long var3 = 0L;
         if (var1 < 0L) {
            StringBuilder var10 = c.a.b.a.a.b("File too short to be a zip file: ");
            var10.append(var0.length());
            ZipException var9 = new ZipException(var10.toString());
            throw var9;
         } else {
            long var5 = var1 - 65536L;
            if (var5 >= 0L) {
               var3 = var5;
            }

            int var7 = Integer.reverseBytes(101010256);

            do {
               var0.seek(var1);
               if (var0.readInt() == var7) {
                  var0.skipBytes(2);
                  var0.skipBytes(2);
                  var0.skipBytes(2);
                  var0.skipBytes(2);
                  b.h.d var8 = new b.h.d();
                  var8.b = (long)Integer.reverseBytes(var0.readInt()) & 4294967295L;
                  var8.a = (long)Integer.reverseBytes(var0.readInt()) & 4294967295L;
                  return var8;
               }

               --var1;
            } while(var1 >= var3);

            throw new ZipException("End Of Central Directory signature not found");
         }
      }
   }
}
