package b.h;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Build.VERSION;
import android.util.Log;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

public final class c implements Closeable {
   public final File a;
   public final long b;
   public final File c;
   public final RandomAccessFile d;
   public final FileChannel e;
   public final FileLock f;

   public c(File var1, File var2) {
      StringBuilder var3 = c.a.b.a.a.b("MultiDexExtractor(");
      var3.append(var1.getPath());
      var3.append(", ");
      var3.append(var2.getPath());
      var3.append(")");
      Log.i("MultiDex", var3.toString());
      this.a = var1;
      this.c = var2;
      this.b = b(var1);
      var1 = new File(var2, "MultiDex.lock");
      this.d = new RandomAccessFile(var1, "rw");

      Object var16;
      label57: {
         IOException var19;
         label56: {
            RuntimeException var18;
            label55: {
               Error var10000;
               label61: {
                  boolean var10001;
                  try {
                     this.e = this.d.getChannel();
                  } catch (IOException var13) {
                     var19 = var13;
                     var10001 = false;
                     break label56;
                  } catch (RuntimeException var14) {
                     var18 = var14;
                     var10001 = false;
                     break label55;
                  } catch (Error var15) {
                     var10000 = var15;
                     var10001 = false;
                     break label61;
                  }

                  StringBuilder var17;
                  label50: {
                     try {
                        var17 = new StringBuilder();
                        var17.append("Blocking on lock ");
                        var17.append(var1.getPath());
                        Log.i("MultiDex", var17.toString());
                        this.f = this.e.lock();
                        break label50;
                     } catch (IOException var10) {
                        var16 = var10;
                     } catch (RuntimeException var11) {
                        var16 = var11;
                     } catch (Error var12) {
                        var16 = var12;
                     }

                     try {
                        a((Closeable)this.e);
                        throw var16;
                     } catch (IOException var4) {
                        var19 = var4;
                        var10001 = false;
                        break label56;
                     } catch (RuntimeException var5) {
                        var18 = var5;
                        var10001 = false;
                        break label55;
                     } catch (Error var6) {
                        var10000 = var6;
                        var10001 = false;
                        break label61;
                     }
                  }

                  try {
                     var17 = new StringBuilder();
                     var17.append(var1.getPath());
                     var17.append(" locked");
                     Log.i("MultiDex", var17.toString());
                     return;
                  } catch (IOException var7) {
                     var19 = var7;
                     var10001 = false;
                     break label56;
                  } catch (RuntimeException var8) {
                     var18 = var8;
                     var10001 = false;
                     break label55;
                  } catch (Error var9) {
                     var10000 = var9;
                     var10001 = false;
                  }
               }

               var16 = var10000;
               break label57;
            }

            var16 = var18;
            break label57;
         }

         var16 = var19;
      }

      a((Closeable)this.d);
      throw var16;
   }

   public static long a(File var0) {
      long var1 = var0.lastModified();
      long var3 = var1;
      if (var1 == -1L) {
         var3 = var1 - 1L;
      }

      return var3;
   }

   public static SharedPreferences a(Context var0) {
      int var1 = VERSION.SDK_INT;
      return var0.getSharedPreferences("multidex.version", 4);
   }

   public static void a(Context var0, String var1, long var2, long var4, List var6) {
      Editor var10 = a(var0).edit();
      StringBuilder var7 = new StringBuilder();
      var7.append(var1);
      var7.append("timestamp");
      var10.putLong(var7.toString(), var2);
      var10.putLong(c.a.b.a.a.a(new StringBuilder(), var1, "crc"), var4);
      var7 = new StringBuilder();
      var7.append(var1);
      var7.append("dex.number");
      var10.putInt(var7.toString(), var6.size() + 1);
      Iterator var11 = var6.iterator();

      for(int var8 = 2; var11.hasNext(); ++var8) {
         c.a var12 = (c.a)var11.next();
         StringBuilder var9 = new StringBuilder();
         var9.append(var1);
         var9.append("dex.crc.");
         var9.append(var8);
         var10.putLong(var9.toString(), var12.a);
         var9 = new StringBuilder();
         var9.append(var1);
         var9.append("dex.time.");
         var9.append(var8);
         var10.putLong(var9.toString(), var12.lastModified());
      }

      var10.commit();
   }

   public static void a(Closeable var0) {
      try {
         var0.close();
      } catch (IOException var1) {
         Log.w("MultiDex", "Failed to close resource", var1);
      }

   }

   public static void a(ZipFile var0, ZipEntry var1, File var2, String var3) {
      InputStream var81 = var0.getInputStream(var1);
      File var86 = File.createTempFile(c.a.b.a.a.a("tmp-", var3), ".zip", var2.getParentFile());
      StringBuilder var4 = c.a.b.a.a.b("Extracting ");
      var4.append(var86.getPath());
      Log.i("MultiDex", var4.toString());

      Throwable var10000;
      Throwable var83;
      label604: {
         boolean var10001;
         ZipOutputStream var87;
         try {
            FileOutputStream var6 = new FileOutputStream(var86);
            BufferedOutputStream var5 = new BufferedOutputStream(var6);
            var87 = new ZipOutputStream(var5);
         } catch (Throwable var80) {
            var10000 = var80;
            var10001 = false;
            break label604;
         }

         label605: {
            label595: {
               int var7;
               byte[] var82;
               try {
                  ZipEntry var88 = new ZipEntry("classes.dex");
                  var88.setTime(var1.getTime());
                  var87.putNextEntry(var88);
                  var82 = new byte[16384];
                  var7 = var81.read(var82);
               } catch (Throwable var79) {
                  var10000 = var79;
                  var10001 = false;
                  break label595;
               }

               while(true) {
                  if (var7 == -1) {
                     try {
                        var87.closeEntry();
                        break label605;
                     } catch (Throwable var77) {
                        var10000 = var77;
                        var10001 = false;
                        break;
                     }
                  }

                  try {
                     var87.write(var82, 0, var7);
                     var7 = var81.read(var82);
                  } catch (Throwable var78) {
                     var10000 = var78;
                     var10001 = false;
                     break;
                  }
               }
            }

            var83 = var10000;

            try {
               var87.close();
               throw var83;
            } catch (Throwable var73) {
               var10000 = var73;
               var10001 = false;
               break label604;
            }
         }

         IOException var85;
         label606: {
            boolean var8;
            try {
               var87.close();
               if (!var86.setReadOnly()) {
                  break label606;
               }

               StringBuilder var84 = new StringBuilder();
               var84.append("Renaming to ");
               var84.append(var2.getPath());
               Log.i("MultiDex", var84.toString());
               var8 = var86.renameTo(var2);
            } catch (Throwable var76) {
               var10000 = var76;
               var10001 = false;
               break label604;
            }

            if (var8) {
               a((Closeable)var81);
               var86.delete();
               return;
            }

            try {
               var4 = new StringBuilder();
               var4.append("Failed to rename \"");
               var4.append(var86.getAbsolutePath());
               var4.append("\" to \"");
               var4.append(var2.getAbsolutePath());
               var4.append("\"");
               var85 = new IOException(var4.toString());
               throw var85;
            } catch (Throwable var74) {
               var10000 = var74;
               var10001 = false;
               break label604;
            }
         }

         label576:
         try {
            var4 = new StringBuilder();
            var4.append("Failed to mark readonly \"");
            var4.append(var86.getAbsolutePath());
            var4.append("\" (tmp of \"");
            var4.append(var2.getAbsolutePath());
            var4.append("\")");
            var85 = new IOException(var4.toString());
            throw var85;
         } catch (Throwable var75) {
            var10000 = var75;
            var10001 = false;
            break label576;
         }
      }

      var83 = var10000;
      a((Closeable)var81);
      var86.delete();
      throw var83;
   }

   public static long b(File var0) {
      RandomAccessFile var28 = new RandomAccessFile(var0, "r");

      long var3;
      long var6;
      label196: {
         Throwable var10000;
         label195: {
            CRC32 var2;
            int var5;
            boolean var10001;
            byte[] var29;
            try {
               d var1 = b.h.a.b.a(var28);
               var2 = new CRC32();
               var3 = var1.b;
               var28.seek(var1.a);
               var5 = (int)Math.min(16384L, var3);
               var29 = new byte[16384];
               var5 = var28.read(var29, 0, var5);
            } catch (Throwable var27) {
               var10000 = var27;
               var10001 = false;
               break label195;
            }

            while(true) {
               if (var5 != -1) {
                  try {
                     var2.update(var29, 0, var5);
                  } catch (Throwable var26) {
                     var10000 = var26;
                     var10001 = false;
                     break;
                  }

                  var3 -= (long)var5;
                  if (var3 != 0L) {
                     try {
                        var5 = var28.read(var29, 0, (int)Math.min(16384L, var3));
                        continue;
                     } catch (Throwable var25) {
                        var10000 = var25;
                        var10001 = false;
                        break;
                     }
                  }
               }

               try {
                  var6 = var2.getValue();
                  break label196;
               } catch (Throwable var24) {
                  var10000 = var24;
                  var10001 = false;
                  break;
               }
            }
         }

         Throwable var30 = var10000;
         var28.close();
         throw var30;
      }

      var28.close();
      var3 = var6;
      if (var6 == -1L) {
         var3 = var6 - 1L;
      }

      return var3;
   }

   public final List a() {
      // $FF: Couldn't be decompiled
   }

   public final List a(Context var1, String var2) {
      Log.i("MultiDex", "loading existing secondary dex files");
      StringBuilder var3 = new StringBuilder();
      var3.append(this.a.getName());
      var3.append(".classes");
      String var17 = var3.toString();
      SharedPreferences var15 = a(var1);
      StringBuilder var4 = new StringBuilder();
      var4.append(var2);
      var4.append("dex.number");
      int var5 = var15.getInt(var4.toString(), 1);
      ArrayList var18 = new ArrayList(var5 - 1);

      for(int var6 = 2; var6 <= var5; ++var6) {
         String var7 = c.a.b.a.a.a(var17, var6, ".zip");
         c.a var19 = new c.a(this.c, var7);
         StringBuilder var16;
         if (!var19.isFile()) {
            var16 = c.a.b.a.a.b("Missing extracted secondary dex file '");
            var16.append(var19.getPath());
            var16.append("'");
            throw new IOException(var16.toString());
         }

         var19.a = b(var19);
         StringBuilder var8 = new StringBuilder();
         var8.append(var2);
         var8.append("dex.crc.");
         var8.append(var6);
         long var9 = var15.getLong(var8.toString(), -1L);
         var8 = new StringBuilder();
         var8.append(var2);
         var8.append("dex.time.");
         var8.append(var6);
         long var11 = var15.getLong(var8.toString(), -1L);
         long var13 = var19.lastModified();
         if (var11 != var13 || var9 != var19.a) {
            var16 = new StringBuilder();
            var16.append("Invalid extracted dex: ");
            var16.append(var19);
            var16.append(" (key \"");
            var16.append(var2);
            var16.append("\"), expected modification time: ");
            var16.append(var11);
            var16.append(", modification time: ");
            var16.append(var13);
            var16.append(", expected crc: ");
            var16.append(var9);
            var16.append(", file crc: ");
            var16.append(var19.a);
            throw new IOException(var16.toString());
         }

         var18.add(var19);
      }

      return var18;
   }

   public List a(Context var1, String var2, boolean var3) {
      StringBuilder var4 = c.a.b.a.a.b("MultiDexExtractor.load(");
      var4.append(this.a.getPath());
      var4.append(", ");
      var4.append(var3);
      var4.append(", ");
      var4.append(var2);
      var4.append(")");
      Log.i("MultiDex", var4.toString());
      if (!this.f.isValid()) {
         throw new IllegalStateException("MultiDexExtractor was closed");
      } else {
         List var11;
         label41: {
            List var14;
            if (!var3) {
               boolean var9;
               label34: {
                  File var5 = this.a;
                  long var6 = this.b;
                  SharedPreferences var13 = a(var1);
                  StringBuilder var8 = new StringBuilder();
                  var8.append(var2);
                  var8.append("timestamp");
                  if (var13.getLong(var8.toString(), -1L) == a(var5)) {
                     var8 = new StringBuilder();
                     var8.append(var2);
                     var8.append("crc");
                     if (var13.getLong(var8.toString(), -1L) == var6) {
                        var9 = false;
                        break label34;
                     }
                  }

                  var9 = true;
               }

               if (!var9) {
                  try {
                     var14 = this.a(var1, var2);
                  } catch (IOException var10) {
                     Log.w("MultiDex", "Failed to reload existing extracted secondary dex files, falling back to fresh extraction", var10);
                     var14 = this.a();
                     a(var1, var2, a(this.a), this.b, var14);
                     var11 = var14;
                     break label41;
                  }

                  var11 = var14;
                  break label41;
               }
            }

            if (var3) {
               Log.i("MultiDex", "Forced extraction must be performed.");
            } else {
               Log.i("MultiDex", "Detected that extraction must be performed.");
            }

            var14 = this.a();
            a(var1, var2, a(this.a), this.b, var14);
            var11 = var14;
         }

         StringBuilder var12 = c.a.b.a.a.b("load found ");
         var12.append(var11.size());
         var12.append(" secondary dex files");
         Log.i("MultiDex", var12.toString());
         return var11;
      }
   }

   public void close() {
      this.f.release();
      this.e.close();
      this.d.close();
   }

   public static class a extends File {
      public long a = -1L;

      public a(File var1, String var2) {
         super(var1, var2);
      }
   }
}
