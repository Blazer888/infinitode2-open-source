package b.h;

import java.io.File;
import java.io.FileFilter;

public class b implements FileFilter {
   public b(c var1) {
   }

   public boolean accept(File var1) {
      return var1.getName().equals("MultiDex.lock") ^ true;
   }
}
