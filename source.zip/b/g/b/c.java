package b.g.b;

import android.os.Binder;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.util.Log;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class c {
   public static final ThreadFactory f = new ThreadFactory() {
      public final AtomicInteger a = new AtomicInteger(1);

      public Thread newThread(Runnable var1) {
         StringBuilder var2 = c.a.b.a.a.b("ModernAsyncTask #");
         var2.append(this.a.getAndIncrement());
         return new Thread(var1, var2.toString());
      }
   };
   public static final BlockingQueue g = new LinkedBlockingQueue(10);
   public static final Executor h;
   public static c.e i;
   public final c.g a;
   public final FutureTask b;
   public volatile c.f c;
   public final AtomicBoolean d;
   public final AtomicBoolean e;

   static {
      h = new ThreadPoolExecutor(5, 128, 1L, TimeUnit.SECONDS, g, f);
   }

   public c() {
      this.c = c.f.a;
      this.d = new AtomicBoolean();
      this.e = new AtomicBoolean();
      this.a = new c.g() {
         public Object call() {
            c.this.e.set(true);
            boolean var6 = false;

            try {
               var6 = true;
               Process.setThreadPriority(10);
               c.this.a(super.a);
               Binder.flushPendingCommands();
               var6 = false;
            } finally {
               if (var6) {
                  try {
                     c.this.d.set(true);
                  } finally {
                     c.this.a((Object)null);
                  }
               }
            }

            c.this.a((Object)null);
            return null;
         }
      };
      this.b = new FutureTask(this.a) {
         public void done() {
            InterruptedException var12;
            label72: {
               c var2;
               try {
                  try {
                     Object var1 = this.get();
                     var2 = c.this;
                     if (!var2.e.get()) {
                        var2.a(var1);
                     }

                     return;
                  } catch (InterruptedException var7) {
                     var12 = var7;
                     break label72;
                  } catch (ExecutionException var8) {
                     ExecutionException var11 = var8;
                     throw new RuntimeException("An error occurred while executing doInBackground()", var11.getCause());
                  } catch (CancellationException var9) {
                  }
               } catch (Throwable var10) {
                  throw new RuntimeException("An error occurred while executing doInBackground()", var10);
               }

               var2 = c.this;
               if (!var2.e.get()) {
                  var2.a((Object)null);
               }

               return;
            }

            Log.w("AsyncTask", var12);
         }
      };
   }

   public static Handler c() {
      synchronized(c.class){}

      Throwable var10000;
      boolean var10001;
      label122: {
         c.e var0;
         try {
            if (i == null) {
               var0 = new c.e();
               i = var0;
            }
         } catch (Throwable var12) {
            var10000 = var12;
            var10001 = false;
            break label122;
         }

         label119:
         try {
            var0 = i;
            return var0;
         } catch (Throwable var11) {
            var10000 = var11;
            var10001 = false;
            break label119;
         }
      }

      while(true) {
         Throwable var13 = var10000;

         try {
            throw var13;
         } catch (Throwable var10) {
            var10000 = var10;
            var10001 = false;
            continue;
         }
      }
   }

   public Object a(Object var1) {
      c().obtainMessage(1, new c.d(this, new Object[]{var1})).sendToTarget();
      return var1;
   }

   public abstract Object a(Object... var1);

   public final boolean a() {
      return this.d.get();
   }

   public void b() {
   }

   public static class d {
      public final c a;
      public final Object[] b;

      public d(c var1, Object... var2) {
         this.a = var1;
         this.b = var2;
      }
   }

   public static class e extends Handler {
      public e() {
         super(Looper.getMainLooper());
      }

      public void handleMessage(Message var1) {
         // $FF: Couldn't be decompiled
      }
   }

   public static enum f {
      a,
      b,
      c;
   }

   public abstract static class g implements Callable {
      public Object[] a;
   }
}
