package b.g.b;

import android.content.Context;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class b {
   public int a;
   public b.a b;
   public boolean c = false;
   public boolean d = false;
   public boolean e = true;
   public boolean f = false;
   public boolean g = false;

   public b(Context var1) {
      var1.getApplicationContext();
   }

   public String a(Object var1) {
      StringBuilder var2 = new StringBuilder(64);
      b.c.b.b.a(var1, var2);
      var2.append("}");
      return var2.toString();
   }

   @Deprecated
   public void a(String var1, FileDescriptor var2, PrintWriter var3, String[] var4) {
      var3.print(var1);
      var3.print("mId=");
      var3.print(this.a);
      var3.print(" mListener=");
      var3.println(this.b);
      if (this.c || this.f || this.g) {
         var3.print(var1);
         var3.print("mStarted=");
         var3.print(this.c);
         var3.print(" mContentChanged=");
         var3.print(this.f);
         var3.print(" mProcessingChange=");
         var3.println(this.g);
      }

      if (this.d || this.e) {
         var3.print(var1);
         var3.print("mAbandoned=");
         var3.print(this.d);
         var3.print(" mReset=");
         var3.println(this.e);
      }

   }

   public boolean a() {
      throw null;
   }

   public void b() {
      throw null;
   }

   public void c() {
      throw null;
   }

   public void d() {
      this.e = true;
      this.c = false;
      this.d = false;
      this.f = false;
      this.g = false;
   }

   public String toString() {
      StringBuilder var1 = new StringBuilder(64);
      b.c.b.b.a((Object)this, (StringBuilder)var1);
      var1.append(" id=");
      return c.a.b.a.a.a(var1, this.a, "}");
   }

   public interface a {
   }
}
