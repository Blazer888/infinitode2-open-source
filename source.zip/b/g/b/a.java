package b.g.b;

import android.content.Context;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import c.c.b.a.b.a.d.e.f;
import c.c.b.a.d.m.e;
import c.c.b.a.d.m.n.m;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

public abstract class a extends b {
   public final Executor h;
   public volatile b.g.b.a.a i;
   public volatile b.g.b.a.a j;
   public long k;
   public long l;
   public Handler m;

   public a(Context var1) {
      Executor var2 = b.g.b.c.h;
      super(var1);
      this.l = -10000L;
      this.h = var2;
   }

   public void a(b.g.b.a.a var1, Object var2) {
      if (this.j == var1) {
         if (super.g) {
            if (super.c) {
               this.b();
            } else {
               super.f = true;
            }
         }

         this.l = SystemClock.uptimeMillis();
         this.j = null;
         this.e();
      }

   }

   @Deprecated
   public void a(String var1, FileDescriptor var2, PrintWriter var3, String[] var4) {
      super.a(var1, var2, var3, var4);
      if (this.i != null) {
         var3.print(var1);
         var3.print("mTask=");
         var3.print(this.i);
         var3.print(" waiting=");
         var3.println(this.i.k);
      }

      if (this.j != null) {
         var3.print(var1);
         var3.print("mCancellingTask=");
         var3.print(this.j);
         var3.print(" waiting=");
         var3.println(this.j.k);
      }

      if (this.k != 0L) {
         var3.print(var1);
         var3.print("mUpdateThrottle=");
         b.c.d.b.a(this.k, var3, 0);
         var3.print(" mLastLoadCompleteTime=");
         long var5 = this.l;
         long var7 = SystemClock.uptimeMillis();
         if (var5 == 0L) {
            var3.print("--");
         } else {
            b.c.d.b.a(var5 - var7, var3, 0);
         }

         var3.println();
      }

   }

   public boolean a() {
      if (this.i != null) {
         if (!super.c) {
            super.f = true;
         }

         if (this.j != null) {
            if (this.i.k) {
               this.i.k = false;
               this.m.removeCallbacks(this.i);
            }

            this.i = null;
            return false;
         } else if (this.i.k) {
            this.i.k = false;
            this.m.removeCallbacks(this.i);
            this.i = null;
            return false;
         } else {
            b.g.b.a.a var1 = this.i;
            var1.d.set(true);
            boolean var2 = var1.b.cancel(false);
            if (var2) {
               this.j = this.i;
            }

            this.i = null;
            return var2;
         }
      } else {
         return false;
      }
   }

   public void b() {
      this.a();
      this.i = new b.g.b.a.a();
      this.e();
   }

   public void e() {
      if (this.j == null && this.i != null) {
         if (this.i.k) {
            this.i.k = false;
            this.m.removeCallbacks(this.i);
         }

         if (this.k > 0L && SystemClock.uptimeMillis() < this.l + this.k) {
            this.i.k = true;
            this.m.postAtTime(this.i, this.l + this.k);
            return;
         }

         b.g.b.a.a var1 = this.i;
         Executor var2 = this.h;
         if (var1.c != c.f.a) {
            int var3 = var1.c.ordinal();
            if (var3 != 1) {
               if (var3 != 2) {
                  throw new IllegalStateException("We should never reach this state");
               }

               throw new IllegalStateException("Cannot execute task: the task has already been executed (a task can be executed only once)");
            }

            throw new IllegalStateException("Cannot execute task: the task is already running.");
         }

         var1.c = c.f.b;
         var1.a.a = null;
         var2.execute(var1.b);
      }

   }

   public Object f() {
      f var1 = (f)this;
      Iterator var2 = var1.o.iterator();
      int var3 = 0;

      while(var2.hasNext()) {
         if (((e)var2.next()).a((m)var1)) {
            ++var3;
         }
      }

      try {
         var1.n.tryAcquire(var3, 5L, TimeUnit.SECONDS);
      } catch (InterruptedException var4) {
         Log.i("GACSignInLoader", "Unexpected InterruptedException", var4);
         Thread.currentThread().interrupt();
      }

      return null;
   }

   public final class a extends c implements Runnable {
      public final CountDownLatch j = new CountDownLatch(1);
      public boolean k;

      public Object a(Object[] var1) {
         Void[] var2 = (Void[])var1;
         a.this.f();
         return null;
      }

      public void run() {
         this.k = false;
         a.this.e();
      }
   }
}
