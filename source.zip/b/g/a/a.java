package b.g.a;

import b.f.h;
import b.f.v;

public abstract class a {
   public static b.g.a.a a(h var0) {
      return new b(var0, ((v)var0).getViewModelStore());
   }

   public interface a {
   }
}
