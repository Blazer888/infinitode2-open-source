package b.g.a;

import android.os.Bundle;
import android.os.Looper;
import androidx.lifecycle.LiveData;
import b.b.g;
import b.f.h;
import b.f.n;
import b.f.o;
import b.f.s;
import b.f.t;
import b.f.u;
import com.google.android.gms.auth.api.signin.internal.SignInHubActivity;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class b extends b.g.a.a {
   public final h a;
   public final b.g.a.b.c b;

   public b(h var1, u var2) {
      this.a = var1;
      t var3 = b.g.a.b.c.c;
      String var5 = b.g.a.b.c.class.getCanonicalName();
      if (var5 != null) {
         String var4 = c.a.b.a.a.a("androidx.lifecycle.ViewModelProvider.DefaultKey:", var5);
         s var6 = (s)var2.a.get(var4);
         if (!b.g.a.b.c.class.isInstance(var6)) {
            s var8 = ((<undefinedtype>)var3).a(b.g.a.b.c.class);
            s var7 = (s)var2.a.put(var4, var8);
            var6 = var8;
            if (var7 != null) {
               var7.a();
               var6 = var8;
            }
         }

         this.b = (b.g.a.b.c)var6;
      } else {
         throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
      }
   }

   public String toString() {
      StringBuilder var1 = new StringBuilder(128);
      var1.append("LoaderManager{");
      var1.append(Integer.toHexString(System.identityHashCode(this)));
      var1.append(" in ");
      b.c.b.b.a((Object)this.a, (StringBuilder)var1);
      var1.append("}}");
      return var1.toString();
   }

   public static class a extends n implements b.g.b.b.a {
      public final int k;
      public final Bundle l;
      public final b.g.b.b m;
      public h n;
      public b.g.a.b.b o;
      public b.g.b.b p;

      public a(int var1, Bundle var2, b.g.b.b var3, b.g.b.b var4) {
         this.k = var1;
         this.l = var2;
         this.m = var3;
         this.p = var4;
         b.g.b.b var5 = this.m;
         if (var5.b == null) {
            var5.b = this;
            var5.a = var1;
         } else {
            throw new IllegalStateException("There is already a listener registered");
         }
      }

      public b.g.b.b a(h var1, b.g.a.a.a var2) {
         b.g.a.b.b var4 = new b.g.a.b.b(this.m, var2);
         this.a(var1, var4);
         b.g.a.b.b var3 = this.o;
         if (var3 != null) {
            this.a(var3);
         }

         this.n = var1;
         this.o = var4;
         return this.m;
      }

      public b.g.b.b a(boolean var1) {
         this.m.a();
         this.m.d = true;
         b.g.a.b.b var2 = this.o;
         if (var2 != null) {
            super.a((o)var2);
            this.n = null;
            this.o = null;
            if (var1 && var2.c) {
               b.g.a.a.a var3 = var2.b;
               b.g.b.b var4 = var2.a;
               ((SignInHubActivity.a)var3).a(var4);
            }
         }

         b.g.b.b var6 = this.m;
         b.g.b.b.a var7 = var6.b;
         if (var7 != null) {
            if (var7 != this) {
               throw new IllegalArgumentException("Attempting to unregister the wrong listener");
            } else {
               var6.b = null;
               if ((var2 == null || var2.c) && !var1) {
                  return this.m;
               } else {
                  b.g.b.b var5 = this.m;
                  var5.e = true;
                  var5.c = false;
                  var5.d = false;
                  var5.f = false;
                  var5.g = false;
                  return this.p;
               }
            }
         } else {
            throw new IllegalStateException("No listener register");
         }
      }

      public void a() {
         b.g.b.b var1 = this.m;
         var1.c = true;
         var1.e = false;
         var1.d = false;
         var1.c();
      }

      public void a(o var1) {
         super.a(var1);
         this.n = null;
         this.o = null;
      }

      public void a(b.g.b.b var1, Object var2) {
         if (Looper.myLooper() == Looper.getMainLooper()) {
            super.b(var2);
            var1 = this.p;
            if (var1 != null) {
               var1.d();
               this.p = null;
            }
         } else {
            this.a(var2);
         }

      }

      public void b() {
         this.m.c = false;
      }

      public void b(Object var1) {
         super.b(var1);
         b.g.b.b var2 = this.p;
         if (var2 != null) {
            var2.e = true;
            var2.c = false;
            var2.d = false;
            var2.f = false;
            var2.g = false;
            this.p = null;
         }

      }

      public void c() {
         h var1 = this.n;
         b.g.a.b.b var2 = this.o;
         if (var1 != null && var2 != null) {
            super.a((o)var2);
            this.a(var1, var2);
         }

      }

      public String toString() {
         StringBuilder var1 = new StringBuilder(64);
         var1.append("LoaderInfo{");
         var1.append(Integer.toHexString(System.identityHashCode(this)));
         var1.append(" #");
         var1.append(this.k);
         var1.append(" : ");
         b.c.b.b.a((Object)this.m, (StringBuilder)var1);
         var1.append("}}");
         return var1.toString();
      }
   }

   public static class b implements o {
      public final b.g.b.b a;
      public final b.g.a.a.a b;
      public boolean c = false;

      public b(b.g.b.b var1, b.g.a.a.a var2) {
         this.a = var1;
         this.b = var2;
      }

      public void a(String var1, PrintWriter var2) {
         var2.print(var1);
         var2.print("mDeliveredData=");
         var2.println(this.c);
      }

      public String toString() {
         return this.b.toString();
      }
   }

   public static class c extends s {
      public static final t c = new t() {
         public s a(Class var1) {
            return new b.g.a.b.c();
         }
      };
      public g a = new g(10);
      public boolean b = false;

      public b.g.a.b.a a(int var1) {
         return (b.g.a.b.a)this.a.a(var1);
      }

      public void a() {
         int var1 = this.a.c();

         int var2;
         for(var2 = 0; var2 < var1; ++var2) {
            ((b.g.a.b.a)this.a.d(var2)).a(true);
         }

         g var3 = this.a;
         var1 = var3.d;
         Object[] var4 = var3.c;

         for(var2 = 0; var2 < var1; ++var2) {
            var4[var2] = null;
         }

         var3.d = 0;
         var3.a = false;
      }

      public void a(int var1, b.g.a.b.a var2) {
         this.a.a(var1, var2);
      }

      public void a(String var1, FileDescriptor var2, PrintWriter var3, String[] var4) {
         if (this.a.c() > 0) {
            var3.print(var1);
            var3.println("Loaders:");
            StringBuilder var5 = new StringBuilder();
            var5.append(var1);
            var5.append("    ");
            String var6 = var5.toString();

            for(int var7 = 0; var7 < this.a.c(); ++var7) {
               b.g.a.b.a var8 = (b.g.a.b.a)this.a.d(var7);
               var3.print(var1);
               var3.print("  #");
               var3.print(this.a.b(var7));
               var3.print(": ");
               var3.println(var8.toString());
               var3.print(var6);
               var3.print("mId=");
               var3.print(var8.k);
               var3.print(" mArgs=");
               var3.println(var8.l);
               var3.print(var6);
               var3.print("mLoader=");
               var3.println(var8.m);
               var8.m.a(c.a.b.a.a.a(var6, "  "), var2, var3, var4);
               if (var8.o != null) {
                  var3.print(var6);
                  var3.print("mCallbacks=");
                  var3.println(var8.o);
                  b.g.a.b.b var11 = var8.o;
                  StringBuilder var9 = new StringBuilder();
                  var9.append(var6);
                  var9.append("  ");
                  var11.a(var9.toString(), var3);
               }

               var3.print(var6);
               var3.print("mData=");
               b.g.b.b var13 = var8.m;
               Object var12 = var8.d;
               if (var12 == LiveData.j) {
                  var12 = null;
               }

               var3.println(var13.a(var12));
               var3.print(var6);
               var3.print("mStarted=");
               boolean var10;
               if (var8.c > 0) {
                  var10 = true;
               } else {
                  var10 = false;
               }

               var3.println(var10);
            }
         }

      }

      public void b() {
         this.b = false;
      }

      public boolean c() {
         return this.b;
      }

      public void d() {
         int var1 = this.a.c();

         for(int var2 = 0; var2 < var1; ++var2) {
            ((b.g.a.b.a)this.a.d(var2)).c();
         }

      }

      public void e() {
         this.b = true;
      }
   }
}
