package b.j.a;

public interface e {
   String a();

   void a(d var1);
}
