package b.j.a;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build.VERSION;
import android.util.Log;
import java.io.Closeable;
import java.io.File;

public interface c extends Closeable {
   void close();

   String getDatabaseName();

   b.j.a.b getWritableDatabase();

   void setWriteAheadLoggingEnabled(boolean var1);

   public abstract static class a {
      public final int a;

      public a(int var1) {
         this.a = var1;
      }

      public void a(b.j.a.b var1) {
      }

      public abstract void a(b.j.a.b var1, int var2, int var3);

      public final void a(String var1) {
         if (!var1.equalsIgnoreCase(":memory:") && var1.trim().length() != 0) {
            StringBuilder var2 = new StringBuilder();
            var2.append("deleting the database file: ");
            var2.append(var1);
            Log.w("SupportSQLite", var2.toString());

            try {
               int var3 = VERSION.SDK_INT;
               File var5 = new File(var1);
               SQLiteDatabase.deleteDatabase(var5);
            } catch (Exception var4) {
               Log.w("SupportSQLite", "delete failed: ", var4);
            }
         }

      }

      public void b(b.j.a.b param1) {
         // $FF: Couldn't be decompiled
      }

      public abstract void c(b.j.a.b var1);

      public void d(b.j.a.b var1) {
      }
   }

   public static class b {
      public final Context a;
      public final String b;
      public final b.j.a.c.a c;
      public final boolean d;

      public b(Context var1, String var2, b.j.a.c.a var3, boolean var4) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
      }
   }

   public interface c {
      b.j.a.c a(b.j.a.c.b var1);
   }
}
