package b.j.a;

import java.io.Closeable;

public interface b extends Closeable {
}
