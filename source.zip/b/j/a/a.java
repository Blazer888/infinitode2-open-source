package b.j.a;

public final class a implements e {
   public final String a;
   public final Object[] b;

   public a(String var1) {
      this.a = var1;
      this.b = null;
   }

   public String a() {
      return this.a;
   }

   public void a(d var1) {
      Object[] var2 = this.b;
      if (var2 != null) {
         int var3 = var2.length;
         int var4 = 0;

         while(var4 < var3) {
            Object var5 = var2[var4];
            ++var4;
            if (var5 == null) {
               var1.b(var4);
            } else if (var5 instanceof byte[]) {
               var1.a(var4, (byte[])var5);
            } else if (var5 instanceof Float) {
               var1.a(var4, (double)(Float)var5);
            } else if (var5 instanceof Double) {
               var1.a(var4, (Double)var5);
            } else if (var5 instanceof Long) {
               var1.a(var4, (Long)var5);
            } else if (var5 instanceof Integer) {
               var1.a(var4, (long)(Integer)var5);
            } else if (var5 instanceof Short) {
               var1.a(var4, (long)(Short)var5);
            } else if (var5 instanceof Byte) {
               var1.a(var4, (long)(Byte)var5);
            } else if (var5 instanceof String) {
               var1.a(var4, (String)var5);
            } else {
               if (!(var5 instanceof Boolean)) {
                  StringBuilder var8 = new StringBuilder();
                  var8.append("Cannot bind ");
                  var8.append(var5);
                  var8.append(" at index ");
                  var8.append(var4);
                  var8.append(" Supported types: null, byte[], float, double, long, int, short, byte, string");
                  throw new IllegalArgumentException(var8.toString());
               }

               long var6;
               if ((Boolean)var5) {
                  var6 = 1L;
               } else {
                  var6 = 0L;
               }

               var1.a(var4, var6);
            }
         }
      }

   }
}
