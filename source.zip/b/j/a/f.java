package b.j.a;

public interface f extends d {
}
