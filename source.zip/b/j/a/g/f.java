package b.j.a.g;

import android.database.sqlite.SQLiteStatement;

public class f extends e implements b.j.a.f {
   public final SQLiteStatement b;

   public f(SQLiteStatement var1) {
      super(var1);
      this.b = var1;
   }

   public int a() {
      return this.b.executeUpdateDelete();
   }
}
