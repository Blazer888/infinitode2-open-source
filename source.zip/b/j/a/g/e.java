package b.j.a.g;

import android.database.sqlite.SQLiteProgram;

public class e implements b.j.a.d {
   public final SQLiteProgram a;

   public e(SQLiteProgram var1) {
      this.a = var1;
   }

   public void a(int var1, double var2) {
      this.a.bindDouble(var1, var2);
   }

   public void a(int var1, long var2) {
      this.a.bindLong(var1, var2);
   }

   public void a(int var1, String var2) {
      this.a.bindString(var1, var2);
   }

   public void a(int var1, byte[] var2) {
      this.a.bindBlob(var1, var2);
   }

   public void b(int var1) {
      this.a.bindNull(var1);
   }

   public void close() {
      this.a.close();
   }
}
