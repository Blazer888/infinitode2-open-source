package b.j.a.g;

import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteCursorDriver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQuery;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

public class b implements CursorFactory {
   // $FF: synthetic field
   public final b.j.a.e a;

   public b(a var1, b.j.a.e var2) {
      this.a = var2;
   }

   public Cursor newCursor(SQLiteDatabase var1, SQLiteCursorDriver var2, String var3, SQLiteQuery var4) {
      this.a.a(new e(var4));
      return new SQLiteCursor(var2, var3, var4);
   }
}
