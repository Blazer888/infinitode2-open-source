package b.j.a.g;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.os.Build.VERSION;
import b.i.h;
import java.io.File;

public class c implements b.j.a.c {
   public final Context a;
   public final String b;
   public final b.j.a.c.a c;
   public final boolean d;
   public final Object e;
   public b.j.a.g.c.a f;
   public boolean g;

   public c(Context var1, String var2, b.j.a.c.a var3, boolean var4) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = new Object();
   }

   public final b.j.a.g.c.a a() {
      Object var1 = this.e;
      synchronized(var1){}

      Throwable var10000;
      boolean var10001;
      label312: {
         label317: {
            label309: {
               b.j.a.g.a[] var2;
               try {
                  if (this.f != null) {
                     break label317;
                  }

                  var2 = new b.j.a.g.a[1];
                  if (VERSION.SDK_INT >= 23 && this.b != null && this.d) {
                     File var38 = new File(this.a.getNoBackupFilesDir(), this.b);
                     b.j.a.g.c.a var4 = new b.j.a.g.c.a(this.a, var38.getAbsolutePath(), var2, this.c);
                     this.f = var4;
                     break label309;
                  }
               } catch (Throwable var35) {
                  var10000 = var35;
                  var10001 = false;
                  break label312;
               }

               try {
                  b.j.a.g.c.a var3 = new b.j.a.g.c.a(this.a, this.b, var2, this.c);
                  this.f = var3;
               } catch (Throwable var34) {
                  var10000 = var34;
                  var10001 = false;
                  break label312;
               }
            }

            try {
               int var5 = VERSION.SDK_INT;
               this.f.setWriteAheadLoggingEnabled(this.g);
            } catch (Throwable var33) {
               var10000 = var33;
               var10001 = false;
               break label312;
            }
         }

         label294:
         try {
            b.j.a.g.c.a var37 = this.f;
            return var37;
         } catch (Throwable var32) {
            var10000 = var32;
            var10001 = false;
            break label294;
         }
      }

      while(true) {
         Throwable var36 = var10000;

         try {
            throw var36;
         } catch (Throwable var31) {
            var10000 = var31;
            var10001 = false;
            continue;
         }
      }
   }

   public void close() {
      this.a().close();
   }

   public String getDatabaseName() {
      return this.b;
   }

   public b.j.a.b getWritableDatabase() {
      return this.a().a();
   }

   public void setWriteAheadLoggingEnabled(boolean var1) {
      Object var2 = this.e;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label122: {
         try {
            if (this.f != null) {
               this.f.setWriteAheadLoggingEnabled(var1);
            }
         } catch (Throwable var15) {
            var10000 = var15;
            var10001 = false;
            break label122;
         }

         label119:
         try {
            this.g = var1;
            return;
         } catch (Throwable var14) {
            var10000 = var14;
            var10001 = false;
            break label119;
         }
      }

      while(true) {
         Throwable var3 = var10000;

         try {
            throw var3;
         } catch (Throwable var13) {
            var10000 = var13;
            var10001 = false;
            continue;
         }
      }
   }

   public static class a extends SQLiteOpenHelper {
      public final b.j.a.g.a[] a;
      public final b.j.a.c.a b;
      public boolean c;

      public a(Context var1, String var2, final b.j.a.g.a[] var3, final b.j.a.c.a var4) {
         super(var1, var2, (CursorFactory)null, var4.a, new DatabaseErrorHandler() {
            public void onCorruption(SQLiteDatabase var1) {
               var4.b(b.j.a.g.c.a.a(var3, var1));
            }
         });
         this.b = var4;
         this.a = var3;
      }

      public static b.j.a.g.a a(b.j.a.g.a[] var0, SQLiteDatabase var1) {
         b.j.a.g.a var2 = var0[0];
         if (var2 != null) {
            boolean var3;
            if (var2.a == var1) {
               var3 = true;
            } else {
               var3 = false;
            }

            if (var3) {
               return var0[0];
            }
         }

         var0[0] = new b.j.a.g.a(var1);
         return var0[0];
      }

      public b.j.a.b a() {
         synchronized(this){}

         b.j.a.g.a var4;
         try {
            this.c = false;
            SQLiteDatabase var1 = super.getWritableDatabase();
            if (this.c) {
               this.close();
               b.j.a.b var5 = this.a();
               return var5;
            }

            var4 = this.a(var1);
         } finally {
            ;
         }

         return var4;
      }

      public b.j.a.g.a a(SQLiteDatabase var1) {
         return a(this.a, var1);
      }

      public void close() {
         synchronized(this){}

         try {
            super.close();
            this.a[0] = null;
         } finally {
            ;
         }

      }

      public void onConfigure(SQLiteDatabase var1) {
         this.b.a((b.j.a.b)a(this.a, var1));
      }

      public void onCreate(SQLiteDatabase var1) {
         this.b.c(a(this.a, var1));
      }

      public void onDowngrade(SQLiteDatabase var1, int var2, int var3) {
         this.c = true;
         b.j.a.c.a var4 = this.b;
         b.j.a.g.a var5 = a(this.a, var1);
         ((h)var4).a(var5, var2, var3);
      }

      public void onOpen(SQLiteDatabase var1) {
         if (!this.c) {
            this.b.d(a(this.a, var1));
         }

      }

      public void onUpgrade(SQLiteDatabase var1, int var2, int var3) {
         this.c = true;
         this.b.a(a(this.a, var1), var2, var3);
      }
   }
}
