package b.j.a.g;

public final class d implements b.j.a.c.c {
   public b.j.a.c a(b.j.a.c.b var1) {
      return new c(var1.a, var1.b, var1.c, var1.d);
   }
}
