package b.j.a.g;

import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteCursorDriver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQuery;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

public class a implements b.j.a.b {
   public static final String[] b = new String[0];
   public final SQLiteDatabase a;

   public a(SQLiteDatabase var1) {
      this.a = var1;
   }

   public Cursor a(final b.j.a.e var1) {
      return this.a.rawQueryWithFactory(new CursorFactory(this) {
         public Cursor newCursor(SQLiteDatabase var1x, SQLiteCursorDriver var2, String var3, SQLiteQuery var4) {
            var1.a(new e(var4));
            return new SQLiteCursor(var2, var3, var4);
         }
      }, var1.a(), b, (String)null);
   }

   public Cursor a(String var1) {
      return this.a((b.j.a.e)(new b.j.a.a(var1)));
   }

   public String a() {
      return this.a.getPath();
   }

   public void close() {
      this.a.close();
   }
}
