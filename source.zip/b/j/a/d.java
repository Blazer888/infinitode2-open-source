package b.j.a;

import java.io.Closeable;

public interface d extends Closeable {
   void a(int var1, double var2);

   void a(int var1, long var2);

   void a(int var1, String var2);

   void a(int var1, byte[] var2);

   void b(int var1);
}
