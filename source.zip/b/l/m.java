package b.l;

public enum m {
   a,
   b,
   c,
   d,
   e;
}
