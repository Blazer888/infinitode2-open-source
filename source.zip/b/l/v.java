package b.l;

import android.content.Context;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;

public abstract class v {
   public static final String a = l.a("WorkerFactory");

   public static v a() {
      return new v() {
      };
   }

   public final ListenableWorker a(Context var1, String var2, WorkerParameters var3) {
      <undefinedtype> var4 = (<undefinedtype>)this;

      Class var8;
      try {
         var8 = Class.forName(var2).asSubclass(ListenableWorker.class);
      } catch (ClassNotFoundException var5) {
         l.a().b(a, c.a.b.a.a.a("Class not found: ", var2));
         var8 = null;
      }

      ListenableWorker var7;
      label30: {
         if (var8 != null) {
            try {
               var7 = (ListenableWorker)var8.getDeclaredConstructor(Context.class, WorkerParameters.class).newInstance(var1, var3);
               break label30;
            } catch (Exception var6) {
               l.a().b(a, c.a.b.a.a.a("Could not instantiate ", var2), var6);
            }
         }

         var7 = null;
      }

      if (var7 != null && var7.isUsed()) {
         throw new IllegalStateException(String.format("WorkerFactory (%s) returned an instance of a ListenableWorker (%s) which has already been invoked. createWorker() must always return a new instance of a ListenableWorker.", this.getClass().getName(), var2));
      } else {
         return var7;
      }
   }
}
