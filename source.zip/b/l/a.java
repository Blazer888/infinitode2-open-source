package b.l;

public enum a {
   a,
   b;
}
