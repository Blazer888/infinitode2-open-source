package b.l;

import java.util.List;

public abstract class i {
   public static final String a = l.a("InputMerger");

   public static i a(String var0) {
      try {
         i var1 = (i)Class.forName(var0).newInstance();
         return var1;
      } catch (Exception var2) {
         l.a().b(a, c.a.b.a.a.a("Trouble instantiating + ", var0), var2);
         return null;
      }
   }

   public abstract e a(List var1);
}
