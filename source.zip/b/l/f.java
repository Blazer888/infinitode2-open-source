package b.l;

public enum f {
   a,
   b,
   c;
}
