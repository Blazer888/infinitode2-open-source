package b.l;

public interface p {
}
