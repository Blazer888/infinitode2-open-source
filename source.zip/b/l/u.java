package b.l;

import android.os.Build.VERSION;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public abstract class u {
   public UUID a;
   public b.l.w.q.p b;
   public Set c;

   public u(UUID var1, b.l.w.q.p var2, Set var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public String a() {
      return this.a.toString();
   }

   public abstract static class a {
      public boolean a = false;
      public UUID b = UUID.randomUUID();
      public b.l.w.q.p c;
      public Set d = new HashSet();

      public a(Class var1) {
         this.c = new b.l.w.q.p(this.b.toString(), var1.getName());
         String var2 = var1.getName();
         this.d.add(var2);
         n.a var3 = (n.a)this;
      }

      public final u a() {
         n.a var1 = (n.a)this;
         if (var1.a && VERSION.SDK_INT >= 23 && var1.c.j.c) {
            throw new IllegalArgumentException("Cannot set backoff criteria on an idle mode job");
         } else {
            b.l.w.q.p var2 = var1.c;
            if (var2.q && VERSION.SDK_INT >= 23 && var2.j.c) {
               throw new IllegalArgumentException("Cannot run in foreground with an idle mode constraint");
            } else {
               n var3 = new n(var1);
               this.b = UUID.randomUUID();
               this.c = new b.l.w.q.p(this.c);
               this.c.a = this.b.toString();
               return var3;
            }
         }
      }
   }
}
