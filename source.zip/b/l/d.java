package b.l;

import android.net.Uri;
import java.util.HashSet;
import java.util.Set;

public final class d {
   public final Set a = new HashSet();

   public Set a() {
      return this.a;
   }

   public int b() {
      return this.a.size();
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && d.class == var1.getClass()) {
         d var2 = (d)var1;
         return this.a.equals(var2.a);
      } else {
         return false;
      }
   }

   public int hashCode() {
      return this.a.hashCode();
   }

   public static final class a {
      public final Uri a;
      public final boolean b;

      public a(Uri var1, boolean var2) {
         this.a = var1;
         this.b = var2;
      }

      public Uri a() {
         return this.a;
      }

      public boolean b() {
         return this.b;
      }

      public boolean equals(Object var1) {
         boolean var2 = true;
         if (this == var1) {
            return true;
         } else if (var1 != null && d.a.class == var1.getClass()) {
            d.a var3 = (d.a)var1;
            if (this.b != var3.b || !this.a.equals(var3.a)) {
               var2 = false;
            }

            return var2;
         } else {
            return false;
         }
      }

      public int hashCode() {
         return this.a.hashCode() * 31 + this.b;
      }
   }
}
