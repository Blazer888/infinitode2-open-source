package b.l;

import android.util.Log;

public abstract class l {
   public static l a;

   public static l a() {
      synchronized(l.class){}

      l var3;
      try {
         if (a == null) {
            l.a var0 = new l.a(3);
            a = var0;
         }

         var3 = a;
      } finally {
         ;
      }

      return var3;
   }

   public static String a(String var0) {
      int var1 = var0.length();
      StringBuilder var2 = new StringBuilder(23);
      var2.append("WM-");
      if (var1 >= 20) {
         var2.append(var0.substring(0, 20));
      } else {
         var2.append(var0);
      }

      return var2.toString();
   }

   public static void a(l var0) {
      synchronized(l.class){}

      try {
         a = var0;
      } finally {
         ;
      }

   }

   public abstract void a(String var1, String var2, Throwable... var3);

   public abstract void b(String var1, String var2, Throwable... var3);

   public abstract void c(String var1, String var2, Throwable... var3);

   public abstract void d(String var1, String var2, Throwable... var3);

   public static class a extends l {
      public int b;

      public a(int var1) {
         this.b = var1;
      }

      public void a(String var1, String var2, Throwable... var3) {
         if (this.b <= 3) {
            if (var3 != null && var3.length >= 1) {
               Log.d(var1, var2, var3[0]);
            } else {
               Log.d(var1, var2);
            }
         }

      }

      public void b(String var1, String var2, Throwable... var3) {
         if (this.b <= 6) {
            if (var3 != null && var3.length >= 1) {
               Log.e(var1, var2, var3[0]);
            } else {
               Log.e(var1, var2);
            }
         }

      }

      public void c(String var1, String var2, Throwable... var3) {
         if (this.b <= 4) {
            if (var3 != null && var3.length >= 1) {
               Log.i(var1, var2, var3[0]);
            } else {
               Log.i(var1, var2);
            }
         }

      }

      public void d(String var1, String var2, Throwable... var3) {
         if (this.b <= 5) {
            if (var3 != null && var3.length >= 1) {
               Log.w(var1, var2, var3[0]);
            } else {
               Log.w(var1, var2);
            }
         }

      }
   }
}
