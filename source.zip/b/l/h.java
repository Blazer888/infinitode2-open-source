package b.l;

public interface h {
}
