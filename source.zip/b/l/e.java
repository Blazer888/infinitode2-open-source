package b.l;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public final class e {
   public static final String b = l.a("Data");
   public static final e c;
   public Map a;

   static {
      e var0 = new e(new HashMap());
      a(var0);
      c = var0;
   }

   public e() {
   }

   public e(e var1) {
      this.a = new HashMap(var1.a);
   }

   public e(Map var1) {
      this.a = new HashMap(var1);
   }

   public static byte[] a(e param0) {
      // $FF: Couldn't be decompiled
   }

   public static Boolean[] a(boolean[] var0) {
      Boolean[] var1 = new Boolean[var0.length];

      for(int var2 = 0; var2 < var0.length; ++var2) {
         var1[var2] = var0[var2];
      }

      return var1;
   }

   public static Byte[] a(byte[] var0) {
      Byte[] var1 = new Byte[var0.length];

      for(int var2 = 0; var2 < var0.length; ++var2) {
         var1[var2] = var0[var2];
      }

      return var1;
   }

   public static Double[] a(double[] var0) {
      Double[] var1 = new Double[var0.length];

      for(int var2 = 0; var2 < var0.length; ++var2) {
         var1[var2] = var0[var2];
      }

      return var1;
   }

   public static Float[] a(float[] var0) {
      Float[] var1 = new Float[var0.length];

      for(int var2 = 0; var2 < var0.length; ++var2) {
         var1[var2] = var0[var2];
      }

      return var1;
   }

   public static Integer[] a(int[] var0) {
      Integer[] var1 = new Integer[var0.length];

      for(int var2 = 0; var2 < var0.length; ++var2) {
         var1[var2] = var0[var2];
      }

      return var1;
   }

   public static Long[] a(long[] var0) {
      Long[] var1 = new Long[var0.length];

      for(int var2 = 0; var2 < var0.length; ++var2) {
         var1[var2] = var0[var2];
      }

      return var1;
   }

   public static e b(byte[] param0) {
      // $FF: Couldn't be decompiled
   }

   public String a(String var1) {
      Object var2 = this.a.get(var1);
      return var2 instanceof String ? (String)var2 : null;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && e.class == var1.getClass()) {
         e var6 = (e)var1;
         Set var2 = this.a.keySet();
         if (!var2.equals(var6.a.keySet())) {
            return false;
         } else {
            Iterator var7 = var2.iterator();

            boolean var5;
            do {
               if (!var7.hasNext()) {
                  return true;
               }

               String var3 = (String)var7.next();
               Object var4 = this.a.get(var3);
               Object var8 = var6.a.get(var3);
               if (var4 != null && var8 != null) {
                  if (var4 instanceof Object[] && var8 instanceof Object[]) {
                     var5 = Arrays.deepEquals((Object[])var4, (Object[])var8);
                  } else {
                     var5 = var4.equals(var8);
                  }
               } else if (var4 == var8) {
                  var5 = true;
               } else {
                  var5 = false;
               }
            } while(var5);

            return false;
         }
      } else {
         return false;
      }
   }

   public int hashCode() {
      return this.a.hashCode() * 31;
   }

   public String toString() {
      StringBuilder var1 = new StringBuilder("Data {");
      if (!this.a.isEmpty()) {
         for(Iterator var2 = this.a.keySet().iterator(); var2.hasNext(); var1.append(", ")) {
            String var3 = (String)var2.next();
            var1.append(var3);
            var1.append(" : ");
            Object var4 = this.a.get(var3);
            if (var4 instanceof Object[]) {
               var1.append(Arrays.toString((Object[])var4));
            } else {
               var1.append(var4);
            }
         }
      }

      var1.append("}");
      return var1.toString();
   }

   public static final class a {
      public Map a = new HashMap();

      public e.a a(Map var1) {
         Iterator var5 = var1.entrySet().iterator();

         while(true) {
            while(var5.hasNext()) {
               Entry var2 = (Entry)var5.next();
               String var3 = (String)var2.getKey();
               Object var6 = var2.getValue();
               if (var6 == null) {
                  this.a.put(var3, (Object)null);
               } else {
                  Class var4 = var6.getClass();
                  if (var4 != Boolean.class && var4 != Byte.class && var4 != Integer.class && var4 != Long.class && var4 != Float.class && var4 != Double.class && var4 != String.class && var4 != Boolean[].class && var4 != Byte[].class && var4 != Integer[].class && var4 != Long[].class && var4 != Float[].class && var4 != Double[].class && var4 != String[].class) {
                     if (var4 == boolean[].class) {
                        this.a.put(var3, e.a((boolean[])var6));
                     } else if (var4 == byte[].class) {
                        this.a.put(var3, e.a((byte[])var6));
                     } else if (var4 == int[].class) {
                        this.a.put(var3, e.a((int[])var6));
                     } else if (var4 == long[].class) {
                        this.a.put(var3, e.a((long[])var6));
                     } else if (var4 == float[].class) {
                        this.a.put(var3, e.a((float[])var6));
                     } else {
                        if (var4 != double[].class) {
                           throw new IllegalArgumentException(String.format("Key %s has invalid type %s", var3, var4));
                        }

                        this.a.put(var3, e.a((double[])var6));
                     }
                  } else {
                     this.a.put(var3, var6);
                  }
               }
            }

            return this;
         }
      }

      public e a() {
         e var1 = new e(this.a);
         e.a(var1);
         return var1;
      }
   }
}
