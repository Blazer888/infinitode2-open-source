package b.l;

public abstract class k {
   public final i a(String var1) {
      j var2 = (j)this;
      return i.a(var1);
   }
}
