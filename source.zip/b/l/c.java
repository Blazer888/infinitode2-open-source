package b.l;

import android.os.Build.VERSION;

public final class c {
   public static final c i = (new c.a()).a();
   public m a;
   public boolean b;
   public boolean c;
   public boolean d;
   public boolean e;
   public long f;
   public long g;
   public d h;

   public c() {
      this.a = m.a;
      this.f = -1L;
      this.g = -1L;
      this.h = new d();
   }

   public c(c.a var1) {
      this.a = m.a;
      this.f = -1L;
      this.g = -1L;
      this.h = new d();
      this.b = var1.a;
      boolean var2;
      if (VERSION.SDK_INT >= 23 && var1.b) {
         var2 = true;
      } else {
         var2 = false;
      }

      this.c = var2;
      this.a = var1.c;
      this.d = var1.d;
      this.e = var1.e;
      if (VERSION.SDK_INT >= 24) {
         this.h = var1.h;
         this.f = var1.f;
         this.g = var1.g;
      }

   }

   public c(c var1) {
      this.a = m.a;
      this.f = -1L;
      this.g = -1L;
      this.h = new d();
      this.b = var1.b;
      this.c = var1.c;
      this.a = var1.a;
      this.d = var1.d;
      this.e = var1.e;
      this.h = var1.h;
   }

   public d a() {
      return this.h;
   }

   public long b() {
      return this.f;
   }

   public long c() {
      return this.g;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && c.class == var1.getClass()) {
         c var2 = (c)var1;
         if (this.b != var2.b) {
            return false;
         } else if (this.c != var2.c) {
            return false;
         } else if (this.d != var2.d) {
            return false;
         } else if (this.e != var2.e) {
            return false;
         } else if (this.f != var2.f) {
            return false;
         } else if (this.g != var2.g) {
            return false;
         } else {
            return this.a != var2.a ? false : this.h.equals(var2.h);
         }
      } else {
         return false;
      }
   }

   public int hashCode() {
      int var1 = this.a.hashCode();
      byte var2 = this.b;
      byte var3 = this.c;
      byte var4 = this.d;
      byte var5 = this.e;
      long var6 = this.f;
      int var8 = (int)(var6 ^ var6 >>> 32);
      var6 = this.g;
      int var9 = (int)(var6 ^ var6 >>> 32);
      return this.h.hashCode() + ((((((var1 * 31 + var2) * 31 + var3) * 31 + var4) * 31 + var5) * 31 + var8) * 31 + var9) * 31;
   }

   public static final class a {
      public boolean a = false;
      public boolean b = false;
      public m c;
      public boolean d;
      public boolean e;
      public long f;
      public long g;
      public d h;

      public a() {
         this.c = m.a;
         this.d = false;
         this.e = false;
         this.f = -1L;
         this.g = -1L;
         this.h = new d();
      }

      public c a() {
         return new c(this);
      }
   }
}
