package b.l;

public final class q {
   public static final int enable_system_alarm_service_default = 2130837504;
   public static final int enable_system_foreground_service_default = 2130837505;
   public static final int enable_system_job_service_default = 2130837506;
   public static final int workmanager_test_configuration = 2130837507;
}
