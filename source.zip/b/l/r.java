package b.l;

public abstract class r {
   public abstract o a();
}
