package b.l;

import android.os.Build.VERSION;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public final class b {
   public final Executor a;
   public final Executor b;
   public final v c;
   public final k d;
   public final int e;
   public final int f;
   public final int g;
   public final int h;

   public b(b.l.b.a var1) {
      Executor var2 = var1.a;
      if (var2 == null) {
         this.a = this.a();
      } else {
         this.a = var2;
      }

      var2 = var1.d;
      if (var2 == null) {
         this.b = this.a();
      } else {
         this.b = var2;
      }

      v var3 = var1.b;
      if (var3 == null) {
         this.c = v.a();
      } else {
         this.c = var3;
      }

      k var4 = var1.c;
      if (var4 == null) {
         this.d = new j();
      } else {
         this.d = var4;
      }

      this.e = var1.e;
      this.f = var1.f;
      this.g = var1.g;
      this.h = var1.h;
   }

   public final Executor a() {
      return Executors.newFixedThreadPool(Math.max(2, Math.min(Runtime.getRuntime().availableProcessors() - 1, 4)));
   }

   public int b() {
      return VERSION.SDK_INT == 23 ? this.h / 2 : this.h;
   }

   public v c() {
      return this.c;
   }

   public static final class a {
      public Executor a;
      public v b;
      public k c;
      public Executor d;
      public int e = 4;
      public int f = 0;
      public int g = Integer.MAX_VALUE;
      public int h = 20;
   }

   public interface b {
      b.l.b a();
   }
}
