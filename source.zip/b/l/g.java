package b.l;

import android.app.Notification;

public final class g {
   public final int a;
   public final int b;
   public final Notification c;

   public g(int var1, Notification var2, int var3) {
      this.a = var1;
      this.c = var2;
      this.b = var3;
   }

   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && g.class == var1.getClass()) {
         g var2 = (g)var1;
         if (this.a != var2.a) {
            return false;
         } else {
            return this.b != var2.b ? false : this.c.equals(var2.c);
         }
      } else {
         return false;
      }
   }

   public int hashCode() {
      int var1 = this.a;
      int var2 = this.b;
      return this.c.hashCode() + (var1 * 31 + var2) * 31;
   }

   public String toString() {
      StringBuilder var1 = new StringBuilder("ForegroundInfo{");
      var1.append("mNotificationId=");
      var1.append(this.a);
      var1.append(", mForegroundServiceType=");
      var1.append(this.b);
      var1.append(", mNotification=");
      var1.append(this.c);
      var1.append('}');
      return var1.toString();
   }
}
