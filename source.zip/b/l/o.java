package b.l;

import android.annotation.SuppressLint;

public interface o {
   @SuppressLint({"SyntheticAccessor"})
   o.b.c a = new o.b.c();
   @SuppressLint({"SyntheticAccessor"})
   o.b.b b = new o.b.b();

   public abstract static class b {
      public static final class a extends o.b {
         public final Throwable a;

         public a(Throwable var1) {
            this.a = var1;
         }

         public String toString() {
            return String.format("FAILURE (%s)", this.a.getMessage());
         }
      }

      public static final class b extends o.b {
         // $FF: synthetic method
         public b(Object var1) {
         }

         public String toString() {
            return "IN_PROGRESS";
         }
      }

      public static final class c extends o.b {
         public c() {
         }

         // $FF: synthetic method
         public c(Object var1) {
         }

         public String toString() {
            return "SUCCESS";
         }
      }
   }
}
