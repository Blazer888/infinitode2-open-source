package b.l;

import java.util.Collections;
import java.util.List;

public abstract class t {
   public abstract o a(String var1);

   public final r a(String var1, f var2, n var3) {
      List var5 = Collections.singletonList(var3);
      b.l.w.j var4 = (b.l.w.j)this;
      if (!var5.isEmpty()) {
         return new b.l.w.f(var4, var1, var2, var5);
      } else {
         throw new IllegalArgumentException("beginUniqueWork needs at least one OneTimeWorkRequest.");
      }
   }
}
