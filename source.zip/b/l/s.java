package b.l;

public enum s {
   a,
   b,
   c,
   d,
   e,
   f;

   public boolean a() {
      boolean var1;
      if (this != c && this != d && this != f) {
         var1 = false;
      } else {
         var1 = true;
      }

      return var1;
   }
}
