package b.l;

import androidx.work.OverwritingInputMerger;

public final class n extends u {
   public n(n.a var1) {
      super(var1.b, var1.c, var1.d);
   }

   public static final class a extends u.a {
      public a(Class var1) {
         super(var1);
         super.c.d = OverwritingInputMerger.class.getName();
      }
   }
}
