package b.l.w.o.f;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import b.l.l;

public class b extends c {
   public static final String i = l.a("BatteryNotLowTracker");

   public b(Context var1, b.l.w.r.n.a var2) {
      super(var1, var2);
   }

   public Object a() {
      IntentFilter var1 = new IntentFilter("android.intent.action.BATTERY_CHANGED");
      Context var2 = super.b;
      Boolean var3 = null;
      Intent var11 = var2.registerReceiver((BroadcastReceiver)null, var1);
      if (var11 == null) {
         l.a().b(i, "getInitialState - null intent received");
      } else {
         int var4 = var11.getIntExtra("plugged", 0);
         int var5 = var11.getIntExtra("status", -1);
         int var6 = var11.getIntExtra("level", -1);
         int var7 = var11.getIntExtra("scale", -1);
         float var8 = (float)var6 / (float)var7;
         boolean var9 = true;
         boolean var10 = var9;
         if (var4 == 0) {
            var10 = var9;
            if (var5 != 1) {
               if (var8 > 0.15F) {
                  var10 = var9;
               } else {
                  var10 = false;
               }
            }
         }

         var3 = var10;
      }

      return var3;
   }

   public void a(Context var1, Intent var2) {
      if (var2.getAction() != null) {
         l.a().a(i, String.format("Received %s", var2.getAction()));
         String var5 = var2.getAction();
         byte var3 = -1;
         int var4 = var5.hashCode();
         if (var4 != -1980154005) {
            if (var4 == 490310653 && var5.equals("android.intent.action.BATTERY_LOW")) {
               var3 = 1;
            }
         } else if (var5.equals("android.intent.action.BATTERY_OKAY")) {
            var3 = 0;
         }

         if (var3 != 0) {
            if (var3 == 1) {
               this.a((Object)false);
            }
         } else {
            this.a((Object)true);
         }

      }
   }

   public IntentFilter d() {
      IntentFilter var1 = new IntentFilter();
      var1.addAction("android.intent.action.BATTERY_OKAY");
      var1.addAction("android.intent.action.BATTERY_LOW");
      return var1;
   }
}
