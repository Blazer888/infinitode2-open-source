package b.l.w.o.f;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import b.l.l;

public abstract class c extends d {
   public static final String h = l.a("BrdcstRcvrCnstrntTrckr");
   public final BroadcastReceiver g = new BroadcastReceiver() {
      public void onReceive(Context var1, Intent var2) {
         if (var2 != null) {
            c.this.a(var1, var2);
         }

      }
   };

   public c(Context var1, b.l.w.r.n.a var2) {
      super(var1, var2);
   }

   public abstract void a(Context var1, Intent var2);

   public void b() {
      l.a().a(h, String.format("%s: registering receiver", this.getClass().getSimpleName()));
      super.b.registerReceiver(this.g, this.d());
   }

   public void c() {
      l.a().a(h, String.format("%s: unregistering receiver", this.getClass().getSimpleName()));
      super.b.unregisterReceiver(this.g);
   }

   public abstract IntentFilter d();
}
