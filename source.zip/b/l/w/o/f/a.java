package b.l.w.o.f;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build.VERSION;
import b.l.l;

public class a extends c {
   public static final String i = l.a("BatteryChrgTracker");

   public a(Context var1, b.l.w.r.n.a var2) {
      super(var1, var2);
   }

   public Object a() {
      IntentFilter var1 = new IntentFilter("android.intent.action.BATTERY_CHANGED");
      Context var2 = super.b;
      Boolean var3 = null;
      Intent var6 = var2.registerReceiver((BroadcastReceiver)null, var1);
      boolean var4 = false;
      if (var6 == null) {
         l.a().b(i, "getInitialState - null intent received");
      } else {
         label19: {
            if (VERSION.SDK_INT >= 23) {
               int var5 = var6.getIntExtra("status", -1);
               if (var5 != 2 && var5 != 5) {
                  break label19;
               }
            } else if (var6.getIntExtra("plugged", 0) == 0) {
               break label19;
            }

            var4 = true;
         }

         var3 = var4;
      }

      return var3;
   }

   public void a(Context var1, Intent var2) {
      String var4 = var2.getAction();
      if (var4 != null) {
         l.a().a(i, String.format("Received %s", var4));
         byte var3 = -1;
         switch(var4.hashCode()) {
         case -1886648615:
            if (var4.equals("android.intent.action.ACTION_POWER_DISCONNECTED")) {
               var3 = 3;
            }
            break;
         case -54942926:
            if (var4.equals("android.os.action.DISCHARGING")) {
               var3 = 1;
            }
            break;
         case 948344062:
            if (var4.equals("android.os.action.CHARGING")) {
               var3 = 0;
            }
            break;
         case 1019184907:
            if (var4.equals("android.intent.action.ACTION_POWER_CONNECTED")) {
               var3 = 2;
            }
         }

         if (var3 != 0) {
            if (var3 != 1) {
               if (var3 != 2) {
                  if (var3 == 3) {
                     this.a((Object)false);
                  }
               } else {
                  this.a((Object)true);
               }
            } else {
               this.a((Object)false);
            }
         } else {
            this.a((Object)true);
         }

      }
   }

   public IntentFilter d() {
      IntentFilter var1 = new IntentFilter();
      if (VERSION.SDK_INT >= 23) {
         var1.addAction("android.os.action.CHARGING");
         var1.addAction("android.os.action.DISCHARGING");
      } else {
         var1.addAction("android.intent.action.ACTION_POWER_CONNECTED");
         var1.addAction("android.intent.action.ACTION_POWER_DISCONNECTED");
      }

      return var1;
   }
}
