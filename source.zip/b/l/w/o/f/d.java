package b.l.w.o.f;

import android.content.Context;
import b.l.l;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.Executor;

public abstract class d {
   public static final String f = l.a("ConstraintTracker");
   public final b.l.w.r.n.a a;
   public final Context b;
   public final Object c = new Object();
   public final Set d = new LinkedHashSet();
   public Object e;

   public d(Context var1, b.l.w.r.n.a var2) {
      this.b = var1.getApplicationContext();
      this.a = var2;
   }

   public abstract Object a();

   public void a(b.l.w.o.a var1) {
      Object var2 = this.c;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label278: {
         label282: {
            try {
               if (!this.d.add(var1)) {
                  break label282;
               }

               if (this.d.size() == 1) {
                  this.e = this.a();
                  l.a().a(f, String.format("%s: initial state = %s", this.getClass().getSimpleName(), this.e));
                  this.b();
               }
            } catch (Throwable var33) {
               var10000 = var33;
               var10001 = false;
               break label278;
            }

            Object var3;
            try {
               var3 = this.e;
            } catch (Throwable var32) {
               var10000 = var32;
               var10001 = false;
               break label278;
            }

            b.l.w.o.e.c var34 = (b.l.w.o.e.c)var1;

            try {
               var34.b = var3;
               var34.a(var34.d, var34.b);
            } catch (Throwable var31) {
               var10000 = var31;
               var10001 = false;
               break label278;
            }
         }

         label267:
         try {
            return;
         } catch (Throwable var30) {
            var10000 = var30;
            var10001 = false;
            break label267;
         }
      }

      while(true) {
         Throwable var35 = var10000;

         try {
            throw var35;
         } catch (Throwable var29) {
            var10000 = var29;
            var10001 = false;
            continue;
         }
      }
   }

   public void a(Object var1) {
      Object var2 = this.c;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label218: {
         label223: {
            try {
               if (this.e != var1 && (this.e == null || !this.e.equals(var1))) {
                  break label223;
               }
            } catch (Throwable var24) {
               var10000 = var24;
               var10001 = false;
               break label218;
            }

            try {
               return;
            } catch (Throwable var23) {
               var10000 = var23;
               var10001 = false;
               break label218;
            }
         }

         label204:
         try {
            this.e = var1;
            final ArrayList var3 = new ArrayList(this.d);
            Executor var26 = ((b.l.w.r.n.b)this.a).c;
            Runnable var4 = new Runnable() {
               public void run() {
                  Iterator var1 = var3.iterator();

                  while(var1.hasNext()) {
                     Object var2 = var1.next();
                     Object var3x = d.this.e;
                     b.l.w.o.e.c var4 = (b.l.w.o.e.c)var2;
                     var4.b = var3x;
                     var4.a(var4.d, var4.b);
                  }

               }
            };
            var26.execute(var4);
            return;
         } catch (Throwable var22) {
            var10000 = var22;
            var10001 = false;
            break label204;
         }
      }

      while(true) {
         Throwable var25 = var10000;

         try {
            throw var25;
         } catch (Throwable var21) {
            var10000 = var21;
            var10001 = false;
            continue;
         }
      }
   }

   public abstract void b();

   public void b(b.l.w.o.a var1) {
      Object var2 = this.c;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label130: {
         try {
            if (this.d.remove(var1) && this.d.isEmpty()) {
               this.c();
            }
         } catch (Throwable var14) {
            var10000 = var14;
            var10001 = false;
            break label130;
         }

         label127:
         try {
            return;
         } catch (Throwable var13) {
            var10000 = var13;
            var10001 = false;
            break label127;
         }
      }

      while(true) {
         Throwable var15 = var10000;

         try {
            throw var15;
         } catch (Throwable var12) {
            var10000 = var12;
            var10001 = false;
            continue;
         }
      }
   }

   public abstract void c();
}
