package b.l.w.o.f;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.ConnectivityManager.NetworkCallback;
import android.os.Build.VERSION;
import b.l.l;

public class e extends d {
   public static final String j = l.a("NetworkStateTracker");
   public final ConnectivityManager g;
   public e.b h;
   public e.a i;

   public e(Context var1, b.l.w.r.n.a var2) {
      super(var1, var2);
      this.g = (ConnectivityManager)super.b.getSystemService("connectivity");
      if (e()) {
         this.h = new e.b();
      } else {
         this.i = new e.a();
      }

   }

   public static boolean e() {
      boolean var0;
      if (VERSION.SDK_INT >= 24) {
         var0 = true;
      } else {
         var0 = false;
      }

      return var0;
   }

   public Object a() {
      return this.d();
   }

   public void b() {
      if (e()) {
         try {
            l.a().a(j, "Registering network callback");
            this.g.registerDefaultNetworkCallback(this.h);
         } catch (IllegalArgumentException var2) {
            l.a().b(j, "Received exception while unregistering network callback", var2);
         }
      } else {
         l.a().a(j, "Registering broadcast receiver");
         super.b.registerReceiver(this.i, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
      }

   }

   public void c() {
      if (e()) {
         try {
            l.a().a(j, "Unregistering network callback");
            this.g.unregisterNetworkCallback(this.h);
         } catch (IllegalArgumentException var2) {
            l.a().b(j, "Received exception while unregistering network callback", var2);
         }
      } else {
         l.a().a(j, "Unregistering broadcast receiver");
         super.b.unregisterReceiver(this.i);
      }

   }

   public b.l.w.o.b d() {
      NetworkInfo var1 = this.g.getActiveNetworkInfo();
      boolean var2 = true;
      boolean var3;
      if (var1 != null && var1.isConnected()) {
         var3 = true;
      } else {
         var3 = false;
      }

      boolean var5;
      label28: {
         if (VERSION.SDK_INT >= 23) {
            Network var4 = this.g.getActiveNetwork();
            NetworkCapabilities var8 = this.g.getNetworkCapabilities(var4);
            if (var8 != null && var8.hasCapability(16)) {
               var5 = true;
               break label28;
            }
         }

         var5 = false;
      }

      ConnectivityManager var9 = this.g;
      int var6 = VERSION.SDK_INT;
      boolean var7 = var9.isActiveNetworkMetered();
      if (var1 == null || var1.isRoaming()) {
         var2 = false;
      }

      return new b.l.w.o.b(var3, var5, var7, var2);
   }

   public class a extends BroadcastReceiver {
      public void onReceive(Context var1, Intent var2) {
         if (var2 != null && var2.getAction() != null && var2.getAction().equals("android.net.conn.CONNECTIVITY_CHANGE")) {
            l.a().a(b.l.w.o.f.e.j, "Network broadcast received");
            e var3 = e.this;
            var3.a((Object)var3.d());
         }

      }
   }

   public class b extends NetworkCallback {
      public void onCapabilitiesChanged(Network var1, NetworkCapabilities var2) {
         l.a().a(b.l.w.o.f.e.j, String.format("Network capabilities changed: %s", var2));
         e var3 = e.this;
         var3.a((Object)var3.d());
      }

      public void onLost(Network var1) {
         l.a().a(b.l.w.o.f.e.j, "Network connection lost");
         e var2 = e.this;
         var2.a((Object)var2.d());
      }
   }
}
