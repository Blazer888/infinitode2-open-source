package b.l.w.o.f;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import b.l.l;

public class f extends c {
   public static final String i = l.a("StorageNotLowTracker");

   public f(Context var1, b.l.w.r.n.a var2) {
      super(var1, var2);
   }

   public Object a() {
      Context var1 = super.b;
      IntentFilter var2 = this.d();
      Boolean var3 = null;
      Intent var6 = var1.registerReceiver((BroadcastReceiver)null, var2);
      if (var6 != null && var6.getAction() != null) {
         String var7 = var6.getAction();
         byte var4 = -1;
         int var5 = var7.hashCode();
         if (var5 != -1181163412) {
            if (var5 == -730838620 && var7.equals("android.intent.action.DEVICE_STORAGE_OK")) {
               var4 = 0;
            }
         } else if (var7.equals("android.intent.action.DEVICE_STORAGE_LOW")) {
            var4 = 1;
         }

         if (var4 != 0) {
            if (var4 == 1) {
               var3 = false;
            }

            return var3;
         }
      }

      var3 = true;
      return var3;
   }

   public void a(Context var1, Intent var2) {
      if (var2.getAction() != null) {
         l.a().a(i, String.format("Received %s", var2.getAction()));
         String var5 = var2.getAction();
         byte var3 = -1;
         int var4 = var5.hashCode();
         if (var4 != -1181163412) {
            if (var4 == -730838620 && var5.equals("android.intent.action.DEVICE_STORAGE_OK")) {
               var3 = 0;
            }
         } else if (var5.equals("android.intent.action.DEVICE_STORAGE_LOW")) {
            var3 = 1;
         }

         if (var3 != 0) {
            if (var3 == 1) {
               this.a((Object)false);
            }
         } else {
            this.a((Object)true);
         }

      }
   }

   public IntentFilter d() {
      IntentFilter var1 = new IntentFilter();
      var1.addAction("android.intent.action.DEVICE_STORAGE_OK");
      var1.addAction("android.intent.action.DEVICE_STORAGE_LOW");
      return var1;
   }
}
