package b.l.w.o.f;

import android.content.Context;

public class g {
   public static g e;
   public a a;
   public b b;
   public e c;
   public f d;

   public g(Context var1, b.l.w.r.n.a var2) {
      var1 = var1.getApplicationContext();
      this.a = new a(var1, var2);
      this.b = new b(var1, var2);
      this.c = new e(var1, var2);
      this.d = new f(var1, var2);
   }

   public static g a(Context var0, b.l.w.r.n.a var1) {
      synchronized(g.class){}

      g var5;
      try {
         if (e == null) {
            g var2 = new g(var0, var1);
            e = var2;
         }

         var5 = e;
      } finally {
         ;
      }

      return var5;
   }
}
