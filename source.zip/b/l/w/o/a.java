package b.l.w.o;

public interface a {
}
