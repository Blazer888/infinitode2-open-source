package b.l.w.o.e;

import android.content.Context;
import b.l.w.q.p;

public class a extends c {
   public a(Context var1, b.l.w.r.n.a var2) {
      super(b.l.w.o.f.g.a(var1, var2).a);
   }

   public boolean a(p var1) {
      return var1.j.b;
   }

   public boolean a(Object var1) {
      return (Boolean)var1 ^ true;
   }
}
