package b.l.w.o.e;

import android.content.Context;
import b.l.m;
import b.l.w.q.p;

public class g extends c {
   public g(Context var1, b.l.w.r.n.a var2) {
      super(b.l.w.o.f.g.a(var1, var2).c);
   }

   public boolean a(p var1) {
      boolean var2;
      if (var1.j.a == m.c) {
         var2 = true;
      } else {
         var2 = false;
      }

      return var2;
   }

   public boolean a(Object var1) {
      b.l.w.o.b var3 = (b.l.w.o.b)var1;
      boolean var2;
      if (var3.a && !var3.a()) {
         var2 = false;
      } else {
         var2 = true;
      }

      return var2;
   }
}
