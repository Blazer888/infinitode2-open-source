package b.l.w.o.e;

import android.content.Context;
import android.os.Build.VERSION;
import b.l.m;
import b.l.w.q.p;

public class d extends c {
   public d(Context var1, b.l.w.r.n.a var2) {
      super(b.l.w.o.f.g.a(var1, var2).c);
   }

   public boolean a(p var1) {
      boolean var2;
      if (var1.j.a == m.b) {
         var2 = true;
      } else {
         var2 = false;
      }

      return var2;
   }

   public boolean a(Object var1) {
      b.l.w.o.b var5 = (b.l.w.o.b)var1;
      int var2 = VERSION.SDK_INT;
      boolean var3 = true;
      boolean var4;
      if (var2 >= 26) {
         var4 = var3;
         if (var5.a) {
            if (!var5.b) {
               var4 = var3;
            } else {
               var4 = false;
            }
         }
      } else {
         var4 = true ^ var5.a;
      }

      return var4;
   }
}
