package b.l.w.o.e;

import android.content.Context;
import android.os.Build.VERSION;
import b.l.l;
import b.l.m;
import b.l.w.q.p;

public class e extends c {
   public static final String e = l.a("NetworkMeteredCtrlr");

   public e(Context var1, b.l.w.r.n.a var2) {
      super(b.l.w.o.f.g.a(var1, var2).c);
   }

   public boolean a(p var1) {
      boolean var2;
      if (var1.j.a == m.e) {
         var2 = true;
      } else {
         var2 = false;
      }

      return var2;
   }

   public boolean a(Object var1) {
      b.l.w.o.b var3 = (b.l.w.o.b)var1;
      boolean var2;
      if (VERSION.SDK_INT < 26) {
         l.a().a(e, "Metered network constraint is not supported before API 26, only checking for connected state.");
         var2 = var3.a ^ true;
      } else if (var3.a && var3.a()) {
         var2 = false;
      } else {
         var2 = true;
      }

      return var2;
   }
}
