package b.l.w.o.e;

import b.l.w.q.p;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class c implements b.l.w.o.a {
   public final List a = new ArrayList();
   public Object b;
   public b.l.w.o.f.d c;
   public c.a d;

   public c(b.l.w.o.f.d var1) {
      this.c = var1;
   }

   public final void a(c.a var1, Object var2) {
      if (!this.a.isEmpty() && var1 != null) {
         List var3;
         if (var2 != null && !this.a(var2)) {
            var3 = this.a;
            ((b.l.w.o.d)var1).a(var3);
         } else {
            var3 = this.a;
            ((b.l.w.o.d)var1).b(var3);
         }
      }

   }

   public void a(Iterable var1) {
      this.a.clear();
      Iterator var2 = var1.iterator();

      while(var2.hasNext()) {
         p var3 = (p)var2.next();
         if (this.a(var3)) {
            this.a.add(var3.a);
         }
      }

      if (this.a.isEmpty()) {
         this.c.b(this);
      } else {
         this.c.a((b.l.w.o.a)this);
      }

      this.a(this.d, this.b);
   }

   public abstract boolean a(p var1);

   public abstract boolean a(Object var1);

   public interface a {
   }
}
