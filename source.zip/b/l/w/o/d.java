package b.l.w.o;

import android.content.Context;
import b.l.l;
import b.l.w.o.e.e;
import b.l.w.o.e.f;
import b.l.w.o.e.g;
import b.l.w.o.e.h;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class d implements b.l.w.o.e.c.a {
   public static final String d = l.a("WorkConstraintsTracker");
   public final c a;
   public final b.l.w.o.e.c[] b;
   public final Object c;

   public d(Context var1, b.l.w.r.n.a var2, c var3) {
      var1 = var1.getApplicationContext();
      this.a = var3;
      this.b = new b.l.w.o.e.c[]{new b.l.w.o.e.a(var1, var2), new b.l.w.o.e.b(var1, var2), new h(var1, var2), new b.l.w.o.e.d(var1, var2), new g(var1, var2), new f(var1, var2), new e(var1, var2)};
      this.c = new Object();
   }

   public void a() {
      Object var1 = this.c;
      synchronized(var1){}

      Throwable var10000;
      boolean var10001;
      label247: {
         b.l.w.o.e.c[] var2;
         int var3;
         try {
            var2 = this.b;
            var3 = var2.length;
         } catch (Throwable var25) {
            var10000 = var25;
            var10001 = false;
            break label247;
         }

         for(int var4 = 0; var4 < var3; ++var4) {
            b.l.w.o.e.c var5 = var2[var4];

            try {
               if (!var5.a.isEmpty()) {
                  var5.a.clear();
                  var5.c.b(var5);
               }
            } catch (Throwable var24) {
               var10000 = var24;
               var10001 = false;
               break label247;
            }
         }

         label227:
         try {
            return;
         } catch (Throwable var23) {
            var10000 = var23;
            var10001 = false;
            break label227;
         }
      }

      while(true) {
         Throwable var26 = var10000;

         try {
            throw var26;
         } catch (Throwable var22) {
            var10000 = var22;
            var10001 = false;
            continue;
         }
      }
   }

   public void a(Iterable var1) {
      Object var2 = this.c;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label855: {
         b.l.w.o.e.c[] var3;
         int var4;
         try {
            var3 = this.b;
            var4 = var3.length;
         } catch (Throwable var79) {
            var10000 = var79;
            var10001 = false;
            break label855;
         }

         byte var5 = 0;

         int var6;
         for(var6 = 0; var6 < var4; ++var6) {
            b.l.w.o.e.c var7 = var3[var6];

            try {
               if (var7.d != null) {
                  var7.d = null;
                  var7.a(var7.d, var7.b);
               }
            } catch (Throwable var78) {
               var10000 = var78;
               var10001 = false;
               break label855;
            }
         }

         try {
            var3 = this.b;
            var4 = var3.length;
         } catch (Throwable var77) {
            var10000 = var77;
            var10001 = false;
            break label855;
         }

         for(var6 = 0; var6 < var4; ++var6) {
            try {
               var3[var6].a(var1);
            } catch (Throwable var76) {
               var10000 = var76;
               var10001 = false;
               break label855;
            }
         }

         try {
            var3 = this.b;
            var4 = var3.length;
         } catch (Throwable var75) {
            var10000 = var75;
            var10001 = false;
            break label855;
         }

         for(var6 = var5; var6 < var4; ++var6) {
            b.l.w.o.e.c var80 = var3[var6];

            try {
               if (var80.d != this) {
                  var80.d = this;
                  var80.a(var80.d, var80.b);
               }
            } catch (Throwable var74) {
               var10000 = var74;
               var10001 = false;
               break label855;
            }
         }

         label807:
         try {
            return;
         } catch (Throwable var73) {
            var10000 = var73;
            var10001 = false;
            break label807;
         }
      }

      while(true) {
         Throwable var81 = var10000;

         try {
            throw var81;
         } catch (Throwable var72) {
            var10000 = var72;
            var10001 = false;
            continue;
         }
      }
   }

   public void a(List var1) {
      Object var2 = this.c;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label326: {
         ArrayList var3;
         Iterator var4;
         try {
            var3 = new ArrayList();
            var4 = var1.iterator();
         } catch (Throwable var33) {
            var10000 = var33;
            var10001 = false;
            break label326;
         }

         while(true) {
            try {
               if (!var4.hasNext()) {
                  break;
               }

               String var35 = (String)var4.next();
               if (this.a(var35)) {
                  l.a().a(d, String.format("Constraints met for %s", var35));
                  var3.add(var35);
               }
            } catch (Throwable var34) {
               var10000 = var34;
               var10001 = false;
               break label326;
            }
         }

         try {
            if (this.a != null) {
               this.a.b(var3);
            }
         } catch (Throwable var32) {
            var10000 = var32;
            var10001 = false;
            break label326;
         }

         label306:
         try {
            return;
         } catch (Throwable var31) {
            var10000 = var31;
            var10001 = false;
            break label306;
         }
      }

      while(true) {
         Throwable var36 = var10000;

         try {
            throw var36;
         } catch (Throwable var30) {
            var10000 = var30;
            var10001 = false;
            continue;
         }
      }
   }

   public boolean a(String var1) {
      Object var2 = this.c;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label472: {
         b.l.w.o.e.c[] var3;
         int var4;
         try {
            var3 = this.b;
            var4 = var3.length;
         } catch (Throwable var50) {
            var10000 = var50;
            var10001 = false;
            break label472;
         }

         for(int var5 = 0; var5 < var4; ++var5) {
            b.l.w.o.e.c var6 = var3[var5];

            Object var7;
            try {
               var7 = var6.b;
            } catch (Throwable var48) {
               var10000 = var48;
               var10001 = false;
               break label472;
            }

            boolean var8;
            label460: {
               label459: {
                  if (var7 != null) {
                     try {
                        if (var6.a(var7) && var6.a.contains(var1)) {
                           break label459;
                        }
                     } catch (Throwable var49) {
                        var10000 = var49;
                        var10001 = false;
                        break label472;
                     }
                  }

                  var8 = false;
                  break label460;
               }

               var8 = true;
            }

            if (var8) {
               try {
                  l.a().a(d, String.format("Work %s constrained by %s", var1, var6.getClass().getSimpleName()));
                  return false;
               } catch (Throwable var46) {
                  var10000 = var46;
                  var10001 = false;
                  break label472;
               }
            }
         }

         label444:
         try {
            return true;
         } catch (Throwable var47) {
            var10000 = var47;
            var10001 = false;
            break label444;
         }
      }

      while(true) {
         Throwable var51 = var10000;

         try {
            throw var51;
         } catch (Throwable var45) {
            var10000 = var45;
            var10001 = false;
            continue;
         }
      }
   }

   public void b(List var1) {
      Object var2 = this.c;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label122: {
         try {
            if (this.a != null) {
               this.a.a(var1);
            }
         } catch (Throwable var14) {
            var10000 = var14;
            var10001 = false;
            break label122;
         }

         label119:
         try {
            return;
         } catch (Throwable var13) {
            var10000 = var13;
            var10001 = false;
            break label119;
         }
      }

      while(true) {
         Throwable var15 = var10000;

         try {
            throw var15;
         } catch (Throwable var12) {
            var10000 = var12;
            var10001 = false;
            continue;
         }
      }
   }
}
