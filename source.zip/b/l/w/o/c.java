package b.l.w.o;

import java.util.List;

public interface c {
   void a(List var1);

   void b(List var1);
}
