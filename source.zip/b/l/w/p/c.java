package b.l.w.p;

import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION;
import android.text.TextUtils;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.foreground.SystemForegroundService;
import b.l.g;
import b.l.l;
import b.l.w.j;
import b.l.w.o.d;
import b.l.w.q.p;
import b.l.w.r.h;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;

public class c implements b.l.w.o.c, b.l.w.a {
   public static final String l = b.l.l.a("SystemFgDispatcher");
   public Context a;
   public j b;
   public final b.l.w.r.n.a c;
   public final Object d;
   public String e;
   public g f;
   public final Map g;
   public final Map h;
   public final Set i;
   public final d j;
   public c.a k;

   public c(Context var1) {
      this.a = var1;
      this.d = new Object();
      this.b = b.l.w.j.a(this.a);
      this.c = this.b.d;
      this.e = null;
      this.f = null;
      this.g = new LinkedHashMap();
      this.i = new HashSet();
      this.h = new HashMap();
      this.j = new d(this.a, this.c, this);
      this.b.f.a((b.l.w.a)this);
   }

   public static Intent a(Context var0, String var1, g var2) {
      Intent var3 = new Intent(var0, SystemForegroundService.class);
      var3.setAction("ACTION_NOTIFY");
      var3.putExtra("KEY_NOTIFICATION_ID", var2.a);
      var3.putExtra("KEY_FOREGROUND_SERVICE_TYPE", var2.b);
      var3.putExtra("KEY_NOTIFICATION", var2.c);
      var3.putExtra("KEY_WORKSPEC_ID", var1);
      return var3;
   }

   public static Intent b(Context var0, String var1, g var2) {
      Intent var3 = new Intent(var0, SystemForegroundService.class);
      var3.setAction("ACTION_START_FOREGROUND");
      var3.putExtra("KEY_WORKSPEC_ID", var1);
      var3.putExtra("KEY_NOTIFICATION_ID", var2.a);
      var3.putExtra("KEY_FOREGROUND_SERVICE_TYPE", var2.b);
      var3.putExtra("KEY_NOTIFICATION", var2.c);
      var3.putExtra("KEY_WORKSPEC_ID", var1);
      return var3;
   }

   public void a() {
      b.l.l.a().c(l, "Stopping foreground service");
      c.a var1 = this.k;
      if (var1 != null) {
         g var2 = this.f;
         if (var2 != null) {
            var1.a(var2.a);
            this.f = null;
         }

         this.k.stop();
      }

   }

   public final void a(Intent var1) {
      int var2 = 0;
      int var3 = var1.getIntExtra("KEY_NOTIFICATION_ID", 0);
      int var4 = var1.getIntExtra("KEY_FOREGROUND_SERVICE_TYPE", 0);
      String var5 = var1.getStringExtra("KEY_WORKSPEC_ID");
      Notification var7 = (Notification)var1.getParcelableExtra("KEY_NOTIFICATION");
      b.l.l.a().a(l, String.format("Notifying with (id: %s, workSpecId: %s, notificationType: %s)", var3, var5, var4));
      if (var7 != null && this.k != null) {
         g var6 = new g(var3, var7, var4);
         this.g.put(var5, var6);
         if (TextUtils.isEmpty(this.e)) {
            this.e = var5;
            this.k.a(var3, var4, var7);
         } else {
            this.k.a(var3, var7);
            if (var4 != 0 && VERSION.SDK_INT >= 29) {
               for(Iterator var8 = this.g.entrySet().iterator(); var8.hasNext(); var2 |= ((g)((Entry)var8.next()).getValue()).b) {
               }

               g var9 = (g)this.g.get(this.e);
               if (var9 != null) {
                  this.k.a(var9.a, var2, var9.c);
               }
            }
         }
      }

   }

   public void a(String var1, boolean var2) {
      Object var3 = this.d;
      synchronized(var3){}

      label340: {
         Throwable var10000;
         boolean var10001;
         label341: {
            p var4;
            try {
               var4 = (p)this.h.remove(var1);
            } catch (Throwable var24) {
               var10000 = var24;
               var10001 = false;
               break label341;
            }

            if (var4 != null) {
               try {
                  var2 = this.i.remove(var4);
               } catch (Throwable var23) {
                  var10000 = var23;
                  var10001 = false;
                  break label341;
               }
            } else {
               var2 = false;
            }

            label327:
            try {
               break label340;
            } catch (Throwable var22) {
               var10000 = var22;
               var10001 = false;
               break label327;
            }
         }

         while(true) {
            Throwable var25 = var10000;

            try {
               throw var25;
            } catch (Throwable var21) {
               var10000 = var21;
               var10001 = false;
               continue;
            }
         }
      }

      if (var2) {
         this.j.a((Iterable)this.i);
      }

      this.f = (g)this.g.remove(var1);
      if (var1.equals(this.e)) {
         if (this.g.size() > 0) {
            Iterator var29 = this.g.entrySet().iterator();

            Entry var26;
            for(var26 = (Entry)var29.next(); var29.hasNext(); var26 = (Entry)var29.next()) {
            }

            this.e = (String)var26.getKey();
            if (this.k != null) {
               g var27 = (g)var26.getValue();
               this.k.a(var27.a, var27.b, var27.c);
               this.k.a(var27.a);
            }
         }
      } else {
         g var30 = this.f;
         if (var30 != null) {
            c.a var28 = this.k;
            if (var28 != null) {
               var28.a(var30.a);
            }
         }
      }

   }

   public void a(List var1) {
      if (!var1.isEmpty()) {
         Iterator var5 = var1.iterator();

         while(var5.hasNext()) {
            String var2 = (String)var5.next();
            b.l.l.a().a(l, String.format("Constraints unmet for WorkSpec %s", var2));
            j var3 = this.b;
            b.l.w.r.n.a var4 = var3.d;
            h var6 = new h(var3, var2, true);
            ((b.l.w.r.n.b)var4).a.execute(var6);
         }
      }

   }

   public void b(Intent var1) {
      String var2 = var1.getAction();
      if ("ACTION_START_FOREGROUND".equals(var2)) {
         b.l.l.a().c(l, String.format("Started foreground service %s", var1));
         String var3 = var1.getStringExtra("KEY_WORKSPEC_ID");
         WorkDatabase var4 = this.b.c;
         b.l.w.r.n.a var6 = this.c;
         b var7 = new b(this, var4, var3);
         ((b.l.w.r.n.b)var6).a.execute(var7);
         this.a(var1);
      } else if ("ACTION_NOTIFY".equals(var2)) {
         this.a(var1);
      } else if ("ACTION_CANCEL_WORK".equals(var2)) {
         b.l.l.a().c(l, String.format("Stopping foreground work for %s", var1));
         String var5 = var1.getStringExtra("KEY_WORKSPEC_ID");
         if (var5 != null && !TextUtils.isEmpty(var5)) {
            this.b.a(UUID.fromString(var5));
         }
      }

   }

   public void b(List var1) {
   }

   public interface a {
      void a(int var1);

      void a(int var1, int var2, Notification var3);

      void a(int var1, Notification var2);

      void stop();
   }
}
