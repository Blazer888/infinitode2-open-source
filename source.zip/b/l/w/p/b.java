package b.l.w.p;

import androidx.work.impl.WorkDatabase;

public class b implements Runnable {
   // $FF: synthetic field
   public final WorkDatabase a;
   // $FF: synthetic field
   public final String b;
   // $FF: synthetic field
   public final c c;

   public b(c var1, WorkDatabase var2, String var3) {
      this.c = var1;
      this.a = var2;
      this.b = var3;
   }

   public void run() {
      // $FF: Couldn't be decompiled
   }
}
