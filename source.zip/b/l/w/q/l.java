package b.l.w.q;

public final class l implements k {
   public final b.i.g a;
   public final b.i.b b;

   public l(b.i.g var1) {
      this.a = var1;
      this.b = new b.i.b(this, var1) {
         public void a(b.j.a.f var1, Object var2) {
            j var3 = (j)var2;
            String var4 = var3.a;
            if (var4 == null) {
               var1.b(1);
            } else {
               var1.a(1, (String)var4);
            }

            var4 = var3.b;
            if (var4 == null) {
               var1.b(2);
            } else {
               var1.a(2, (String)var4);
            }

         }

         public String c() {
            return "INSERT OR IGNORE INTO `WorkName` (`name`,`work_spec_id`) VALUES (?,?)";
         }
      };
   }
}
