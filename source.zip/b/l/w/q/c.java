package b.l.w.q;

import android.database.Cursor;
import android.os.CancellationSignal;
import java.util.ArrayList;
import java.util.List;

public final class c implements b {
   public final b.i.g a;
   public final b.i.b b;

   public c(b.i.g var1) {
      this.a = var1;
      this.b = new b.i.b(this, var1) {
         public void a(b.j.a.f var1, Object var2) {
            a var4 = (a)var2;
            String var3 = var4.a;
            if (var3 == null) {
               var1.b(1);
            } else {
               var1.a(1, (String)var3);
            }

            String var5 = var4.b;
            if (var5 == null) {
               var1.b(2);
            } else {
               var1.a(2, (String)var5);
            }

         }

         public String c() {
            return "INSERT OR IGNORE INTO `Dependency` (`work_spec_id`,`prerequisite_id`) VALUES (?,?)";
         }
      };
   }

   public List a(String var1) {
      b.i.i var2 = b.i.i.a("SELECT work_spec_id FROM dependency WHERE prerequisite_id=?", 1);
      if (var1 == null) {
         var2.b(1);
      } else {
         var2.a(1, (String)var1);
      }

      this.a.b();
      Cursor var10 = b.i.o.b.a(this.a, var2, false, (CancellationSignal)null);

      ArrayList var3;
      label95: {
         Throwable var10000;
         label94: {
            boolean var10001;
            try {
               var3 = new ArrayList(var10.getCount());
            } catch (Throwable var9) {
               var10000 = var9;
               var10001 = false;
               break label94;
            }

            while(true) {
               try {
                  if (!var10.moveToNext()) {
                     break label95;
                  }

                  var3.add(var10.getString(0));
               } catch (Throwable var8) {
                  var10000 = var8;
                  var10001 = false;
                  break;
               }
            }
         }

         Throwable var11 = var10000;
         var10.close();
         var2.b();
         throw var11;
      }

      var10.close();
      var2.b();
      return var3;
   }

   public boolean b(String var1) {
      b.i.i var2 = b.i.i.a("SELECT COUNT(*)=0 FROM dependency WHERE work_spec_id=? AND prerequisite_id IN (SELECT id FROM workspec WHERE state!=2)", 1);
      if (var1 == null) {
         var2.b(1);
      } else {
         var2.a(1, (String)var1);
      }

      this.a.b();
      b.i.g var10 = this.a;
      boolean var3 = false;
      Cursor var4 = b.i.o.b.a(var10, var2, false, (CancellationSignal)null);
      boolean var5 = var3;
      boolean var8 = false;

      label50: {
         int var6;
         try {
            var8 = true;
            if (!var4.moveToFirst()) {
               var8 = false;
               break label50;
            }

            var6 = var4.getInt(0);
            var8 = false;
         } finally {
            if (var8) {
               var4.close();
               var2.b();
            }
         }

         var5 = var3;
         if (var6 != 0) {
            var5 = true;
         }
      }

      var4.close();
      var2.b();
      return var5;
   }

   public boolean c(String var1) {
      b.i.i var2 = b.i.i.a("SELECT COUNT(*)>0 FROM dependency WHERE prerequisite_id=?", 1);
      if (var1 == null) {
         var2.b(1);
      } else {
         var2.a(1, (String)var1);
      }

      this.a.b();
      b.i.g var10 = this.a;
      boolean var3 = false;
      Cursor var11 = b.i.o.b.a(var10, var2, false, (CancellationSignal)null);
      boolean var4 = var3;
      boolean var8 = false;

      label50: {
         int var5;
         try {
            var8 = true;
            if (!var11.moveToFirst()) {
               var8 = false;
               break label50;
            }

            var5 = var11.getInt(0);
            var8 = false;
         } finally {
            if (var8) {
               var11.close();
               var2.b();
            }
         }

         var4 = var3;
         if (var5 != 0) {
            var4 = true;
         }
      }

      var11.close();
      var2.b();
      return var4;
   }
}
