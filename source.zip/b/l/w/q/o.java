package b.l.w.q;

public final class o implements n {
   public final b.i.g a;
   public final b.i.b b;
   public final b.i.l c;
   public final b.i.l d;

   public o(b.i.g var1) {
      this.a = var1;
      this.b = new b.i.b(this, var1) {
         public void a(b.j.a.f var1, Object var2) {
            m var4 = (m)var2;
            String var3 = var4.a;
            if (var3 == null) {
               var1.b(1);
            } else {
               var1.a(1, (String)var3);
            }

            byte[] var5 = b.l.e.a(var4.b);
            if (var5 == null) {
               var1.b(2);
            } else {
               var1.a(2, (byte[])var5);
            }

         }

         public String c() {
            return "INSERT OR REPLACE INTO `WorkProgress` (`work_spec_id`,`progress`) VALUES (?,?)";
         }
      };
      this.c = new b.i.l(this, var1) {
         public String c() {
            return "DELETE from WorkProgress where work_spec_id=?";
         }
      };
      this.d = new b.i.l(this, var1) {
         public String c() {
            return "DELETE FROM WorkProgress";
         }
      };
   }

   public void a() {
      this.a.b();
      b.j.a.f var1 = this.d.a();
      this.a.c();
      b.j.a.g.f var2 = (b.j.a.g.f)var1;
      boolean var4 = false;

      try {
         var4 = true;
         var2.a();
         this.a.k();
         var4 = false;
      } finally {
         if (var4) {
            this.a.e();
            this.d.a(var1);
         }
      }

      this.a.e();
      b.i.l var6 = this.d;
      if (var2 == var6.c) {
         var6.a.set(false);
      }

   }

   public void a(String var1) {
      this.a.b();
      b.j.a.f var2 = this.c.a();
      if (var1 == null) {
         var2.b(1);
      } else {
         var2.a(1, (String)var1);
      }

      this.a.c();
      b.j.a.g.f var6 = (b.j.a.g.f)var2;
      boolean var4 = false;

      try {
         var4 = true;
         var6.a();
         this.a.k();
         var4 = false;
      } finally {
         if (var4) {
            this.a.e();
            this.c.a(var2);
         }
      }

      this.a.e();
      b.i.l var7 = this.c;
      if (var6 == var7.c) {
         var7.a.set(false);
      }

   }
}
