package b.l.w.q;

import android.database.Cursor;
import android.os.CancellationSignal;
import java.util.ArrayList;
import java.util.List;

public final class u implements t {
   public final b.i.g a;
   public final b.i.b b;

   public u(b.i.g var1) {
      this.a = var1;
      this.b = new b.i.b(this, var1) {
         public void a(b.j.a.f var1, Object var2) {
            s var4 = (s)var2;
            String var3 = var4.a;
            if (var3 == null) {
               var1.b(1);
            } else {
               var1.a(1, (String)var3);
            }

            String var5 = var4.b;
            if (var5 == null) {
               var1.b(2);
            } else {
               var1.a(2, (String)var5);
            }

         }

         public String c() {
            return "INSERT OR IGNORE INTO `WorkTag` (`tag`,`work_spec_id`) VALUES (?,?)";
         }
      };
   }

   public List a(String var1) {
      b.i.i var2 = b.i.i.a("SELECT DISTINCT tag FROM worktag WHERE work_spec_id=?", 1);
      if (var1 == null) {
         var2.b(1);
      } else {
         var2.a(1, (String)var1);
      }

      this.a.b();
      Cursor var10 = b.i.o.b.a(this.a, var2, false, (CancellationSignal)null);

      ArrayList var3;
      label95: {
         Throwable var10000;
         label94: {
            boolean var10001;
            try {
               var3 = new ArrayList(var10.getCount());
            } catch (Throwable var9) {
               var10000 = var9;
               var10001 = false;
               break label94;
            }

            while(true) {
               try {
                  if (!var10.moveToNext()) {
                     break label95;
                  }

                  var3.add(var10.getString(0));
               } catch (Throwable var8) {
                  var10000 = var8;
                  var10001 = false;
                  break;
               }
            }
         }

         Throwable var11 = var10000;
         var10.close();
         var2.b();
         throw var11;
      }

      var10.close();
      var2.b();
      return var3;
   }
}
