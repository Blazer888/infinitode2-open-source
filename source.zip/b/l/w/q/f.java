package b.l.w.q;

import android.database.Cursor;
import android.os.CancellationSignal;

public final class f implements e {
   public final b.i.g a;
   public final b.i.b b;

   public f(b.i.g var1) {
      this.a = var1;
      this.b = new b.i.b(this, var1) {
         public void a(b.j.a.f var1, Object var2) {
            d var4 = (d)var2;
            String var3 = var4.a;
            if (var3 == null) {
               var1.b(1);
            } else {
               var1.a(1, (String)var3);
            }

            Long var5 = var4.b;
            if (var5 == null) {
               var1.b(2);
            } else {
               var1.a(2, var5);
            }

         }

         public String c() {
            return "INSERT OR REPLACE INTO `Preference` (`key`,`long_value`) VALUES (?,?)";
         }
      };
   }

   public Long a(String var1) {
      b.i.i var2 = b.i.i.a("SELECT long_value FROM Preference where `key`=?", 1);
      if (var1 == null) {
         var2.b(1);
      } else {
         var2.a(1, (String)var1);
      }

      this.a.b();
      b.i.g var8 = this.a;
      Object var3 = null;
      Cursor var4 = b.i.o.b.a(var8, var2, false, (CancellationSignal)null);
      Long var9 = (Long)var3;
      boolean var6 = false;

      label56: {
         try {
            var6 = true;
            if (!var4.moveToFirst()) {
               var6 = false;
               break label56;
            }

            if (!var4.isNull(0)) {
               var9 = var4.getLong(0);
               var6 = false;
               break label56;
            }

            var6 = false;
         } finally {
            if (var6) {
               var4.close();
               var2.b();
            }
         }

         var9 = (Long)var3;
      }

      var4.close();
      var2.b();
      return var9;
   }

   public void a(d var1) {
      this.a.b();
      this.a.c();

      try {
         this.b.a(var1);
         this.a.k();
      } finally {
         this.a.e();
      }

   }
}
