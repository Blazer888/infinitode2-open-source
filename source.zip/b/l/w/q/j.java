package b.l.w.q;

public class j {
   public final String a;
   public final String b;

   public j(String var1, String var2) {
      this.a = var1;
      this.b = var2;
   }
}
