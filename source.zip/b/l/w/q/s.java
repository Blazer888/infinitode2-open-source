package b.l.w.q;

public class s {
   public final String a;
   public final String b;

   public s(String var1, String var2) {
      this.a = var1;
      this.b = var2;
   }
}
