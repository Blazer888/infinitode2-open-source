package b.l.w.q;

public class d {
   public String a;
   public Long b;

   public d(String var1, long var2) {
      this.a = var1;
      this.b = var2;
   }

   public boolean equals(Object var1) {
      boolean var2 = true;
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof d)) {
         return false;
      } else {
         d var3 = (d)var1;
         if (!this.a.equals(var3.a)) {
            return false;
         } else {
            Long var4 = this.b;
            Long var5 = var3.b;
            if (var4 != null) {
               var2 = var4.equals(var5);
            } else if (var5 != null) {
               var2 = false;
            }

            return var2;
         }
      }
   }

   public int hashCode() {
      int var1 = this.a.hashCode();
      Long var2 = this.b;
      int var3;
      if (var2 != null) {
         var3 = var2.hashCode();
      } else {
         var3 = 0;
      }

      return var1 * 31 + var3;
   }
}
