package b.l.w.q;

public class m {
   public final String a;
   public final b.l.e b;

   public m(String var1, b.l.e var2) {
      this.a = var1;
      this.b = var2;
   }
}
