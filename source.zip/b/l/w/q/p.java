package b.l.w.q;

public final class p {
   public String a;
   public b.l.s b;
   public String c;
   public String d;
   public b.l.e e;
   public b.l.e f;
   public long g;
   public long h;
   public long i;
   public b.l.c j;
   public int k;
   public b.l.a l;
   public long m;
   public long n;
   public long o;
   public long p;
   public boolean q;

   static {
      b.l.l.a("WorkSpec");
   }

   public p(p var1) {
      this.b = b.l.s.a;
      b.l.e var2 = b.l.e.c;
      this.e = var2;
      this.f = var2;
      this.j = b.l.c.i;
      this.l = b.l.a.a;
      this.m = 30000L;
      this.p = -1L;
      this.a = var1.a;
      this.c = var1.c;
      this.b = var1.b;
      this.d = var1.d;
      this.e = new b.l.e(var1.e);
      this.f = new b.l.e(var1.f);
      this.g = var1.g;
      this.h = var1.h;
      this.i = var1.i;
      this.j = new b.l.c(var1.j);
      this.k = var1.k;
      this.l = var1.l;
      this.m = var1.m;
      this.n = var1.n;
      this.o = var1.o;
      this.p = var1.p;
      this.q = var1.q;
   }

   public p(String var1, String var2) {
      this.b = b.l.s.a;
      b.l.e var3 = b.l.e.c;
      this.e = var3;
      this.f = var3;
      this.j = b.l.c.i;
      this.l = b.l.a.a;
      this.m = 30000L;
      this.p = -1L;
      this.a = var1;
      this.c = var2;
   }

   public long a() {
      boolean var1 = this.c();
      boolean var2 = false;
      boolean var3 = false;
      long var4;
      long var6;
      long var8;
      if (var1) {
         if (this.l == b.l.a.b) {
            var3 = true;
         }

         if (var3) {
            var4 = this.m * (long)this.k;
         } else {
            var4 = (long)Math.scalb((float)this.m, this.k - 1);
         }

         var6 = this.n;
         var8 = Math.min(18000000L, var4);
         var4 = var6;
         var6 = var8;
      } else {
         var1 = this.d();
         var6 = 0L;
         if (var1) {
            long var10 = System.currentTimeMillis();
            var8 = this.n;
            var4 = var8;
            if (var8 == 0L) {
               var4 = this.g + var10;
            }

            var3 = var2;
            if (this.i != this.h) {
               var3 = true;
            }

            if (var3) {
               if (this.n == 0L) {
                  var6 = this.i * -1L;
               }

               return var4 + this.h + var6;
            }

            if (this.n != 0L) {
               var6 = this.h;
            }

            return var4 + var6;
         }

         var6 = this.n;
         var4 = var6;
         if (var6 == 0L) {
            var4 = System.currentTimeMillis();
         }

         var8 = this.g;
         var6 = var4;
         var4 = var8;
      }

      return var6 + var4;
   }

   public boolean b() {
      return b.l.c.i.equals(this.j) ^ true;
   }

   public boolean c() {
      boolean var1;
      if (this.b == b.l.s.a && this.k > 0) {
         var1 = true;
      } else {
         var1 = false;
      }

      return var1;
   }

   public boolean d() {
      boolean var1;
      if (this.h != 0L) {
         var1 = true;
      } else {
         var1 = false;
      }

      return var1;
   }

   public boolean equals(Object var1) {
      boolean var2 = true;
      if (this == var1) {
         return true;
      } else if (!(var1 instanceof p)) {
         return false;
      } else {
         p var4 = (p)var1;
         if (this.g != var4.g) {
            return false;
         } else if (this.h != var4.h) {
            return false;
         } else if (this.i != var4.i) {
            return false;
         } else if (this.k != var4.k) {
            return false;
         } else if (this.m != var4.m) {
            return false;
         } else if (this.n != var4.n) {
            return false;
         } else if (this.o != var4.o) {
            return false;
         } else if (this.p != var4.p) {
            return false;
         } else if (this.q != var4.q) {
            return false;
         } else if (!this.a.equals(var4.a)) {
            return false;
         } else if (this.b != var4.b) {
            return false;
         } else if (!this.c.equals(var4.c)) {
            return false;
         } else {
            String var3 = this.d;
            if (var3 != null) {
               if (!var3.equals(var4.d)) {
                  return false;
               }
            } else if (var4.d != null) {
               return false;
            }

            if (!this.e.equals(var4.e)) {
               return false;
            } else if (!this.f.equals(var4.f)) {
               return false;
            } else if (!this.j.equals(var4.j)) {
               return false;
            } else {
               if (this.l != var4.l) {
                  var2 = false;
               }

               return var2;
            }
         }
      }
   }

   public int hashCode() {
      int var1 = this.a.hashCode();
      int var2 = this.b.hashCode();
      int var3 = this.c.hashCode();
      String var4 = this.d;
      int var5;
      if (var4 != null) {
         var5 = var4.hashCode();
      } else {
         var5 = 0;
      }

      int var6 = this.e.hashCode();
      int var7 = this.f.hashCode();
      long var8 = this.g;
      int var10 = (int)(var8 ^ var8 >>> 32);
      var8 = this.h;
      int var11 = (int)(var8 ^ var8 >>> 32);
      var8 = this.i;
      int var12 = (int)(var8 ^ var8 >>> 32);
      int var13 = this.j.hashCode();
      int var14 = this.k;
      int var15 = this.l.hashCode();
      var8 = this.m;
      int var16 = (int)(var8 ^ var8 >>> 32);
      var8 = this.n;
      int var17 = (int)(var8 ^ var8 >>> 32);
      var8 = this.o;
      int var18 = (int)(var8 ^ var8 >>> 32);
      var8 = this.p;
      return (((((var15 + ((var13 + ((((var7 + (var6 + ((var3 + (var2 + var1 * 31) * 31) * 31 + var5) * 31) * 31) * 31 + var10) * 31 + var11) * 31 + var12) * 31) * 31 + var14) * 31) * 31 + var16) * 31 + var17) * 31 + var18) * 31 + (int)(var8 ^ var8 >>> 32)) * 31 + this.q;
   }

   public String toString() {
      return c.a.b.a.a.a(c.a.b.a.a.b("{WorkSpec: "), this.a, "}");
   }

   public static class a {
      public String a;
      public b.l.s b;

      public boolean equals(Object var1) {
         if (this == var1) {
            return true;
         } else if (!(var1 instanceof p.a)) {
            return false;
         } else {
            p.a var2 = (p.a)var1;
            return this.b != var2.b ? false : this.a.equals(var2.a);
         }
      }

      public int hashCode() {
         int var1 = this.a.hashCode();
         return this.b.hashCode() + var1 * 31;
      }
   }
}
