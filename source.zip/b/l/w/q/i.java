package b.l.w.q;

import android.database.Cursor;
import android.os.CancellationSignal;

public final class i implements h {
   public final b.i.g a;
   public final b.i.b b;
   public final b.i.l c;

   public i(b.i.g var1) {
      this.a = var1;
      this.b = new b.i.b(this, var1) {
         public void a(b.j.a.f var1, Object var2) {
            g var3 = (g)var2;
            String var4 = var3.a;
            if (var4 == null) {
               var1.b(1);
            } else {
               var1.a(1, (String)var4);
            }

            var1.a(2, (long)var3.b);
         }

         public String c() {
            return "INSERT OR REPLACE INTO `SystemIdInfo` (`work_spec_id`,`system_id`) VALUES (?,?)";
         }
      };
      this.c = new b.i.l(this, var1) {
         public String c() {
            return "DELETE FROM SystemIdInfo where work_spec_id=?";
         }
      };
   }

   public g a(String var1) {
      b.i.i var2 = b.i.i.a("SELECT `SystemIdInfo`.`work_spec_id` AS `work_spec_id`, `SystemIdInfo`.`system_id` AS `system_id` FROM SystemIdInfo WHERE work_spec_id=?", 1);
      if (var1 == null) {
         var2.b(1);
      } else {
         var2.a(1, (String)var1);
      }

      this.a.b();
      b.i.g var3 = this.a;
      g var8 = null;
      Cursor var9 = b.i.o.b.a(var3, var2, false, (CancellationSignal)null);

      try {
         int var4 = b.c.b.b.a(var9, "work_spec_id");
         int var5 = b.c.b.b.a(var9, "system_id");
         if (var9.moveToFirst()) {
            var8 = new g(var9.getString(var4), var9.getInt(var5));
         }
      } finally {
         var9.close();
         var2.b();
      }

      return var8;
   }

   public void a(g var1) {
      this.a.b();
      this.a.c();

      try {
         this.b.a(var1);
         this.a.k();
      } finally {
         this.a.e();
      }

   }

   public void b(String var1) {
      this.a.b();
      b.j.a.f var2 = this.c.a();
      if (var1 == null) {
         var2.b(1);
      } else {
         var2.a(1, (String)var1);
      }

      this.a.c();
      b.j.a.g.f var6 = (b.j.a.g.f)var2;
      boolean var4 = false;

      try {
         var4 = true;
         var6.a();
         this.a.k();
         var4 = false;
      } finally {
         if (var4) {
            this.a.e();
            this.c.a(var2);
         }
      }

      this.a.e();
      b.i.l var7 = this.c;
      if (var6 == var7.c) {
         var7.a.set(false);
      }

   }
}
