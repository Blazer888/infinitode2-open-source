package b.l.w.q;

import android.database.Cursor;
import android.os.CancellationSignal;
import java.util.ArrayList;
import java.util.List;

public final class r implements q {
   public final b.i.g a;
   public final b.i.b b;
   public final b.i.l c;
   public final b.i.l d;
   public final b.i.l e;
   public final b.i.l f;
   public final b.i.l g;
   public final b.i.l h;
   public final b.i.l i;

   public r(b.i.g var1) {
      this.a = var1;
      this.b = new b.i.b(this, var1) {
         public void a(b.j.a.f param1, Object param2) {
            // $FF: Couldn't be decompiled
         }

         public String c() {
            return "INSERT OR IGNORE INTO `WorkSpec` (`id`,`state`,`worker_class_name`,`input_merger_class_name`,`input`,`output`,`initial_delay`,`interval_duration`,`flex_duration`,`run_attempt_count`,`backoff_policy`,`backoff_delay_duration`,`period_start_time`,`minimum_retention_duration`,`schedule_requested_at`,`run_in_foreground`,`required_network_type`,`requires_charging`,`requires_device_idle`,`requires_battery_not_low`,`requires_storage_not_low`,`trigger_content_update_delay`,`trigger_max_content_delay`,`content_uri_triggers`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
         }
      };
      this.c = new b.i.l(this, var1) {
         public String c() {
            return "DELETE FROM workspec WHERE id=?";
         }
      };
      this.d = new b.i.l(this, var1) {
         public String c() {
            return "UPDATE workspec SET output=? WHERE id=?";
         }
      };
      this.e = new b.i.l(this, var1) {
         public String c() {
            return "UPDATE workspec SET period_start_time=? WHERE id=?";
         }
      };
      this.f = new b.i.l(this, var1) {
         public String c() {
            return "UPDATE workspec SET run_attempt_count=run_attempt_count+1 WHERE id=?";
         }
      };
      this.g = new b.i.l(this, var1) {
         public String c() {
            return "UPDATE workspec SET run_attempt_count=0 WHERE id=?";
         }
      };
      this.h = new b.i.l(this, var1) {
         public String c() {
            return "UPDATE workspec SET schedule_requested_at=? WHERE id=?";
         }
      };
      this.i = new b.i.l(this, var1) {
         public String c() {
            return "UPDATE workspec SET schedule_requested_at=-1 WHERE state NOT IN (2, 3, 5)";
         }
      };
      b.i.l var10001 = new b.i.l(this, var1) {
         public String c() {
            return "DELETE FROM workspec WHERE state IN (2, 3, 5) AND (SELECT COUNT(*)=0 FROM dependency WHERE     prerequisite_id=id AND     work_spec_id NOT IN         (SELECT id FROM workspec WHERE state IN (2, 3, 5)))";
         }
      };
   }

   public int a(b.l.s var1, String... var2) {
      this.a.b();
      StringBuilder var3 = new StringBuilder();
      var3.append("UPDATE workspec SET state=");
      var3.append("?");
      var3.append(" WHERE id IN (");
      int var4 = var2.length;
      int var5 = 0;

      int var6;
      for(var6 = 0; var6 < var4; ++var6) {
         var3.append("?");
         if (var6 < var4 - 1) {
            var3.append(",");
         }
      }

      var3.append(")");
      String var11 = var3.toString();
      b.j.a.f var12 = this.a.a(var11);
      var12.a(1, (long)b.c.b.b.a(var1));
      var6 = 2;

      for(var4 = var2.length; var5 < var4; ++var5) {
         String var9 = var2[var5];
         if (var9 == null) {
            var12.b(var6);
         } else {
            var12.a(var6, var9);
         }

         ++var6;
      }

      this.a.c();
      b.j.a.g.f var10 = (b.j.a.g.f)var12;

      try {
         var6 = var10.a();
         this.a.k();
      } finally {
         this.a.e();
      }

      return var6;
   }

   public int a(String var1, long var2) {
      this.a.b();
      b.j.a.f var4 = this.h.a();
      var4.a(1, var2);
      if (var1 == null) {
         var4.b(2);
      } else {
         var4.a(2, (String)var1);
      }

      this.a.c();
      b.j.a.g.f var10 = (b.j.a.g.f)var4;
      boolean var8 = false;

      int var5;
      try {
         var8 = true;
         var5 = var10.a();
         this.a.k();
         var8 = false;
      } finally {
         if (var8) {
            this.a.e();
            b.i.l var6 = this.h;
            if (var4 == var6.c) {
               var6.a.set(false);
            }

         }
      }

      this.a.e();
      b.i.l var11 = this.h;
      if (var4 == var11.c) {
         var11.a.set(false);
      }

      return var5;
   }

   public List a() {
      b.i.i var1 = b.i.i.a("SELECT id FROM workspec WHERE state NOT IN (2, 3, 5)", 0);
      this.a.b();
      Cursor var2 = b.i.o.b.a(this.a, var1, false, (CancellationSignal)null);

      ArrayList var3;
      label80: {
         Throwable var10000;
         label79: {
            boolean var10001;
            try {
               var3 = new ArrayList(var2.getCount());
            } catch (Throwable var9) {
               var10000 = var9;
               var10001 = false;
               break label79;
            }

            while(true) {
               try {
                  if (!var2.moveToNext()) {
                     break label80;
                  }

                  var3.add(var2.getString(0));
               } catch (Throwable var8) {
                  var10000 = var8;
                  var10001 = false;
                  break;
               }
            }
         }

         Throwable var10 = var10000;
         var2.close();
         var1.b();
         throw var10;
      }

      var2.close();
      var1.b();
      return var3;
   }

   public List a(int param1) {
      // $FF: Couldn't be decompiled
   }

   public List a(String var1) {
      b.i.i var2 = b.i.i.a("SELECT output FROM workspec WHERE id IN (SELECT prerequisite_id FROM dependency WHERE work_spec_id=?)", 1);
      if (var1 == null) {
         var2.b(1);
      } else {
         var2.a(1, (String)var1);
      }

      this.a.b();
      Cursor var10 = b.i.o.b.a(this.a, var2, false, (CancellationSignal)null);

      ArrayList var3;
      label95: {
         Throwable var10000;
         label94: {
            boolean var10001;
            try {
               var3 = new ArrayList(var10.getCount());
            } catch (Throwable var9) {
               var10000 = var9;
               var10001 = false;
               break label94;
            }

            while(true) {
               try {
                  if (!var10.moveToNext()) {
                     break label95;
                  }

                  var3.add(b.l.e.b(var10.getBlob(0)));
               } catch (Throwable var8) {
                  var10000 = var8;
                  var10001 = false;
                  break;
               }
            }
         }

         Throwable var11 = var10000;
         var10.close();
         var2.b();
         throw var11;
      }

      var10.close();
      var2.b();
      return var3;
   }

   public void a(String var1, b.l.e var2) {
      this.a.b();
      b.j.a.f var3 = this.d.a();
      byte[] var8 = b.l.e.a(var2);
      if (var8 == null) {
         var3.b(1);
      } else {
         var3.a(1, (byte[])var8);
      }

      if (var1 == null) {
         var3.b(2);
      } else {
         var3.a(2, (String)var1);
      }

      this.a.c();
      b.j.a.g.f var7 = (b.j.a.g.f)var3;
      boolean var5 = false;

      try {
         var5 = true;
         var7.a();
         this.a.k();
         var5 = false;
      } finally {
         if (var5) {
            this.a.e();
            this.d.a(var3);
         }
      }

      this.a.e();
      b.i.l var9 = this.d;
      if (var7 == var9.c) {
         var9.a.set(false);
      }

   }

   public b.l.s b(String var1) {
      b.i.i var2 = b.i.i.a("SELECT state FROM workspec WHERE id=?", 1);
      if (var1 == null) {
         var2.b(1);
      } else {
         var2.a(1, (String)var1);
      }

      this.a.b();
      b.i.g var3 = this.a;
      b.l.s var6 = null;
      Cursor var7 = b.i.o.b.a(var3, var2, false, (CancellationSignal)null);

      try {
         if (var7.moveToFirst()) {
            var6 = b.c.b.b.d(var7.getInt(0));
         }
      } finally {
         var7.close();
         var2.b();
      }

      return var6;
   }

   public List b() {
      // $FF: Couldn't be decompiled
   }

   public void b(String var1, long var2) {
      this.a.b();
      b.j.a.f var4 = this.e.a();
      var4.a(1, var2);
      if (var1 == null) {
         var4.b(2);
      } else {
         var4.a(2, (String)var1);
      }

      this.a.c();
      b.j.a.g.f var8 = (b.j.a.g.f)var4;

      try {
         var8.a();
         this.a.k();
      } finally {
         this.a.e();
         b.i.l var9 = this.e;
         if (var4 == var9.c) {
            var9.a.set(false);
         }

      }

   }

   public List c() {
      // $FF: Couldn't be decompiled
   }

   public List c(String var1) {
      b.i.i var2 = b.i.i.a("SELECT id FROM workspec WHERE state NOT IN (2, 3, 5) AND id IN (SELECT work_spec_id FROM workname WHERE name=?)", 1);
      if (var1 == null) {
         var2.b(1);
      } else {
         var2.a(1, (String)var1);
      }

      this.a.b();
      Cursor var10 = b.i.o.b.a(this.a, var2, false, (CancellationSignal)null);

      ArrayList var3;
      label95: {
         Throwable var10000;
         label94: {
            boolean var10001;
            try {
               var3 = new ArrayList(var10.getCount());
            } catch (Throwable var9) {
               var10000 = var9;
               var10001 = false;
               break label94;
            }

            while(true) {
               try {
                  if (!var10.moveToNext()) {
                     break label95;
                  }

                  var3.add(var10.getString(0));
               } catch (Throwable var8) {
                  var10000 = var8;
                  var10001 = false;
                  break;
               }
            }
         }

         Throwable var11 = var10000;
         var10.close();
         var2.b();
         throw var11;
      }

      var10.close();
      var2.b();
      return var3;
   }

   public p d(String param1) {
      // $FF: Couldn't be decompiled
   }

   public List e(String var1) {
      b.i.i var2 = b.i.i.a("SELECT id, state FROM workspec WHERE id IN (SELECT work_spec_id FROM workname WHERE name=?)", 1);
      if (var1 == null) {
         var2.b(1);
      } else {
         var2.a(1, (String)var1);
      }

      this.a.b();
      Cursor var13 = b.i.o.b.a(this.a, var2, false, (CancellationSignal)null);

      ArrayList var5;
      label95: {
         Throwable var10000;
         label94: {
            int var3;
            int var4;
            boolean var10001;
            try {
               var3 = b.c.b.b.a(var13, "id");
               var4 = b.c.b.b.a(var13, "state");
               var5 = new ArrayList(var13.getCount());
            } catch (Throwable var12) {
               var10000 = var12;
               var10001 = false;
               break label94;
            }

            while(true) {
               try {
                  if (!var13.moveToNext()) {
                     break label95;
                  }

                  p.a var14 = new p.a();
                  var14.a = var13.getString(var3);
                  var14.b = b.c.b.b.d(var13.getInt(var4));
                  var5.add(var14);
               } catch (Throwable var11) {
                  var10000 = var11;
                  var10001 = false;
                  break;
               }
            }
         }

         Throwable var6 = var10000;
         var13.close();
         var2.b();
         throw var6;
      }

      var13.close();
      var2.b();
      return var5;
   }

   public int f(String var1) {
      this.a.b();
      b.j.a.f var2 = this.f.a();
      if (var1 == null) {
         var2.b(1);
      } else {
         var2.a(1, (String)var1);
      }

      this.a.c();
      b.j.a.g.f var7 = (b.j.a.g.f)var2;
      boolean var5 = false;

      int var3;
      try {
         var5 = true;
         var3 = var7.a();
         this.a.k();
         var5 = false;
      } finally {
         if (var5) {
            this.a.e();
            this.f.a(var2);
         }
      }

      this.a.e();
      b.i.l var8 = this.f;
      if (var7 == var8.c) {
         var8.a.set(false);
      }

      return var3;
   }

   public int g(String var1) {
      this.a.b();
      b.j.a.f var2 = this.g.a();
      if (var1 == null) {
         var2.b(1);
      } else {
         var2.a(1, (String)var1);
      }

      this.a.c();
      b.j.a.g.f var7 = (b.j.a.g.f)var2;
      boolean var5 = false;

      int var3;
      try {
         var5 = true;
         var3 = var7.a();
         this.a.k();
         var5 = false;
      } finally {
         if (var5) {
            this.a.e();
            this.g.a(var2);
         }
      }

      this.a.e();
      b.i.l var8 = this.g;
      if (var7 == var8.c) {
         var8.a.set(false);
      }

      return var3;
   }
}
