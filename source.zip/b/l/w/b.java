package b.l.w;

import b.f.n;
import b.l.o;

public class b implements o {
   public final n c = new n();
   public final b.l.w.r.m.c d = new b.l.w.r.m.c();

   public b() {
      this.a(o.b);
   }

   public void a(o.b var1) {
      this.c.a(var1);
      if (var1 instanceof o.b.c) {
         this.d.c((o.b.c)var1);
      } else if (var1 instanceof o.b.a) {
         o.b.a var2 = (o.b.a)var1;
         this.d.a(var2.a);
      }

   }
}
