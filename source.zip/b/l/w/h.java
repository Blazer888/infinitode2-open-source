package b.l.w;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build.VERSION;

public class h {
   public static b.i.n.a a = new b.i.n.a(1, 2) {
      public void a(b.j.a.b var1) {
         ((b.j.a.g.a)var1).a.execSQL("CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
         b.j.a.g.a var2 = (b.j.a.g.a)var1;
         var2.a.execSQL("INSERT INTO SystemIdInfo(work_spec_id, system_id) SELECT work_spec_id, alarm_id AS system_id FROM alarmInfo");
         var2.a.execSQL("DROP TABLE IF EXISTS alarmInfo");
         var2.a.execSQL("INSERT OR IGNORE INTO worktag(tag, work_spec_id) SELECT worker_class_name AS tag, id AS work_spec_id FROM workspec");
      }
   };
   public static b.i.n.a b = new b.i.n.a(3, 4) {
      public void a(b.j.a.b var1) {
         if (VERSION.SDK_INT >= 23) {
            ((b.j.a.g.a)var1).a.execSQL("UPDATE workspec SET schedule_requested_at=0 WHERE state NOT IN (2, 3, 5) AND schedule_requested_at=-1 AND interval_duration<>0");
         }

      }
   };
   public static b.i.n.a c = new b.i.n.a(4, 5) {
      public void a(b.j.a.b var1) {
         ((b.j.a.g.a)var1).a.execSQL("ALTER TABLE workspec ADD COLUMN `trigger_content_update_delay` INTEGER NOT NULL DEFAULT -1");
         ((b.j.a.g.a)var1).a.execSQL("ALTER TABLE workspec ADD COLUMN `trigger_max_content_delay` INTEGER NOT NULL DEFAULT -1");
      }
   };
   public static b.i.n.a d = new b.i.n.a(6, 7) {
      public void a(b.j.a.b var1) {
         ((b.j.a.g.a)var1).a.execSQL("CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      }
   };
   public static b.i.n.a e = new b.i.n.a(7, 8) {
      public void a(b.j.a.b var1) {
         ((b.j.a.g.a)var1).a.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `workspec` (`period_start_time`)");
      }
   };
   public static b.i.n.a f = new b.i.n.a(8, 9) {
      public void a(b.j.a.b var1) {
         ((b.j.a.g.a)var1).a.execSQL("ALTER TABLE workspec ADD COLUMN `run_in_foreground` INTEGER NOT NULL DEFAULT 0");
      }
   };

   public static class g extends b.i.n.a {
      public final Context c;

      public g(Context var1, int var2, int var3) {
         super(var2, var3);
         this.c = var1;
      }

      public void a(b.j.a.b var1) {
         if (super.b >= 10) {
            ((b.j.a.g.a)var1).a.execSQL("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", new Object[]{"reschedule_needed", 1});
         } else {
            this.c.getSharedPreferences("androidx.work.util.preferences", 0).edit().putBoolean("reschedule_needed", true).apply();
         }

      }
   }

   public static class h extends b.i.n.a {
      public final Context c;

      public h(Context var1) {
         super(9, 10);
         this.c = var1;
      }

      public void a(b.j.a.b var1) {
         ((b.j.a.g.a)var1).a.execSQL("CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))");
         SharedPreferences var2 = this.c.getSharedPreferences("androidx.work.util.preferences", 0);
         b.j.a.g.a var7;
         if (var2.contains("reschedule_needed") || var2.contains("last_cancel_all_time_ms")) {
            long var3 = 0L;
            long var5 = var2.getLong("last_cancel_all_time_ms", 0L);
            if (var2.getBoolean("reschedule_needed", false)) {
               var3 = 1L;
            }

            var7 = (b.j.a.g.a)var1;
            var7.a.beginTransaction();

            try {
               ((b.j.a.g.a)var1).a.execSQL("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", new Object[]{"last_cancel_all_time_ms", var5});
               ((b.j.a.g.a)var1).a.execSQL("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", new Object[]{"reschedule_needed", var3});
               var2.edit().clear().apply();
               ((b.j.a.g.a)var1).a.setTransactionSuccessful();
            } finally {
               var7.a.endTransaction();
            }
         }

         var2 = this.c.getSharedPreferences("androidx.work.util.id", 0);
         if (var2.contains("next_job_scheduler_id") || var2.contains("next_job_scheduler_id")) {
            int var8 = var2.getInt("next_job_scheduler_id", 0);
            int var9 = var2.getInt("next_alarm_manager_id", 0);
            var7 = (b.j.a.g.a)var1;
            var7.a.beginTransaction();

            try {
               ((b.j.a.g.a)var1).a.execSQL("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", new Object[]{"next_job_scheduler_id", var8});
               ((b.j.a.g.a)var1).a.execSQL("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", new Object[]{"next_alarm_manager_id", var9});
               var2.edit().clear().apply();
               ((b.j.a.g.a)var1).a.setTransactionSuccessful();
            } finally {
               var7.a.endTransaction();
            }
         }

      }
   }
}
