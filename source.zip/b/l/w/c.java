package b.l.w;

import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.PowerManager.WakeLock;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.foreground.SystemForegroundService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;

public class c implements b.l.w.a, b.l.w.p.a {
   public static final String l = b.l.l.a("Processor");
   public WakeLock a;
   public Context b;
   public b.l.b c;
   public b.l.w.r.n.a d;
   public WorkDatabase e;
   public Map f;
   public Map g;
   public List h;
   public Set i;
   public final List j;
   public final Object k;

   public c(Context var1, b.l.b var2, b.l.w.r.n.a var3, WorkDatabase var4, List var5) {
      this.b = var1;
      this.c = var2;
      this.d = var3;
      this.e = var4;
      this.g = new HashMap();
      this.f = new HashMap();
      this.h = var5;
      this.i = new HashSet();
      this.j = new ArrayList();
      this.a = null;
      this.k = new Object();
   }

   public static boolean a(String var0, m var1) {
      if (var1 != null) {
         var1.s = true;
         var1.f();
         c.c.c.a.a.a var2 = var1.r;
         boolean var3;
         if (var2 != null) {
            var3 = var2.isDone();
            var1.r.cancel(true);
         } else {
            var3 = false;
         }

         ListenableWorker var5 = var1.f;
         if (var5 != null && !var3) {
            var5.stop();
         } else {
            String var4 = String.format("WorkSpec %s is already done. Not interrupting.", var1.e);
            b.l.l.a().a(m.t, var4);
         }

         b.l.l.a().a(l, String.format("WorkerWrapper interrupted for %s", var0));
         return true;
      } else {
         b.l.l.a().a(l, String.format("WorkerWrapper could not be found for %s", var0));
         return false;
      }
   }

   public final void a() {
      Object var1 = this.k;
      synchronized(var1){}

      Throwable var10000;
      boolean var10001;
      label340: {
         label344: {
            SystemForegroundService var2;
            try {
               if (this.f.isEmpty() ^ true) {
                  break label344;
               }

               var2 = SystemForegroundService.g;
            } catch (Throwable var44) {
               var10000 = var44;
               var10001 = false;
               break label340;
            }

            if (var2 != null) {
               try {
                  b.l.l.a().a(l, "No more foreground work. Stopping SystemForegroundService");
                  var2.c();
               } catch (Throwable var43) {
                  var10000 = var43;
                  var10001 = false;
                  break label340;
               }
            } else {
               try {
                  b.l.l.a().a(l, "No more foreground work. SystemForegroundService is already stopped");
               } catch (Throwable var42) {
                  var10000 = var42;
                  var10001 = false;
                  break label340;
               }
            }

            try {
               if (this.a != null) {
                  this.a.release();
                  this.a = null;
               }
            } catch (Throwable var41) {
               var10000 = var41;
               var10001 = false;
               break label340;
            }
         }

         label327:
         try {
            return;
         } catch (Throwable var40) {
            var10000 = var40;
            var10001 = false;
            break label327;
         }
      }

      while(true) {
         Throwable var45 = var10000;

         try {
            throw var45;
         } catch (Throwable var39) {
            var10000 = var39;
            var10001 = false;
            continue;
         }
      }
   }

   public void a(b.l.w.a param1) {
      // $FF: Couldn't be decompiled
   }

   public void a(String var1, b.l.g var2) {
      Object var3 = this.k;
      synchronized(var3){}

      Throwable var10000;
      boolean var10001;
      label374: {
         m var4;
         try {
            b.l.l.a().c(l, String.format("Moving WorkSpec (%s) to the foreground", var1));
            var4 = (m)this.g.remove(var1);
         } catch (Throwable var46) {
            var10000 = var46;
            var10001 = false;
            break label374;
         }

         if (var4 != null) {
            label376: {
               try {
                  if (this.a == null) {
                     this.a = b.l.w.r.i.a(this.b, "ProcessorForegroundLck");
                     this.a.acquire();
                  }
               } catch (Throwable var44) {
                  var10000 = var44;
                  var10001 = false;
                  break label374;
               }

               Intent var47;
               Context var49;
               try {
                  this.f.put(var1, var4);
                  var47 = b.l.w.p.c.b(this.b, var1, var2);
                  var49 = this.b;
                  if (VERSION.SDK_INT >= 26) {
                     var49.startForegroundService(var47);
                     break label376;
                  }
               } catch (Throwable var45) {
                  var10000 = var45;
                  var10001 = false;
                  break label374;
               }

               try {
                  var49.startService(var47);
               } catch (Throwable var43) {
                  var10000 = var43;
                  var10001 = false;
                  break label374;
               }
            }
         }

         label354:
         try {
            return;
         } catch (Throwable var42) {
            var10000 = var42;
            var10001 = false;
            break label354;
         }
      }

      while(true) {
         Throwable var48 = var10000;

         try {
            throw var48;
         } catch (Throwable var41) {
            var10000 = var41;
            var10001 = false;
            continue;
         }
      }
   }

   public void a(String var1, boolean var2) {
      Object var3 = this.k;
      synchronized(var3){}

      Throwable var10000;
      boolean var10001;
      label200: {
         Iterator var4;
         try {
            this.g.remove(var1);
            b.l.l.a().a(l, String.format("%s %s executed; reschedule = %s", this.getClass().getSimpleName(), var1, var2));
            var4 = this.j.iterator();
         } catch (Throwable var23) {
            var10000 = var23;
            var10001 = false;
            break label200;
         }

         while(true) {
            try {
               if (var4.hasNext()) {
                  ((b.l.w.a)var4.next()).a(var1, var2);
                  continue;
               }
            } catch (Throwable var24) {
               var10000 = var24;
               var10001 = false;
               break;
            }

            try {
               return;
            } catch (Throwable var22) {
               var10000 = var22;
               var10001 = false;
               break;
            }
         }
      }

      while(true) {
         Throwable var25 = var10000;

         try {
            throw var25;
         } catch (Throwable var21) {
            var10000 = var21;
            var10001 = false;
            continue;
         }
      }
   }

   public boolean a(String param1) {
      // $FF: Couldn't be decompiled
   }

   public boolean a(String var1, WorkerParameters.a var2) {
      Object var3 = this.k;
      synchronized(var3){}

      Throwable var10000;
      boolean var10001;
      label277: {
         try {
            if (this.g.containsKey(var1)) {
               b.l.l.a().a(l, String.format("Work %s is already enqueued for processing", var1));
               return false;
            }
         } catch (Throwable var35) {
            var10000 = var35;
            var10001 = false;
            break label277;
         }

         m.a var4;
         try {
            var4 = new m.a(this.b, this.c, this.d, this, this.e, var1);
            var4.h = this.h;
         } catch (Throwable var34) {
            var10000 = var34;
            var10001 = false;
            break label277;
         }

         if (var2 != null) {
            try {
               var4.i = var2;
            } catch (Throwable var33) {
               var10000 = var33;
               var10001 = false;
               break label277;
            }
         }

         m var37;
         try {
            var37 = new m(var4);
            b.l.w.r.m.c var38 = var37.q;
            c.a var5 = new c.a(this, var1, var38);
            var38.a(var5, ((b.l.w.r.n.b)this.d).c);
            this.g.put(var1, var37);
         } catch (Throwable var32) {
            var10000 = var32;
            var10001 = false;
            break label277;
         }

         ((b.l.w.r.n.b)this.d).a.execute(var37);
         b.l.l.a().a(l, String.format("%s: processing %s", c.class.getSimpleName(), var1));
         return true;
      }

      while(true) {
         Throwable var36 = var10000;

         try {
            throw var36;
         } catch (Throwable var31) {
            var10000 = var31;
            var10001 = false;
            continue;
         }
      }
   }

   public void b(b.l.w.a param1) {
      // $FF: Couldn't be decompiled
   }

   public boolean b(String var1) {
      Object var2 = this.k;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label151: {
         boolean var3;
         label150: {
            label149: {
               try {
                  if (!this.g.containsKey(var1) && !this.f.containsKey(var1)) {
                     break label149;
                  }
               } catch (Throwable var15) {
                  var10000 = var15;
                  var10001 = false;
                  break label151;
               }

               var3 = true;
               break label150;
            }

            var3 = false;
         }

         label140:
         try {
            return var3;
         } catch (Throwable var14) {
            var10000 = var14;
            var10001 = false;
            break label140;
         }
      }

      while(true) {
         Throwable var16 = var10000;

         try {
            throw var16;
         } catch (Throwable var13) {
            var10000 = var13;
            var10001 = false;
            continue;
         }
      }
   }

   public boolean c(String var1) {
      Object var2 = this.k;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label466: {
         b.l.l var3;
         String var4;
         try {
            var3 = b.l.l.a();
            var4 = l;
         } catch (Throwable var62) {
            var10000 = var62;
            var10001 = false;
            break label466;
         }

         boolean var5 = true;

         m var65;
         try {
            var3.a(var4, String.format("Processor cancelling %s", var1));
            this.i.add(var1);
            var65 = (m)this.f.remove(var1);
         } catch (Throwable var61) {
            var10000 = var61;
            var10001 = false;
            break label466;
         }

         if (var65 == null) {
            var5 = false;
         }

         m var64 = var65;
         if (var65 == null) {
            try {
               var64 = (m)this.g.remove(var1);
            } catch (Throwable var60) {
               var10000 = var60;
               var10001 = false;
               break label466;
            }
         }

         boolean var6;
         try {
            var6 = a(var1, var64);
         } catch (Throwable var59) {
            var10000 = var59;
            var10001 = false;
            break label466;
         }

         if (var5) {
            try {
               this.a();
            } catch (Throwable var58) {
               var10000 = var58;
               var10001 = false;
               break label466;
            }
         }

         label443:
         try {
            return var6;
         } catch (Throwable var57) {
            var10000 = var57;
            var10001 = false;
            break label443;
         }
      }

      while(true) {
         Throwable var63 = var10000;

         try {
            throw var63;
         } catch (Throwable var56) {
            var10000 = var56;
            var10001 = false;
            continue;
         }
      }
   }

   public void d(String param1) {
      // $FF: Couldn't be decompiled
   }

   public boolean e(String param1) {
      // $FF: Couldn't be decompiled
   }

   public boolean f(String param1) {
      // $FF: Couldn't be decompiled
   }

   public static class a implements Runnable {
      public b.l.w.a a;
      public String b;
      public c.c.c.a.a.a c;

      public a(b.l.w.a var1, String var2, c.c.c.a.a.a var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }

      public void run() {
         boolean var1;
         try {
            var1 = (Boolean)this.c.get();
         } catch (ExecutionException | InterruptedException var3) {
            var1 = true;
         }

         this.a.a(this.b, var1);
      }
   }
}
