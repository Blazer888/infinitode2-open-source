package b.l.w;

import android.content.Context;
import android.os.Build.VERSION;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.background.systemalarm.SystemAlarmService;
import androidx.work.impl.background.systemjob.SystemJobService;
import b.l.w.q.p;
import b.l.w.q.q;
import b.l.w.q.r;
import java.util.Iterator;
import java.util.List;

public class e {
   public static final String a = b.l.l.a("Schedulers");

   public static d a(Context var0, j var1) {
      Object var5;
      if (VERSION.SDK_INT >= 23) {
         var5 = new b.l.w.n.c.b(var0, var1);
         b.l.w.r.d.a(var0, SystemJobService.class, true);
         b.l.l.a().a(a, "Created SystemJobScheduler and enabled SystemJobService");
      } else {
         d var6;
         label32:
         try {
            var6 = (d)Class.forName("androidx.work.impl.background.gcm.GcmScheduler").getConstructor(Context.class).newInstance(var0);
            b.l.l.a().a(a, String.format("Created %s", "androidx.work.impl.background.gcm.GcmScheduler"));
         } catch (Throwable var4) {
            b.l.l.a().a(a, "Unable to create GCM Scheduler", var4);
            var6 = null;
            break label32;
         }

         d var2 = var6;
         var5 = var6;
         if (var2 == null) {
            var5 = new b.l.w.n.b.f(var0);
            b.l.w.r.d.a(var0, SystemAlarmService.class, true);
            b.l.l.a().a(a, "Created SystemAlarmScheduler");
         }
      }

      return (d)var5;
   }

   public static void a(b.l.b var0, WorkDatabase var1, List var2) {
      if (var2 != null && var2.size() != 0) {
         q var3 = var1.q();
         var1.c();

         List var5;
         label294: {
            Throwable var10000;
            label301: {
               int var4;
               boolean var10001;
               try {
                  var4 = var0.b();
               } catch (Throwable var27) {
                  var10000 = var27;
                  var10001 = false;
                  break label301;
               }

               r var28 = (r)var3;

               label288: {
                  Iterator var32;
                  long var6;
                  try {
                     var5 = var28.a(var4);
                     if (var5.size() <= 0) {
                        break label288;
                     }

                     var6 = System.currentTimeMillis();
                     var32 = var5.iterator();
                  } catch (Throwable var26) {
                     var10000 = var26;
                     var10001 = false;
                     break label301;
                  }

                  while(true) {
                     try {
                        if (!var32.hasNext()) {
                           break;
                        }

                        var28.a(((p)var32.next()).a, var6);
                     } catch (Throwable var25) {
                        var10000 = var25;
                        var10001 = false;
                        break label301;
                     }
                  }
               }

               label277:
               try {
                  var1.k();
                  break label294;
               } catch (Throwable var24) {
                  var10000 = var24;
                  var10001 = false;
                  break label277;
               }
            }

            Throwable var29 = var10000;
            var1.e();
            throw var29;
         }

         var1.e();
         if (var5.size() > 0) {
            p[] var30 = (p[])var5.toArray(new p[0]);
            Iterator var31 = var2.iterator();

            while(var31.hasNext()) {
               ((d)var31.next()).a(var30);
            }
         }

      }
   }
}
