package b.l.w;

import android.content.Context;
import android.content.BroadcastReceiver.PendingResult;
import android.os.Build.VERSION;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.utils.ForceStopRunnable;
import b.l.o;
import b.l.q;
import b.l.t;
import b.l.w.q.r;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class j extends t {
   public static j j;
   public static j k;
   public static final Object l = new Object();
   public Context a;
   public b.l.b b;
   public WorkDatabase c;
   public b.l.w.r.n.a d;
   public List e;
   public c f;
   public b.l.w.r.e g;
   public boolean h;
   public PendingResult i;

   public j(Context var1, b.l.b var2, b.l.w.r.n.a var3) {
      boolean var4 = var1.getResources().getBoolean(q.workmanager_test_configuration);
      WorkDatabase var5 = WorkDatabase.a(var1.getApplicationContext(), ((b.l.w.r.n.b)var3).a, var4);
      super();
      Context var6 = var1.getApplicationContext();
      b.l.l.a((b.l.l)(new b.l.l.a(var2.e)));
      List var7 = Arrays.asList(b.l.w.e.a(var6, this), new b.l.w.n.a.a(var6, var3, this));
      c var10 = new c(var1, var2, var3, var5, var7);
      var1 = var1.getApplicationContext();
      this.a = var1;
      this.b = var2;
      this.d = var3;
      this.c = var5;
      this.e = var7;
      this.f = var10;
      this.g = new b.l.w.r.e(var5);
      this.h = false;
      b.l.w.r.n.a var9 = this.d;
      ForceStopRunnable var8 = new ForceStopRunnable(var1, this);
      ((b.l.w.r.n.b)var9).a.execute(var8);
   }

   public static j a(Context var0) {
      Object var1 = l;
      synchronized(var1){}

      Throwable var10000;
      boolean var10001;
      label287: {
         j var2;
         try {
            var2 = c();
         } catch (Throwable var33) {
            var10000 = var33;
            var10001 = false;
            break label287;
         }

         label279: {
            j var3 = var2;
            if (var2 == null) {
               try {
                  var0 = var0.getApplicationContext();
                  if (!(var0 instanceof b.l.b.b)) {
                     break label279;
                  }

                  a(var0, ((b.l.b.b)var0).a());
                  var3 = a(var0);
               } catch (Throwable var32) {
                  var10000 = var32;
                  var10001 = false;
                  break label287;
               }
            }

            try {
               return var3;
            } catch (Throwable var31) {
               var10000 = var31;
               var10001 = false;
               break label287;
            }
         }

         label269:
         try {
            IllegalStateException var35 = new IllegalStateException("WorkManager is not initialized properly.  You have explicitly disabled WorkManagerInitializer in your manifest, have not manually called WorkManager#initialize at this point, and your Application does not implement Configuration.Provider.");
            throw var35;
         } catch (Throwable var30) {
            var10000 = var30;
            var10001 = false;
            break label269;
         }
      }

      while(true) {
         Throwable var34 = var10000;

         try {
            throw var34;
         } catch (Throwable var29) {
            var10000 = var29;
            var10001 = false;
            continue;
         }
      }
   }

   public static void a(Context var0, b.l.b var1) {
      Object var2 = l;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label409: {
         label415: {
            try {
               if (j != null && k != null) {
                  break label415;
               }
            } catch (Throwable var46) {
               var10000 = var46;
               var10001 = false;
               break label409;
            }

            label398: {
               try {
                  if (j != null) {
                     break label398;
                  }

                  Context var3 = var0.getApplicationContext();
                  if (k == null) {
                     b.l.w.r.n.b var47 = new b.l.w.r.n.b(var1.b);
                     j var4 = new j(var3, var1, var47);
                     k = var4;
                  }
               } catch (Throwable var45) {
                  var10000 = var45;
                  var10001 = false;
                  break label409;
               }

               try {
                  j = k;
               } catch (Throwable var44) {
                  var10000 = var44;
                  var10001 = false;
                  break label409;
               }
            }

            try {
               return;
            } catch (Throwable var43) {
               var10000 = var43;
               var10001 = false;
               break label409;
            }
         }

         label389:
         try {
            IllegalStateException var49 = new IllegalStateException("WorkManager is already initialized.  Did you try to initialize it manually without disabling WorkManagerInitializer? See WorkManager#initialize(Context, Configuration) or the class level Javadoc for more information.");
            throw var49;
         } catch (Throwable var42) {
            var10000 = var42;
            var10001 = false;
            break label389;
         }
      }

      while(true) {
         Throwable var48 = var10000;

         try {
            throw var48;
         } catch (Throwable var41) {
            var10000 = var41;
            var10001 = false;
            continue;
         }
      }
   }

   @Deprecated
   public static j c() {
      Object var0 = l;
      synchronized(var0){}

      Throwable var10000;
      boolean var10001;
      label123: {
         j var14;
         try {
            if (j != null) {
               var14 = j;
               return var14;
            }
         } catch (Throwable var13) {
            var10000 = var13;
            var10001 = false;
            break label123;
         }

         label117:
         try {
            var14 = k;
            return var14;
         } catch (Throwable var12) {
            var10000 = var12;
            var10001 = false;
            break label117;
         }
      }

      while(true) {
         Throwable var1 = var10000;

         try {
            throw var1;
         } catch (Throwable var11) {
            var10000 = var11;
            var10001 = false;
            continue;
         }
      }
   }

   public o a(String var1) {
      b.l.w.r.a var2 = b.l.w.r.a.a(var1, this, true);
      ((b.l.w.r.n.b)this.d).a.execute(var2);
      return var2.a;
   }

   public o a(UUID var1) {
      b.l.w.r.a var2 = b.l.w.r.a.a(var1, this);
      ((b.l.w.r.n.b)this.d).a.execute(var2);
      return var2.a;
   }

   public void a() {
      Object var1 = l;
      synchronized(var1){}

      Throwable var10000;
      boolean var10001;
      label122: {
         try {
            this.h = true;
            if (this.i != null) {
               this.i.finish();
               this.i = null;
            }
         } catch (Throwable var14) {
            var10000 = var14;
            var10001 = false;
            break label122;
         }

         label119:
         try {
            return;
         } catch (Throwable var13) {
            var10000 = var13;
            var10001 = false;
            break label119;
         }
      }

      while(true) {
         Throwable var2 = var10000;

         try {
            throw var2;
         } catch (Throwable var12) {
            var10000 = var12;
            var10001 = false;
            continue;
         }
      }
   }

   public void a(PendingResult var1) {
      Object var2 = l;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label122: {
         try {
            this.i = var1;
            if (this.h) {
               this.i.finish();
               this.i = null;
            }
         } catch (Throwable var14) {
            var10000 = var14;
            var10001 = false;
            break label122;
         }

         label119:
         try {
            return;
         } catch (Throwable var13) {
            var10000 = var13;
            var10001 = false;
            break label119;
         }
      }

      while(true) {
         Throwable var15 = var10000;

         try {
            throw var15;
         } catch (Throwable var12) {
            var10000 = var12;
            var10001 = false;
            continue;
         }
      }
   }

   public void b() {
      if (VERSION.SDK_INT >= 23) {
         b.l.w.n.c.b.a(this.a);
      }

      r var1 = (r)this.c.q();
      var1.a.b();
      b.j.a.f var2 = var1.i.a();
      var1.a.c();
      b.j.a.g.f var3 = (b.j.a.g.f)var2;
      boolean var5 = false;

      try {
         var5 = true;
         var3.a();
         var1.a.k();
         var5 = false;
      } finally {
         if (var5) {
            var1.a.e();
            var1.i.a(var2);
         }
      }

      var1.a.e();
      b.i.l var7 = var1.i;
      if (var3 == var7.c) {
         var7.a.set(false);
      }

      b.l.w.e.a(this.b, this.c, this.e);
   }

   public void b(String var1) {
      b.l.w.r.n.a var2 = this.d;
      b.l.w.r.g var3 = new b.l.w.r.g(this, var1, (WorkerParameters.a)null);
      ((b.l.w.r.n.b)var2).a.execute(var3);
   }

   public void c(String var1) {
      b.l.w.r.n.a var2 = this.d;
      b.l.w.r.h var3 = new b.l.w.r.h(this, var1, false);
      ((b.l.w.r.n.b)var2).a.execute(var3);
   }
}
