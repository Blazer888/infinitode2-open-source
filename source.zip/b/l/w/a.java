package b.l.w;

public interface a {
   void a(String var1, boolean var2);
}
