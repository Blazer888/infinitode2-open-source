package b.l.w.r;

import android.content.Context;
import androidx.work.impl.WorkDatabase;
import b.l.p;
import b.l.s;
import b.l.w.q.m;
import b.l.w.q.o;
import b.l.w.q.q;
import b.l.w.q.r;
import java.util.UUID;

public class k implements p {
   public static final String c = b.l.l.a("WorkProgressUpdater");
   public final WorkDatabase a;
   public final b.l.w.r.n.a b;

   public k(WorkDatabase var1, b.l.w.r.n.a var2) {
      this.a = var1;
      this.b = var2;
   }

   public c.c.c.a.a.a a(Context var1, final UUID var2, final b.l.e var3) {
      final b.l.w.r.m.c var4 = new b.l.w.r.m.c();
      b.l.w.r.n.a var5 = this.b;
      Runnable var6 = new Runnable() {
         public void run() {
            String var1 = var2.toString();
            b.l.l.a().a(k.c, String.format("Updating progress for %s (%s)", var2, var3));
            k.this.a.c();

            Throwable var10000;
            label724: {
               q var2x;
               boolean var10001;
               try {
                  var2x = k.this.a.q();
               } catch (Throwable var108) {
                  var10000 = var108;
                  var10001 = false;
                  break label724;
               }

               r var111 = (r)var2x;

               b.l.w.q.p var112;
               try {
                  var112 = var111.d(var1);
               } catch (Throwable var107) {
                  var10000 = var107;
                  var10001 = false;
                  break label724;
               }

               if (var112 != null) {
                  label709: {
                     label708: {
                        o var109;
                        m var113;
                        try {
                           if (var112.b != s.b) {
                              break label708;
                           }

                           var113 = new m(var1, var3);
                           var109 = (o)k.this.a.p();
                           var109.a.b();
                           var109.a.c();
                        } catch (Throwable var106) {
                           var10000 = var106;
                           var10001 = false;
                           break label724;
                        }

                        try {
                           var109.b.a(var113);
                           var109.a.k();
                           break label709;
                        } finally {
                           try {
                              var109.a.e();
                           } catch (Throwable var101) {
                              var10000 = var101;
                              var10001 = false;
                              break label724;
                           }
                        }
                     }

                     try {
                        b.l.l.a().d(k.c, String.format("Ignoring setProgressAsync(...). WorkSpec (%s) is not in a RUNNING state.", var1));
                     } catch (Throwable var104) {
                        var10000 = var104;
                        var10001 = false;
                        break label724;
                     }
                  }
               } else {
                  try {
                     b.l.l.a().d(k.c, String.format("Ignoring setProgressAsync(...). WorkSpec (%s) does not exist.", var1));
                  } catch (Throwable var103) {
                     var10000 = var103;
                     var10001 = false;
                     break label724;
                  }
               }

               label698:
               try {
                  var4.c((Object)null);
                  k.this.a.k();
                  return;
               } catch (Throwable var102) {
                  var10000 = var102;
                  var10001 = false;
                  break label698;
               }
            }

            Throwable var110 = var10000;

            try {
               b.l.l.a().b(k.c, "Error updating Worker progress", var110);
               var4.a(var110);
            } finally {
               k.this.a.e();
            }

         }
      };
      ((b.l.w.r.n.b)var5).a.execute(var6);
      return var4;
   }
}
