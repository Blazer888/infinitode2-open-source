package b.l.w.r;

import android.os.Build.VERSION;
import android.text.TextUtils;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.background.systemalarm.RescheduleReceiver;
import androidx.work.impl.workers.ConstraintTrackingWorker;
import b.l.o;
import b.l.s;
import b.l.u;
import b.l.w.q.p;
import b.l.w.q.q;
import b.l.w.q.r;
import b.l.w.q.t;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class b implements Runnable {
   public static final String c = b.l.l.a("EnqueueRunnable");
   public final b.l.w.f a;
   public final b.l.w.b b;

   public b(b.l.w.f var1) {
      this.a = var1;
      this.b = new b.l.w.b();
   }

   public static void a(p var0) {
      b.l.c var1 = var0.j;
      if (var1.d || var1.e) {
         String var2 = var0.c;
         b.l.e.a var3 = new b.l.e.a();
         var3.a(var0.e.a);
         var3.a.put("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME", var2);
         var0.c = ConstraintTrackingWorker.class.getName();
         var0.e = var3.a();
      }

   }

   public static boolean a(b.l.w.f var0) {
      List var1 = var0.g;
      Iterator var2;
      boolean var3;
      boolean var4;
      if (var1 != null) {
         var2 = var1.iterator();
         var3 = false;

         while(true) {
            var4 = var3;
            if (!var2.hasNext()) {
               break;
            }

            b.l.w.f var67 = (b.l.w.f)var2.next();
            if (!var67.h) {
               var3 |= a(var67);
            } else {
               b.l.l.a().d(c, String.format("Already enqueued work ids (%s).", TextUtils.join(", ", var67.e)));
            }
         }
      } else {
         var4 = false;
      }

      Set var68 = b.l.w.f.a(var0);
      b.l.w.j var5 = var0.a;
      List var6 = var0.d;
      String[] var69 = (String[])var68.toArray(new String[0]);
      String var7 = var0.b;
      b.l.f var8 = var0.c;
      long var9 = System.currentTimeMillis();
      WorkDatabase var11 = var5.c;
      boolean var12;
      if (var69 != null && var69.length > 0) {
         var12 = true;
      } else {
         var12 = false;
      }

      boolean var18;
      label1687: {
         int var13;
         boolean var15;
         boolean var16;
         boolean var17;
         boolean var19;
         boolean var83;
         Iterator var84;
         r var86;
         label1671: {
            label1670: {
               label1704: {
                  if (var12) {
                     var13 = var69.length;
                     int var14 = 0;
                     var15 = true;
                     var16 = false;
                     var17 = false;

                     while(true) {
                        var18 = var15;
                        var3 = var16;
                        var19 = var17;
                        if (var14 >= var13) {
                           break;
                        }

                        String var70 = var69[var14];
                        p var20 = ((r)var11.q()).d(var70);
                        if (var20 == null) {
                           b.l.l.a().b(c, String.format("Prerequisite %s doesn't exist; not enqueuing", var70));
                           break label1704;
                        }

                        s var71 = var20.b;
                        if (var71 == s.c) {
                           var3 = true;
                        } else {
                           var3 = false;
                        }

                        var15 &= var3;
                        if (var71 == s.d) {
                           var3 = true;
                        } else {
                           var3 = var17;
                           if (var71 == s.f) {
                              var16 = true;
                              var3 = var17;
                           }
                        }

                        ++var14;
                        var17 = var3;
                     }
                  } else {
                     var18 = true;
                     var3 = false;
                     var19 = false;
                  }

                  var83 = TextUtils.isEmpty(var7) ^ true;
                  if (var83 && !var12) {
                     var17 = true;
                  } else {
                     var17 = false;
                  }

                  if (!var17) {
                     break label1670;
                  }

                  List var72 = ((r)var11.q()).e(var7);
                  if (var72.isEmpty()) {
                     break label1670;
                  }

                  String var22;
                  if (var8 == b.l.f.c) {
                     b.l.w.q.b var77 = var11.l();
                     ArrayList var88 = new ArrayList();

                     for(var2 = var72.iterator(); var2.hasNext(); var19 = var12) {
                        p.a var89 = (p.a)var2.next();
                        var22 = var89.a;
                        var16 = var18;
                        var17 = var3;
                        var12 = var19;
                        if (!((b.l.w.q.c)var77).c(var22)) {
                           if (var89.b == s.c) {
                              var17 = true;
                           } else {
                              var17 = false;
                           }

                           s var97 = var89.b;
                           if (var97 == s.d) {
                              var12 = true;
                           } else {
                              var12 = var19;
                              if (var97 == s.f) {
                                 var3 = true;
                                 var12 = var19;
                              }
                           }

                           var88.add(var89.a);
                           var16 = var17 & var18;
                           var17 = var3;
                        }

                        var18 = var16;
                        var3 = var17;
                     }

                     var69 = (String[])var88.toArray(var69);
                     if (var69.length > 0) {
                        var12 = true;
                     } else {
                        var12 = false;
                     }
                     break label1670;
                  }

                  if (var8 == b.l.f.b) {
                     var84 = var72.iterator();

                     while(var84.hasNext()) {
                        s var75 = ((p.a)var84.next()).b;
                        if (var75 == s.a || var75 == s.b) {
                           break label1704;
                        }
                     }
                  }

                  b.l.w.r.a.a(var7, var5, false).run();
                  q var76 = var11.q();
                  var2 = var72.iterator();

                  while(var2.hasNext()) {
                     var22 = ((p.a)var2.next()).a;
                     var86 = (r)var76;
                     var86.a.b();
                     b.j.a.f var21 = var86.c.a();
                     if (var22 == null) {
                        var21.b(1);
                     } else {
                        var21.a(1, (String)var22);
                     }

                     var86.a.c();
                     b.j.a.g.f var93 = (b.j.a.g.f)var21;
                     boolean var59 = false;

                     try {
                        var59 = true;
                        var93.a();
                        var86.a.k();
                        var59 = false;
                     } finally {
                        if (var59) {
                           var86.a.e();
                           var86.c.a(var21);
                        }
                     }

                     var86.a.e();
                     b.i.l var87 = var86.c;
                     if (var93 == var87.c) {
                        var87.a.set(false);
                     }
                  }

                  var17 = true;
                  var15 = var18;
                  var16 = var3;
                  break label1671;
               }

               var18 = false;
               break label1687;
            }

            var17 = false;
            var16 = var3;
            var15 = var18;
         }

         var2 = var6.iterator();
         var3 = var17;

         while(true) {
            var18 = var3;
            if (!var2.hasNext()) {
               break;
            }

            u var73 = (u)var2.next();
            p var78 = var73.b;
            if (var12 && !var15) {
               if (var19) {
                  var78.b = s.d;
               } else if (var16) {
                  var78.b = s.f;
               } else {
                  var78.b = s.e;
               }
            } else if (!var78.d()) {
               var78.n = var9;
            } else {
               var78.n = 0L;
            }

            int var85 = VERSION.SDK_INT;
            if (var85 >= 23 && var85 <= 25) {
               a(var78);
            } else if (VERSION.SDK_INT <= 22) {
               label1706: {
                  label1591: {
                     boolean var10001;
                     Class var90;
                     try {
                        var90 = Class.forName("androidx.work.impl.background.gcm.GcmScheduler");
                        var84 = var5.e.iterator();
                     } catch (ClassNotFoundException var66) {
                        var10001 = false;
                        break label1591;
                     }

                     while(true) {
                        boolean var23;
                        try {
                           if (!var84.hasNext()) {
                              break;
                           }

                           var23 = var90.isAssignableFrom(((b.l.w.d)var84.next()).getClass());
                        } catch (ClassNotFoundException var65) {
                           var10001 = false;
                           break;
                        }

                        if (var23) {
                           var18 = true;
                           break label1706;
                        }
                     }
                  }

                  var18 = false;
               }

               if (var18) {
                  a(var78);
               }
            }

            if (var78.b == s.a) {
               var3 = true;
            }

            var86 = (r)var11.q();
            var86.a.b();
            var86.a.c();

            try {
               var86.b.a(var78);
               var86.a.k();
            } finally {
               var86.a.e();
            }

            var18 = var3;
            if (var12) {
               var13 = var69.length;
               int var91 = 0;

               while(true) {
                  var18 = var3;
                  if (var91 >= var13) {
                     break;
                  }

                  String var79 = var69[var91];
                  b.l.w.q.a var94 = new b.l.w.q.a(var73.a(), var79);
                  b.l.w.q.c var80 = (b.l.w.q.c)var11.l();
                  var80.a.b();
                  var80.a.c();

                  try {
                     var80.b.a(var94);
                     var80.a.k();
                  } finally {
                     var80.a.e();
                  }

                  ++var91;
               }
            }

            Iterator var81 = var73.c.iterator();

            while(var81.hasNext()) {
               String var92 = (String)var81.next();
               t var96 = var11.r();
               b.l.w.q.s var95 = new b.l.w.q.s(var92, var73.a());
               b.l.w.q.u var98 = (b.l.w.q.u)var96;
               var98.a.b();
               var98.a.c();

               try {
                  var98.b.a(var95);
                  var98.a.k();
               } finally {
                  var98.a.e();
               }
            }

            if (var83) {
               b.l.w.q.k var99 = var11.o();
               b.l.w.q.j var82 = new b.l.w.q.j(var7, var73.a());
               b.l.w.q.l var74 = (b.l.w.q.l)var99;
               var74.a.b();
               var74.a.c();

               try {
                  var74.b.a(var82);
                  var74.a.k();
               } finally {
                  var74.a.e();
               }
            }

            var3 = var18;
         }
      }

      var0.h = true;
      return var4 | var18;
   }

   public void run() {
      Throwable var10000;
      label390: {
         boolean var10001;
         label393: {
            WorkDatabase var1;
            try {
               if (this.a.b()) {
                  break label393;
               }

               var1 = this.a.a.c;
               var1.c();
            } catch (Throwable var56) {
               var10000 = var56;
               var10001 = false;
               break label390;
            }

            boolean var2;
            try {
               var2 = a(this.a);
               var1.k();
            } finally {
               try {
                  var1.e();
               } catch (Throwable var51) {
                  var10000 = var51;
                  var10001 = false;
                  break label390;
               }
            }

            if (var2) {
               try {
                  d.a(this.a.a.a, RescheduleReceiver.class, true);
                  b.l.w.j var3 = this.a.a;
                  b.l.w.e.a(var3.b, var3.c, var3.e);
               } catch (Throwable var54) {
                  var10000 = var54;
                  var10001 = false;
                  break label390;
               }
            }

            try {
               this.b.a(o.a);
               return;
            } catch (Throwable var53) {
               var10000 = var53;
               var10001 = false;
               break label390;
            }
         }

         label373:
         try {
            IllegalStateException var58 = new IllegalStateException(String.format("WorkContinuation has cycles (%s)", this.a));
            throw var58;
         } catch (Throwable var52) {
            var10000 = var52;
            var10001 = false;
            break label373;
         }
      }

      Throwable var57 = var10000;
      this.b.a(new o.b.a(var57));
   }
}
