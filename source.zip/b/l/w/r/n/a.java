package b.l.w.r.n;

public interface a {
}
