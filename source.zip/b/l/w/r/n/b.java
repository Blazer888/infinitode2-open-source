package b.l.w.r.n;

import android.os.Handler;
import android.os.Looper;
import b.l.w.r.f;
import java.util.concurrent.Executor;

public class b implements a {
   public final f a;
   public final Handler b = new Handler(Looper.getMainLooper());
   public final Executor c = new Executor() {
      public void execute(Runnable var1) {
         b.this.b.post(var1);
      }
   };

   public b(Executor var1) {
      this.a = new f(var1);
   }
}
