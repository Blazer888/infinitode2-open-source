package b.l.w.r;

import android.content.Context;
import android.os.PowerManager.WakeLock;
import java.util.WeakHashMap;

public class i {
   public static final String a = b.l.l.a("WakeLocks");
   public static final WeakHashMap b = new WeakHashMap();

   public static WakeLock a(Context param0, String param1) {
      // $FF: Couldn't be decompiled
   }

   public static void a() {
      // $FF: Couldn't be decompiled
   }
}
