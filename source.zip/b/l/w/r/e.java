package b.l.w.r;

import androidx.work.impl.WorkDatabase;

public class e {
   public final WorkDatabase a;

   public e(WorkDatabase var1) {
      this.a = var1;
   }

   public void a(boolean var1) {
      long var2;
      if (var1) {
         var2 = 1L;
      } else {
         var2 = 0L;
      }

      b.l.w.q.d var4 = new b.l.w.q.d("reschedule_needed", var2);
      ((b.l.w.q.f)this.a.m()).a(var4);
   }
}
