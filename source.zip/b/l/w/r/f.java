package b.l.w.r;

import java.util.ArrayDeque;
import java.util.concurrent.Executor;

public class f implements Executor {
   public final ArrayDeque a;
   public final Executor b;
   public final Object c;
   public volatile Runnable d;

   public f(Executor var1) {
      this.b = var1;
      this.a = new ArrayDeque();
      this.c = new Object();
   }

   public boolean a() {
      Object var1 = this.c;
      synchronized(var1){}

      Throwable var10000;
      boolean var10001;
      label134: {
         boolean var2;
         label133: {
            label132: {
               try {
                  if (!this.a.isEmpty()) {
                     break label132;
                  }
               } catch (Throwable var15) {
                  var10000 = var15;
                  var10001 = false;
                  break label134;
               }

               var2 = false;
               break label133;
            }

            var2 = true;
         }

         label126:
         try {
            return var2;
         } catch (Throwable var14) {
            var10000 = var14;
            var10001 = false;
            break label126;
         }
      }

      while(true) {
         Throwable var3 = var10000;

         try {
            throw var3;
         } catch (Throwable var13) {
            var10000 = var13;
            var10001 = false;
            continue;
         }
      }
   }

   public void b() {
      Object var1 = this.c;
      synchronized(var1){}

      Throwable var10000;
      boolean var10001;
      label176: {
         Runnable var2;
         try {
            var2 = (Runnable)this.a.poll();
            this.d = var2;
         } catch (Throwable var22) {
            var10000 = var22;
            var10001 = false;
            break label176;
         }

         if (var2 != null) {
            try {
               this.b.execute(this.d);
            } catch (Throwable var21) {
               var10000 = var21;
               var10001 = false;
               break label176;
            }
         }

         label165:
         try {
            return;
         } catch (Throwable var20) {
            var10000 = var20;
            var10001 = false;
            break label165;
         }
      }

      while(true) {
         Throwable var23 = var10000;

         try {
            throw var23;
         } catch (Throwable var19) {
            var10000 = var19;
            var10001 = false;
            continue;
         }
      }
   }

   public void execute(Runnable var1) {
      Object var2 = this.c;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label122: {
         try {
            ArrayDeque var3 = this.a;
            f.a var4 = new f.a(this, var1);
            var3.add(var4);
            if (this.d == null) {
               this.b();
            }
         } catch (Throwable var16) {
            var10000 = var16;
            var10001 = false;
            break label122;
         }

         label119:
         try {
            return;
         } catch (Throwable var15) {
            var10000 = var15;
            var10001 = false;
            break label119;
         }
      }

      while(true) {
         Throwable var17 = var10000;

         try {
            throw var17;
         } catch (Throwable var14) {
            var10000 = var14;
            var10001 = false;
            continue;
         }
      }
   }

   public static class a implements Runnable {
      public final f a;
      public final Runnable b;

      public a(f var1, Runnable var2) {
         this.a = var1;
         this.b = var2;
      }

      public void run() {
         try {
            this.b.run();
         } finally {
            this.a.b();
         }

      }
   }
}
