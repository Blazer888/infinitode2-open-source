package b.l.w.r;

import androidx.work.WorkerParameters;

public class g implements Runnable {
   public b.l.w.j a;
   public String b;
   public WorkerParameters.a c;

   public g(b.l.w.j var1, String var2, WorkerParameters.a var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public void run() {
      this.a.f.a(this.b, this.c);
   }
}
