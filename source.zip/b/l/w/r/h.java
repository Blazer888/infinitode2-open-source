package b.l.w.r;

import androidx.work.impl.WorkDatabase;
import b.l.s;
import b.l.w.q.q;
import b.l.w.q.r;

public class h implements Runnable {
   public static final String d = b.l.l.a("StopWorkRunnable");
   public final b.l.w.j a;
   public final String b;
   public final boolean c;

   public h(b.l.w.j var1, String var2, boolean var3) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
   }

   public void run() {
      WorkDatabase var1 = this.a.c;
      q var2 = var1.q();
      var1.c();

      label283: {
         Throwable var10000;
         label288: {
            String var3;
            boolean var10001;
            try {
               var3 = this.b;
            } catch (Throwable var34) {
               var10000 = var34;
               var10001 = false;
               break label288;
            }

            r var35 = (r)var2;

            try {
               if (var35.b(var3) == s.b) {
                  var35.a(s.a, this.b);
               }
            } catch (Throwable var33) {
               var10000 = var33;
               var10001 = false;
               break label288;
            }

            boolean var4;
            label273: {
               try {
                  if (this.c) {
                     var4 = this.a.f.e(this.b);
                     break label273;
                  }
               } catch (Throwable var32) {
                  var10000 = var32;
                  var10001 = false;
                  break label288;
               }

               try {
                  var4 = this.a.f.f(this.b);
               } catch (Throwable var31) {
                  var10000 = var31;
                  var10001 = false;
                  break label288;
               }
            }

            label264:
            try {
               b.l.l.a().a(d, String.format("StopWorkRunnable for %s; Processor.stopWork = %s", this.b, var4));
               var1.k();
               break label283;
            } catch (Throwable var30) {
               var10000 = var30;
               var10001 = false;
               break label264;
            }
         }

         Throwable var36 = var10000;
         var1.e();
         throw var36;
      }

      var1.e();
   }
}
