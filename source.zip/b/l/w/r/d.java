package b.l.w.r;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;

public class d {
   public static final String a = b.l.l.a("PackageManagerHelper");

   public static void a(Context var0, Class var1, boolean var2) {
      String var3 = "enabled";

      String var11;
      String var13;
      Exception var10000;
      label47: {
         PackageManager var4;
         ComponentName var5;
         boolean var10001;
         try {
            var4 = var0.getPackageManager();
            var5 = new ComponentName(var0, var1.getName());
         } catch (Exception var10) {
            var10000 = var10;
            var10001 = false;
            break label47;
         }

         byte var6;
         if (var2) {
            var6 = 1;
         } else {
            var6 = 2;
         }

         b.l.l var7;
         String var14;
         try {
            var4.setComponentEnabledSetting(var5, var6, 1);
            var7 = b.l.l.a();
            var13 = a;
            var14 = var1.getName();
         } catch (Exception var9) {
            var10000 = var9;
            var10001 = false;
            break label47;
         }

         if (var2) {
            var11 = "enabled";
         } else {
            var11 = "disabled";
         }

         try {
            var7.a(var13, String.format("%s %s", var14, var11));
            return;
         } catch (Exception var8) {
            var10000 = var8;
            var10001 = false;
         }
      }

      Exception var16 = var10000;
      b.l.l var15 = b.l.l.a();
      var13 = a;
      String var12 = var1.getName();
      if (var2) {
         var11 = var3;
      } else {
         var11 = "disabled";
      }

      var15.a(var13, String.format("%s could not be %s", var12, var11), var16);
   }
}
