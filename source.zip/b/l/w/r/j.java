package b.l.w.r;

import android.content.Context;
import java.util.UUID;

public class j implements b.l.h {
   public final b.l.w.r.n.a a;
   public final b.l.w.p.a b;

   public j(b.l.w.p.a var1, b.l.w.r.n.a var2) {
      this.b = var1;
      this.a = var2;
   }

   public c.c.c.a.a.a a(final Context var1, final UUID var2, final b.l.g var3) {
      final b.l.w.r.m.c var4 = new b.l.w.r.m.c();
      b.l.w.r.n.a var5 = this.a;
      Runnable var6 = new Runnable() {
         public void run() {
            // $FF: Couldn't be decompiled
         }
      };
      ((b.l.w.r.n.b)var5).a.execute(var6);
      return var4;
   }
}
