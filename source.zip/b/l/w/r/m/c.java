package b.l.w.r.m;

public final class c extends a {
   public boolean a(Throwable var1) {
      if (var1 != null) {
         a.d var3 = new a.d(var1);
         boolean var2;
         if (b.l.w.r.m.a.f.a(this, (Object)null, (Object)var3)) {
            b.l.w.r.m.a.a((a)this);
            var2 = true;
         } else {
            var2 = false;
         }

         return var2;
      } else {
         throw new NullPointerException();
      }
   }

   public boolean b(c.c.c.a.a.a var1) {
      if (var1 == null) {
         NullPointerException var21 = new NullPointerException();
         throw var21;
      } else {
         Object var2 = super.a;
         boolean var3 = false;
         Object var4 = var2;
         boolean var5;
         if (var2 == null) {
            label235: {
               if (var1.isDone()) {
                  Object var18 = b.l.w.r.m.a.a(var1);
                  var5 = var3;
                  if (!b.l.w.r.m.a.f.a(this, (Object)null, (Object)var18)) {
                     return var5;
                  }

                  b.l.w.r.m.a.a((a)this);
               } else {
                  label224: {
                     a.g var24 = new a.g(this, var1);
                     if (!b.l.w.r.m.a.f.a(this, (Object)null, (Object)var24)) {
                        var4 = super.a;
                        break label235;
                     }

                     Throwable var10000;
                     label225: {
                        boolean var10001;
                        b.l.w.r.m.b var22;
                        try {
                           var22 = b.l.w.r.m.b.a;
                        } catch (Throwable var17) {
                           var10000 = var17;
                           var10001 = false;
                           break label225;
                        }

                        a var19 = (a)var1;

                        label206:
                        try {
                           var19.a(var24, var22);
                           break label224;
                        } catch (Throwable var16) {
                           var10000 = var16;
                           var10001 = false;
                           break label206;
                        }
                     }

                     Throwable var23 = var10000;

                     a.d var20;
                     try {
                        var20 = new a.d(var23);
                     } finally {
                        ;
                     }

                     b.l.w.r.m.a.f.a(this, (Object)var24, (Object)var20);
                  }
               }

               var5 = true;
               return var5;
            }
         }

         var5 = var3;
         if (var4 instanceof a.c) {
            var1.cancel(((a.c)var4).a);
            var5 = var3;
         }

         return var5;
      }
   }

   public boolean c(Object var1) {
      Object var2 = var1;
      if (var1 == null) {
         var2 = b.l.w.r.m.a.g;
      }

      boolean var3;
      if (b.l.w.r.m.a.f.a(this, (Object)null, (Object)var2)) {
         b.l.w.r.m.a.a((a)this);
         var3 = true;
      } else {
         var3 = false;
      }

      return var3;
   }
}
