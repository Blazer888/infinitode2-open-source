package b.l.w.r.m;

import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class a implements c.c.c.a.a.a {
   public static final boolean d = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));
   public static final Logger e = Logger.getLogger(a.class.getName());
   public static final a.b f;
   public static final Object g;
   public volatile Object a;
   public volatile a.e b;
   public volatile a.i c;

   static {
      boolean var6 = false;

      AtomicReferenceFieldUpdater var3;
      a.h var8;
      label61: {
         try {
            var6 = true;
            AtomicReferenceFieldUpdater var1 = AtomicReferenceFieldUpdater.newUpdater(a.i.class, Thread.class, "a");
            AtomicReferenceFieldUpdater var2 = AtomicReferenceFieldUpdater.newUpdater(a.i.class, a.i.class, "b");
            var3 = AtomicReferenceFieldUpdater.newUpdater(a.class, a.i.class, "c");
            AtomicReferenceFieldUpdater var4 = AtomicReferenceFieldUpdater.newUpdater(a.class, a.e.class, "b");
            a.f var0 = new a.f(var1, var2, var3, var4, AtomicReferenceFieldUpdater.newUpdater(a.class, Object.class, "a"));
            var6 = false;
         } finally {
            if (var6) {
               var8 = new a.h();
               break label61;
            }
         }

      }

      f = var8;
      if (var3 != null) {
         e.log(Level.SEVERE, "SafeAtomicHelper is broken!", var3);
      }

      g = new Object();
   }

   public static Object a(c.c.c.a.a.a param0) {
      // $FF: Couldn't be decompiled
   }

   public static Object a(Future var0) {
      boolean var1 = false;

      Object var2;
      while(true) {
         boolean var5 = false;

         try {
            var5 = true;
            var2 = var0.get();
            var5 = false;
            break;
         } catch (InterruptedException var6) {
            var5 = false;
         } finally {
            if (var5) {
               if (var1) {
                  Thread.currentThread().interrupt();
               }

            }
         }

         var1 = true;
      }

      if (var1) {
         Thread.currentThread().interrupt();
      }

      return var2;
   }

   public static void a(a var0) {
      a.i var1 = null;
      a var2 = var0;
      a.e var4 = var1;

      label51:
      while(true) {
         do {
            var1 = var2.c;
         } while(!f.a(var2, var1, a.i.c));

         for(; var1 != null; var1 = var1.b) {
            Thread var3 = var1.a;
            if (var3 != null) {
               var1.a = null;
               LockSupport.unpark(var3);
            }
         }

         a.e var5;
         do {
            var5 = var2.b;
         } while(!f.a(var2, var5, a.e.d));

         a.e var6 = var5;

         while(true) {
            var5 = var6;
            var6 = var4;
            if (var5 == null) {
               for(; var6 != null; var6 = var4) {
                  var4 = var6.c;
                  Runnable var7 = var6.a;
                  if (var7 instanceof a.g) {
                     a.g var9 = (a.g)var7;
                     var2 = var9.a;
                     if (var2.a == var9) {
                        Object var8 = a(var9.b);
                        if (f.a(var2, (Object)var9, (Object)var8)) {
                           continue label51;
                        }
                     }
                  } else {
                     b(var7, var6.b);
                  }
               }

               return;
            }

            var6 = var5.c;
            var5.c = var4;
            var4 = var5;
         }
      }
   }

   public static Object b(Object var0) {
      if (var0 != null) {
         return var0;
      } else {
         throw new NullPointerException();
      }
   }

   public static void b(Runnable var0, Executor var1) {
      try {
         var1.execute(var0);
      } catch (RuntimeException var6) {
         Logger var3 = e;
         Level var4 = Level.SEVERE;
         StringBuilder var5 = new StringBuilder();
         var5.append("RuntimeException while executing runnable ");
         var5.append(var0);
         var5.append(" with executor ");
         var5.append(var1);
         var3.log(var4, var5.toString(), var6);
      }

   }

   public final Object a(Object var1) {
      if (!(var1 instanceof a.c)) {
         if (!(var1 instanceof a.d)) {
            Object var4 = var1;
            if (var1 == g) {
               var4 = null;
            }

            return var4;
         } else {
            throw new ExecutionException(((a.d)var1).a);
         }
      } else {
         Throwable var3 = ((a.c)var1).b;
         CancellationException var2 = new CancellationException("Task was cancelled.");
         var2.initCause(var3);
         throw var2;
      }
   }

   public String a() {
      Object var1 = this.a;
      if (var1 instanceof a.g) {
         StringBuilder var2 = c.a.b.a.a.b("setFuture=[");
         c.c.c.a.a.a var4 = ((a.g)var1).b;
         String var5;
         if (var4 == this) {
            var5 = "this future";
         } else {
            var5 = String.valueOf(var4);
         }

         return c.a.b.a.a.a(var2, var5, "]");
      } else if (this instanceof ScheduledFuture) {
         StringBuilder var3 = c.a.b.a.a.b("remaining delay=[");
         var3.append(((ScheduledFuture)this).getDelay(TimeUnit.MILLISECONDS));
         var3.append(" ms]");
         return var3.toString();
      } else {
         return null;
      }
   }

   public final void a(a.i var1) {
      var1.a = null;

      label30:
      while(true) {
         var1 = this.c;
         if (var1 == a.i.c) {
            return;
         }

         a.i var4;
         for(a.i var2 = null; var1 != null; var2 = var4) {
            a.i var3 = var1.b;
            if (var1.a != null) {
               var4 = var1;
            } else if (var2 != null) {
               var2.b = var3;
               var4 = var2;
               if (var2.a == null) {
                  continue label30;
               }
            } else {
               var4 = var2;
               if (!f.a(this, var1, var3)) {
                  continue label30;
               }
            }

            var1 = var3;
         }

         return;
      }
   }

   public final void a(Runnable var1, Executor var2) {
      if (var1 != null) {
         if (var2 == null) {
            throw new NullPointerException();
         } else {
            a.e var3 = this.b;
            if (var3 != a.e.d) {
               a.e var4 = new a.e(var1, var2);

               a.e var5;
               do {
                  var4.c = var3;
                  if (f.a(this, var3, var4)) {
                     return;
                  }

                  var5 = this.b;
                  var3 = var5;
               } while(var5 != a.e.d);
            }

            b(var1, var2);
         }
      } else {
         NullPointerException var6 = new NullPointerException();
         throw var6;
      }
   }

   public final void a(StringBuilder var1) {
      ExecutionException var15;
      label60: {
         label61: {
            RuntimeException var10000;
            label49: {
               Object var2;
               boolean var10001;
               try {
                  var2 = a((Future)this);
                  var1.append("SUCCESS, result=[");
               } catch (ExecutionException var9) {
                  var15 = var9;
                  var10001 = false;
                  break label60;
               } catch (CancellationException var10) {
                  var10001 = false;
                  break label61;
               } catch (RuntimeException var11) {
                  var10000 = var11;
                  var10001 = false;
                  break label49;
               }

               String var12;
               if (var2 == this) {
                  var12 = "this future";
               } else {
                  try {
                     var12 = String.valueOf(var2);
                  } catch (ExecutionException var6) {
                     var15 = var6;
                     var10001 = false;
                     break label60;
                  } catch (CancellationException var7) {
                     var10001 = false;
                     break label61;
                  } catch (RuntimeException var8) {
                     var10000 = var8;
                     var10001 = false;
                     break label49;
                  }
               }

               try {
                  var1.append(var12);
                  var1.append("]");
                  return;
               } catch (ExecutionException var3) {
                  var15 = var3;
                  var10001 = false;
                  break label60;
               } catch (CancellationException var4) {
                  var10001 = false;
                  break label61;
               } catch (RuntimeException var5) {
                  var10000 = var5;
                  var10001 = false;
               }
            }

            RuntimeException var13 = var10000;
            var1.append("UNKNOWN, cause=[");
            var1.append(var13.getClass());
            var1.append(" thrown from get()]");
            return;
         }

         var1.append("CANCELLED");
         return;
      }

      ExecutionException var14 = var15;
      var1.append("FAILURE, cause=[");
      var1.append(var14.getCause());
      var1.append("]");
   }

   public final boolean cancel(boolean var1) {
      Object var2 = this.a;
      boolean var3 = true;
      boolean var4;
      if (var2 == null) {
         var4 = true;
      } else {
         var4 = false;
      }

      boolean var6;
      if (var4 | var2 instanceof a.g) {
         a.c var5;
         if (d) {
            var5 = new a.c(var1, new CancellationException("Future.cancel() was called."));
         } else if (var1) {
            var5 = a.c.c;
         } else {
            var5 = a.c.d;
         }

         var6 = false;
         a var7 = this;

         while(true) {
            while(!f.a(var7, (Object)var2, (Object)var5)) {
               Object var8 = var7.a;
               var2 = var8;
               if (!(var8 instanceof a.g)) {
                  return var6;
               }
            }

            a(var7);
            var6 = var3;
            if (!(var2 instanceof a.g)) {
               break;
            }

            c.c.c.a.a.a var9 = ((a.g)var2).b;
            if (!(var9 instanceof a)) {
               var9.cancel(var1);
               var6 = var3;
               break;
            }

            var7 = (a)var9;
            var2 = var7.a;
            if (var2 == null) {
               var4 = true;
            } else {
               var4 = false;
            }

            var6 = var3;
            if (!(var4 | var2 instanceof a.g)) {
               break;
            }

            var6 = true;
         }
      } else {
         var6 = false;
      }

      return var6;
   }

   public final Object get() {
      if (!Thread.interrupted()) {
         Object var5 = this.a;
         boolean var2;
         if (var5 != null) {
            var2 = true;
         } else {
            var2 = false;
         }

         if (var2 & (var5 instanceof a.g ^ true)) {
            return this.a(var5);
         } else {
            a.i var6 = this.c;
            if (var6 != a.i.c) {
               a.i var3 = new a.i();

               a.i var4;
               do {
                  f.a(var3, var6);
                  if (f.a(this, var6, var3)) {
                     do {
                        LockSupport.park(this);
                        if (Thread.interrupted()) {
                           this.a(var3);
                           throw new InterruptedException();
                        }

                        var5 = this.a;
                        if (var5 != null) {
                           var2 = true;
                        } else {
                           var2 = false;
                        }
                     } while(!(var2 & (var5 instanceof a.g ^ true)));

                     return this.a(var5);
                  }

                  var4 = this.c;
                  var6 = var4;
               } while(var4 != a.i.c);
            }

            return this.a(this.a);
         }
      } else {
         InterruptedException var1 = new InterruptedException();
         throw var1;
      }
   }

   public final Object get(long var1, TimeUnit var3) {
      long var4 = var3.toNanos(var1);
      if (!Thread.interrupted()) {
         Object var6 = this.a;
         boolean var7;
         if (var6 != null) {
            var7 = true;
         } else {
            var7 = false;
         }

         if (var7 & (var6 instanceof a.g ^ true)) {
            return this.a(var6);
         } else {
            long var8;
            if (var4 > 0L) {
               var8 = System.nanoTime() + var4;
            } else {
               var8 = 0L;
            }

            long var10 = var4;
            if (var4 >= 1000L) {
               label116: {
                  a.i var18 = this.c;
                  if (var18 != a.i.c) {
                     a.i var12 = new a.i();

                     a.i var13;
                     do {
                        f.a(var12, var18);
                        if (f.a(this, var18, var12)) {
                           do {
                              LockSupport.parkNanos(this, var4);
                              if (Thread.interrupted()) {
                                 this.a(var12);
                                 throw new InterruptedException();
                              }

                              var6 = this.a;
                              if (var6 != null) {
                                 var7 = true;
                              } else {
                                 var7 = false;
                              }

                              if (var7 & (var6 instanceof a.g ^ true)) {
                                 return this.a(var6);
                              }

                              var10 = var8 - System.nanoTime();
                              var4 = var10;
                           } while(var10 >= 1000L);

                           this.a(var12);
                           break label116;
                        }

                        var13 = this.c;
                        var18 = var13;
                     } while(var13 != a.i.c);
                  }

                  return this.a(this.a);
               }
            }

            while(var10 > 0L) {
               var6 = this.a;
               if (var6 != null) {
                  var7 = true;
               } else {
                  var7 = false;
               }

               if (var7 & (var6 instanceof a.g ^ true)) {
                  return this.a(var6);
               }

               if (Thread.interrupted()) {
                  throw new InterruptedException();
               }

               var10 = var8 - System.nanoTime();
            }

            String var21 = this.toString();
            String var14 = var3.toString().toLowerCase(Locale.ROOT);
            StringBuilder var19 = new StringBuilder();
            var19.append("Waited ");
            var19.append(var1);
            var19.append(" ");
            var19.append(var3.toString().toLowerCase(Locale.ROOT));
            String var22 = var19.toString();
            String var20 = var22;
            if (var10 + 1000L < 0L) {
               var20 = c.a.b.a.a.a(var22, " (plus ");
               var10 = -var10;
               var1 = var3.convert(var10, TimeUnit.NANOSECONDS);
               var10 -= var3.toNanos(var1);
               if (var1 != 0L && var10 <= 1000L) {
                  var7 = false;
               } else {
                  var7 = true;
               }

               String var16 = var20;
               if (var1 > 0L) {
                  StringBuilder var17 = new StringBuilder();
                  var17.append(var20);
                  var17.append(var1);
                  var17.append(" ");
                  var17.append(var14);
                  var20 = var17.toString();
                  var16 = var20;
                  if (var7) {
                     var16 = c.a.b.a.a.a(var20, ",");
                  }

                  var16 = c.a.b.a.a.a(var16, " ");
               }

               var20 = var16;
               if (var7) {
                  var19 = new StringBuilder();
                  var19.append(var16);
                  var19.append(var10);
                  var19.append(" nanoseconds ");
                  var20 = var19.toString();
               }

               var20 = c.a.b.a.a.a(var20, "delay)");
            }

            if (this.isDone()) {
               throw new TimeoutException(c.a.b.a.a.a(var20, " but future completed as timeout expired"));
            } else {
               throw new TimeoutException(c.a.b.a.a.a(var20, " for ", var21));
            }
         }
      } else {
         InterruptedException var15 = new InterruptedException();
         throw var15;
      }
   }

   public final boolean isCancelled() {
      return this.a instanceof a.c;
   }

   public final boolean isDone() {
      Object var1 = this.a;
      boolean var2;
      if (var1 != null) {
         var2 = true;
      } else {
         var2 = false;
      }

      return (var1 instanceof a.g ^ true) & var2;
   }

   public String toString() {
      StringBuilder var1 = new StringBuilder();
      var1.append(super.toString());
      var1.append("[status=");
      if (this.a instanceof a.c) {
         var1.append("CANCELLED");
      } else if (this.isDone()) {
         this.a(var1);
      } else {
         String var2;
         try {
            var2 = this.a();
         } catch (RuntimeException var4) {
            StringBuilder var3 = c.a.b.a.a.b("Exception thrown from implementation: ");
            var3.append(var4.getClass());
            var2 = var3.toString();
         }

         if (var2 != null && !var2.isEmpty()) {
            var1.append("PENDING, info=[");
            var1.append(var2);
            var1.append("]");
         } else if (this.isDone()) {
            this.a(var1);
         } else {
            var1.append("PENDING");
         }
      }

      var1.append("]");
      return var1.toString();
   }

   public abstract static class b {
      // $FF: synthetic method
      public b(Object var1) {
      }

      public abstract void a(a.i var1, a.i var2);

      public abstract void a(a.i var1, Thread var2);

      public abstract boolean a(a var1, a.e var2, a.e var3);

      public abstract boolean a(a var1, a.i var2, a.i var3);

      public abstract boolean a(a var1, Object var2, Object var3);
   }

   public static final class c {
      public static final a.c c;
      public static final a.c d;
      public final boolean a;
      public final Throwable b;

      static {
         if (b.l.w.r.m.a.d) {
            d = null;
            c = null;
         } else {
            d = new a.c(false, (Throwable)null);
            c = new a.c(true, (Throwable)null);
         }

      }

      public c(boolean var1, Throwable var2) {
         this.a = var1;
         this.b = var2;
      }
   }

   public static final class d {
      public static final a.d b = new a.d(new Throwable("Failure occurred while trying to finish a future.") {
         public Throwable fillInStackTrace() {
            synchronized(this){}
            return this;
         }
      });
      public final Throwable a;

      public d(Throwable var1) {
         b.l.w.r.m.a.b(var1);
         this.a = (Throwable)var1;
      }
   }

   public static final class e {
      public static final a.e d = new a.e((Runnable)null, (Executor)null);
      public final Runnable a;
      public final Executor b;
      public a.e c;

      public e(Runnable var1, Executor var2) {
         this.a = var1;
         this.b = var2;
      }
   }

   public static final class f extends a.b {
      public final AtomicReferenceFieldUpdater a;
      public final AtomicReferenceFieldUpdater b;
      public final AtomicReferenceFieldUpdater c;
      public final AtomicReferenceFieldUpdater d;
      public final AtomicReferenceFieldUpdater e;

      public f(AtomicReferenceFieldUpdater var1, AtomicReferenceFieldUpdater var2, AtomicReferenceFieldUpdater var3, AtomicReferenceFieldUpdater var4, AtomicReferenceFieldUpdater var5) {
         super(null);
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
         this.e = var5;
      }

      public void a(a.i var1, a.i var2) {
         this.b.lazySet(var1, var2);
      }

      public void a(a.i var1, Thread var2) {
         this.a.lazySet(var1, var2);
      }

      public boolean a(a var1, a.e var2, a.e var3) {
         return this.d.compareAndSet(var1, var2, var3);
      }

      public boolean a(a var1, a.i var2, a.i var3) {
         return this.c.compareAndSet(var1, var2, var3);
      }

      public boolean a(a var1, Object var2, Object var3) {
         return this.e.compareAndSet(var1, var2, var3);
      }
   }

   public static final class g implements Runnable {
      public final a a;
      public final c.c.c.a.a.a b;

      public g(a var1, c.c.c.a.a.a var2) {
         this.a = var1;
         this.b = var2;
      }

      public void run() {
         if (this.a.a == this) {
            Object var1 = b.l.w.r.m.a.a(this.b);
            if (b.l.w.r.m.a.f.a(this.a, (Object)this, (Object)var1)) {
               b.l.w.r.m.a.a(this.a);
            }

         }
      }
   }

   public static final class h extends a.b {
      public h() {
         super(null);
      }

      public void a(a.i var1, a.i var2) {
         var1.b = var2;
      }

      public void a(a.i var1, Thread var2) {
         var1.a = var2;
      }

      public boolean a(a var1, a.e var2, a.e var3) {
         synchronized(var1){}

         Throwable var10000;
         boolean var10001;
         label123: {
            try {
               if (var1.b == var2) {
                  var1.b = var3;
                  return true;
               }
            } catch (Throwable var15) {
               var10000 = var15;
               var10001 = false;
               break label123;
            }

            label117:
            try {
               return false;
            } catch (Throwable var14) {
               var10000 = var14;
               var10001 = false;
               break label117;
            }
         }

         while(true) {
            Throwable var16 = var10000;

            try {
               throw var16;
            } catch (Throwable var13) {
               var10000 = var13;
               var10001 = false;
               continue;
            }
         }
      }

      public boolean a(a var1, a.i var2, a.i var3) {
         synchronized(var1){}

         Throwable var10000;
         boolean var10001;
         label123: {
            try {
               if (var1.c == var2) {
                  var1.c = var3;
                  return true;
               }
            } catch (Throwable var15) {
               var10000 = var15;
               var10001 = false;
               break label123;
            }

            label117:
            try {
               return false;
            } catch (Throwable var14) {
               var10000 = var14;
               var10001 = false;
               break label117;
            }
         }

         while(true) {
            Throwable var16 = var10000;

            try {
               throw var16;
            } catch (Throwable var13) {
               var10000 = var13;
               var10001 = false;
               continue;
            }
         }
      }

      public boolean a(a var1, Object var2, Object var3) {
         synchronized(var1){}

         Throwable var10000;
         boolean var10001;
         label123: {
            try {
               if (var1.a == var2) {
                  var1.a = var3;
                  return true;
               }
            } catch (Throwable var15) {
               var10000 = var15;
               var10001 = false;
               break label123;
            }

            label117:
            try {
               return false;
            } catch (Throwable var14) {
               var10000 = var14;
               var10001 = false;
               break label117;
            }
         }

         while(true) {
            Throwable var16 = var10000;

            try {
               throw var16;
            } catch (Throwable var13) {
               var10000 = var13;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public static final class i {
      public static final a.i c = new a.i(false);
      public volatile Thread a;
      public volatile a.i b;

      public i() {
         b.l.w.r.m.a.f.a(this, Thread.currentThread());
      }

      public i(boolean var1) {
      }
   }
}
