package b.l.w.r.m;

import java.util.concurrent.Executor;

public enum b implements Executor {
   a;

   public void execute(Runnable var1) {
      var1.run();
   }

   public String toString() {
      return "DirectExecutor";
   }
}
