package b.l.w.r;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;

public class l {
   public static final String f = b.l.l.a("WorkTimer");
   public final ThreadFactory a = new ThreadFactory(this) {
      public int a = 0;

      public Thread newThread(Runnable var1) {
         Thread var3 = Executors.defaultThreadFactory().newThread(var1);
         StringBuilder var2 = c.a.b.a.a.b("WorkManager-WorkTimer-thread-");
         var2.append(this.a);
         var3.setName(var2.toString());
         ++this.a;
         return var3;
      }
   };
   public final ScheduledExecutorService b;
   public final Map c = new HashMap();
   public final Map d = new HashMap();
   public final Object e = new Object();

   public l() {
      this.b = Executors.newSingleThreadScheduledExecutor(this.a);
   }

   public void a(String var1) {
      Object var2 = this.e;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label122: {
         try {
            if ((l.c)this.c.remove(var1) != null) {
               b.l.l.a().a(f, String.format("Stopping timer for %s", var1));
               this.d.remove(var1);
            }
         } catch (Throwable var14) {
            var10000 = var14;
            var10001 = false;
            break label122;
         }

         label119:
         try {
            return;
         } catch (Throwable var13) {
            var10000 = var13;
            var10001 = false;
            break label119;
         }
      }

      while(true) {
         Throwable var15 = var10000;

         try {
            throw var15;
         } catch (Throwable var12) {
            var10000 = var12;
            var10001 = false;
            continue;
         }
      }
   }

   public void a(String param1, long param2, l.b param4) {
      // $FF: Couldn't be decompiled
   }

   public interface b {
   }

   public static class c implements Runnable {
      public final l a;
      public final String b;

      public c(l var1, String var2) {
         this.a = var1;
         this.b = var2;
      }

      public void run() {
         Object var1 = this.a.e;
         synchronized(var1){}

         Throwable var10000;
         boolean var10001;
         label263: {
            label262: {
               label261: {
                  l.b var2;
                  try {
                     if ((l.c)this.a.c.remove(this.b) == null) {
                        break label261;
                     }

                     var2 = (l.b)this.a.d.remove(this.b);
                  } catch (Throwable var33) {
                     var10000 = var33;
                     var10001 = false;
                     break label263;
                  }

                  if (var2 != null) {
                     try {
                        String var3 = this.b;
                        b.l.w.n.b.d var34 = (b.l.w.n.b.d)var2;
                        b.l.l.a().a(b.l.w.n.b.d.j, String.format("Exceeded time limits on execution for %s", var3));
                        var34.c();
                     } catch (Throwable var32) {
                        var10000 = var32;
                        var10001 = false;
                        break label263;
                     }
                  }
                  break label262;
               }

               try {
                  b.l.l.a().a("WrkTimerRunnable", String.format("Timer with %s is already marked as complete.", this.b));
               } catch (Throwable var31) {
                  var10000 = var31;
                  var10001 = false;
                  break label263;
               }
            }

            label250:
            try {
               return;
            } catch (Throwable var30) {
               var10000 = var30;
               var10001 = false;
               break label250;
            }
         }

         while(true) {
            Throwable var35 = var10000;

            try {
               throw var35;
            } catch (Throwable var29) {
               var10000 = var29;
               var10001 = false;
               continue;
            }
         }
      }
   }
}
