package b.l.w.r;

import androidx.work.impl.WorkDatabase;
import b.l.o;
import b.l.s;
import b.l.w.q.q;
import b.l.w.q.r;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.UUID;

public abstract class a implements Runnable {
   public final b.l.w.b a = new b.l.w.b();

   public static a a(final String var0, final b.l.w.j var1, final boolean var2) {
      return new a() {
         public void a() {
            WorkDatabase var1x = var1.c;
            var1x.c();

            label218: {
               Throwable var10000;
               label222: {
                  q var2x;
                  String var3;
                  boolean var10001;
                  try {
                     var2x = var1x.q();
                     var3 = var0;
                  } catch (Throwable var23) {
                     var10000 = var23;
                     var10001 = false;
                     break label222;
                  }

                  r var25 = (r)var2x;

                  Iterator var27;
                  try {
                     var27 = var25.c(var3).iterator();
                  } catch (Throwable var21) {
                     var10000 = var21;
                     var10001 = false;
                     break label222;
                  }

                  while(true) {
                     try {
                        if (!var27.hasNext()) {
                           break;
                        }

                        String var26 = (String)var27.next();
                        this.a(var1, var26);
                     } catch (Throwable var22) {
                        var10000 = var22;
                        var10001 = false;
                        break label222;
                     }
                  }

                  label203:
                  try {
                     var1x.k();
                     break label218;
                  } catch (Throwable var20) {
                     var10000 = var20;
                     var10001 = false;
                     break label203;
                  }
               }

               Throwable var28 = var10000;
               var1x.e();
               throw var28;
            }

            var1x.e();
            if (var2) {
               b.l.w.j var24 = var1;
               b.l.w.e.a(var24.b, var24.c, var24.e);
            }

         }
      };
   }

   public static a a(final UUID var0, final b.l.w.j var1) {
      return new a() {
         public void a() {
            WorkDatabase var1x = var1.c;
            var1x.c();

            try {
               this.a(var1, var0.toString());
               var1x.k();
            } finally {
               var1x.e();
            }

            b.l.w.j var5 = var1;
            b.l.w.e.a(var5.b, var5.c, var5.e);
         }
      };
   }

   public abstract void a();

   public void a(b.l.w.j var1, String var2) {
      WorkDatabase var3 = var1.c;
      q var4 = var3.q();
      b.l.w.q.b var5 = var3.l();
      LinkedList var6 = new LinkedList();
      var6.add(var2);

      String var10;
      for(; !var6.isEmpty(); var6.addAll(((b.l.w.q.c)var5).a(var10))) {
         var10 = (String)var6.remove();
         r var7 = (r)var4;
         s var8 = var7.b(var10);
         if (var8 != s.c && var8 != s.d) {
            var7.a(s.f, var10);
         }
      }

      var1.f.c(var2);
      Iterator var9 = var1.e.iterator();

      while(var9.hasNext()) {
         ((b.l.w.d)var9.next()).a(var2);
      }

   }

   public void run() {
      try {
         this.a();
         this.a.a(o.a);
      } catch (Throwable var3) {
         this.a.a(new o.b.a(var3));
         return;
      }

   }
}
