package b.l.w.r;

import androidx.work.impl.WorkDatabase;

public class c {
   public final WorkDatabase a;

   public c(WorkDatabase var1) {
      this.a = var1;
   }

   public int a() {
      // $FF: Couldn't be decompiled
   }

   public int a(int var1, int var2) {
      synchronized(c.class){}

      Throwable var10000;
      boolean var10001;
      label203: {
         int var3;
         try {
            var3 = this.a("next_job_scheduler_id");
         } catch (Throwable var24) {
            var10000 = var24;
            var10001 = false;
            break label203;
         }

         if (var3 >= var1 && var3 <= var2) {
            var1 = var3;
         } else {
            try {
               this.a("next_job_scheduler_id", var1 + 1);
            } catch (Throwable var23) {
               var10000 = var23;
               var10001 = false;
               break label203;
            }
         }

         label188:
         try {
            return var1;
         } catch (Throwable var22) {
            var10000 = var22;
            var10001 = false;
            break label188;
         }
      }

      while(true) {
         Throwable var4 = var10000;

         try {
            throw var4;
         } catch (Throwable var21) {
            var10000 = var21;
            var10001 = false;
            continue;
         }
      }
   }

   public final int a(String var1) {
      this.a.c();

      int var4;
      label213: {
         Throwable var10000;
         label218: {
            b.l.w.q.e var2;
            boolean var10001;
            try {
               var2 = this.a.m();
            } catch (Throwable var24) {
               var10000 = var24;
               var10001 = false;
               break label218;
            }

            b.l.w.q.f var26 = (b.l.w.q.f)var2;

            Long var27;
            try {
               var27 = var26.a(var1);
            } catch (Throwable var23) {
               var10000 = var23;
               var10001 = false;
               break label218;
            }

            int var3 = 0;
            if (var27 != null) {
               try {
                  var4 = var27.intValue();
               } catch (Throwable var22) {
                  var10000 = var22;
                  var10001 = false;
                  break label218;
               }
            } else {
               var4 = 0;
            }

            if (var4 != Integer.MAX_VALUE) {
               var3 = var4 + 1;
            }

            label200:
            try {
               this.a(var1, var3);
               this.a.k();
               break label213;
            } catch (Throwable var21) {
               var10000 = var21;
               var10001 = false;
               break label200;
            }
         }

         Throwable var25 = var10000;
         this.a.e();
         throw var25;
      }

      this.a.e();
      return var4;
   }

   public final void a(String var1, int var2) {
      b.l.w.q.e var3 = this.a.m();
      b.l.w.q.d var4 = new b.l.w.q.d(var1, (long)var2);
      ((b.l.w.q.f)var3).a(var4);
   }
}
