package b.l.w;

import android.annotation.SuppressLint;

public class l implements Runnable {
   // $FF: synthetic field
   public final b.l.w.r.m.c a;
   // $FF: synthetic field
   public final String b;
   // $FF: synthetic field
   public final m c;

   public l(m var1, b.l.w.r.m.c var2, String var3) {
      this.c = var1;
      this.a = var2;
      this.b = var3;
   }

   @SuppressLint({"SyntheticAccessor"})
   public void run() {
      // $FF: Couldn't be decompiled
   }
}
