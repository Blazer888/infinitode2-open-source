package b.l.w;

import androidx.work.impl.WorkDatabase;

public final class g extends b.i.g.b {
   public void a(b.j.a.b var1) {
      super.a(var1);
      ((b.j.a.g.a)var1).a.beginTransaction();

      try {
         String var2 = WorkDatabase.s();
         ((b.j.a.g.a)var1).a.execSQL(var2);
         ((b.j.a.g.a)var1).a.setTransactionSuccessful();
      } finally {
         ((b.j.a.g.a)var1).a.endTransaction();
      }

   }
}
