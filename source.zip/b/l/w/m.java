package b.l.w;

import android.content.Context;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.background.systemalarm.RescheduleReceiver;
import b.l.s;
import b.l.w.q.n;
import b.l.w.q.o;
import b.l.w.q.p;
import b.l.w.q.q;
import b.l.w.q.r;
import b.l.w.q.t;
import b.l.w.q.u;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

public class m implements Runnable {
   public static final String t = b.l.l.a("WorkerWrapper");
   public Context a;
   public String b;
   public List c;
   public WorkerParameters.a d;
   public p e;
   public ListenableWorker f;
   public ListenableWorker.a g = new ListenableWorker.a.a();
   public b.l.b h;
   public b.l.w.r.n.a i;
   public b.l.w.p.a j;
   public WorkDatabase k;
   public q l;
   public b.l.w.q.b m;
   public t n;
   public List o;
   public String p;
   public b.l.w.r.m.c q = new b.l.w.r.m.c();
   public c.c.c.a.a.a r = null;
   public volatile boolean s;

   public m(m.a var1) {
      this.a = var1.a;
      this.i = var1.d;
      this.j = var1.c;
      this.b = var1.g;
      this.c = var1.h;
      this.d = var1.i;
      this.f = var1.b;
      this.h = var1.e;
      this.k = var1.f;
      this.l = this.k.q();
      this.m = this.k.l();
      this.n = this.k.r();
   }

   public void a() {
      if (!this.f()) {
         this.k.c();

         label658: {
            Throwable var10000;
            label664: {
               q var1;
               String var2;
               boolean var10001;
               try {
                  var1 = this.l;
                  var2 = this.b;
               } catch (Throwable var59) {
                  var10000 = var59;
                  var10001 = false;
                  break label664;
               }

               r var60 = (r)var1;

               n var3;
               s var61;
               try {
                  var61 = var60.b(var2);
                  var3 = this.k.p();
                  var2 = this.b;
               } catch (Throwable var58) {
                  var10000 = var58;
                  var10001 = false;
                  break label664;
               }

               o var65 = (o)var3;

               try {
                  var65.a(var2);
               } catch (Throwable var57) {
                  var10000 = var57;
                  var10001 = false;
                  break label664;
               }

               if (var61 == null) {
                  try {
                     this.a(false);
                  } catch (Throwable var55) {
                     var10000 = var55;
                     var10001 = false;
                     break label664;
                  }
               } else {
                  label668: {
                     try {
                        if (var61 == b.l.s.b) {
                           this.a(this.g);
                           break label668;
                        }
                     } catch (Throwable var56) {
                        var10000 = var56;
                        var10001 = false;
                        break label664;
                     }

                     try {
                        if (!var61.a()) {
                           this.b();
                        }
                     } catch (Throwable var54) {
                        var10000 = var54;
                        var10001 = false;
                        break label664;
                     }
                  }
               }

               label633:
               try {
                  this.k.k();
                  break label658;
               } catch (Throwable var53) {
                  var10000 = var53;
                  var10001 = false;
                  break label633;
               }
            }

            Throwable var62 = var10000;
            this.k.e();
            throw var62;
         }

         this.k.e();
      }

      List var63 = this.c;
      if (var63 != null) {
         Iterator var64 = var63.iterator();

         while(var64.hasNext()) {
            ((d)var64.next()).a(this.b);
         }

         b.l.w.e.a(this.h, this.k, this.c);
      }

   }

   public final void a(ListenableWorker.a var1) {
      if (!(var1 instanceof ListenableWorker.a.c)) {
         if (var1 instanceof ListenableWorker.a.b) {
            b.l.l.a().c(t, String.format("Worker result RETRY for %s", this.p));
            this.b();
         } else {
            b.l.l.a().c(t, String.format("Worker result FAILURE for %s", this.p));
            if (this.e.d()) {
               this.c();
            } else {
               this.e();
            }
         }
      } else {
         b.l.l.a().c(t, String.format("Worker result SUCCESS for %s", this.p));
         if (this.e.d()) {
            this.c();
         } else {
            this.k.c();

            label1124: {
               Throwable var10000;
               label1132: {
                  q var2;
                  s var3;
                  boolean var10001;
                  String var117;
                  try {
                     var2 = this.l;
                     var3 = b.l.s.c;
                     var117 = this.b;
                  } catch (Throwable var116) {
                     var10000 = var116;
                     var10001 = false;
                     break label1132;
                  }

                  r var119 = (r)var2;

                  b.l.e var118;
                  String var122;
                  try {
                     var119.a(var3, var117);
                     var118 = ((ListenableWorker.a.c)this.g).a;
                     var2 = this.l;
                     var122 = this.b;
                  } catch (Throwable var115) {
                     var10000 = var115;
                     var10001 = false;
                     break label1132;
                  }

                  var119 = (r)var2;

                  long var4;
                  b.l.w.q.b var123;
                  try {
                     var119.a(var122, var118);
                     var4 = System.currentTimeMillis();
                     var123 = this.m;
                     var117 = this.b;
                  } catch (Throwable var114) {
                     var10000 = var114;
                     var10001 = false;
                     break label1132;
                  }

                  b.l.w.q.c var124 = (b.l.w.q.c)var123;

                  Iterator var120;
                  try {
                     var120 = var124.a(var117).iterator();
                  } catch (Throwable var110) {
                     var10000 = var110;
                     var10001 = false;
                     break label1132;
                  }

                  while(true) {
                     try {
                        if (!var120.hasNext()) {
                           break;
                        }

                        var122 = (String)var120.next();
                        var2 = this.l;
                     } catch (Throwable var113) {
                        var10000 = var113;
                        var10001 = false;
                        break label1132;
                     }

                     var119 = (r)var2;

                     b.l.w.q.b var125;
                     try {
                        if (var119.b(var122) != b.l.s.e) {
                           continue;
                        }

                        var125 = this.m;
                     } catch (Throwable var112) {
                        var10000 = var112;
                        var10001 = false;
                        break label1132;
                     }

                     b.l.w.q.c var126 = (b.l.w.q.c)var125;

                     q var6;
                     s var127;
                     try {
                        if (!var126.b(var122)) {
                           continue;
                        }

                        b.l.l.a().c(t, String.format("Setting status to enqueued for %s", var122));
                        var6 = this.l;
                        var127 = b.l.s.a;
                     } catch (Throwable var111) {
                        var10000 = var111;
                        var10001 = false;
                        break label1132;
                     }

                     r var128 = (r)var6;

                     try {
                        var128.a(var127, var122);
                        var2 = this.l;
                     } catch (Throwable var109) {
                        var10000 = var109;
                        var10001 = false;
                        break label1132;
                     }

                     var119 = (r)var2;

                     try {
                        var119.b(var122, var4);
                     } catch (Throwable var108) {
                        var10000 = var108;
                        var10001 = false;
                        break label1132;
                     }
                  }

                  label1085:
                  try {
                     this.k.k();
                     break label1124;
                  } catch (Throwable var107) {
                     var10000 = var107;
                     var10001 = false;
                     break label1085;
                  }
               }

               Throwable var121 = var10000;
               this.k.e();
               this.a(false);
               throw var121;
            }

            this.k.e();
            this.a(false);
         }
      }

   }

   public final void a(String var1) {
      LinkedList var2 = new LinkedList();
      var2.add(var1);

      for(; !var2.isEmpty(); var2.addAll(((b.l.w.q.c)this.m).a(var1))) {
         var1 = (String)var2.remove();
         if (((r)this.l).b(var1) != b.l.s.f) {
            q var3 = this.l;
            s var4 = b.l.s.d;
            ((r)var3).a(var4, var1);
         }
      }

   }

   public final void a(boolean var1) {
      this.k.c();

      label803: {
         Throwable var10000;
         label807: {
            q var2;
            boolean var10001;
            try {
               var2 = this.k.q();
            } catch (Throwable var94) {
               var10000 = var94;
               var10001 = false;
               break label807;
            }

            r var95 = (r)var2;

            boolean var3;
            label797: {
               label796: {
                  try {
                     if (var95.a().isEmpty()) {
                        break label796;
                     }
                  } catch (Throwable var93) {
                     var10000 = var93;
                     var10001 = false;
                     break label807;
                  }

                  var3 = false;
                  break label797;
               }

               var3 = true;
            }

            if (var3) {
               try {
                  b.l.w.r.d.a(this.a, RescheduleReceiver.class, false);
               } catch (Throwable var92) {
                  var10000 = var92;
                  var10001 = false;
                  break label807;
               }
            }

            label808: {
               try {
                  if (this.e == null || this.f == null || !this.f.isRunInForeground()) {
                     break label808;
                  }
               } catch (Throwable var91) {
                  var10000 = var91;
                  var10001 = false;
                  break label807;
               }

               String var96;
               if (var1) {
                  q var4;
                  try {
                     var4 = this.l;
                     var96 = this.b;
                  } catch (Throwable var90) {
                     var10000 = var90;
                     var10001 = false;
                     break label807;
                  }

                  r var98 = (r)var4;

                  try {
                     var98.a(var96, -1L);
                  } catch (Throwable var89) {
                     var10000 = var89;
                     var10001 = false;
                     break label807;
                  }
               }

               b.l.w.p.a var99;
               try {
                  var99 = this.j;
                  var96 = this.b;
               } catch (Throwable var88) {
                  var10000 = var88;
                  var10001 = false;
                  break label807;
               }

               c var100 = (c)var99;

               try {
                  var100.d(var96);
               } catch (Throwable var87) {
                  var10000 = var87;
                  var10001 = false;
                  break label807;
               }
            }

            label766:
            try {
               this.k.k();
               break label803;
            } catch (Throwable var86) {
               var10000 = var86;
               var10001 = false;
               break label766;
            }
         }

         Throwable var97 = var10000;
         this.k.e();
         throw var97;
      }

      this.k.e();
      this.q.c(var1);
   }

   public final void b() {
      this.k.c();

      label186: {
         Throwable var10000;
         label190: {
            q var1;
            s var2;
            String var3;
            boolean var10001;
            try {
               var1 = this.l;
               var2 = b.l.s.a;
               var3 = this.b;
            } catch (Throwable var25) {
               var10000 = var25;
               var10001 = false;
               break label190;
            }

            r var26 = (r)var1;

            long var4;
            q var27;
            try {
               var26.a(var2, var3);
               var27 = this.l;
               var3 = this.b;
               var4 = System.currentTimeMillis();
            } catch (Throwable var24) {
               var10000 = var24;
               var10001 = false;
               break label190;
            }

            r var28 = (r)var27;

            try {
               var28.b(var3, var4);
               var27 = this.l;
               var3 = this.b;
            } catch (Throwable var23) {
               var10000 = var23;
               var10001 = false;
               break label190;
            }

            var28 = (r)var27;

            label173:
            try {
               var28.a(var3, -1L);
               this.k.k();
               break label186;
            } catch (Throwable var22) {
               var10000 = var22;
               var10001 = false;
               break label173;
            }
         }

         Throwable var29 = var10000;
         this.k.e();
         this.a(true);
         throw var29;
      }

      this.k.e();
      this.a(true);
   }

   public final void c() {
      this.k.c();

      label266: {
         Throwable var10000;
         label270: {
            q var1;
            String var2;
            long var3;
            boolean var10001;
            try {
               var1 = this.l;
               var2 = this.b;
               var3 = System.currentTimeMillis();
            } catch (Throwable var35) {
               var10000 = var35;
               var10001 = false;
               break label270;
            }

            r var36 = (r)var1;

            q var5;
            String var37;
            s var38;
            try {
               var36.b(var2, var3);
               var5 = this.l;
               var38 = b.l.s.a;
               var37 = this.b;
            } catch (Throwable var34) {
               var10000 = var34;
               var10001 = false;
               break label270;
            }

            r var40 = (r)var5;

            try {
               var40.a(var38, var37);
               var1 = this.l;
               var2 = this.b;
            } catch (Throwable var33) {
               var10000 = var33;
               var10001 = false;
               break label270;
            }

            var36 = (r)var1;

            try {
               var36.g(var2);
               var1 = this.l;
               var2 = this.b;
            } catch (Throwable var32) {
               var10000 = var32;
               var10001 = false;
               break label270;
            }

            var36 = (r)var1;

            label249:
            try {
               var36.a(var2, -1L);
               this.k.k();
               break label266;
            } catch (Throwable var31) {
               var10000 = var31;
               var10001 = false;
               break label249;
            }
         }

         Throwable var39 = var10000;
         this.k.e();
         this.a(false);
         throw var39;
      }

      this.k.e();
      this.a(false);
   }

   public final void d() {
      q var1 = this.l;
      String var2 = this.b;
      s var3 = ((r)var1).b(var2);
      if (var3 == b.l.s.b) {
         b.l.l.a().a(t, String.format("Status for %s is RUNNING;not doing any work and rescheduling for later execution", this.b));
         this.a(true);
      } else {
         b.l.l.a().a(t, String.format("Status for %s is %s; not doing any work", this.b, var3));
         this.a(false);
      }

   }

   public void e() {
      this.k.c();

      label68: {
         Throwable var10000;
         label72: {
            b.l.e var1;
            boolean var10001;
            q var2;
            String var3;
            try {
               this.a(this.b);
               var1 = ((ListenableWorker.a.a)this.g).a;
               var2 = this.l;
               var3 = this.b;
            } catch (Throwable var9) {
               var10000 = var9;
               var10001 = false;
               break label72;
            }

            r var11 = (r)var2;

            label63:
            try {
               var11.a(var3, var1);
               this.k.k();
               break label68;
            } catch (Throwable var8) {
               var10000 = var8;
               var10001 = false;
               break label63;
            }
         }

         Throwable var10 = var10000;
         this.k.e();
         this.a(false);
         throw var10;
      }

      this.k.e();
      this.a(false);
   }

   public final boolean f() {
      if (this.s) {
         b.l.l.a().a(t, String.format("Work interrupted for %s", this.p));
         q var1 = this.l;
         String var2 = this.b;
         s var3 = ((r)var1).b(var2);
         if (var3 == null) {
            this.a(false);
         } else {
            this.a(var3.a() ^ true);
         }

         return true;
      } else {
         return false;
      }
   }

   public void run() {
      t var1 = this.n;
      String var2 = this.b;
      this.o = ((u)var1).a(var2);
      List var166 = this.o;
      StringBuilder var169 = new StringBuilder("Work [ id=");
      var169.append(this.b);
      var169.append(", tags={ ");
      Iterator var167 = var166.iterator();
      boolean var3 = true;

      boolean var4;
      String var5;
      for(var4 = true; var167.hasNext(); var169.append(var5)) {
         var5 = (String)var167.next();
         if (var4) {
            var4 = false;
         } else {
            var169.append(", ");
         }
      }

      var169.append(" } ]");
      this.p = var169.toString();
      if (!this.f()) {
         this.k.c();

         Throwable var10000;
         Throwable var172;
         label2207: {
            boolean var10001;
            q var168;
            try {
               var168 = this.l;
               var2 = this.b;
            } catch (Throwable var160) {
               var10000 = var160;
               var10001 = false;
               break label2207;
            }

            r var170 = (r)var168;

            label2208: {
               label2187: {
                  try {
                     this.e = var170.d(var2);
                     if (this.e == null) {
                        b.l.l.a().b(t, String.format("Didn't find WorkSpec for id %s", this.b));
                        this.a(false);
                        break label2187;
                     }
                  } catch (Throwable var165) {
                     var10000 = var165;
                     var10001 = false;
                     break label2207;
                  }

                  try {
                     if (this.e.b != b.l.s.a) {
                        this.d();
                        this.k.k();
                        b.l.l.a().a(t, String.format("%s is not in ENQUEUED state. Nothing more to do.", this.e.c));
                        break label2187;
                     }
                  } catch (Throwable var164) {
                     var10000 = var164;
                     var10001 = false;
                     break label2207;
                  }

                  try {
                     if (!this.e.d() && !this.e.c()) {
                        break label2208;
                     }
                  } catch (Throwable var162) {
                     var10000 = var162;
                     var10001 = false;
                     break label2207;
                  }

                  long var6;
                  label2156: {
                     label2155: {
                        try {
                           var6 = System.currentTimeMillis();
                           if (this.e.n == 0L) {
                              break label2155;
                           }
                        } catch (Throwable var163) {
                           var10000 = var163;
                           var10001 = false;
                           break label2207;
                        }

                        var4 = false;
                        break label2156;
                     }

                     var4 = true;
                  }

                  if (var4) {
                     break label2208;
                  }

                  try {
                     if (var6 >= this.e.a()) {
                        break label2208;
                     }

                     b.l.l.a().a(t, String.format("Delaying execution for %s because it is being executed before schedule.", this.e.c));
                     this.a(true);
                  } catch (Throwable var161) {
                     var10000 = var161;
                     var10001 = false;
                     break label2207;
                  }
               }

               this.k.e();
               return;
            }

            try {
               this.k.k();
            } catch (Throwable var159) {
               var10000 = var159;
               var10001 = false;
               break label2207;
            }

            this.k.e();
            b.l.e var174;
            q var179;
            if (this.e.d()) {
               var174 = this.e.e;
            } else {
               b.l.i var175 = this.h.d.a(this.e.d);
               if (var175 == null) {
                  b.l.l.a().b(t, String.format("Could not create Input Merger %s", this.e.d));
                  this.e();
                  return;
               }

               ArrayList var171 = new ArrayList();
               var171.add(this.e.e);
               var179 = this.l;
               String var8 = this.b;
               var171.addAll(((r)var179).a(var8));
               var174 = var175.a((List)var171);
            }

            UUID var173 = UUID.fromString(this.b);
            List var9 = this.o;
            WorkerParameters.a var184 = this.d;
            int var180 = this.e.k;
            b.l.b var181 = this.h;
            WorkerParameters var177 = new WorkerParameters(var173, var174, var9, var184, var180, var181.a, this.i, var181.c(), new b.l.w.r.k(this.k, this.i), new b.l.w.r.j(this.j, this.i));
            if (this.f == null) {
               this.f = this.h.c().a(this.a, this.e.c, var177);
            }

            ListenableWorker var178 = this.f;
            if (var178 == null) {
               b.l.l.a().b(t, String.format("Could not create Worker %s", this.e.c));
               this.e();
               return;
            }

            if (var178.isUsed()) {
               b.l.l.a().b(t, String.format("Received an already-used Worker %s; WorkerFactory should return new instances", this.e.c));
               this.e();
               return;
            }

            this.f.setUsed();
            this.k.c();

            label2128: {
               label2188: {
                  try {
                     var168 = this.l;
                     var2 = this.b;
                  } catch (Throwable var158) {
                     var10000 = var158;
                     var10001 = false;
                     break label2188;
                  }

                  var170 = (r)var168;

                  label2122: {
                     label2189: {
                        s var176;
                        try {
                           if (var170.b(var2) != b.l.s.a) {
                              break label2189;
                           }

                           var179 = this.l;
                           var176 = b.l.s.b;
                           var2 = this.b;
                        } catch (Throwable var157) {
                           var10000 = var157;
                           var10001 = false;
                           break label2188;
                        }

                        r var182 = (r)var179;

                        try {
                           var182.a(var176, var2);
                           var168 = this.l;
                           var2 = this.b;
                        } catch (Throwable var156) {
                           var10000 = var156;
                           var10001 = false;
                           break label2188;
                        }

                        var170 = (r)var168;

                        try {
                           var170.f(var2);
                        } catch (Throwable var155) {
                           var10000 = var155;
                           var10001 = false;
                           break label2188;
                        }

                        var4 = var3;
                        break label2122;
                     }

                     var4 = false;
                  }

                  label2108:
                  try {
                     this.k.k();
                     break label2128;
                  } catch (Throwable var154) {
                     var10000 = var154;
                     var10001 = false;
                     break label2108;
                  }
               }

               var172 = var10000;
               this.k.e();
               throw var172;
            }

            this.k.e();
            if (var4) {
               if (!this.f()) {
                  b.l.w.r.m.c var183 = new b.l.w.r.m.c();
                  ((b.l.w.r.n.b)this.i).c.execute(new k(this, var183));
                  var183.a(new l(this, var183, this.p), ((b.l.w.r.n.b)this.i).a);
                  return;
               }
            } else {
               this.d();
            }

            return;
         }

         var172 = var10000;
         this.k.e();
         throw var172;
      }
   }

   public static class a {
      public Context a;
      public ListenableWorker b;
      public b.l.w.p.a c;
      public b.l.w.r.n.a d;
      public b.l.b e;
      public WorkDatabase f;
      public String g;
      public List h;
      public WorkerParameters.a i = new WorkerParameters.a();

      public a(Context var1, b.l.b var2, b.l.w.r.n.a var3, b.l.w.p.a var4, WorkDatabase var5, String var6) {
         this.a = var1.getApplicationContext();
         this.d = var3;
         this.c = var4;
         this.e = var2;
         this.f = var5;
         this.g = var6;
      }
   }
}
