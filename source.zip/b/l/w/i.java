package b.l.w;

import android.content.Context;
import android.os.Build.VERSION;
import java.io.File;
import java.util.HashMap;
import java.util.Iterator;

public class i {
   public static final String a = b.l.l.a("WrkDbPathHelper");
   public static final String[] b = new String[]{"-journal", "-shm", "-wal"};

   public static String a() {
      return "androidx.work.workdb";
   }

   public static void a(Context var0) {
      File var1 = var0.getDatabasePath("androidx.work.workdb");
      if (VERSION.SDK_INT >= 23 && var1.exists()) {
         b.l.l.a().a(a, "Migrating WorkDatabase to the no-backup directory");
         HashMap var10 = new HashMap();
         String var6;
         File var9;
         if (VERSION.SDK_INT >= 23) {
            File var2 = var0.getDatabasePath("androidx.work.workdb");
            if (VERSION.SDK_INT < 23) {
               var9 = var0.getDatabasePath("androidx.work.workdb");
            } else {
               var9 = new File(var0.getNoBackupFilesDir(), "androidx.work.workdb");
            }

            var10.put(var2, var9);
            String[] var3 = b;
            int var4 = var3.length;

            for(int var5 = 0; var5 < var4; ++var5) {
               var6 = var3[var5];
               StringBuilder var7 = new StringBuilder();
               var7.append(var2.getPath());
               var7.append(var6);
               File var8 = new File(var7.toString());
               var7 = new StringBuilder();
               var7.append(var9.getPath());
               var7.append(var6);
               var10.put(var8, new File(var7.toString()));
            }
         }

         Iterator var12 = var10.keySet().iterator();

         while(var12.hasNext()) {
            var9 = (File)var12.next();
            File var13 = (File)var10.get(var9);
            if (var9.exists() && var13 != null) {
               if (var13.exists()) {
                  var6 = String.format("Over-writing contents of %s", var13);
                  b.l.l.a().d(a, var6);
               }

               String var11;
               if (var9.renameTo(var13)) {
                  var11 = String.format("Migrated %s to %s", var9, var13);
               } else {
                  var11 = String.format("Renaming %s to %s failed", var9, var13);
               }

               b.l.l.a().a(a, var11);
            }
         }
      }

   }
}
