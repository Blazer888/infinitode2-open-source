package b.l.w;

public class k implements Runnable {
   // $FF: synthetic field
   public final b.l.w.r.m.c a;
   // $FF: synthetic field
   public final m b;

   public k(m var1, b.l.w.r.m.c var2) {
      this.b = var1;
      this.a = var2;
   }

   public void run() {
      try {
         b.l.l.a().a(m.t, String.format("Starting work for %s", this.b.e.c));
         this.b.r = this.b.f.startWork();
         this.a.b(this.b.r);
      } catch (Throwable var3) {
         this.a.a(var3);
         return;
      }

   }
}
