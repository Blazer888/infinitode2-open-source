package b.l.w;

import b.l.w.q.p;

public interface d {
   void a(String var1);

   void a(p... var1);
}
