package b.l.w;

import android.text.TextUtils;
import b.l.o;
import b.l.r;
import b.l.u;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class f extends r {
   public static final String j = b.l.l.a("WorkContinuationImpl");
   public final j a;
   public final String b;
   public final b.l.f c;
   public final List d;
   public final List e;
   public final List f;
   public final List g;
   public boolean h;
   public o i;

   public f(j var1, String var2, b.l.f var3, List var4) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.g = null;
      this.e = new ArrayList(this.d.size());
      this.f = new ArrayList();

      for(int var5 = 0; var5 < var4.size(); ++var5) {
         String var6 = ((u)var4.get(var5)).a();
         this.e.add(var6);
         this.f.add(var6);
      }

   }

   public static Set a(f var0) {
      HashSet var1 = new HashSet();
      List var2 = var0.g;
      if (var2 != null && !var2.isEmpty()) {
         Iterator var3 = var2.iterator();

         while(var3.hasNext()) {
            var1.addAll(((f)var3.next()).e);
         }
      }

      return var1;
   }

   public static boolean a(f var0, Set var1) {
      var1.addAll(var0.e);
      Set var2 = a(var0);
      Iterator var3 = var1.iterator();

      while(var3.hasNext()) {
         if (var2.contains((String)var3.next())) {
            return true;
         }
      }

      List var4 = var0.g;
      if (var4 != null && !var4.isEmpty()) {
         Iterator var5 = var4.iterator();

         while(var5.hasNext()) {
            if (a((f)var5.next(), var1)) {
               return true;
            }
         }
      }

      var1.removeAll(var0.e);
      return false;
   }

   public o a() {
      if (!this.h) {
         b.l.w.r.b var1 = new b.l.w.r.b(this);
         ((b.l.w.r.n.b)this.a.d).a.execute(var1);
         this.i = var1.b;
      } else {
         b.l.l.a().d(j, String.format("Already enqueued work ids (%s)", TextUtils.join(", ", this.e)));
      }

      return this.i;
   }

   public boolean b() {
      return a(this, new HashSet());
   }
}
