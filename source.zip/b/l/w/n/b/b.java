package b.l.w.n.b;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.background.systemalarm.ConstraintProxy;
import androidx.work.impl.background.systemalarm.SystemAlarmService;
import b.l.l;
import b.l.w.q.p;
import b.l.w.q.q;
import b.l.w.q.r;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class b implements b.l.w.a {
   public static final String d = l.a("CommandHandler");
   public final Context a;
   public final Map b;
   public final Object c;

   public b(Context var1) {
      this.a = var1;
      this.b = new HashMap();
      this.c = new Object();
   }

   public static Intent a(Context var0) {
      Intent var1 = new Intent(var0, SystemAlarmService.class);
      var1.setAction("ACTION_CONSTRAINTS_CHANGED");
      return var1;
   }

   public static Intent a(Context var0, String var1) {
      Intent var2 = new Intent(var0, SystemAlarmService.class);
      var2.setAction("ACTION_DELAY_MET");
      var2.putExtra("KEY_WORKSPEC_ID", var1);
      return var2;
   }

   public static Intent a(Context var0, String var1, boolean var2) {
      Intent var3 = new Intent(var0, SystemAlarmService.class);
      var3.setAction("ACTION_EXECUTION_COMPLETED");
      var3.putExtra("KEY_WORKSPEC_ID", var1);
      var3.putExtra("KEY_NEEDS_RESCHEDULE", var2);
      return var3;
   }

   public static Intent b(Context var0) {
      Intent var1 = new Intent(var0, SystemAlarmService.class);
      var1.setAction("ACTION_RESCHEDULE");
      return var1;
   }

   public static Intent b(Context var0, String var1) {
      Intent var2 = new Intent(var0, SystemAlarmService.class);
      var2.setAction("ACTION_SCHEDULE_WORK");
      var2.putExtra("KEY_WORKSPEC_ID", var1);
      return var2;
   }

   public static Intent c(Context var0, String var1) {
      Intent var2 = new Intent(var0, SystemAlarmService.class);
      var2.setAction("ACTION_STOP_WORK");
      var2.putExtra("KEY_WORKSPEC_ID", var1);
      return var2;
   }

   public final void a(Intent var1, int var2, e var3) {
      Bundle var4 = var1.getExtras();
      Object var26 = this.c;
      synchronized(var26){}

      Throwable var10000;
      boolean var10001;
      label195: {
         label189: {
            String var28;
            try {
               var28 = var4.getString("KEY_WORKSPEC_ID");
               l.a().a(d, String.format("Handing delay met for %s", var28));
               if (!this.b.containsKey(var28)) {
                  d var5 = new d(this.a, var2, var28, var3);
                  this.b.put(var28, var5);
                  var5.b();
                  break label189;
               }
            } catch (Throwable var25) {
               var10000 = var25;
               var10001 = false;
               break label195;
            }

            try {
               l.a().a(d, String.format("WorkSpec %s is already being handled for ACTION_DELAY_MET", var28));
            } catch (Throwable var24) {
               var10000 = var24;
               var10001 = false;
               break label195;
            }
         }

         label180:
         try {
            return;
         } catch (Throwable var23) {
            var10000 = var23;
            var10001 = false;
            break label180;
         }
      }

      while(true) {
         Throwable var27 = var10000;

         try {
            throw var27;
         } catch (Throwable var22) {
            var10000 = var22;
            var10001 = false;
            continue;
         }
      }
   }

   public void a(String var1, boolean var2) {
      Object var3 = this.c;
      synchronized(var3){}

      Throwable var10000;
      boolean var10001;
      label176: {
         b.l.w.a var4;
         try {
            var4 = (b.l.w.a)this.b.remove(var1);
         } catch (Throwable var24) {
            var10000 = var24;
            var10001 = false;
            break label176;
         }

         if (var4 != null) {
            try {
               var4.a(var1, var2);
            } catch (Throwable var23) {
               var10000 = var23;
               var10001 = false;
               break label176;
            }
         }

         label165:
         try {
            return;
         } catch (Throwable var22) {
            var10000 = var22;
            var10001 = false;
            break label165;
         }
      }

      while(true) {
         Throwable var25 = var10000;

         try {
            throw var25;
         } catch (Throwable var21) {
            var10000 = var21;
            var10001 = false;
            continue;
         }
      }
   }

   public boolean a() {
      Object var1 = this.c;
      synchronized(var1){}

      Throwable var10000;
      boolean var10001;
      label134: {
         boolean var2;
         label133: {
            label132: {
               try {
                  if (!this.b.isEmpty()) {
                     break label132;
                  }
               } catch (Throwable var15) {
                  var10000 = var15;
                  var10001 = false;
                  break label134;
               }

               var2 = false;
               break label133;
            }

            var2 = true;
         }

         label126:
         try {
            return var2;
         } catch (Throwable var14) {
            var10000 = var14;
            var10001 = false;
            break label126;
         }
      }

      while(true) {
         Throwable var3 = var10000;

         try {
            throw var3;
         } catch (Throwable var13) {
            var10000 = var13;
            var10001 = false;
            continue;
         }
      }
   }

   public void b(Intent var1, int var2, e var3) {
      String var4 = var1.getAction();
      long var6;
      e.b var78;
      if ("ACTION_CONSTRAINTS_CHANGED".equals(var4)) {
         l.a().a(d, String.format("Handling constraints changed %s", var1));
         c var70 = new c(this.a, var2, var3);
         List var79 = ((r)var70.c.e.c.q()).c();
         ConstraintProxy.a(var70.a, var79);
         var70.d.a((Iterable)var79);
         ArrayList var75 = new ArrayList(var79.size());
         var6 = System.currentTimeMillis();
         Iterator var87 = var79.iterator();

         while(true) {
            p var80;
            do {
               do {
                  if (!var87.hasNext()) {
                     Iterator var76 = var75.iterator();

                     while(var76.hasNext()) {
                        String var89 = ((p)var76.next()).a;
                        Intent var81 = a(var70.a, var89);
                        l.a().a(b.l.w.n.b.c.e, String.format("Creating a delay_met command for workSpec with id (%s)", var89));
                        e var90 = var70.c;
                        var78 = new e.b(var90, var81, var70.b);
                        var90.g.post(var78);
                     }

                     var70.d.a();
                     return;
                  }

                  var80 = (p)var87.next();
                  var4 = var80.a;
               } while(var6 < var80.a());
            } while(var80.b() && !var70.d.a(var4));

            var75.add(var80);
         }
      } else if ("ACTION_RESCHEDULE".equals(var4)) {
         l.a().a(d, String.format("Handling reschedule %s, %s", var1, var2));
         var3.e.b();
      } else {
         boolean var88;
         label1140: {
            Bundle var5 = var1.getExtras();
            String[] var8 = new String[]{"KEY_WORKSPEC_ID"};
            if (var5 != null && !var5.isEmpty()) {
               int var9 = var8.length;
               int var10 = 0;

               while(true) {
                  if (var10 >= var9) {
                     var88 = true;
                     break label1140;
                  }

                  if (var5.get(var8[var10]) == null) {
                     break;
                  }

                  ++var10;
               }
            }

            var88 = false;
         }

         if (!var88) {
            l.a().b(d, String.format("Invalid request for %s, requires %s.", var4, "KEY_WORKSPEC_ID"));
         } else {
            String var77;
            if ("ACTION_SCHEDULE_WORK".equals(var4)) {
               var77 = var1.getExtras().getString("KEY_WORKSPEC_ID");
               l.a().a(d, String.format("Handling schedule work for %s", var77));
               WorkDatabase var69 = var3.e.c;
               var69.c();

               label1124: {
                  Throwable var10000;
                  label1151: {
                     boolean var10001;
                     q var82;
                     try {
                        var82 = var69.q();
                     } catch (Throwable var67) {
                        var10000 = var67;
                        var10001 = false;
                        break label1151;
                     }

                     r var83 = (r)var82;

                     p var84;
                     try {
                        var84 = var83.d(var77);
                     } catch (Throwable var66) {
                        var10000 = var66;
                        var10001 = false;
                        break label1151;
                     }

                     String var72;
                     StringBuilder var74;
                     l var85;
                     if (var84 == null) {
                        label1100:
                        try {
                           var85 = l.a();
                           var72 = d;
                           var74 = new StringBuilder();
                           var74.append("Skipping scheduling ");
                           var74.append(var77);
                           var74.append(" because it's no longer in the DB");
                           var85.d(var72, var74.toString());
                        } catch (Throwable var61) {
                           var10000 = var61;
                           var10001 = false;
                           break label1100;
                        }
                     } else {
                        label1152: {
                           try {
                              if (var84.b.a()) {
                                 var85 = l.a();
                                 var72 = d;
                                 var74 = new StringBuilder();
                                 var74.append("Skipping scheduling ");
                                 var74.append(var77);
                                 var74.append("because it is finished.");
                                 var85.d(var72, var74.toString());
                                 break label1124;
                              }
                           } catch (Throwable var65) {
                              var10000 = var65;
                              var10001 = false;
                              break label1152;
                           }

                           label1159: {
                              try {
                                 var6 = var84.a();
                                 if (!var84.b()) {
                                    l.a().a(d, String.format("Setting up Alarms for %s at %s", var77, var6));
                                    b.l.w.n.b.a.a(this.a, var3.e, var77, var6);
                                    break label1159;
                                 }
                              } catch (Throwable var64) {
                                 var10000 = var64;
                                 var10001 = false;
                                 break label1152;
                              }

                              try {
                                 l.a().a(d, String.format("Opportunistically setting an alarm for %s at %s", var77, var6));
                                 b.l.w.n.b.a.a(this.a, var3.e, var77, var6);
                                 Intent var86 = a(this.a);
                                 var78 = new e.b(var3, var86, var2);
                                 var3.g.post(var78);
                              } catch (Throwable var63) {
                                 var10000 = var63;
                                 var10001 = false;
                                 break label1152;
                              }
                           }

                           label1102:
                           try {
                              var69.k();
                           } catch (Throwable var62) {
                              var10000 = var62;
                              var10001 = false;
                              break label1102;
                           }
                        }
                     }
                     break label1124;
                  }

                  Throwable var73 = var10000;
                  var69.e();
                  throw var73;
               }

               var69.e();
            } else if ("ACTION_DELAY_MET".equals(var4)) {
               this.a(var1, var2, var3);
            } else if ("ACTION_STOP_WORK".equals(var4)) {
               String var68 = var1.getExtras().getString("KEY_WORKSPEC_ID");
               l.a().a(d, String.format("Handing stopWork work for %s", var68));
               var3.e.c(var68);
               b.l.w.n.b.a.a(this.a, var3.e, var68);
               var3.a(var68, false);
            } else if ("ACTION_EXECUTION_COMPLETED".equals(var4)) {
               Bundle var71 = var1.getExtras();
               var77 = var71.getString("KEY_WORKSPEC_ID");
               boolean var11 = var71.getBoolean("KEY_NEEDS_RESCHEDULE");
               l.a().a(d, String.format("Handling onExecutionCompleted %s, %s", var1, var2));
               this.a(var77, var11);
            } else {
               l.a().d(d, String.format("Ignoring intent %s", var1));
            }
         }
      }

   }
}
