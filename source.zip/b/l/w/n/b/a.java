package b.l.w.n.b;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Build.VERSION;
import androidx.work.impl.WorkDatabase;
import b.l.l;
import b.l.w.j;
import b.l.w.q.g;
import b.l.w.q.i;

public class a {
   public static final String a = l.a("Alarms");

   public static void a(Context var0, j var1, String var2) {
      i var3 = (i)var1.c.n();
      g var4 = var3.a(var2);
      if (var4 != null) {
         a(var0, var2, var4.b);
         l.a().a(a, String.format("Removing SystemIdInfo for workSpecId (%s)", var2));
         var3.b(var2);
      }

   }

   public static void a(Context var0, j var1, String var2, long var3) {
      WorkDatabase var8 = var1.c;
      i var5 = (i)var8.n();
      g var6 = var5.a(var2);
      if (var6 != null) {
         a(var0, var2, var6.b);
         a(var0, var2, var6.b, var3);
      } else {
         int var7 = (new b.l.w.r.c(var8)).a();
         var5.a(new g(var2, var7));
         a(var0, var2, var7, var3);
      }

   }

   public static void a(Context var0, String var1, int var2) {
      AlarmManager var3 = (AlarmManager)var0.getSystemService("alarm");
      PendingIntent var4 = PendingIntent.getService(var0, var2, b.a(var0, var1), 536870912);
      if (var4 != null && var3 != null) {
         l.a().a(a, String.format("Cancelling existing alarm with (workSpecId, systemId) (%s, %s)", var1, var2));
         var3.cancel(var4);
      }

   }

   public static void a(Context var0, String var1, int var2, long var3) {
      AlarmManager var5 = (AlarmManager)var0.getSystemService("alarm");
      PendingIntent var6 = PendingIntent.getService(var0, var2, b.a(var0, var1), 134217728);
      if (var5 != null) {
         if (VERSION.SDK_INT >= 19) {
            var5.setExact(0, var3, var6);
         } else {
            var5.set(0, var3, var6);
         }
      }

   }
}
