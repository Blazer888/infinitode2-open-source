package b.l.w.n.b;

import android.content.Context;
import android.content.Intent;
import b.l.l;
import b.l.w.q.p;

public class f implements b.l.w.d {
   public static final String b = l.a("SystemAlarmScheduler");
   public final Context a;

   public f(Context var1) {
      this.a = var1.getApplicationContext();
   }

   public void a(String var1) {
      Intent var2 = b.l.w.n.b.b.c(this.a, var1);
      this.a.startService(var2);
   }

   public void a(p... var1) {
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         p var4 = var1[var3];
         l.a().a(b, String.format("Scheduling work with workSpecId %s", var4.a));
         Intent var5 = b.l.w.n.b.b.b(this.a, var4.a);
         this.a.startService(var5);
      }

   }
}
