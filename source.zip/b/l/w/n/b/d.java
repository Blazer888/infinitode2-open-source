package b.l.w.n.b;

import android.content.Context;
import android.content.Intent;
import android.os.PowerManager.WakeLock;
import androidx.work.WorkerParameters;
import b.l.w.q.p;
import b.l.w.q.q;
import b.l.w.q.r;
import b.l.w.r.i;
import b.l.w.r.l;
import java.util.Collections;
import java.util.List;

public class d implements b.l.w.o.c, b.l.w.a, l.b {
   public static final String j = b.l.l.a("DelayMetCommandHandler");
   public final Context a;
   public final int b;
   public final String c;
   public final e d;
   public final b.l.w.o.d e;
   public final Object f;
   public int g;
   public WakeLock h;
   public boolean i;

   public d(Context var1, int var2, String var3, e var4) {
      this.a = var1;
      this.b = var2;
      this.d = var4;
      this.c = var3;
      b.l.w.r.n.a var5 = var4.b;
      this.e = new b.l.w.o.d(this.a, var5, this);
      this.i = false;
      this.g = 0;
      this.f = new Object();
   }

   public final void a() {
      Object var1 = this.f;
      synchronized(var1){}

      Throwable var10000;
      boolean var10001;
      label130: {
         try {
            this.e.a();
            this.d.c.a(this.c);
            if (this.h != null && this.h.isHeld()) {
               b.l.l.a().a(j, String.format("Releasing wakelock %s for WorkSpec %s", this.h, this.c));
               this.h.release();
            }
         } catch (Throwable var14) {
            var10000 = var14;
            var10001 = false;
            break label130;
         }

         label127:
         try {
            return;
         } catch (Throwable var13) {
            var10000 = var13;
            var10001 = false;
            break label127;
         }
      }

      while(true) {
         Throwable var2 = var10000;

         try {
            throw var2;
         } catch (Throwable var12) {
            var10000 = var12;
            var10001 = false;
            continue;
         }
      }
   }

   public void a(String var1, boolean var2) {
      b.l.l.a().a(j, String.format("onExecuted %s, %s", var1, var2));
      this.a();
      Intent var3;
      e var4;
      e.b var5;
      if (var2) {
         var3 = b.l.w.n.b.b.b(this.a, this.c);
         var4 = this.d;
         var5 = new e.b(var4, var3, this.b);
         var4.g.post(var5);
      }

      if (this.i) {
         var3 = b.l.w.n.b.b.a(this.a);
         var4 = this.d;
         var5 = new e.b(var4, var3, this.b);
         var4.g.post(var5);
      }

   }

   public void a(List var1) {
      this.c();
   }

   public void b() {
      this.h = b.l.w.r.i.a(this.a, String.format("%s (%s)", this.c, this.b));
      b.l.l.a().a(j, String.format("Acquiring wakelock %s for WorkSpec %s", this.h, this.c));
      this.h.acquire();
      q var1 = this.d.e.c.q();
      String var2 = this.c;
      p var3 = ((r)var1).d(var2);
      if (var3 == null) {
         this.c();
      } else {
         this.i = var3.b();
         if (!this.i) {
            b.l.l.a().a(j, String.format("No constraints for %s", this.c));
            this.b(Collections.singletonList(this.c));
         } else {
            this.e.a((Iterable)Collections.singletonList(var3));
         }

      }
   }

   public void b(List var1) {
      if (var1.contains(this.c)) {
         Object var33 = this.f;
         synchronized(var33){}

         Throwable var10000;
         boolean var10001;
         label322: {
            label321: {
               label331: {
                  try {
                     if (this.g != 0) {
                        break label331;
                     }

                     this.g = 1;
                     b.l.l.a().a(j, String.format("onAllConstraintsMet for %s", this.c));
                     if (this.d.d.a(this.c, (WorkerParameters.a)null)) {
                        this.d.c.a(this.c, 600000L, this);
                        break label321;
                     }
                  } catch (Throwable var32) {
                     var10000 = var32;
                     var10001 = false;
                     break label322;
                  }

                  try {
                     this.a();
                     break label321;
                  } catch (Throwable var31) {
                     var10000 = var31;
                     var10001 = false;
                     break label322;
                  }
               }

               try {
                  b.l.l.a().a(j, String.format("Already started work for %s", this.c));
               } catch (Throwable var30) {
                  var10000 = var30;
                  var10001 = false;
                  break label322;
               }
            }

            label306:
            try {
               return;
            } catch (Throwable var29) {
               var10000 = var29;
               var10001 = false;
               break label306;
            }
         }

         while(true) {
            Throwable var2 = var10000;

            try {
               throw var2;
            } catch (Throwable var28) {
               var10000 = var28;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public final void c() {
      Object var1 = this.f;
      synchronized(var1){}

      Throwable var10000;
      boolean var10001;
      label302: {
         label306: {
            label308: {
               try {
                  if (this.g < 2) {
                     this.g = 2;
                     b.l.l.a().a(j, String.format("Stopping work for WorkSpec %s", this.c));
                     Intent var2 = b.l.w.n.b.b.c(this.a, this.c);
                     e var3 = this.d;
                     e.b var4 = new e.b(this.d, var2, this.b);
                     var3.g.post(var4);
                     if (!this.d.d.b(this.c)) {
                        break label308;
                     }

                     b.l.l.a().a(j, String.format("WorkSpec %s needs to be rescheduled", this.c));
                     Intent var36 = b.l.w.n.b.b.b(this.a, this.c);
                     e var37 = this.d;
                     e.b var35 = new e.b(this.d, var36, this.b);
                     var37.g.post(var35);
                     break label306;
                  }
               } catch (Throwable var34) {
                  var10000 = var34;
                  var10001 = false;
                  break label302;
               }

               try {
                  b.l.l.a().a(j, String.format("Already stopped work for %s", this.c));
                  break label306;
               } catch (Throwable var32) {
                  var10000 = var32;
                  var10001 = false;
                  break label302;
               }
            }

            try {
               b.l.l.a().a(j, String.format("Processor does not have WorkSpec %s. No need to reschedule ", this.c));
            } catch (Throwable var33) {
               var10000 = var33;
               var10001 = false;
               break label302;
            }
         }

         label285:
         try {
            return;
         } catch (Throwable var31) {
            var10000 = var31;
            var10001 = false;
            break label285;
         }
      }

      while(true) {
         Throwable var38 = var10000;

         try {
            throw var38;
         } catch (Throwable var30) {
            var10000 = var30;
            var10001 = false;
            continue;
         }
      }
   }
}
