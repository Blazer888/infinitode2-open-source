package b.l.w.n.b;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager.WakeLock;
import android.text.TextUtils;
import b.l.l;
import b.l.w.j;
import b.l.w.r.i;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class e implements b.l.w.a {
   public static final String k = l.a("SystemAlarmDispatcher");
   public final Context a;
   public final b.l.w.r.n.a b;
   public final b.l.w.r.l c;
   public final b.l.w.c d;
   public final j e;
   public final b.l.w.n.b.b f;
   public final Handler g;
   public final List h;
   public Intent i;
   public e.c j;

   public e(Context var1) {
      this.a = var1.getApplicationContext();
      this.f = new b.l.w.n.b.b(this.a);
      this.c = new b.l.w.r.l();
      this.e = b.l.w.j.a(var1);
      j var2 = this.e;
      this.d = var2.f;
      this.b = var2.d;
      this.d.a((b.l.w.a)this);
      this.h = new ArrayList();
      this.i = null;
      this.g = new Handler(Looper.getMainLooper());
   }

   public final void a() {
      if (this.g.getLooper().getThread() != Thread.currentThread()) {
         throw new IllegalStateException("Needs to be invoked on the main thread.");
      }
   }

   public void a(String var1, boolean var2) {
      e.b var3 = new e.b(this, b.l.w.n.b.b.a(this.a, var1, var2), 0);
      this.g.post(var3);
   }

   public boolean a(Intent var1, int var2) {
      l var3 = l.a();
      String var4 = k;
      boolean var5 = false;
      var3.a(var4, String.format("Adding command %s (%s)", var1, var2));
      this.a();
      String var38 = var1.getAction();
      if (TextUtils.isEmpty(var38)) {
         l.a().d(k, "Unknown command. Ignoring");
         return false;
      } else if ("ACTION_CONSTRAINTS_CHANGED".equals(var38) && this.a("ACTION_CONSTRAINTS_CHANGED")) {
         return false;
      } else {
         var1.putExtra("KEY_START_ID", var2);
         List var39 = this.h;
         synchronized(var39){}
         boolean var37 = var5;

         Throwable var10000;
         boolean var10001;
         label325: {
            label317: {
               try {
                  if (this.h.isEmpty()) {
                     break label317;
                  }
               } catch (Throwable var35) {
                  var10000 = var35;
                  var10001 = false;
                  break label325;
               }

               var37 = true;
            }

            try {
               this.h.add(var1);
            } catch (Throwable var34) {
               var10000 = var34;
               var10001 = false;
               break label325;
            }

            if (!var37) {
               try {
                  this.d();
               } catch (Throwable var33) {
                  var10000 = var33;
                  var10001 = false;
                  break label325;
               }
            }

            label305:
            try {
               return true;
            } catch (Throwable var32) {
               var10000 = var32;
               var10001 = false;
               break label305;
            }
         }

         while(true) {
            Throwable var36 = var10000;

            try {
               throw var36;
            } catch (Throwable var31) {
               var10000 = var31;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public final boolean a(String var1) {
      this.a();
      List var2 = this.h;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label204: {
         Iterator var3;
         try {
            var3 = this.h.iterator();
         } catch (Throwable var23) {
            var10000 = var23;
            var10001 = false;
            break label204;
         }

         try {
            while(var3.hasNext()) {
               if (var1.equals(((Intent)var3.next()).getAction())) {
                  return true;
               }
            }
         } catch (Throwable var22) {
            var10000 = var22;
            var10001 = false;
            break label204;
         }

         label194:
         try {
            return false;
         } catch (Throwable var21) {
            var10000 = var21;
            var10001 = false;
            break label194;
         }
      }

      while(true) {
         Throwable var24 = var10000;

         try {
            throw var24;
         } catch (Throwable var20) {
            var10000 = var20;
            var10001 = false;
            continue;
         }
      }
   }

   public void b() {
      l.a().a(k, "Checking if commands are complete.");
      this.a();
      List var1 = this.h;
      synchronized(var1){}

      Throwable var10000;
      boolean var10001;
      label497: {
         label504: {
            try {
               if (this.i != null) {
                  l.a().a(k, String.format("Removing command %s", this.i));
                  if (!((Intent)this.h.remove(0)).equals(this.i)) {
                     break label504;
                  }

                  this.i = null;
               }
            } catch (Throwable var44) {
               var10000 = var44;
               var10001 = false;
               break label497;
            }

            label506: {
               try {
                  b.l.w.r.f var2 = ((b.l.w.r.n.b)this.b).a;
                  if (!this.f.a() && this.h.isEmpty() && !var2.a()) {
                     l.a().a(k, "No more commands & intents.");
                     if (this.j != null) {
                        this.j.a();
                     }
                     break label506;
                  }
               } catch (Throwable var43) {
                  var10000 = var43;
                  var10001 = false;
                  break label497;
               }

               try {
                  if (!this.h.isEmpty()) {
                     this.d();
                  }
               } catch (Throwable var42) {
                  var10000 = var42;
                  var10001 = false;
                  break label497;
               }
            }

            try {
               return;
            } catch (Throwable var41) {
               var10000 = var41;
               var10001 = false;
               break label497;
            }
         }

         label468:
         try {
            IllegalStateException var46 = new IllegalStateException("Dequeue-d command is not the first.");
            throw var46;
         } catch (Throwable var40) {
            var10000 = var40;
            var10001 = false;
            break label468;
         }
      }

      while(true) {
         Throwable var45 = var10000;

         try {
            throw var45;
         } catch (Throwable var39) {
            var10000 = var39;
            var10001 = false;
            continue;
         }
      }
   }

   public void c() {
      l.a().a(k, "Destroying SystemAlarmDispatcher");
      this.d.b((b.l.w.a)this);
      b.l.w.r.l var1 = this.c;
      if (!var1.b.isShutdown()) {
         var1.b.shutdownNow();
      }

      this.j = null;
   }

   public final void d() {
      this.a();
      WakeLock var1 = b.l.w.r.i.a(this.a, "ProcessCommand");

      try {
         var1.acquire();
         b.l.w.r.n.a var2 = this.e.d;
         Runnable var3 = new Runnable() {
            public void run() {
               // $FF: Couldn't be decompiled
            }
         };
         ((b.l.w.r.n.b)var2).a.execute(var3);
      } finally {
         var1.release();
      }

   }

   public static class b implements Runnable {
      public final e a;
      public final Intent b;
      public final int c;

      public b(e var1, Intent var2, int var3) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
      }

      public void run() {
         this.a.a(this.b, this.c);
      }
   }

   public interface c {
      void a();
   }

   public static class d implements Runnable {
      public final e a;

      public d(e var1) {
         this.a = var1;
      }

      public void run() {
         this.a.b();
      }
   }
}
