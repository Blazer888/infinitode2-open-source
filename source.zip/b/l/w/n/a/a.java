package b.l.w.n.a;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.Context;
import android.os.Process;
import android.os.Build.VERSION;
import android.text.TextUtils;
import b.l.l;
import b.l.s;
import b.l.w.d;
import b.l.w.j;
import b.l.w.o.c;
import b.l.w.q.p;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class a implements d, c, b.l.w.a {
   public static final String h = l.a("GreedyScheduler");
   public final Context a;
   public final j b;
   public final b.l.w.o.d c;
   public List d = new ArrayList();
   public boolean e;
   public final Object f;
   public Boolean g;

   public a(Context var1, b.l.w.r.n.a var2, j var3) {
      this.a = var1;
      this.b = var3;
      this.c = new b.l.w.o.d(var1, var2, this);
      this.f = new Object();
   }

   public final String a() {
      int var1 = Process.myPid();
      ActivityManager var2 = (ActivityManager)this.a.getSystemService("activity");
      if (var2 != null) {
         List var4 = var2.getRunningAppProcesses();
         if (var4 != null && !var4.isEmpty()) {
            Iterator var3 = var4.iterator();

            while(var3.hasNext()) {
               RunningAppProcessInfo var5 = (RunningAppProcessInfo)var3.next();
               if (var5.pid == var1) {
                  return var5.processName;
               }
            }
         }
      }

      return null;
   }

   public void a(String var1) {
      if (this.g == null) {
         this.g = TextUtils.equals(this.a.getPackageName(), this.a());
      }

      if (!this.g) {
         l.a().c(h, "Ignoring schedule request in non-main process");
      } else {
         if (!this.e) {
            this.b.f.a((b.l.w.a)this);
            this.e = true;
         }

         l.a().a(h, String.format("Cancelling work ID %s", var1));
         this.b.c(var1);
      }
   }

   public void a(String var1, boolean var2) {
      this.b(var1);
   }

   public void a(List var1) {
      Iterator var2 = var1.iterator();

      while(var2.hasNext()) {
         String var3 = (String)var2.next();
         l.a().a(h, String.format("Constraints not met: Cancelling work ID %s", var3));
         this.b.c(var3);
      }

   }

   public void a(p... var1) {
      if (this.g == null) {
         this.g = TextUtils.equals(this.a.getPackageName(), this.a());
      }

      if (!this.g) {
         l.a().c(h, "Ignoring schedule request in non-main process");
      } else {
         if (!this.e) {
            this.b.f.a((b.l.w.a)this);
            this.e = true;
         }

         ArrayList var2 = new ArrayList();
         ArrayList var3 = new ArrayList();
         int var4 = var1.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            p var6 = var1[var5];
            if (var6.b == s.a && !var6.d() && var6.g == 0L && !var6.c()) {
               if (var6.b()) {
                  if (VERSION.SDK_INT >= 23 && var6.j.c) {
                     l.a().a(h, String.format("Ignoring WorkSpec %s, Requires device idle.", var6));
                  } else {
                     if (VERSION.SDK_INT >= 24) {
                        boolean var7;
                        if (var6.j.h.b() > 0) {
                           var7 = true;
                        } else {
                           var7 = false;
                        }

                        if (var7) {
                           l.a().a(h, String.format("Ignoring WorkSpec %s, Requires ContentUri triggers.", var6));
                           continue;
                        }
                     }

                     var2.add(var6);
                     var3.add(var6.a);
                  }
               } else {
                  l.a().a(h, String.format("Starting work for %s", var6.a));
                  this.b.b(var6.a);
               }
            }
         }

         Object var20 = this.f;
         synchronized(var20){}

         Throwable var10000;
         boolean var10001;
         label333: {
            try {
               if (!var2.isEmpty()) {
                  l.a().a(h, String.format("Starting tracking for [%s]", TextUtils.join(",", var3)));
                  this.d.addAll(var2);
                  this.c.a((Iterable)this.d);
               }
            } catch (Throwable var19) {
               var10000 = var19;
               var10001 = false;
               break label333;
            }

            label330:
            try {
               return;
            } catch (Throwable var18) {
               var10000 = var18;
               var10001 = false;
               break label330;
            }
         }

         while(true) {
            Throwable var21 = var10000;

            try {
               throw var21;
            } catch (Throwable var17) {
               var10000 = var17;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public final void b(String var1) {
      Object var2 = this.f;
      synchronized(var2){}

      Throwable var10000;
      boolean var10001;
      label257: {
         int var3;
         try {
            var3 = this.d.size();
         } catch (Throwable var24) {
            var10000 = var24;
            var10001 = false;
            break label257;
         }

         for(int var4 = 0; var4 < var3; ++var4) {
            try {
               if (((p)this.d.get(var4)).a.equals(var1)) {
                  l.a().a(h, String.format("Stopping tracking for %s", var1));
                  this.d.remove(var4);
                  this.c.a((Iterable)this.d);
                  break;
               }
            } catch (Throwable var23) {
               var10000 = var23;
               var10001 = false;
               break label257;
            }
         }

         label235:
         try {
            return;
         } catch (Throwable var22) {
            var10000 = var22;
            var10001 = false;
            break label235;
         }
      }

      while(true) {
         Throwable var25 = var10000;

         try {
            throw var25;
         } catch (Throwable var21) {
            var10000 = var21;
            var10001 = false;
            continue;
         }
      }
   }

   public void b(List var1) {
      Iterator var2 = var1.iterator();

      while(var2.hasNext()) {
         String var3 = (String)var2.next();
         l.a().a(h, String.format("Constraints met: Scheduling work ID %s", var3));
         this.b.b(var3);
      }

   }
}
