package b.l.w.n.c;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.PersistableBundle;
import android.os.Build.VERSION;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.background.systemjob.SystemJobService;
import b.l.l;
import b.l.s;
import b.l.w.d;
import b.l.w.j;
import b.l.w.q.g;
import b.l.w.q.h;
import b.l.w.q.i;
import b.l.w.q.p;
import b.l.w.q.q;
import b.l.w.q.r;
import b.l.w.r.c;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class b implements d {
   public static final String e = l.a("SystemJobScheduler");
   public final Context a;
   public final JobScheduler b;
   public final j c;
   public final a d;

   public b(Context var1, j var2) {
      JobScheduler var3 = (JobScheduler)var1.getSystemService("jobscheduler");
      a var4 = new a(var1);
      super();
      this.a = var1;
      this.c = var2;
      this.b = var3;
      this.d = var4;
   }

   public static String a(JobInfo var0) {
      PersistableBundle var2 = var0.getExtras();
      if (var2 != null) {
         try {
            if (var2.containsKey("EXTRA_WORK_SPEC_ID")) {
               String var3 = var2.getString("EXTRA_WORK_SPEC_ID");
               return var3;
            }
         } catch (NullPointerException var1) {
         }
      }

      return null;
   }

   public static List a(Context var0, JobScheduler var1) {
      List var7;
      label47:
      try {
         var7 = var1.getAllPendingJobs();
      } catch (Throwable var5) {
         l.a().b(e, "getAllPendingJobs() is not reliable on this device.", var5);
         var7 = null;
         break label47;
      }

      if (var7 == null) {
         return null;
      } else {
         ArrayList var2 = new ArrayList(var7.size());
         ComponentName var6 = new ComponentName(var0, SystemJobService.class);
         Iterator var3 = var7.iterator();

         while(var3.hasNext()) {
            JobInfo var8 = (JobInfo)var3.next();
            if (var6.equals(var8.getService())) {
               var2.add(var8);
            }
         }

         return var2;
      }
   }

   public static List a(Context var0, JobScheduler var1, String var2) {
      List var5 = a(var0, var1);
      if (var5 == null) {
         return null;
      } else {
         ArrayList var4 = new ArrayList(2);
         Iterator var3 = var5.iterator();

         while(var3.hasNext()) {
            JobInfo var6 = (JobInfo)var3.next();
            if (var2.equals(a(var6))) {
               var4.add(var6.getId());
            }
         }

         return var4;
      }
   }

   public static void a(JobScheduler var0, int var1) {
      try {
         var0.cancel(var1);
      } catch (Throwable var3) {
         l.a().b(e, String.format(Locale.getDefault(), "Exception while trying to cancel job (%d)", var1), var3);
         return;
      }

   }

   public static void a(Context var0) {
      JobScheduler var1 = (JobScheduler)var0.getSystemService("jobscheduler");
      if (var1 != null) {
         List var2 = a(var0, var1);
         if (var2 != null && !var2.isEmpty()) {
            Iterator var3 = var2.iterator();

            while(var3.hasNext()) {
               a(var1, ((JobInfo)var3.next()).getId());
            }
         }
      }

   }

   public static void b(Context var0) {
      JobScheduler var1 = (JobScheduler)var0.getSystemService("jobscheduler");
      if (var1 != null) {
         List var3 = a(var0, var1);
         if (var3 != null && !var3.isEmpty()) {
            Iterator var2 = var3.iterator();

            while(var2.hasNext()) {
               JobInfo var4 = (JobInfo)var2.next();
               if (a(var4) == null) {
                  a(var1, var4.getId());
               }
            }
         }
      }

   }

   public void a(p var1, int var2) {
      JobInfo var3 = this.d.a(var1, var2);
      l.a().a(e, String.format("Scheduling work ID %s Job ID %s", var1.a, var2));

      IllegalStateException var8;
      try {
         try {
            this.b.schedule(var3);
            return;
         } catch (IllegalStateException var6) {
            var8 = var6;
         }
      } catch (Throwable var7) {
         l.a().b(e, String.format("Unable to schedule %s", var1), var7);
         return;
      }

      List var9 = a(this.a, this.b);
      if (var9 != null) {
         var2 = var9.size();
      } else {
         var2 = 0;
      }

      String var10 = String.format(Locale.getDefault(), "JobScheduler 100 job limit exceeded.  We count %d WorkManager jobs in JobScheduler; we have %d tracked jobs in our DB; our Configuration limit is %d.", var2, ((r)this.c.c.q()).c().size(), this.c.b.b());
      l.a().b(e, var10);
      throw new IllegalStateException(var10, var8);
   }

   public void a(String var1) {
      List var2 = a(this.a, this.b, var1);
      if (var2 != null && !var2.isEmpty()) {
         Iterator var4 = var2.iterator();

         while(var4.hasNext()) {
            int var3 = (Integer)var4.next();
            a(this.b, var3);
         }

         ((i)this.c.c.n()).b(var1);
      }

   }

   public void a(p... var1) {
      WorkDatabase var2 = this.c.c;
      c var3 = new c(var2);
      int var4 = var1.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         p var6 = var1[var5];
         var2.c();

         label2368: {
            Throwable var10000;
            label2376: {
               q var7;
               String var8;
               boolean var10001;
               try {
                  var7 = var2.q();
                  var8 = var6.a;
               } catch (Throwable var315) {
                  var10000 = var315;
                  var10001 = false;
                  break label2376;
               }

               r var318 = (r)var7;

               p var321;
               try {
                  var321 = var318.d(var8);
               } catch (Throwable var314) {
                  var10000 = var314;
                  var10001 = false;
                  break label2376;
               }

               if (var321 == null) {
                  label2308:
                  try {
                     l var324 = l.a();
                     String var325 = e;
                     StringBuilder var328 = new StringBuilder();
                     var328.append("Skipping scheduling ");
                     var328.append(var6.a);
                     var328.append(" because it's no longer in the DB");
                     var324.d(var325, var328.toString());
                     var2.k();
                  } catch (Throwable var300) {
                     var10000 = var300;
                     var10001 = false;
                     break label2308;
                  }
               } else {
                  label2380: {
                     try {
                        if (var321.b != s.a) {
                           l var327 = l.a();
                           String var9 = e;
                           StringBuilder var322 = new StringBuilder();
                           var322.append("Skipping scheduling ");
                           var322.append(var6.a);
                           var322.append(" because it is no longer enqueued");
                           var327.d(var9, var322.toString());
                           var2.k();
                           break label2368;
                        }
                     } catch (Throwable var316) {
                        var10000 = var316;
                        var10001 = false;
                        break label2380;
                     }

                     h var319;
                     try {
                        var319 = var2.n();
                        var8 = var6.a;
                     } catch (Throwable var313) {
                        var10000 = var313;
                        var10001 = false;
                        break label2380;
                     }

                     i var320 = (i)var319;

                     g var323;
                     try {
                        var323 = var320.a(var8);
                     } catch (Throwable var312) {
                        var10000 = var312;
                        var10001 = false;
                        break label2380;
                     }

                     int var10;
                     if (var323 != null) {
                        try {
                           var10 = var323.b;
                        } catch (Throwable var311) {
                           var10000 = var311;
                           var10001 = false;
                           break label2380;
                        }
                     } else {
                        try {
                           var10 = var3.a(this.c.b.f, this.c.b.g);
                        } catch (Throwable var310) {
                           var10000 = var310;
                           var10001 = false;
                           break label2380;
                        }
                     }

                     if (var323 == null) {
                        try {
                           var323 = new g(var6.a, var10);
                           var319 = this.c.c.n();
                        } catch (Throwable var309) {
                           var10000 = var309;
                           var10001 = false;
                           break label2380;
                        }

                        var320 = (i)var319;

                        try {
                           var320.a(var323);
                        } catch (Throwable var308) {
                           var10000 = var308;
                           var10001 = false;
                           break label2380;
                        }
                     }

                     label2333: {
                        List var326;
                        try {
                           this.a(var6, var10);
                           if (VERSION.SDK_INT != 23) {
                              break label2333;
                           }

                           var326 = a(this.a, this.b, var6.a);
                        } catch (Throwable var307) {
                           var10000 = var307;
                           var10001 = false;
                           break label2380;
                        }

                        if (var326 != null) {
                           try {
                              var10 = var326.indexOf(var10);
                           } catch (Throwable var305) {
                              var10000 = var305;
                              var10001 = false;
                              break label2380;
                           }

                           if (var10 >= 0) {
                              try {
                                 var326.remove(var10);
                              } catch (Throwable var304) {
                                 var10000 = var304;
                                 var10001 = false;
                                 break label2380;
                              }
                           }

                           label2324: {
                              try {
                                 if (!var326.isEmpty()) {
                                    var10 = (Integer)var326.get(0);
                                    break label2324;
                                 }
                              } catch (Throwable var306) {
                                 var10000 = var306;
                                 var10001 = false;
                                 break label2380;
                              }

                              try {
                                 var10 = var3.a(this.c.b.f, this.c.b.g);
                              } catch (Throwable var303) {
                                 var10000 = var303;
                                 var10001 = false;
                                 break label2380;
                              }
                           }

                           try {
                              this.a(var6, var10);
                           } catch (Throwable var302) {
                              var10000 = var302;
                              var10001 = false;
                              break label2380;
                           }
                        }
                     }

                     label2310:
                     try {
                        var2.k();
                     } catch (Throwable var301) {
                        var10000 = var301;
                        var10001 = false;
                        break label2310;
                     }
                  }
               }
               break label2368;
            }

            Throwable var317 = var10000;
            var2.e();
            throw var317;
         }

         var2.e();
      }

   }
}
