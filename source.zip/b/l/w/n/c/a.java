package b.l.w.n.c;

import android.app.job.JobInfo;
import android.app.job.JobInfo.Builder;
import android.app.job.JobInfo.TriggerContentUri;
import android.content.ComponentName;
import android.content.Context;
import android.os.PersistableBundle;
import android.os.Build.VERSION;
import androidx.work.impl.background.systemjob.SystemJobService;
import b.l.c;
import b.l.d;
import b.l.l;
import b.l.m;
import b.l.w.q.p;
import java.util.Iterator;

public class a {
   public static final String b = l.a("SystemJobInfoConverter");
   public final ComponentName a;

   public a(Context var1) {
      this.a = new ComponentName(var1.getApplicationContext(), SystemJobService.class);
   }

   public JobInfo a(p var1, int var2) {
      c var3 = var1.j;
      m var4 = var3.a;
      int var5 = var4.ordinal();
      boolean var6 = true;
      byte var7;
      if (var5 != 0) {
         label68: {
            if (var5 != 1) {
               var7 = 2;
               if (var5 == 2) {
                  break label68;
               }

               var7 = 3;
               if (var5 != 3) {
                  var7 = 4;
                  if (var5 == 4 && VERSION.SDK_INT >= 26) {
                     break label68;
                  }
               } else if (VERSION.SDK_INT >= 24) {
                  break label68;
               }

               l.a().a(b, String.format("API version too low. Cannot convert network type value %s", var4));
            }

            var7 = 1;
         }
      } else {
         var7 = 0;
      }

      PersistableBundle var14 = new PersistableBundle();
      var14.putString("EXTRA_WORK_SPEC_ID", var1.a);
      var14.putBoolean("EXTRA_IS_PERIODIC", var1.d());
      Builder var15 = (new Builder(var2, this.a)).setRequiredNetworkType(var7).setRequiresCharging(var3.b).setRequiresDeviceIdle(var3.c).setExtras(var14);
      byte var12;
      if (!var3.c) {
         if (var1.l == b.l.a.b) {
            var12 = 0;
         } else {
            var12 = 1;
         }

         var15.setBackoffCriteria(var1.m, var12);
      }

      long var8 = Math.max(var1.a() - System.currentTimeMillis(), 0L);
      if (VERSION.SDK_INT <= 28) {
         var15.setMinimumLatency(var8);
      } else if (var8 > 0L) {
         var15.setMinimumLatency(var8);
      } else {
         var15.setImportantWhileForeground(true);
      }

      if (VERSION.SDK_INT >= 24) {
         boolean var13;
         if (var3.h.b() > 0) {
            var13 = var6;
         } else {
            var13 = false;
         }

         if (var13) {
            Iterator var10 = var3.h.a.iterator();

            while(var10.hasNext()) {
               d.a var11 = (d.a)var10.next();
               var12 = var11.b;
               var15.addTriggerContentUri(new TriggerContentUri(var11.a, var12));
            }

            var15.setTriggerContentUpdateDelay(var3.f);
            var15.setTriggerContentMaxDelay(var3.g);
         }
      }

      var15.setPersisted(false);
      if (VERSION.SDK_INT >= 26) {
         var15.setRequiresBatteryNotLow(var3.d);
         var15.setRequiresStorageNotLow(var3.e);
      }

      return var15.build();
   }
}
