package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteCallbackList;
import b.i.c;
import b.i.d;
import java.util.HashMap;

public class MultiInstanceInvalidationService extends Service {
   public int a = 0;
   public final HashMap b = new HashMap();
   public final RemoteCallbackList c = new RemoteCallbackList() {
      public void onCallbackDied(IInterface var1, Object var2) {
         c var3 = (c)var1;
         MultiInstanceInvalidationService.this.b.remove((Integer)var2);
      }
   };
   public final d.a d = new d.a() {
      public int a(c var1, String var2) {
         if (var2 == null) {
            return 0;
         } else {
            RemoteCallbackList var3 = MultiInstanceInvalidationService.this.c;
            synchronized(var3){}

            Throwable var10000;
            boolean var10001;
            label137: {
               try {
                  MultiInstanceInvalidationService var4 = MultiInstanceInvalidationService.this;
                  int var5 = var4.a + 1;
                  var4.a = var5;
                  if (MultiInstanceInvalidationService.this.c.register(var1, var5)) {
                     MultiInstanceInvalidationService.this.b.put(var5, var2);
                     return var5;
                  }
               } catch (Throwable var17) {
                  var10000 = var17;
                  var10001 = false;
                  break label137;
               }

               label131:
               try {
                  MultiInstanceInvalidationService var19 = MultiInstanceInvalidationService.this;
                  --var19.a;
                  return 0;
               } catch (Throwable var16) {
                  var10000 = var16;
                  var10001 = false;
                  break label131;
               }
            }

            while(true) {
               Throwable var18 = var10000;

               try {
                  throw var18;
               } catch (Throwable var15) {
                  var10000 = var15;
                  var10001 = false;
                  continue;
               }
            }
         }
      }

      public void a(int param1, String[] param2) {
         // $FF: Couldn't be decompiled
      }

      public void a(c param1, int param2) {
         // $FF: Couldn't be decompiled
      }
   };

   public IBinder onBind(Intent var1) {
      return this.d;
   }
}
