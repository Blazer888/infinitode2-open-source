package androidx.work.impl.foreground;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.Build.VERSION;
import b.f.k;
import b.l.l;
import b.l.w.a;
import b.l.w.p.c;

public class SystemForegroundService extends k implements c.a {
   public static final String f = l.a("SystemFgService");
   public static SystemForegroundService g = null;
   public Handler b;
   public boolean c;
   public c d;
   public NotificationManager e;

   public void a(final int var1) {
      this.b.post(new Runnable() {
         public void run() {
            SystemForegroundService.this.e.cancel(var1);
         }
      });
   }

   public void a(final int var1, final int var2, final Notification var3) {
      this.b.post(new Runnable() {
         public void run() {
            if (VERSION.SDK_INT >= 29) {
               SystemForegroundService.this.startForeground(var1, var3, var2);
            } else {
               SystemForegroundService.this.startForeground(var1, var3);
            }

         }
      });
   }

   public void a(final int var1, final Notification var2) {
      this.b.post(new Runnable() {
         public void run() {
            SystemForegroundService.this.e.notify(var1, var2);
         }
      });
   }

   public final void b() {
      this.b = new Handler(Looper.getMainLooper());
      this.e = (NotificationManager)this.getApplicationContext().getSystemService("notification");
      this.d = new c(this.getApplicationContext());
      c var1 = this.d;
      if (var1.k != null) {
         l.a().b(b.l.w.p.c.l, "A callback already exists.");
      } else {
         var1.k = this;
      }

   }

   public void c() {
      this.b.post(new Runnable() {
         public void run() {
            SystemForegroundService.this.d.a();
         }
      });
   }

   public void onCreate() {
      super.onCreate();
      g = this;
      this.b();
   }

   public void onDestroy() {
      super.onDestroy();
      c var1 = this.d;
      var1.k = null;
      var1.j.a();
      var1.b.f.b((a)var1);
   }

   public int onStartCommand(Intent var1, int var2, int var3) {
      super.onStartCommand(var1, var2, var3);
      if (this.c) {
         l.a().c(f, "Re-initializing SystemForegroundService after a request to shut-down.");
         c var4 = this.d;
         var4.k = null;
         var4.j.a();
         var4.b.f.b((a)var4);
         this.b();
         this.c = false;
      }

      if (var1 != null) {
         this.d.b(var1);
      }

      return 3;
   }

   public void stop() {
      this.c = true;
      l.a().a(f, "All commands completed.");
      if (VERSION.SDK_INT >= 26) {
         this.stopForeground(true);
      }

      g = null;
      this.stopSelf();
   }
}
