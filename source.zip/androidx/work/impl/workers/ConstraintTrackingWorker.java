package androidx.work.impl.workers;

import android.content.Context;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import b.l.l;
import b.l.w.j;
import b.l.w.o.d;
import b.l.w.q.p;
import b.l.w.q.q;
import b.l.w.q.r;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executor;

public class ConstraintTrackingWorker extends ListenableWorker implements b.l.w.o.c {
   public static final String k = l.a("ConstraintTrkngWrkr");
   public WorkerParameters f;
   public final Object g;
   public volatile boolean h;
   public b.l.w.r.m.c i;
   public ListenableWorker j;

   public ConstraintTrackingWorker(Context var1, WorkerParameters var2) {
      super(var1, var2);
      this.f = var2;
      this.g = new Object();
      this.h = false;
      this.i = new b.l.w.r.m.c();
   }

   public WorkDatabase a() {
      return b.l.w.j.a(this.getApplicationContext()).c;
   }

   public void a(List param1) {
      // $FF: Couldn't be decompiled
   }

   public void b() {
      this.i.c(new ListenableWorker.a.a());
   }

   public void b(List var1) {
   }

   public void c() {
      this.i.c(new ListenableWorker.a.b());
   }

   public void d() {
      String var1 = this.getInputData().a("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME");
      if (TextUtils.isEmpty(var1)) {
         l.a().b(k, "No worker to delegate to.");
         this.b();
      } else {
         this.j = this.getWorkerFactory().a(this.getApplicationContext(), var1, this.f);
         if (this.j == null) {
            l.a().a(k, "No worker to delegate to.");
            this.b();
         } else {
            q var2 = this.a().q();
            String var3 = this.getId().toString();
            p var48 = ((r)var2).d(var3);
            if (var48 == null) {
               this.b();
            } else {
               d var50 = new d(this.getApplicationContext(), this.getTaskExecutor(), this);
               var50.a((Iterable)Collections.singletonList(var48));
               if (var50.a(this.getId().toString())) {
                  l.a().a(k, String.format("Constraints met for delegate %s", var1));

                  Throwable var10000;
                  boolean var10001;
                  label527: {
                     final c.c.c.a.a.a var4;
                     Runnable var49;
                     Executor var51;
                     try {
                        var4 = this.j.startWork();
                        var49 = new Runnable() {
                           public void run() {
                              Object var1 = ConstraintTrackingWorker.this.g;
                              synchronized(var1){}

                              Throwable var10000;
                              boolean var10001;
                              label195: {
                                 label189: {
                                    try {
                                       if (ConstraintTrackingWorker.this.h) {
                                          ConstraintTrackingWorker.this.c();
                                          break label189;
                                       }
                                    } catch (Throwable var22) {
                                       var10000 = var22;
                                       var10001 = false;
                                       break label195;
                                    }

                                    try {
                                       ConstraintTrackingWorker.this.i.b(var4);
                                    } catch (Throwable var21) {
                                       var10000 = var21;
                                       var10001 = false;
                                       break label195;
                                    }
                                 }

                                 label180:
                                 try {
                                    return;
                                 } catch (Throwable var20) {
                                    var10000 = var20;
                                    var10001 = false;
                                    break label180;
                                 }
                              }

                              while(true) {
                                 Throwable var2 = var10000;

                                 try {
                                    throw var2;
                                 } catch (Throwable var19) {
                                    var10000 = var19;
                                    var10001 = false;
                                    continue;
                                 }
                              }
                           }
                        };
                        var51 = this.getBackgroundExecutor();
                     } catch (Throwable var46) {
                        var10000 = var46;
                        var10001 = false;
                        break label527;
                     }

                     b.l.w.r.m.a var53 = (b.l.w.r.m.a)var4;

                     label511:
                     try {
                        var53.a(var49, var51);
                        return;
                     } catch (Throwable var45) {
                        var10000 = var45;
                        var10001 = false;
                        break label511;
                     }
                  }

                  Throwable var52 = var10000;
                  l.a().a(k, String.format("Delegated worker %s threw exception in startWork.", var1), var52);
                  Object var54 = this.g;
                  synchronized(var54){}

                  label528: {
                     label504: {
                        try {
                           if (this.h) {
                              l.a().a(k, "Constraints were unmet, Retrying.");
                              this.c();
                              break label504;
                           }
                        } catch (Throwable var44) {
                           var10000 = var44;
                           var10001 = false;
                           break label528;
                        }

                        try {
                           this.b();
                        } catch (Throwable var43) {
                           var10000 = var43;
                           var10001 = false;
                           break label528;
                        }
                     }

                     label495:
                     try {
                        return;
                     } catch (Throwable var42) {
                        var10000 = var42;
                        var10001 = false;
                        break label495;
                     }
                  }

                  while(true) {
                     Throwable var47 = var10000;

                     try {
                        throw var47;
                     } catch (Throwable var41) {
                        var10000 = var41;
                        var10001 = false;
                        continue;
                     }
                  }
               } else {
                  l.a().a(k, String.format("Constraints not met for delegate %s. Requesting retry.", var1));
                  this.c();
               }
            }
         }
      }
   }

   public b.l.w.r.n.a getTaskExecutor() {
      return b.l.w.j.a(this.getApplicationContext()).d;
   }

   public void onStopped() {
      super.onStopped();
      ListenableWorker var1 = this.j;
      if (var1 != null) {
         var1.stop();
      }

   }

   public c.c.c.a.a.a startWork() {
      this.getBackgroundExecutor().execute(new Runnable() {
         public void run() {
            ConstraintTrackingWorker.this.d();
         }
      });
      return this.i;
   }
}
