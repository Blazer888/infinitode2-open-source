package androidx.work.impl.utils;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteAccessPermException;
import android.database.sqlite.SQLiteCantOpenDatabaseException;
import android.database.sqlite.SQLiteDatabaseCorruptException;
import android.os.Build.VERSION;
import android.util.Log;
import androidx.work.impl.WorkDatabase;
import b.l.l;
import b.l.s;
import b.l.w.e;
import b.l.w.i;
import b.l.w.j;
import b.l.w.n.c.b;
import b.l.w.q.f;
import b.l.w.q.n;
import b.l.w.q.o;
import b.l.w.q.p;
import b.l.w.q.q;
import b.l.w.q.r;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ForceStopRunnable implements Runnable {
   public static final String c = l.a("ForceStopRunnable");
   public static final long d;
   public final Context a;
   public final j b;

   static {
      d = TimeUnit.DAYS.toMillis(3650L);
   }

   public ForceStopRunnable(Context var1, j var2) {
      this.a = var1.getApplicationContext();
      this.b = var2;
   }

   public static PendingIntent a(Context var0, int var1) {
      Intent var2 = new Intent();
      var2.setComponent(new ComponentName(var0, ForceStopRunnable.BroadcastReceiver.class));
      var2.setAction("ACTION_FORCE_STOP_RESCHEDULE");
      return PendingIntent.getBroadcast(var0, -1, var2, var1);
   }

   public static void a(Context var0) {
      AlarmManager var1 = (AlarmManager)var0.getSystemService("alarm");
      PendingIntent var4 = a(var0, 134217728);
      long var2 = System.currentTimeMillis() + d;
      if (var1 != null) {
         if (VERSION.SDK_INT >= 19) {
            var1.setExact(0, var2, var4);
         } else {
            var1.set(0, var2, var4);
         }
      }

   }

   public boolean a() {
      if (VERSION.SDK_INT >= 23) {
         b.l.w.n.c.b.b(this.a);
      }

      WorkDatabase var1 = this.b.c;
      q var2 = var1.q();
      n var3 = var1.p();
      var1.c();
      r var27 = (r)var2;

      boolean var5;
      label261: {
         Throwable var10000;
         label267: {
            List var4;
            boolean var10001;
            label259: {
               label258: {
                  try {
                     var4 = var27.b();
                     if (!var4.isEmpty()) {
                        break label258;
                     }
                  } catch (Throwable var26) {
                     var10000 = var26;
                     var10001 = false;
                     break label267;
                  }

                  var5 = false;
                  break label259;
               }

               var5 = true;
            }

            if (var5) {
               Iterator var6;
               try {
                  var6 = var4.iterator();
               } catch (Throwable var24) {
                  var10000 = var24;
                  var10001 = false;
                  break label267;
               }

               while(true) {
                  try {
                     if (!var6.hasNext()) {
                        break;
                     }

                     p var30 = (p)var6.next();
                     var27.a(s.a, var30.a);
                     var27.a(var30.a, -1L);
                  } catch (Throwable var25) {
                     var10000 = var25;
                     var10001 = false;
                     break label267;
                  }
               }
            }

            o var28 = (o)var3;

            label240:
            try {
               var28.a();
               var1.k();
               break label261;
            } catch (Throwable var23) {
               var10000 = var23;
               var10001 = false;
               break label240;
            }
         }

         Throwable var29 = var10000;
         var1.e();
         throw var29;
      }

      var1.e();
      return var5;
   }

   public boolean b() {
      Long var1 = ((f)this.b.g.a.m()).a("reschedule_needed");
      boolean var2;
      if (var1 != null && var1 == 1L) {
         var2 = true;
      } else {
         var2 = false;
      }

      return var2;
   }

   public void run() {
      i.a(this.a);
      l.a().a(c, "Performing cleanup operations.");

      Object var2;
      label87: {
         SQLiteCantOpenDatabaseException var20;
         label86: {
            SQLiteDatabaseCorruptException var19;
            label85: {
               SQLiteAccessPermException var10000;
               label92: {
                  boolean var10001;
                  label91: {
                     boolean var1;
                     try {
                        var1 = this.a();
                        if (this.b()) {
                           l.a().a(c, "Rescheduling Workers.");
                           this.b.b();
                           this.b.g.a(false);
                           break label91;
                        }
                     } catch (SQLiteCantOpenDatabaseException var16) {
                        var20 = var16;
                        var10001 = false;
                        break label86;
                     } catch (SQLiteDatabaseCorruptException var17) {
                        var19 = var17;
                        var10001 = false;
                        break label85;
                     } catch (SQLiteAccessPermException var18) {
                        var10000 = var18;
                        var10001 = false;
                        break label92;
                     }

                     boolean var3;
                     label75: {
                        label74: {
                           try {
                              if (a(this.a, 536870912) == null) {
                                 a(this.a);
                                 break label74;
                              }
                           } catch (SQLiteCantOpenDatabaseException var13) {
                              var20 = var13;
                              var10001 = false;
                              break label86;
                           } catch (SQLiteDatabaseCorruptException var14) {
                              var19 = var14;
                              var10001 = false;
                              break label85;
                           } catch (SQLiteAccessPermException var15) {
                              var10000 = var15;
                              var10001 = false;
                              break label92;
                           }

                           var3 = false;
                           break label75;
                        }

                        var3 = true;
                     }

                     if (var3) {
                        try {
                           l.a().a(c, "Application was force-stopped, rescheduling.");
                           this.b.b();
                        } catch (SQLiteCantOpenDatabaseException var10) {
                           var20 = var10;
                           var10001 = false;
                           break label86;
                        } catch (SQLiteDatabaseCorruptException var11) {
                           var19 = var11;
                           var10001 = false;
                           break label85;
                        } catch (SQLiteAccessPermException var12) {
                           var10000 = var12;
                           var10001 = false;
                           break label92;
                        }
                     } else if (var1) {
                        try {
                           l.a().a(c, "Found unfinished work, scheduling it.");
                           e.a(this.b.b, this.b.c, this.b.e);
                        } catch (SQLiteCantOpenDatabaseException var7) {
                           var20 = var7;
                           var10001 = false;
                           break label86;
                        } catch (SQLiteDatabaseCorruptException var8) {
                           var19 = var8;
                           var10001 = false;
                           break label85;
                        } catch (SQLiteAccessPermException var9) {
                           var10000 = var9;
                           var10001 = false;
                           break label92;
                        }
                     }
                  }

                  try {
                     this.b.a();
                     return;
                  } catch (SQLiteCantOpenDatabaseException var4) {
                     var20 = var4;
                     var10001 = false;
                     break label86;
                  } catch (SQLiteDatabaseCorruptException var5) {
                     var19 = var5;
                     var10001 = false;
                     break label85;
                  } catch (SQLiteAccessPermException var6) {
                     var10000 = var6;
                     var10001 = false;
                  }
               }

               var2 = var10000;
               break label87;
            }

            var2 = var19;
            break label87;
         }

         var2 = var20;
      }

      l.a().b(c, "The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", (Throwable)var2);
      throw new IllegalStateException("The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", (Throwable)var2);
   }

   public static class BroadcastReceiver extends android.content.BroadcastReceiver {
      public static final String a = l.a("ForceStopRunnable$Rcvr");

      public void onReceive(Context var1, Intent var2) {
         if (var2 != null && "ACTION_FORCE_STOP_RESCHEDULE".equals(var2.getAction())) {
            l var3 = l.a();
            String var4 = a;
            Throwable[] var5 = new Throwable[0];
            if (((l.a)var3).b <= 2) {
               if (var5.length >= 1) {
                  Log.v(var4, "Rescheduling alarm that keeps track of force-stops.", var5[0]);
               } else {
                  Log.v(var4, "Rescheduling alarm that keeps track of force-stops.");
               }
            }

            ForceStopRunnable.a(var1);
         }

      }
   }
}
