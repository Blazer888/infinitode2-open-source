package androidx.work.impl;

import android.content.Context;
import android.text.TextUtils;
import b.i.g;
import b.i.k;
import b.l.w.h;
import b.l.w.i;
import b.l.w.q.e;
import b.l.w.q.n;
import b.l.w.q.q;
import b.l.w.q.t;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

public abstract class WorkDatabase extends g {
   public static final long j;

   static {
      j = TimeUnit.DAYS.toMillis(7L);
   }

   public static WorkDatabase a(final Context var0, Executor var1, boolean var2) {
      g.a var3;
      if (var2) {
         var3 = new g.a(var0, WorkDatabase.class, (String)null);
         var3.h = true;
      } else {
         b.l.w.i.a();
         if ("androidx.work.workdb".trim().length() == 0) {
            IllegalArgumentException var27 = new IllegalArgumentException("Cannot build a database with null or empty name. If you are trying to create an in memory database, use Room.inMemoryDatabaseBuilder");
            throw var27;
         }

         var3 = new g.a(var0, WorkDatabase.class, "androidx.work.workdb");
         var3.g = new b.j.a.c.c() {
            public b.j.a.c a(b.j.a.c.b var1) {
               Context var2 = var0;
               String var3 = var1.b;
               b.j.a.c.a var4 = var1.c;
               if (var4 != null) {
                  if (var2 != null) {
                     if (!TextUtils.isEmpty(var3)) {
                        var1 = new b.j.a.c.b(var2, var3, var4, true);
                        return new b.j.a.g.c(var1.a, var1.b, var1.c, var1.d);
                     } else {
                        throw new IllegalArgumentException("Must set a non-null database name to a configuration that uses the no backup directory.");
                     }
                  } else {
                     throw new IllegalArgumentException("Must set a non-null context to create the configuration.");
                  }
               } else {
                  throw new IllegalArgumentException("Must set a callback to create the configuration.");
               }
            }
         };
      }

      var3.e = var1;
      b.l.w.g var16 = new b.l.w.g();
      if (var3.d == null) {
         var3.d = new ArrayList();
      }

      var3.d.add(var16);
      var3.a(b.l.w.h.a);
      var3.a(new h.g(var0, 2, 3));
      var3.a(b.l.w.h.b);
      var3.a(b.l.w.h.c);
      var3.a(new h.g(var0, 5, 6));
      var3.a(b.l.w.h.d);
      var3.a(b.l.w.h.e);
      var3.a(b.l.w.h.f);
      var3.a(new h.h(var0));
      var3.k = false;
      var3.l = true;
      if (var3.c != null) {
         if (var3.a == null) {
            throw new IllegalArgumentException("Must provide an abstract class that extends RoomDatabase");
         } else {
            Executor var15;
            if (var3.e == null && var3.f == null) {
               var15 = b.a.a.a.a.d;
               var3.f = var15;
               var3.e = var15;
            } else {
               var15 = var3.e;
               if (var15 != null && var3.f == null) {
                  var3.f = var15;
               } else if (var3.e == null) {
                  var15 = var3.f;
                  if (var15 != null) {
                     var3.e = var15;
                  }
               }
            }

            Set var17 = var3.o;
            StringBuilder var20;
            if (var17 != null && var3.n != null) {
               Iterator var18 = var17.iterator();

               while(var18.hasNext()) {
                  Integer var19 = (Integer)var18.next();
                  if (var3.n.contains(var19)) {
                     var20 = new StringBuilder();
                     var20.append("Inconsistency detected. A Migration was supplied to addMigration(Migration... migrations) that has a start or end version equal to a start version supplied to fallbackToDestructiveMigrationFrom(int... startVersions). Start version: ");
                     var20.append(var19);
                     throw new IllegalArgumentException(var20.toString());
                  }
               }
            }

            if (var3.g == null) {
               var3.g = new b.j.a.g.d();
            }

            if (var3.p != null || var3.q != null) {
               if (var3.b == null) {
                  throw new IllegalArgumentException("Cannot create from asset or file for an in-memory database.");
               }

               if (var3.p != null && var3.q != null) {
                  throw new IllegalArgumentException("Both createFromAsset() and createFromFile() was called on this Builder but the database can only be created using one of the two configurations.");
               }

               var3.g = new k(var3.p, var3.q, var3.g);
            }

            var0 = var3.c;
            b.i.a var4 = new b.i.a(var0, var3.b, var3.g, var3.m, var3.d, var3.h, var3.i.a(var0), var3.e, var3.f, var3.j, var3.k, var3.l, var3.n, var3.p, var3.q);
            Class var24 = var3.a;
            String var5 = var24.getPackage().getName();
            String var21 = var24.getCanonicalName();
            if (!var5.isEmpty()) {
               var21 = var21.substring(var5.length() + 1);
            }

            var20 = new StringBuilder();
            var20.append(var21.replace('.', '_'));
            var20.append("_Impl");
            String var22 = var20.toString();

            Object var25;
            label106: {
               StringBuilder var23;
               label105: {
                  label104: {
                     label103: {
                        boolean var10001;
                        label102: {
                           label101: {
                              try {
                                 if (!var5.isEmpty()) {
                                    break label101;
                                 }
                              } catch (ClassNotFoundException var12) {
                                 var10001 = false;
                                 break label105;
                              } catch (IllegalAccessException var13) {
                                 var10001 = false;
                                 break label104;
                              } catch (InstantiationException var14) {
                                 var10001 = false;
                                 break label103;
                              }

                              var21 = var22;
                              break label102;
                           }

                           try {
                              var23 = new StringBuilder();
                              var23.append(var5);
                              var23.append(".");
                              var23.append(var22);
                              var21 = var23.toString();
                           } catch (ClassNotFoundException var9) {
                              var10001 = false;
                              break label105;
                           } catch (IllegalAccessException var10) {
                              var10001 = false;
                              break label104;
                           } catch (InstantiationException var11) {
                              var10001 = false;
                              break label103;
                           }
                        }

                        try {
                           var25 = Class.forName(var21).newInstance();
                           break label106;
                        } catch (ClassNotFoundException var6) {
                           var10001 = false;
                           break label105;
                        } catch (IllegalAccessException var7) {
                           var10001 = false;
                           break label104;
                        } catch (InstantiationException var8) {
                           var10001 = false;
                        }
                     }

                     var23 = c.a.b.a.a.b("Failed to create an instance of ");
                     var23.append(var24.getCanonicalName());
                     throw new RuntimeException(var23.toString());
                  }

                  var23 = c.a.b.a.a.b("Cannot access the constructor");
                  var23.append(var24.getCanonicalName());
                  throw new RuntimeException(var23.toString());
               }

               var23 = c.a.b.a.a.b("cannot find implementation for ");
               var23.append(var24.getCanonicalName());
               var23.append(". ");
               var23.append(var22);
               var23.append(" does not exist");
               throw new RuntimeException(var23.toString());
            }

            g var26 = (g)var25;
            var26.b(var4);
            return (WorkDatabase)var26;
         }
      } else {
         throw new IllegalArgumentException("Cannot provide null context for the database.");
      }
   }

   public static String s() {
      StringBuilder var0 = c.a.b.a.a.b("DELETE FROM workspec WHERE state IN (2, 3, 5) AND (period_start_time + minimum_retention_duration) < ");
      var0.append(System.currentTimeMillis() - j);
      var0.append(" AND (SELECT COUNT(*)=0 FROM dependency WHERE     prerequisite_id=id AND     work_spec_id NOT IN         (SELECT id FROM workspec WHERE state IN (2, 3, 5)))");
      return var0.toString();
   }

   public abstract b.l.w.q.b l();

   public abstract e m();

   public abstract b.l.w.q.h n();

   public abstract b.l.w.q.k o();

   public abstract n p();

   public abstract q q();

   public abstract t r();
}
