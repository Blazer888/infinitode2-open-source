package androidx.work.impl.background.systemjob;

import android.app.Application;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Build.VERSION;
import android.text.TextUtils;
import androidx.work.WorkerParameters;
import b.l.l;
import b.l.w.a;
import b.l.w.j;
import b.l.w.r.g;
import b.l.w.r.n.b;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class SystemJobService extends JobService implements a {
   public static final String c = l.a("SystemJobService");
   public j a;
   public final Map b = new HashMap();

   public static String a(JobParameters param0) {
      // $FF: Couldn't be decompiled
   }

   public void a(String param1, boolean param2) {
      // $FF: Couldn't be decompiled
   }

   public void onCreate() {
      super.onCreate();

      try {
         this.a = j.a(this.getApplicationContext());
         this.a.f.a((a)this);
      } catch (IllegalStateException var2) {
         if (!Application.class.equals(this.getApplication().getClass())) {
            throw new IllegalStateException("WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().");
         }

         l.a().d(c, "Could not find WorkManager instance; this may be because an auto-backup is in progress. Ignoring JobScheduler commands for now. Please make sure that you are initializing WorkManager if you have manually disabled WorkManagerInitializer.");
      }

   }

   public void onDestroy() {
      super.onDestroy();
      j var1 = this.a;
      if (var1 != null) {
         var1.f.b((a)this);
      }

   }

   public boolean onStartJob(JobParameters var1) {
      if (this.a == null) {
         l.a().a(c, "WorkManager is not initialized; requesting retry.");
         this.jobFinished(var1, true);
         return false;
      } else {
         String var2 = a(var1);
         if (TextUtils.isEmpty(var2)) {
            l.a().b(c, "WorkSpec id not found!");
            return false;
         } else {
            Map var3 = this.b;
            synchronized(var3){}

            Throwable var10000;
            boolean var10001;
            label228: {
               try {
                  if (this.b.containsKey(var2)) {
                     l.a().a(c, String.format("Job is already being executed by SystemJobService: %s", var2));
                     return false;
                  }
               } catch (Throwable var16) {
                  var10000 = var16;
                  var10001 = false;
                  break label228;
               }

               try {
                  l.a().a(c, String.format("onStartJob for %s", var2));
                  this.b.put(var2, var1);
               } catch (Throwable var15) {
                  var10000 = var15;
                  var10001 = false;
                  break label228;
               }

               WorkerParameters.a var19 = null;
               if (VERSION.SDK_INT >= 24) {
                  WorkerParameters.a var4 = new WorkerParameters.a();
                  if (var1.getTriggeredContentUris() != null) {
                     var4.b = Arrays.asList(var1.getTriggeredContentUris());
                  }

                  if (var1.getTriggeredContentAuthorities() != null) {
                     var4.a = Arrays.asList(var1.getTriggeredContentAuthorities());
                  }

                  var19 = var4;
                  if (VERSION.SDK_INT >= 28) {
                     var4.c = var1.getNetwork();
                     var19 = var4;
                  }
               }

               j var20 = this.a;
               b.l.w.r.n.a var18 = var20.d;
               g var21 = new g(var20, var2, var19);
               ((b)var18).a.execute(var21);
               return true;
            }

            while(true) {
               Throwable var17 = var10000;

               try {
                  throw var17;
               } catch (Throwable var14) {
                  var10000 = var14;
                  var10001 = false;
                  continue;
               }
            }
         }
      }
   }

   public boolean onStopJob(JobParameters param1) {
      // $FF: Couldn't be decompiled
   }
}
