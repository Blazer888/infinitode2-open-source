package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION;
import b.l.l;
import b.l.w.j;
import b.l.w.n.b.b;

public class RescheduleReceiver extends BroadcastReceiver {
   public static final String a = l.a("RescheduleReceiver");

   public void onReceive(Context var1, Intent var2) {
      l.a().a(a, String.format("Received intent %s", var2));
      if (VERSION.SDK_INT >= 23) {
         try {
            j.a(var1).a(this.goAsync());
         } catch (IllegalStateException var3) {
            l.a().b(a, "Cannot reschedule jobs. WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().");
         }
      } else {
         var1.startService(b.b(var1));
      }

   }
}
