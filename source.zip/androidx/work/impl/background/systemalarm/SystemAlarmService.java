package androidx.work.impl.background.systemalarm;

import android.content.Intent;
import b.f.k;
import b.l.l;
import b.l.w.n.b.e;
import b.l.w.r.i;

public class SystemAlarmService extends k implements e.c {
   public static final String d = l.a("SystemAlarmService");
   public e b;
   public boolean c;

   public void a() {
      this.c = true;
      l.a().a(d, "All commands completed in dispatcher");
      i.a();
      this.stopSelf();
   }

   public final void b() {
      this.b = new e(this);
      e var1 = this.b;
      if (var1.j != null) {
         l.a().b(e.k, "A completion listener for SystemAlarmDispatcher already exists.");
      } else {
         var1.j = this;
      }

   }

   public void onCreate() {
      super.onCreate();
      this.b();
      this.c = false;
   }

   public void onDestroy() {
      super.onDestroy();
      this.c = true;
      this.b.c();
   }

   public int onStartCommand(Intent var1, int var2, int var3) {
      super.onStartCommand(var1, var2, var3);
      if (this.c) {
         l.a().c(d, "Re-initializing SystemAlarmDispatcher after a request to shut-down.");
         this.b.c();
         this.b();
         this.c = false;
      }

      if (var1 != null) {
         this.b.a(var1, var3);
      }

      return 3;
   }
}
