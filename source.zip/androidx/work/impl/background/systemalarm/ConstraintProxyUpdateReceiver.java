package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.BroadcastReceiver.PendingResult;
import b.l.l;
import b.l.w.j;
import b.l.w.r.d;
import b.l.w.r.n.a;
import b.l.w.r.n.b;

public class ConstraintProxyUpdateReceiver extends BroadcastReceiver {
   public static final String a = l.a("ConstrntProxyUpdtRecvr");

   public static Intent a(Context var0, boolean var1, boolean var2, boolean var3, boolean var4) {
      Intent var5 = new Intent("androidx.work.impl.background.systemalarm.UpdateProxies");
      var5.setComponent(new ComponentName(var0, ConstraintProxyUpdateReceiver.class));
      var5.putExtra("KEY_BATTERY_NOT_LOW_PROXY_ENABLED", var1).putExtra("KEY_BATTERY_CHARGING_PROXY_ENABLED", var2).putExtra("KEY_STORAGE_NOT_LOW_PROXY_ENABLED", var3).putExtra("KEY_NETWORK_STATE_PROXY_ENABLED", var4);
      return var5;
   }

   public void onReceive(final Context var1, final Intent var2) {
      String var3;
      if (var2 != null) {
         var3 = var2.getAction();
      } else {
         var3 = null;
      }

      if (!"androidx.work.impl.background.systemalarm.UpdateProxies".equals(var3)) {
         l.a().a(a, String.format("Ignoring unknown action %s", var3));
      } else {
         final PendingResult var4 = this.goAsync();
         a var6 = j.a(var1).d;
         Runnable var5 = new Runnable(this) {
            public void run() {
               try {
                  boolean var1x = var2.getBooleanExtra("KEY_BATTERY_NOT_LOW_PROXY_ENABLED", false);
                  boolean var2x = var2.getBooleanExtra("KEY_BATTERY_CHARGING_PROXY_ENABLED", false);
                  boolean var3 = var2.getBooleanExtra("KEY_STORAGE_NOT_LOW_PROXY_ENABLED", false);
                  boolean var4x = var2.getBooleanExtra("KEY_NETWORK_STATE_PROXY_ENABLED", false);
                  l.a().a(ConstraintProxyUpdateReceiver.a, String.format("Updating proxies: BatteryNotLowProxy enabled (%s), BatteryChargingProxy enabled (%s), StorageNotLowProxy (%s), NetworkStateProxy enabled (%s)", var1x, var2x, var3, var4x));
                  d.a(var1, ConstraintProxy.BatteryNotLowProxy.class, var1x);
                  d.a(var1, ConstraintProxy.BatteryChargingProxy.class, var2x);
                  d.a(var1, ConstraintProxy.StorageNotLowProxy.class, var3);
                  d.a(var1, ConstraintProxy.NetworkStateProxy.class, var4x);
               } finally {
                  var4.finish();
               }

            }
         };
         ((b)var6).a.execute(var5);
      }

   }
}
