package androidx.work.impl;

import android.content.Context;
import android.database.Cursor;
import b.i.g;
import b.l.w.q.e;
import b.l.w.q.f;
import b.l.w.q.h;
import b.l.w.q.i;
import b.l.w.q.k;
import b.l.w.q.l;
import b.l.w.q.n;
import b.l.w.q.o;
import b.l.w.q.q;
import b.l.w.q.r;
import b.l.w.q.t;
import b.l.w.q.u;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public final class WorkDatabase_Impl extends WorkDatabase {
   public volatile q k;
   public volatile b.l.w.q.b l;
   public volatile t m;
   public volatile h n;
   public volatile k o;
   public volatile n p;
   public volatile e q;

   // $FF: synthetic method
   public static b.j.a.b a(WorkDatabase_Impl var0, b.j.a.b var1) {
      var0.a = var1;
      return var1;
   }

   // $FF: synthetic method
   public static List a(WorkDatabase_Impl var0) {
      return var0.g;
   }

   // $FF: synthetic method
   public static List b(WorkDatabase_Impl var0) {
      return var0.g;
   }

   public b.j.a.c a(b.i.a var1) {
      b.i.h var2 = new b.i.h(var1, new b.i.h.a(10) {
         public void a(b.j.a.b var1) {
            ((b.j.a.g.a)var1).a.execSQL("CREATE TABLE IF NOT EXISTS `Dependency` (`work_spec_id` TEXT NOT NULL, `prerequisite_id` TEXT NOT NULL, PRIMARY KEY(`work_spec_id`, `prerequisite_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE , FOREIGN KEY(`prerequisite_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            b.j.a.g.a var2 = (b.j.a.g.a)var1;
            var2.a.execSQL("CREATE INDEX IF NOT EXISTS `index_Dependency_work_spec_id` ON `Dependency` (`work_spec_id`)");
            var2.a.execSQL("CREATE INDEX IF NOT EXISTS `index_Dependency_prerequisite_id` ON `Dependency` (`prerequisite_id`)");
            var2.a.execSQL("CREATE TABLE IF NOT EXISTS `WorkSpec` (`id` TEXT NOT NULL, `state` INTEGER NOT NULL, `worker_class_name` TEXT NOT NULL, `input_merger_class_name` TEXT, `input` BLOB NOT NULL, `output` BLOB NOT NULL, `initial_delay` INTEGER NOT NULL, `interval_duration` INTEGER NOT NULL, `flex_duration` INTEGER NOT NULL, `run_attempt_count` INTEGER NOT NULL, `backoff_policy` INTEGER NOT NULL, `backoff_delay_duration` INTEGER NOT NULL, `period_start_time` INTEGER NOT NULL, `minimum_retention_duration` INTEGER NOT NULL, `schedule_requested_at` INTEGER NOT NULL, `run_in_foreground` INTEGER NOT NULL, `required_network_type` INTEGER, `requires_charging` INTEGER NOT NULL, `requires_device_idle` INTEGER NOT NULL, `requires_battery_not_low` INTEGER NOT NULL, `requires_storage_not_low` INTEGER NOT NULL, `trigger_content_update_delay` INTEGER NOT NULL, `trigger_max_content_delay` INTEGER NOT NULL, `content_uri_triggers` BLOB, PRIMARY KEY(`id`))");
            var2.a.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkSpec_schedule_requested_at` ON `WorkSpec` (`schedule_requested_at`)");
            var2.a.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `WorkSpec` (`period_start_time`)");
            var2.a.execSQL("CREATE TABLE IF NOT EXISTS `WorkTag` (`tag` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`tag`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            var2.a.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkTag_work_spec_id` ON `WorkTag` (`work_spec_id`)");
            var2.a.execSQL("CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            var2.a.execSQL("CREATE TABLE IF NOT EXISTS `WorkName` (`name` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`name`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            var2.a.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkName_work_spec_id` ON `WorkName` (`work_spec_id`)");
            var2.a.execSQL("CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            var2.a.execSQL("CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))");
            var2.a.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
            var2.a.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'cf029002fffdcadf079e8d0a1c9a70ac')");
         }

         public void b(b.j.a.b var1) {
            ((b.j.a.g.a)var1).a.execSQL("DROP TABLE IF EXISTS `Dependency`");
            b.j.a.g.a var4 = (b.j.a.g.a)var1;
            var4.a.execSQL("DROP TABLE IF EXISTS `WorkSpec`");
            var4.a.execSQL("DROP TABLE IF EXISTS `WorkTag`");
            var4.a.execSQL("DROP TABLE IF EXISTS `SystemIdInfo`");
            var4.a.execSQL("DROP TABLE IF EXISTS `WorkName`");
            var4.a.execSQL("DROP TABLE IF EXISTS `WorkProgress`");
            var4.a.execSQL("DROP TABLE IF EXISTS `Preference`");
            if (WorkDatabase_Impl.a(WorkDatabase_Impl.this) != null) {
               int var2 = 0;

               for(int var3 = WorkDatabase_Impl.super.g.size(); var2 < var3; ++var2) {
                  ((g.b)WorkDatabase_Impl.super.g.get(var2)).b();
               }
            }

         }

         public void c(b.j.a.b var1) {
         }

         public void d(b.j.a.b var1) {
            ArrayList var2 = new ArrayList();
            b.j.a.g.a var7 = (b.j.a.g.a)var1;
            Cursor var3 = var7.a("SELECT name FROM sqlite_master WHERE type = 'trigger'");

            while(true) {
               boolean var5 = false;

               try {
                  var5 = true;
                  if (!var3.moveToNext()) {
                     var5 = false;
                     break;
                  }

                  var2.add(var3.getString(0));
                  var5 = false;
               } finally {
                  if (var5) {
                     var3.close();
                  }
               }
            }

            var3.close();
            Iterator var8 = var2.iterator();

            while(var8.hasNext()) {
               String var9 = (String)var8.next();
               if (var9.startsWith("room_fts_content_sync_")) {
                  var9 = c.a.b.a.a.a("DROP TRIGGER IF EXISTS ", var9);
                  var7.a.execSQL(var9);
               }
            }

         }

         public b.i.h.b e(b.j.a.b var1) {
            HashMap var2 = new HashMap(2);
            var2.put("work_spec_id", new b.i.o.c.a("work_spec_id", "TEXT", true, 1, (String)null, 1));
            var2.put("prerequisite_id", new b.i.o.c.a("prerequisite_id", "TEXT", true, 2, (String)null, 1));
            HashSet var3 = new HashSet(2);
            var3.add(new b.i.o.c.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
            var3.add(new b.i.o.c.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("prerequisite_id"), Arrays.asList("id")));
            HashSet var4 = new HashSet(2);
            var4.add(new b.i.o.c.d("index_Dependency_work_spec_id", false, Arrays.asList("work_spec_id")));
            var4.add(new b.i.o.c.d("index_Dependency_prerequisite_id", false, Arrays.asList("prerequisite_id")));
            b.i.o.c var6 = new b.i.o.c("Dependency", var2, var3, var4);
            b.i.o.c var9 = b.i.o.c.a(var1, "Dependency");
            StringBuilder var5;
            if (!var6.equals(var9)) {
               var5 = new StringBuilder();
               var5.append("Dependency(androidx.work.impl.model.Dependency).\n Expected:\n");
               var5.append(var6);
               var5.append("\n Found:\n");
               var5.append(var9);
               return new b.i.h.b(false, var5.toString());
            } else {
               HashMap var8 = new HashMap(24);
               var8.put("id", new b.i.o.c.a("id", "TEXT", true, 1, (String)null, 1));
               var8.put("state", new b.i.o.c.a("state", "INTEGER", true, 0, (String)null, 1));
               var8.put("worker_class_name", new b.i.o.c.a("worker_class_name", "TEXT", true, 0, (String)null, 1));
               var8.put("input_merger_class_name", new b.i.o.c.a("input_merger_class_name", "TEXT", false, 0, (String)null, 1));
               var8.put("input", new b.i.o.c.a("input", "BLOB", true, 0, (String)null, 1));
               var8.put("output", new b.i.o.c.a("output", "BLOB", true, 0, (String)null, 1));
               var8.put("initial_delay", new b.i.o.c.a("initial_delay", "INTEGER", true, 0, (String)null, 1));
               var8.put("interval_duration", new b.i.o.c.a("interval_duration", "INTEGER", true, 0, (String)null, 1));
               var8.put("flex_duration", new b.i.o.c.a("flex_duration", "INTEGER", true, 0, (String)null, 1));
               var8.put("run_attempt_count", new b.i.o.c.a("run_attempt_count", "INTEGER", true, 0, (String)null, 1));
               var8.put("backoff_policy", new b.i.o.c.a("backoff_policy", "INTEGER", true, 0, (String)null, 1));
               var8.put("backoff_delay_duration", new b.i.o.c.a("backoff_delay_duration", "INTEGER", true, 0, (String)null, 1));
               var8.put("period_start_time", new b.i.o.c.a("period_start_time", "INTEGER", true, 0, (String)null, 1));
               var8.put("minimum_retention_duration", new b.i.o.c.a("minimum_retention_duration", "INTEGER", true, 0, (String)null, 1));
               var8.put("schedule_requested_at", new b.i.o.c.a("schedule_requested_at", "INTEGER", true, 0, (String)null, 1));
               var8.put("run_in_foreground", new b.i.o.c.a("run_in_foreground", "INTEGER", true, 0, (String)null, 1));
               var8.put("required_network_type", new b.i.o.c.a("required_network_type", "INTEGER", false, 0, (String)null, 1));
               var8.put("requires_charging", new b.i.o.c.a("requires_charging", "INTEGER", true, 0, (String)null, 1));
               var8.put("requires_device_idle", new b.i.o.c.a("requires_device_idle", "INTEGER", true, 0, (String)null, 1));
               var8.put("requires_battery_not_low", new b.i.o.c.a("requires_battery_not_low", "INTEGER", true, 0, (String)null, 1));
               var8.put("requires_storage_not_low", new b.i.o.c.a("requires_storage_not_low", "INTEGER", true, 0, (String)null, 1));
               var8.put("trigger_content_update_delay", new b.i.o.c.a("trigger_content_update_delay", "INTEGER", true, 0, (String)null, 1));
               var8.put("trigger_max_content_delay", new b.i.o.c.a("trigger_max_content_delay", "INTEGER", true, 0, (String)null, 1));
               var8.put("content_uri_triggers", new b.i.o.c.a("content_uri_triggers", "BLOB", false, 0, (String)null, 1));
               var4 = new HashSet(0);
               HashSet var7 = new HashSet(2);
               var7.add(new b.i.o.c.d("index_WorkSpec_schedule_requested_at", false, Arrays.asList("schedule_requested_at")));
               var7.add(new b.i.o.c.d("index_WorkSpec_period_start_time", false, Arrays.asList("period_start_time")));
               var9 = new b.i.o.c("WorkSpec", var8, var4, var7);
               var6 = b.i.o.c.a(var1, "WorkSpec");
               if (!var9.equals(var6)) {
                  var5 = new StringBuilder();
                  var5.append("WorkSpec(androidx.work.impl.model.WorkSpec).\n Expected:\n");
                  var5.append(var9);
                  var5.append("\n Found:\n");
                  var5.append(var6);
                  return new b.i.h.b(false, var5.toString());
               } else {
                  HashMap var10 = new HashMap(2);
                  var10.put("tag", new b.i.o.c.a("tag", "TEXT", true, 1, (String)null, 1));
                  var10.put("work_spec_id", new b.i.o.c.a("work_spec_id", "TEXT", true, 2, (String)null, 1));
                  var7 = new HashSet(1);
                  var7.add(new b.i.o.c.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
                  var3 = new HashSet(1);
                  var3.add(new b.i.o.c.d("index_WorkTag_work_spec_id", false, Arrays.asList("work_spec_id")));
                  var6 = new b.i.o.c("WorkTag", var10, var7, var3);
                  var9 = b.i.o.c.a(var1, "WorkTag");
                  if (!var6.equals(var9)) {
                     var5 = new StringBuilder();
                     var5.append("WorkTag(androidx.work.impl.model.WorkTag).\n Expected:\n");
                     var5.append(var6);
                     var5.append("\n Found:\n");
                     var5.append(var9);
                     return new b.i.h.b(false, var5.toString());
                  } else {
                     var10 = new HashMap(2);
                     var10.put("work_spec_id", new b.i.o.c.a("work_spec_id", "TEXT", true, 1, (String)null, 1));
                     var10.put("system_id", new b.i.o.c.a("system_id", "INTEGER", true, 0, (String)null, 1));
                     var7 = new HashSet(1);
                     var7.add(new b.i.o.c.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
                     var9 = new b.i.o.c("SystemIdInfo", var10, var7, new HashSet(0));
                     var6 = b.i.o.c.a(var1, "SystemIdInfo");
                     if (!var9.equals(var6)) {
                        var5 = new StringBuilder();
                        var5.append("SystemIdInfo(androidx.work.impl.model.SystemIdInfo).\n Expected:\n");
                        var5.append(var9);
                        var5.append("\n Found:\n");
                        var5.append(var6);
                        return new b.i.h.b(false, var5.toString());
                     } else {
                        var10 = new HashMap(2);
                        var10.put("name", new b.i.o.c.a("name", "TEXT", true, 1, (String)null, 1));
                        var10.put("work_spec_id", new b.i.o.c.a("work_spec_id", "TEXT", true, 2, (String)null, 1));
                        var7 = new HashSet(1);
                        var7.add(new b.i.o.c.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
                        var3 = new HashSet(1);
                        var3.add(new b.i.o.c.d("index_WorkName_work_spec_id", false, Arrays.asList("work_spec_id")));
                        var9 = new b.i.o.c("WorkName", var10, var7, var3);
                        var6 = b.i.o.c.a(var1, "WorkName");
                        if (!var9.equals(var6)) {
                           var5 = new StringBuilder();
                           var5.append("WorkName(androidx.work.impl.model.WorkName).\n Expected:\n");
                           var5.append(var9);
                           var5.append("\n Found:\n");
                           var5.append(var6);
                           return new b.i.h.b(false, var5.toString());
                        } else {
                           var2 = new HashMap(2);
                           var2.put("work_spec_id", new b.i.o.c.a("work_spec_id", "TEXT", true, 1, (String)null, 1));
                           var2.put("progress", new b.i.o.c.a("progress", "BLOB", true, 0, (String)null, 1));
                           var4 = new HashSet(1);
                           var4.add(new b.i.o.c.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList("work_spec_id"), Arrays.asList("id")));
                           var6 = new b.i.o.c("WorkProgress", var2, var4, new HashSet(0));
                           var9 = b.i.o.c.a(var1, "WorkProgress");
                           if (!var6.equals(var9)) {
                              var5 = new StringBuilder();
                              var5.append("WorkProgress(androidx.work.impl.model.WorkProgress).\n Expected:\n");
                              var5.append(var6);
                              var5.append("\n Found:\n");
                              var5.append(var9);
                              return new b.i.h.b(false, var5.toString());
                           } else {
                              var2 = new HashMap(2);
                              var2.put("key", new b.i.o.c.a("key", "TEXT", true, 1, (String)null, 1));
                              var2.put("long_value", new b.i.o.c.a("long_value", "INTEGER", false, 0, (String)null, 1));
                              var6 = new b.i.o.c("Preference", var2, new HashSet(0), new HashSet(0));
                              var9 = b.i.o.c.a(var1, "Preference");
                              if (!var6.equals(var9)) {
                                 var5 = new StringBuilder();
                                 var5.append("Preference(androidx.work.impl.model.Preference).\n Expected:\n");
                                 var5.append(var6);
                                 var5.append("\n Found:\n");
                                 var5.append(var9);
                                 return new b.i.h.b(false, var5.toString());
                              } else {
                                 return new b.i.h.b(true, (String)null);
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }, "cf029002fffdcadf079e8d0a1c9a70ac", "8aff2efc47fafe870c738f727dfcfc6e");
      Context var3 = var1.b;
      String var4 = var1.c;
      if (var3 != null) {
         b.j.a.c.b var5 = new b.j.a.c.b(var3, var4, var2, false);
         return var1.a.a(var5);
      } else {
         throw new IllegalArgumentException("Must set a non-null context to create the configuration.");
      }
   }

   public b.i.e d() {
      return new b.i.e(this, new HashMap(0), new HashMap(0), new String[]{"Dependency", "WorkSpec", "WorkTag", "SystemIdInfo", "WorkName", "WorkProgress", "Preference"});
   }

   public b.l.w.q.b l() {
      if (this.l != null) {
         return this.l;
      } else {
         synchronized(this){}

         Throwable var10000;
         boolean var10001;
         label136: {
            try {
               if (this.l == null) {
                  b.l.w.q.c var1 = new b.l.w.q.c(this);
                  this.l = var1;
               }
            } catch (Throwable var13) {
               var10000 = var13;
               var10001 = false;
               break label136;
            }

            label133:
            try {
               b.l.w.q.b var15 = this.l;
               return var15;
            } catch (Throwable var12) {
               var10000 = var12;
               var10001 = false;
               break label133;
            }
         }

         while(true) {
            Throwable var14 = var10000;

            try {
               throw var14;
            } catch (Throwable var11) {
               var10000 = var11;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public e m() {
      if (this.q != null) {
         return this.q;
      } else {
         synchronized(this){}

         Throwable var10000;
         boolean var10001;
         label136: {
            try {
               if (this.q == null) {
                  f var1 = new f(this);
                  this.q = var1;
               }
            } catch (Throwable var13) {
               var10000 = var13;
               var10001 = false;
               break label136;
            }

            label133:
            try {
               e var15 = this.q;
               return var15;
            } catch (Throwable var12) {
               var10000 = var12;
               var10001 = false;
               break label133;
            }
         }

         while(true) {
            Throwable var14 = var10000;

            try {
               throw var14;
            } catch (Throwable var11) {
               var10000 = var11;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public h n() {
      if (this.n != null) {
         return this.n;
      } else {
         synchronized(this){}

         Throwable var10000;
         boolean var10001;
         label136: {
            try {
               if (this.n == null) {
                  i var1 = new i(this);
                  this.n = var1;
               }
            } catch (Throwable var13) {
               var10000 = var13;
               var10001 = false;
               break label136;
            }

            label133:
            try {
               h var15 = this.n;
               return var15;
            } catch (Throwable var12) {
               var10000 = var12;
               var10001 = false;
               break label133;
            }
         }

         while(true) {
            Throwable var14 = var10000;

            try {
               throw var14;
            } catch (Throwable var11) {
               var10000 = var11;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public k o() {
      if (this.o != null) {
         return this.o;
      } else {
         synchronized(this){}

         Throwable var10000;
         boolean var10001;
         label136: {
            try {
               if (this.o == null) {
                  l var1 = new l(this);
                  this.o = var1;
               }
            } catch (Throwable var13) {
               var10000 = var13;
               var10001 = false;
               break label136;
            }

            label133:
            try {
               k var15 = this.o;
               return var15;
            } catch (Throwable var12) {
               var10000 = var12;
               var10001 = false;
               break label133;
            }
         }

         while(true) {
            Throwable var14 = var10000;

            try {
               throw var14;
            } catch (Throwable var11) {
               var10000 = var11;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public n p() {
      if (this.p != null) {
         return this.p;
      } else {
         synchronized(this){}

         Throwable var10000;
         boolean var10001;
         label136: {
            try {
               if (this.p == null) {
                  o var1 = new o(this);
                  this.p = var1;
               }
            } catch (Throwable var13) {
               var10000 = var13;
               var10001 = false;
               break label136;
            }

            label133:
            try {
               n var15 = this.p;
               return var15;
            } catch (Throwable var12) {
               var10000 = var12;
               var10001 = false;
               break label133;
            }
         }

         while(true) {
            Throwable var14 = var10000;

            try {
               throw var14;
            } catch (Throwable var11) {
               var10000 = var11;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public q q() {
      if (this.k != null) {
         return this.k;
      } else {
         synchronized(this){}

         Throwable var10000;
         boolean var10001;
         label136: {
            try {
               if (this.k == null) {
                  r var1 = new r(this);
                  this.k = var1;
               }
            } catch (Throwable var13) {
               var10000 = var13;
               var10001 = false;
               break label136;
            }

            label133:
            try {
               q var15 = this.k;
               return var15;
            } catch (Throwable var12) {
               var10000 = var12;
               var10001 = false;
               break label133;
            }
         }

         while(true) {
            Throwable var14 = var10000;

            try {
               throw var14;
            } catch (Throwable var11) {
               var10000 = var11;
               var10001 = false;
               continue;
            }
         }
      }
   }

   public t r() {
      if (this.m != null) {
         return this.m;
      } else {
         synchronized(this){}

         Throwable var10000;
         boolean var10001;
         label136: {
            try {
               if (this.m == null) {
                  u var1 = new u(this);
                  this.m = var1;
               }
            } catch (Throwable var13) {
               var10000 = var13;
               var10001 = false;
               break label136;
            }

            label133:
            try {
               t var15 = this.m;
               return var15;
            } catch (Throwable var12) {
               var10000 = var12;
               var10001 = false;
               break label133;
            }
         }

         while(true) {
            Throwable var14 = var10000;

            try {
               throw var14;
            } catch (Throwable var11) {
               var10000 = var11;
               var10001 = false;
               continue;
            }
         }
      }
   }
}
