package androidx.work;

import android.net.Network;
import b.l.e;
import b.l.h;
import b.l.p;
import b.l.v;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;

public final class WorkerParameters {
   public UUID a;
   public e b;
   public Set c;
   public WorkerParameters.a d;
   public int e;
   public Executor f;
   public b.l.w.r.n.a g;
   public v h;
   public p i;
   public h j;

   public WorkerParameters(UUID var1, e var2, Collection var3, WorkerParameters.a var4, int var5, Executor var6, b.l.w.r.n.a var7, v var8, p var9, h var10) {
      this.a = var1;
      this.b = var2;
      this.c = new HashSet(var3);
      this.d = var4;
      this.e = var5;
      this.f = var6;
      this.g = var7;
      this.h = var8;
      this.i = var9;
      this.j = var10;
   }

   public Executor a() {
      return this.f;
   }

   public h b() {
      return this.j;
   }

   public UUID c() {
      return this.a;
   }

   public e d() {
      return this.b;
   }

   public Network e() {
      return this.d.c;
   }

   public p f() {
      return this.i;
   }

   public int g() {
      return this.e;
   }

   public Set h() {
      return this.c;
   }

   public b.l.w.r.n.a i() {
      return this.g;
   }

   public List j() {
      return this.d.a;
   }

   public List k() {
      return this.d.b;
   }

   public v l() {
      return this.h;
   }

   public static class a {
      public List a = Collections.emptyList();
      public List b = Collections.emptyList();
      public Network c;
   }
}
