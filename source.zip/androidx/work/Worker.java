package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Keep;

public abstract class Worker extends ListenableWorker {
   public b.l.w.r.m.c f;

   @SuppressLint({"BanKeepAnnotation"})
   @Keep
   public Worker(Context var1, WorkerParameters var2) {
      super(var1, var2);
   }

   public abstract ListenableWorker.a doWork();

   public final c.c.c.a.a.a startWork() {
      this.f = new b.l.w.r.m.c();
      this.getBackgroundExecutor().execute(new Runnable() {
         public void run() {
            try {
               ListenableWorker.a var1 = Worker.this.doWork();
               Worker.this.f.c(var1);
            } catch (Throwable var3) {
               Worker.this.f.a(var3);
               return;
            }

         }
      });
      return this.f;
   }
}
