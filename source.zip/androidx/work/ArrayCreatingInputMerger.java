package androidx.work;

import b.l.e;
import b.l.i;
import java.lang.reflect.Array;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

public final class ArrayCreatingInputMerger extends i {
   public e a(List var1) {
      e.a var2 = new e.a();
      HashMap var3 = new HashMap();
      Iterator var4 = var1.iterator();

      String var6;
      Object var13;
      while(var4.hasNext()) {
         for(Iterator var5 = Collections.unmodifiableMap(((e)var4.next()).a).entrySet().iterator(); var5.hasNext(); var3.put(var6, var13)) {
            Entry var12 = (Entry)var5.next();
            var6 = (String)var12.getKey();
            var13 = var12.getValue();
            Class var7 = var13.getClass();
            Object var8 = var3.get(var6);
            Object var14;
            if (var8 == null) {
               if (!var7.isArray()) {
                  var14 = Array.newInstance(var13.getClass(), 1);
                  Array.set(var14, 0, var13);
                  var13 = var14;
               }
            } else {
               Class var9 = var8.getClass();
               if (var9.equals(var7)) {
                  if (var9.isArray()) {
                     int var10 = Array.getLength(var8);
                     int var11 = Array.getLength(var13);
                     var14 = Array.newInstance(var8.getClass().getComponentType(), var10 + var11);
                     System.arraycopy(var8, 0, var14, 0, var10);
                     System.arraycopy(var13, 0, var14, var10, var11);
                     var13 = var14;
                  } else {
                     var14 = Array.newInstance(var8.getClass(), 2);
                     Array.set(var14, 0, var8);
                     Array.set(var14, 1, var13);
                     var13 = var14;
                  }
               } else if (var9.isArray() && var9.getComponentType().equals(var7)) {
                  var13 = this.a(var8, var13);
               } else {
                  if (!var7.isArray() || !var7.getComponentType().equals(var9)) {
                     throw new IllegalArgumentException();
                  }

                  var13 = this.a(var13, var8);
               }
            }
         }
      }

      var2.a(var3);
      return var2.a();
   }

   public final Object a(Object var1, Object var2) {
      int var3 = Array.getLength(var1);
      Object var4 = Array.newInstance(var2.getClass(), var3 + 1);
      System.arraycopy(var1, 0, var4, 0, var3);
      Array.set(var4, var3, var2);
      return var4;
   }
}
