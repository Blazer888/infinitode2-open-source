package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Network;
import androidx.annotation.Keep;
import b.l.e;
import b.l.g;
import b.l.h;
import b.l.p;
import b.l.v;
import b.l.w.r.j;
import b.l.w.r.k;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;

public abstract class ListenableWorker {
   public Context a;
   public WorkerParameters b;
   public volatile boolean c;
   public boolean d;
   public boolean e;

   @SuppressLint({"BanKeepAnnotation"})
   @Keep
   public ListenableWorker(Context var1, WorkerParameters var2) {
      if (var1 != null) {
         if (var2 != null) {
            this.a = var1;
            this.b = var2;
         } else {
            throw new IllegalArgumentException("WorkerParameters is null");
         }
      } else {
         throw new IllegalArgumentException("Application Context is null");
      }
   }

   public final Context getApplicationContext() {
      return this.a;
   }

   public Executor getBackgroundExecutor() {
      return this.b.a();
   }

   public final UUID getId() {
      return this.b.c();
   }

   public final e getInputData() {
      return this.b.d();
   }

   public final Network getNetwork() {
      return this.b.e();
   }

   public final int getRunAttemptCount() {
      return this.b.g();
   }

   public final Set getTags() {
      return this.b.h();
   }

   public b.l.w.r.n.a getTaskExecutor() {
      return this.b.i();
   }

   public final List getTriggeredContentAuthorities() {
      return this.b.j();
   }

   public final List getTriggeredContentUris() {
      return this.b.k();
   }

   public v getWorkerFactory() {
      return this.b.l();
   }

   public final boolean isRunInForeground() {
      return this.e;
   }

   public final boolean isStopped() {
      return this.c;
   }

   public final boolean isUsed() {
      return this.d;
   }

   public void onStopped() {
   }

   public final c.c.c.a.a.a setForegroundAsync(g var1) {
      this.e = true;
      h var2 = this.b.b();
      Context var3 = this.getApplicationContext();
      UUID var4 = this.getId();
      return ((j)var2).a(var3, var4, var1);
   }

   public final c.c.c.a.a.a setProgressAsync(e var1) {
      p var2 = this.b.f();
      Context var3 = this.getApplicationContext();
      UUID var4 = this.getId();
      return ((k)var2).a(var3, var4, var1);
   }

   public final void setUsed() {
      this.d = true;
   }

   public abstract c.c.c.a.a.a startWork();

   public final void stop() {
      this.c = true;
      this.onStopped();
   }

   public abstract static class a {
      public static final class a extends ListenableWorker.a {
         public final e a;

         public a() {
            e var1 = b.l.e.c;
            super();
            this.a = var1;
         }

         public boolean equals(Object var1) {
            if (this == var1) {
               return true;
            } else if (var1 != null && ListenableWorker.a.a.class == var1.getClass()) {
               ListenableWorker.a.a var2 = (ListenableWorker.a.a)var1;
               return this.a.equals(var2.a);
            } else {
               return false;
            }
         }

         public int hashCode() {
            int var1 = ListenableWorker.a.a.class.getName().hashCode();
            return this.a.hashCode() + var1 * 31;
         }

         public String toString() {
            StringBuilder var1 = c.a.b.a.a.b("Failure {mOutputData=");
            var1.append(this.a);
            var1.append('}');
            return var1.toString();
         }
      }

      public static final class b extends ListenableWorker.a {
         public boolean equals(Object var1) {
            boolean var2 = true;
            if (this == var1) {
               return true;
            } else {
               if (var1 == null || ListenableWorker.a.b.class != var1.getClass()) {
                  var2 = false;
               }

               return var2;
            }
         }

         public int hashCode() {
            return ListenableWorker.a.b.class.getName().hashCode();
         }

         public String toString() {
            return "Retry";
         }
      }

      public static final class c extends ListenableWorker.a {
         public final e a;

         public c() {
            e var1 = b.l.e.c;
            super();
            this.a = var1;
         }

         public c(e var1) {
            this.a = var1;
         }

         public boolean equals(Object var1) {
            if (this == var1) {
               return true;
            } else if (var1 != null && ListenableWorker.a.c.class == var1.getClass()) {
               ListenableWorker.a.c var2 = (ListenableWorker.a.c)var1;
               return this.a.equals(var2.a);
            } else {
               return false;
            }
         }

         public int hashCode() {
            int var1 = ListenableWorker.a.c.class.getName().hashCode();
            return this.a.hashCode() + var1 * 31;
         }

         public String toString() {
            StringBuilder var1 = c.a.b.a.a.b("Success {mOutputData=");
            var1.append(this.a);
            var1.append('}');
            return var1.toString();
         }
      }
   }
}
