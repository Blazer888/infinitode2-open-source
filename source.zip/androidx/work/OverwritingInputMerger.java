package androidx.work;

import b.l.e;
import b.l.i;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public final class OverwritingInputMerger extends i {
   public e a(List var1) {
      e.a var2 = new e.a();
      HashMap var3 = new HashMap();
      Iterator var4 = var1.iterator();

      while(var4.hasNext()) {
         var3.putAll(Collections.unmodifiableMap(((e)var4.next()).a));
      }

      var2.a(var3);
      return var2.a();
   }
}
