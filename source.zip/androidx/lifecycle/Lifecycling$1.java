package androidx.lifecycle;

import b.f.d;
import b.f.e;
import b.f.f;
import b.f.h;

public final class Lifecycling$1 implements d {
   // $FF: synthetic field
   public final f a;

   public void a(h var1, e.a var2) {
      this.a.a(var1, var2);
   }
}
