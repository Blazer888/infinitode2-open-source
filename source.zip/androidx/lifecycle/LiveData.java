package androidx.lifecycle;

import b.a.a.a.a;
import b.f.e;
import b.f.f;
import b.f.g;
import b.f.h;
import b.f.i;
import b.f.o;
import com.google.android.gms.auth.api.signin.internal.SignInHubActivity;
import java.util.Map.Entry;

public abstract class LiveData {
   public static final Object j = new Object();
   public final Object a = new Object();
   public b.a.a.b.b b = new b.a.a.b.b();
   public int c = 0;
   public volatile Object d;
   public volatile Object e;
   public int f;
   public boolean g;
   public boolean h;
   public final Runnable i;

   public LiveData() {
      this.e = j;
      this.i = new Runnable() {
         public void run() {
            // $FF: Couldn't be decompiled
         }
      };
      this.d = j;
      this.f = -1;
   }

   public static void a(String var0) {
      if (!b.a.a.a.a.b().a()) {
         throw new IllegalStateException(c.a.b.a.a.a("Cannot invoke ", var0, " on a background thread"));
      }
   }

   public void a() {
   }

   public final void a(LiveData.b var1) {
      if (var1.b) {
         if (!var1.b()) {
            var1.a(false);
         } else {
            int var2 = var1.c;
            int var3 = this.f;
            if (var2 < var3) {
               var1.c = var3;
               b.g.a.b.b var6 = (b.g.a.b.b)var1.a;
               SignInHubActivity.a var4 = (SignInHubActivity.a)var6.b;
               SignInHubActivity var5 = var4.a;
               var5.setResult(var5.p, var5.q);
               var4.a.finish();
               var6.c = true;
            }
         }
      }
   }

   public void a(h var1, o var2) {
      a("observe");
      if (((i)var1.getLifecycle()).b != e.b.a) {
         LiveData.LifecycleBoundObserver var3 = new LiveData.LifecycleBoundObserver(var1, var2);
         LiveData.b var8 = (LiveData.b)this.b.b(var2, var3);
         if (var8 != null && !var8.a(var1)) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
         } else if (var8 == null) {
            i var9 = (i)var1.getLifecycle();
            e.b var4 = var9.b;
            e.b var7 = e.b.a;
            if (var4 != var7) {
               var7 = e.b.b;
            }

            i.a var5 = new i.a(var3, var7);
            if ((i.a)var9.a.b(var3, var5) == null) {
               h var10 = (h)var9.c.get();
               if (var10 != null) {
                  boolean var6;
                  if (var9.d == 0 && !var9.e) {
                     var6 = false;
                  } else {
                     var6 = true;
                  }

                  var7 = var9.a((g)var3);
                  ++var9.d;

                  while(var5.a.compareTo(var7) < 0 && var9.a.e.containsKey(var3)) {
                     var7 = var5.a;
                     var9.g.add(var7);
                     var5.a(var10, b.f.i.b(var5.a));
                     var9.a();
                     var7 = var9.a((g)var3);
                  }

                  if (!var6) {
                     var9.b();
                  }

                  --var9.d;
               }
            }

         }
      }
   }

   public void a(o var1) {
      a("removeObserver");
      LiveData.b var2 = (LiveData.b)this.b.remove(var1);
      if (var2 != null) {
         var2.a();
         var2.a(false);
      }
   }

   public void a(Object var1) {
      Object var2 = this.a;
      synchronized(var2){}

      boolean var3;
      label164: {
         Throwable var10000;
         boolean var10001;
         label159: {
            label158: {
               label157: {
                  try {
                     if (this.e == j) {
                        break label157;
                     }
                  } catch (Throwable var15) {
                     var10000 = var15;
                     var10001 = false;
                     break label159;
                  }

                  var3 = false;
                  break label158;
               }

               var3 = true;
            }

            label151:
            try {
               this.e = var1;
               break label164;
            } catch (Throwable var14) {
               var10000 = var14;
               var10001 = false;
               break label151;
            }
         }

         while(true) {
            Throwable var16 = var10000;

            try {
               throw var16;
            } catch (Throwable var13) {
               var10000 = var13;
               var10001 = false;
               continue;
            }
         }
      }

      if (var3) {
         a var18 = b.a.a.a.a.b();
         Runnable var17 = this.i;
         var18.a.b(var17);
      }
   }

   public void b() {
   }

   public void b(LiveData.b var1) {
      if (this.g) {
         this.h = true;
      } else {
         this.g = true;
         LiveData.b var2 = var1;

         do {
            this.h = false;
            if (var2 != null) {
               this.a(var2);
               var1 = null;
            } else {
               b.a.a.b.b.d var3 = this.b.a();

               while(true) {
                  var1 = var2;
                  if (!var3.hasNext()) {
                     break;
                  }

                  this.a((LiveData.b)((Entry)var3.next()).getValue());
                  if (this.h) {
                     var1 = var2;
                     break;
                  }
               }
            }

            var2 = var1;
         } while(this.h);

         this.g = false;
      }
   }

   public void b(Object var1) {
      a("setValue");
      ++this.f;
      this.d = var1;
      this.b((LiveData.b)null);
   }

   public class LifecycleBoundObserver extends LiveData.b implements f {
      public final h e;

      public LifecycleBoundObserver(h var2, o var3) {
         super(var3);
         this.e = var2;
      }

      public void a() {
         ((i)this.e.getLifecycle()).a.remove(this);
      }

      public void a(h var1, e.a var2) {
         if (((i)this.e.getLifecycle()).b == e.b.a) {
            LiveData.this.a(super.a);
         } else {
            this.a(this.b());
         }
      }

      public boolean a(h var1) {
         boolean var2;
         if (this.e == var1) {
            var2 = true;
         } else {
            var2 = false;
         }

         return var2;
      }

      public boolean b() {
         boolean var1;
         if (((i)this.e.getLifecycle()).b.compareTo(e.b.d) >= 0) {
            var1 = true;
         } else {
            var1 = false;
         }

         return var1;
      }
   }

   public abstract class b {
      public final o a;
      public boolean b;
      public int c = -1;

      public b(o var2) {
         this.a = var2;
      }

      public void a() {
      }

      public void a(boolean var1) {
         if (var1 != this.b) {
            this.b = var1;
            int var2 = LiveData.this.c;
            byte var3 = 1;
            boolean var6;
            if (var2 == 0) {
               var6 = true;
            } else {
               var6 = false;
            }

            LiveData var4 = LiveData.this;
            int var5 = var4.c;
            if (!this.b) {
               var3 = -1;
            }

            var4.c = var5 + var3;
            if (var6 && this.b) {
               LiveData.this.a();
            }

            var4 = LiveData.this;
            if (var4.c == 0 && !this.b) {
               var4.b();
            }

            if (this.b) {
               LiveData.this.b(this);
            }

         }
      }

      public boolean a(h var1) {
         return false;
      }

      public abstract boolean b();
   }
}
