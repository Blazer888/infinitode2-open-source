package androidx.lifecycle;

import b.f.c;
import b.f.e;
import b.f.f;
import b.f.h;
import b.f.m;

public class SingleGeneratedAdapterObserver implements f {
   public final c a;

   public SingleGeneratedAdapterObserver(c var1) {
      this.a = var1;
   }

   public void a(h var1, e.a var2) {
      this.a.a(var1, var2, false, (m)null);
      this.a.a(var1, var2, true, (m)null);
   }
}
