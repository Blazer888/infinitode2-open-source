package androidx.lifecycle;

import b.f.c;
import b.f.e;
import b.f.f;
import b.f.h;
import b.f.m;

public class CompositeGeneratedAdaptersObserver implements f {
   public final c[] a;

   public CompositeGeneratedAdaptersObserver(c[] var1) {
      this.a = var1;
   }

   public void a(h var1, e.a var2) {
      m var3 = new m();
      c[] var4 = this.a;
      int var5 = var4.length;
      byte var6 = 0;

      int var7;
      for(var7 = 0; var7 < var5; ++var7) {
         var4[var7].a(var1, var2, false, var3);
      }

      var4 = this.a;
      var5 = var4.length;

      for(var7 = var6; var7 < var5; ++var7) {
         var4[var7].a(var1, var2, true, var3);
      }

   }
}
