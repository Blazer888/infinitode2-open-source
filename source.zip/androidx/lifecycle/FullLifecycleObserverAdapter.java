package androidx.lifecycle;

import b.f.b;
import b.f.e;
import b.f.f;
import b.f.h;

public class FullLifecycleObserverAdapter implements f {
   public final b a;
   public final f b;

   public FullLifecycleObserverAdapter(b var1, f var2) {
      this.a = var1;
      this.b = var2;
   }

   public void a(h var1, e.a var2) {
      switch(var2.ordinal()) {
      case 0:
         this.a.c(var1);
         break;
      case 1:
         this.a.e(var1);
         break;
      case 2:
         this.a.a(var1);
         break;
      case 3:
         this.a.d(var1);
         break;
      case 4:
         this.a.f(var1);
         break;
      case 5:
         this.a.b(var1);
         break;
      case 6:
         throw new IllegalArgumentException("ON_ANY must not been send by anybody");
      }

      f var3 = this.b;
      if (var3 != null) {
         var3.a(var1, var2);
      }

   }
}
