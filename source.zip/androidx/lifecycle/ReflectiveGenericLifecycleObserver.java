package androidx.lifecycle;

import b.f.a;
import b.f.e;
import b.f.f;
import b.f.h;
import java.util.List;

public class ReflectiveGenericLifecycleObserver implements f {
   public final Object a;
   public final a.a b;

   public ReflectiveGenericLifecycleObserver(Object var1) {
      this.a = var1;
      this.b = b.f.a.c.b(this.a.getClass());
   }

   public void a(h var1, e.a var2) {
      a.a var3 = this.b;
      Object var4 = this.a;
      a.a.a((List)var3.a.get(var2), var1, var2, var4);
      a.a.a((List)var3.a.get(e.a.ON_ANY), var1, var2, var4);
   }
}
