package androidx.versionedparcelable;

import b.k.c;

public abstract class CustomVersionedParcelable implements c {
}
