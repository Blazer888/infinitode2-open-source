package androidx.versionedparcelable;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import b.k.b;
import b.k.c;

@SuppressLint({"BanParcelableUsage"})
public class ParcelImpl implements Parcelable {
   public static final Creator CREATOR = new Creator() {
      public Object createFromParcel(Parcel var1) {
         return new ParcelImpl(var1);
      }

      public Object[] newArray(int var1) {
         return new ParcelImpl[var1];
      }
   };
   public final c a;

   public ParcelImpl(Parcel var1) {
      this.a = (new b(var1)).d();
   }

   public int describeContents() {
      return 0;
   }

   public void writeToParcel(Parcel var1, int var2) {
      (new b(var1)).a(this.a);
   }
}
