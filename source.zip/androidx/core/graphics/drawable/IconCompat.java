package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Icon;
import android.os.Parcelable;
import android.os.Build.VERSION;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;

public class IconCompat extends CustomVersionedParcelable {
   public static final Mode j;
   public int a = -1;
   public Object b;
   public byte[] c = null;
   public Parcelable d = null;
   public int e = 0;
   public int f = 0;
   public ColorStateList g = null;
   public Mode h;
   public String i;

   static {
      j = Mode.SRC_IN;
   }

   public IconCompat() {
      this.h = j;
      this.i = null;
   }

   public int a() {
      if (this.a == -1) {
         int var1 = VERSION.SDK_INT;
         if (var1 >= 23) {
            Icon var7 = (Icon)this.b;
            if (var1 >= 28) {
               var1 = var7.getResId();
            } else {
               var1 = 0;

               int var3;
               try {
                  var3 = (Integer)var7.getClass().getMethod("getResId").invoke(var7);
               } catch (IllegalAccessException var4) {
                  Log.e("IconCompat", "Unable to get icon resource", var4);
                  return var1;
               } catch (InvocationTargetException var5) {
                  Log.e("IconCompat", "Unable to get icon resource", var5);
                  return var1;
               } catch (NoSuchMethodException var6) {
                  Log.e("IconCompat", "Unable to get icon resource", var6);
                  return var1;
               }

               var1 = var3;
            }

            return var1;
         }
      }

      if (this.a == 2) {
         return this.e;
      } else {
         StringBuilder var2 = new StringBuilder();
         var2.append("called getResId() on ");
         var2.append(this);
         throw new IllegalStateException(var2.toString());
      }
   }

   public void a(boolean var1) {
      this.i = this.h.name();
      int var2 = this.a;
      if (var2 != -1) {
         if (var2 != 1) {
            if (var2 == 2) {
               this.c = ((String)this.b).getBytes(Charset.forName("UTF-16"));
               return;
            }

            if (var2 == 3) {
               this.c = (byte[])this.b;
               return;
            }

            if (var2 == 4) {
               this.c = this.b.toString().getBytes(Charset.forName("UTF-16"));
               return;
            }

            if (var2 != 5) {
               return;
            }
         }

         if (var1) {
            Bitmap var3 = (Bitmap)this.b;
            ByteArrayOutputStream var4 = new ByteArrayOutputStream();
            var3.compress(CompressFormat.PNG, 90, var4);
            this.c = var4.toByteArray();
         } else {
            this.d = (Parcelable)this.b;
         }
      } else {
         if (var1) {
            throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
         }

         this.d = (Parcelable)this.b;
      }

   }

   public String b() {
      if (this.a == -1) {
         int var1 = VERSION.SDK_INT;
         if (var1 >= 23) {
            Icon var2 = (Icon)this.b;
            String var8;
            if (var1 >= 28) {
               var8 = var2.getResPackage();
            } else {
               var8 = null;

               String var7;
               try {
                  var7 = (String)var2.getClass().getMethod("getResPackage").invoke(var2);
               } catch (IllegalAccessException var4) {
                  Log.e("IconCompat", "Unable to get icon package", var4);
                  return var8;
               } catch (InvocationTargetException var5) {
                  Log.e("IconCompat", "Unable to get icon package", var5);
                  return var8;
               } catch (NoSuchMethodException var6) {
                  Log.e("IconCompat", "Unable to get icon package", var6);
                  return var8;
               }

               var8 = var7;
            }

            return var8;
         }
      }

      if (this.a == 2) {
         return ((String)this.b).split(":", -1)[0];
      } else {
         StringBuilder var3 = new StringBuilder();
         var3.append("called getResPackage() on ");
         var3.append(this);
         throw new IllegalStateException(var3.toString());
      }
   }

   public void c() {
      this.h = Mode.valueOf(this.i);
      int var1 = this.a;
      Parcelable var2;
      if (var1 != -1) {
         if (var1 != 1) {
            label47: {
               if (var1 != 2) {
                  if (var1 == 3) {
                     this.b = this.c;
                     return;
                  }

                  if (var1 != 4) {
                     if (var1 != 5) {
                        return;
                     }
                     break label47;
                  }
               }

               this.b = new String(this.c, Charset.forName("UTF-16"));
               return;
            }
         }

         var2 = this.d;
         if (var2 != null) {
            this.b = var2;
         } else {
            byte[] var3 = this.c;
            this.b = var3;
            this.a = 3;
            this.e = 0;
            this.f = var3.length;
         }
      } else {
         var2 = this.d;
         if (var2 == null) {
            throw new IllegalArgumentException("Invalid icon");
         }

         this.b = var2;
      }

   }

   public String toString() {
      if (this.a == -1) {
         return String.valueOf(this.b);
      } else {
         StringBuilder var1 = new StringBuilder("Icon(typ=");
         int var2 = this.a;
         String var3;
         if (var2 != 1) {
            if (var2 != 2) {
               if (var2 != 3) {
                  if (var2 != 4) {
                     if (var2 != 5) {
                        var3 = "UNKNOWN";
                     } else {
                        var3 = "BITMAP_MASKABLE";
                     }
                  } else {
                     var3 = "URI";
                  }
               } else {
                  var3 = "DATA";
               }
            } else {
               var3 = "RESOURCE";
            }
         } else {
            var3 = "BITMAP";
         }

         label52: {
            var1.append(var3);
            var2 = this.a;
            if (var2 != 1) {
               if (var2 == 2) {
                  var1.append(" pkg=");
                  var1.append(this.b());
                  var1.append(" id=");
                  var1.append(String.format("0x%08x", this.a()));
                  break label52;
               }

               if (var2 == 3) {
                  var1.append(" len=");
                  var1.append(this.e);
                  if (this.f != 0) {
                     var1.append(" off=");
                     var1.append(this.f);
                  }
                  break label52;
               }

               if (var2 == 4) {
                  var1.append(" uri=");
                  var1.append(this.b);
                  break label52;
               }

               if (var2 != 5) {
                  break label52;
               }
            }

            var1.append(" size=");
            var1.append(((Bitmap)this.b).getWidth());
            var1.append("x");
            var1.append(((Bitmap)this.b).getHeight());
         }

         if (this.g != null) {
            var1.append(" tint=");
            var1.append(this.g);
         }

         if (this.h != j) {
            var1.append(" mode=");
            var1.append(this.h);
         }

         var1.append(")");
         return var1.toString();
      }
   }
}
