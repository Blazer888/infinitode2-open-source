package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;
import b.k.a;
import b.k.b;

public class IconCompatParcelizer {
   public static IconCompat read(a var0) {
      IconCompat var1 = new IconCompat();
      var1.a = var0.a(var1.a, 1);
      byte[] var2 = var1.c;
      if (var0.a(2)) {
         b var3 = (b)var0;
         int var4 = var3.e.readInt();
         if (var4 < 0) {
            var2 = null;
         } else {
            var2 = new byte[var4];
            var3.e.readByteArray(var2);
         }
      }

      var1.c = var2;
      var1.d = var0.a((Parcelable)var1.d, 3);
      var1.e = var0.a(var1.e, 4);
      var1.f = var0.a(var1.f, 5);
      var1.g = (ColorStateList)var0.a((Parcelable)var1.g, 6);
      String var6 = var1.i;
      String var5;
      if (!var0.a(7)) {
         var5 = var6;
      } else {
         var5 = var0.c();
      }

      var1.i = var5;
      var1.c();
      return var1;
   }

   public static void write(IconCompat var0, a var1) {
      var1.e();
      var0.a(false);
      int var2 = var0.a;
      if (-1 != var2) {
         var1.b(var2, 1);
      }

      byte[] var3 = var0.c;
      if (var3 != null) {
         var1.b(2);
         b var4 = (b)var1;
         var4.e.writeInt(var3.length);
         var4.e.writeByteArray(var3);
      }

      Parcelable var6 = var0.d;
      if (var6 != null) {
         var1.b(3);
         ((b)var1).e.writeParcelable(var6, 0);
      }

      var2 = var0.e;
      if (var2 != 0) {
         var1.b(var2, 4);
      }

      var2 = var0.f;
      if (var2 != 0) {
         var1.b(var2, 5);
      }

      ColorStateList var7 = var0.g;
      if (var7 != null) {
         var1.b(6);
         ((b)var1).e.writeParcelable(var7, 0);
      }

      String var5 = var0.i;
      if (var5 != null) {
         var1.b(7);
         ((b)var1).e.writeString(var5);
      }

   }
}
