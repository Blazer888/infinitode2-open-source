package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import b.k.a;
import b.k.b;
import b.k.c;

public class RemoteActionCompatParcelizer {
   public static RemoteActionCompat read(a var0) {
      RemoteActionCompat var1 = new RemoteActionCompat();
      Object var2 = var1.a;
      if (var0.a(1)) {
         var2 = var0.d();
      }

      var1.a = (IconCompat)var2;
      var1.b = var0.a((CharSequence)var1.b, 2);
      var1.c = var0.a((CharSequence)var1.c, 3);
      var1.d = (PendingIntent)var0.a((Parcelable)var1.d, 4);
      var1.e = var0.a(var1.e, 5);
      var1.f = var0.a(var1.f, 6);
      return var1;
   }

   public static void write(RemoteActionCompat var0, a var1) {
      var1.e();
      IconCompat var2 = var0.a;
      var1.b(1);
      var1.a((c)var2);
      CharSequence var3 = var0.b;
      var1.b(2);
      b var5 = (b)var1;
      TextUtils.writeToParcel(var3, var5.e, 0);
      var3 = var0.c;
      var1.b(3);
      TextUtils.writeToParcel(var3, var5.e, 0);
      var1.b(var0.d, 4);
      byte var4 = var0.e;
      var1.b(5);
      var5.e.writeInt(var4);
      var4 = var0.f;
      var1.b(6);
      var5.e.writeInt(var4);
   }
}
