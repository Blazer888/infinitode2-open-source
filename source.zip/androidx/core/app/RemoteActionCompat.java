package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import b.k.c;

public final class RemoteActionCompat implements c {
   public IconCompat a;
   public CharSequence b;
   public CharSequence c;
   public PendingIntent d;
   public boolean e;
   public boolean f;
}
