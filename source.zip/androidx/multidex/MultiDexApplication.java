package androidx.multidex;

import android.app.Application;
import android.content.Context;
import b.h.a;

public class MultiDexApplication extends Application {
   public void attachBaseContext(Context var1) {
      super.attachBaseContext(var1);
      a.b(this);
   }
}
